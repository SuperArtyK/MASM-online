# Milestone 57L report - `.CODE` Memory Access Diagnostics

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57L - .CODE Memory Access Diagnostics
```

Repository/archive milestone after this work:

```text
Phase 57L - .CODE Memory Access Diagnostics
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 57L - .CODE Memory Access Diagnostics
```

Status interpretation:

Phase 57L is a runtime/source-run behavior milestone. Unlike Phase 57K, it changes source-visible execution behavior: simulated programs can no longer read or write memory whose final byte range overlaps the simulator `.code` region. Therefore both the repository/archive milestone and runtime/source-run MASM behavior phase advance to Phase 57L.

Scope implemented:

- Implemented mandatory source-level/runtime `.code` memory-access denial.
- Denied memory reads whose final byte range overlaps `.code`.
- Denied memory writes whose final byte range overlaps `.code`.
- Added `.code` protected-region cross-boundary diagnostics using `region-boundary-crossing`.
- Preserved existing `.CONST` protected-region behavior and `.CONST` write protection.
- Added structured source-run diagnostics and exact rendered Simulator Messages tests.
- Updated status surfaces, supported-syntax documentation, troubleshooting/status docs, protocol tests, and static checks for Phase 57L.
- Updated user-facing diagnostic copy after manual user feedback to use `.CODE/_TEXT` wording while keeping `_TEXT` non-addressable and Phase 57M segment/group diagnostics deferred.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status and verification files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `Milestone 57K report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_57K.zip
```

Repository archive recommended after implementation:

```text
Latest_repository_state_milestone_57L.zip
```

No full latest repository archive was produced during this milestone-report step. Changed-files packages were produced and are listed in Section 19.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, memory safety, and status-surface hygiene.
- The incremental implementation guide owns phase numbering, target milestone scope, per-phase implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- The audit/handoff report is a navigation and stale-assumption-prevention aid, not a replacement for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only. They do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

## 3. Exact requirements implemented

### 3.1 Mandatory `.code` memory-access denial

Phase 57L implements the Phase 57K policy that `.code` is not user-addressable simulated program memory.

Implemented behavior:

- A source-level memory read whose final byte range is wholly contained in `.code` fails with `unsupported-code-memory-access`.
- A source-level memory write whose final byte range is wholly contained in `.code` fails with `unsupported-code-memory-access`.
- The diagnostic is mandatory and not controlled by optional teaching-policy settings.
- The diagnostic is surfaced through Simulator Messages, not Program Console.
- The failing access stops before reading a value or mutating memory.

Final user-facing wording after Prompt 8 user feedback:

```text
Memory read at 00400000h for 1 byte overlaps .CODE/_TEXT. The simulator does not expose .CODE/_TEXT as an accessible memory region. Program stopped before access.
```

```text
Memory write at 00400000h for 1 byte overlaps .CODE/_TEXT. The simulator does not expose .CODE/_TEXT as an accessible memory region. Program stopped before access.
```

Important interpretation:

- `.CODE/_TEXT` in the diagnostic is explanatory wording only.
- `_TEXT` is not implemented as an addressable symbol, segment, group, alias, or linker concept.
- Phase 57M remains the owner for MASM segment/group-symbol diagnostics.

### 3.2 Cross-region `.code` protected-overlap diagnostics

Implemented cross-region behavior:

- A memory range starting outside `.code` and ending inside `.code` reports `region-boundary-crossing`.
- A memory range starting inside `.code` and extending outside `.code` reports `region-boundary-crossing`.
- The diagnostic uses runtime layout metadata for the `.code` region start address.
- The diagnostic does not hardcode fixed-layout addresses as internal policy.

Final user-facing wording after Prompt 8 user feedback:

```text
Cross-region memory write at 003FFFFFh for 2 bytes. The memory address range 003FFFFFh..00400000h crosses/overlaps a no-access memory region, .CODE/_TEXT, that starts at 00400000h. This is not allowed; program stopped before access.
```

The same wording pattern is used for reads and writes, with the access kind substituted.

### 3.3 Diagnostic precedence and no-partial-mutation behavior

Implemented and tested behavior preserves the Phase 57L diagnostic-precedence model:

- Parser/malformed or unsupported operand shapes are still rejected before runtime memory classification.
- Address arithmetic/range failures remain separate from `.code` classification when no protected region is intersected.
- Cross-region accesses intersecting `.code` use `region-boundary-crossing`.
- Wholly contained `.code` reads/writes use `unsupported-code-memory-access`.
- Wholly contained `.CONST` writes continue to use permission denial.
- `.CONST` cross-region overlaps continue to use `region-boundary-crossing`.
- Optional teaching validations remain separate from mandatory Level 1 protected-region behavior.

No-partial-mutation behavior was implemented and tested for fatal `.code` access diagnostics:

- The failing instruction does not consume a read value.
- Writes do not mutate memory.
- No successful memory-change row is created for denied `.code` writes.
- Read-modify-write operations stop before read/write and before flag updates.
- Registers, flags, flag-validity metadata, memory, Program Console output, and execution-complete status are preserved consistently with stopping before the failing access.

### 3.4 Diagnostic policy metadata

The existing reserved diagnostic-policy family:

```text
unsupported-code-memory-access
```

was advanced from reserved/inactive metadata to current implemented metadata for Phase 57L, while preserving the requirement that `.code` access denial is mandatory and non-configurable.

The family is not exposed as an optional `off` / `warn` / `error` teaching-policy control.

### 3.5 Status-surface updates

Updated status surfaces to Phase 57L where runtime/source-run behavior is reported:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `web/index.html`
- `web/src/protocol.js`
- protocol/status tests
- static documentation/status checks in `scripts/run_tests.py`
- source-run/Wasm status metadata through changed source-run/protocol paths

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57L:

- Phase 57M - MASM Segment and Group Symbol Diagnostics.
- Diagnostics for `_TEXT`, `_DATA`, `_BSS`, `CONST`, `STACK`, `DGROUP`, or `FLAT` as addressable symbols.
- Making `_TEXT` an alias for `.code`.
- Making `CONST` an alias for `.CONST`.
- Any MASM segment/group-symbol namespace implementation.
- Segment registers.
- Segment override behavior.
- `ASSUME` implementation.
- Readable `.code` byte image.
- Deterministic simulator code-image bytes.
- Real x86 opcode bytes.
- Disassembly.
- PE `.text` section behavior.
- COFF/OMF/object-file behavior.
- Linker behavior.
- Relocation records.
- Windows loader behavior.
- Host filesystem behavior.
- Control-flow, stack, procedure, debugger, or Irvine32 routine expansion.
- Any optional setting that can disable `.code` access denial.
- New memory-addressing syntax.
- New instruction opcode behavior.

Future work intentionally preserved:

- Phase 57M should implement MASM segment/group-symbol diagnostics without turning segment/group names into region aliases.
- Future memory-reading opcode planned-access TODOs remain deferred to the phases that add those opcodes.
- Future control-flow, stack, procedure, debugger, macro, and Irvine32 routine phases remain out of scope.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 57L advances both repository/archive milestone and runtime/source-run MASM behavior phase.
- **Reason:** The milestone changes runtime-visible behavior for source programs that access memory overlapping `.code`.
- **Risk:** Missing one status surface could leave documentation, protocol metadata, or static tests stale.
- **How to change later:** Future maintenance-only milestones should advance repository/archive status only. Future runtime behavior milestones should update both values when their scope explicitly changes runtime/source-run behavior.

### Assumption 2

- **Assumption:** `.code` memory-access denial should be implemented centrally in the checked memory path or directly adjacent memory-validation logic.
- **Reason:** Phase 57L requires classification by final effective address and byte range. Central memory validation avoids scattered executor-specific checks.
- **Risk:** If an implemented memory access bypassed checked memory helpers, it could miss `.code` denial.
- **How to change later:** Future memory-capable instructions must continue to route through checked VM memory helpers and planned-access validation where applicable. Add tests for any newly implemented memory-capable instruction.

### Assumption 3

- **Assumption:** Wholly contained `.code` reads and writes should use `unsupported-code-memory-access`; cross-region `.code` overlaps should use `region-boundary-crossing`.
- **Reason:** This matches the Phase 57L guide and the existing protected-region overlap model established for `.CONST`.
- **Risk:** A user might expect a single code for all `.code` access failures.
- **How to change later:** A future deliberate diagnostic-copy or diagnostic-taxonomy phase could revise wording or split codes, but it must update structured tests, rendered-message tests, docs, and milestone reports consistently.

### Assumption 4

- **Assumption:** Diagnostic copy may mention `.CODE/_TEXT` without implementing `_TEXT` as an addressable symbol.
- **Reason:** The user requested clearer wording after manual testing, and the wording helps relate `.code` policy to common MASM object-section terminology.
- **Risk:** Future assistants could misread `.CODE/_TEXT` wording as permission to implement `_TEXT` address resolution early.
- **How to change later:** Phase 57M should implement explicit segment/group-symbol diagnostics and document that these names are not aliases for simulator internal regions unless the canonical spec/guide is deliberately changed.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can be reported as skipped when `emcc` is unavailable in the assistant/container environment.
- **Reason:** The aggregate runner reports this dependency skip explicitly and the environment lacks Emscripten.
- **Risk:** Browser users need a rebuilt Wasm artifact to observe the updated runtime behavior on the served site.
- **How to change later:** Rebuild with Emscripten locally or in CI and perform the served-browser manual verification steps.

## 6. Relevant TODO-style notes reviewed

Target-owned TODO-style notes reviewed:

- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`: Future `.code` memory-access-denial guidance requiring `region-boundary-crossing` for cross-region accesses intersecting `.code`, use of runtime `.code` layout metadata, and no hardcoded fixed-layout addresses.
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`: Phase 57-CORR1-era protected-region note that was future-owned before Phase 57L and became target-owned for this milestone.
- `src/core/vm_memory.c`: Future protected-region diagnostics TODO requiring the `.CONST` overlap helper to be generalized when `.code` becomes access-denying.

Future-owned TODO-style notes reviewed:

- `src/wasm/wasm_api.c`: Future memory-reading opcode planned-read TODO. This remains future-owned because Phase 57L adds no new opcode.

Broad TODO-style search categories reviewed and excluded as irrelevant to Phase 57L:

- future QWORD/SQWORD execution notes;
- future Irvine32 routine notes;
- future stack/procedure/debugger work;
- future macro/high-level-flow notes;
- parser diagnostics for unrelated unsupported constructs;
- static-check strings and test fixture text;
- historical report text and generated artifacts excluded from source-note authority.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- The guide's `.code` protected-region overlap guidance was implemented as current Phase 57L behavior.
- The Phase 57-CORR1-era future `.code` protected-region note was resolved for Phase 57L and documentation was updated so it no longer describes Phase 57L as future behavior.
- The `src/core/vm_memory.c` protected-region helper TODO was resolved by generalizing protected-region overlap handling for `.CONST` and `.code`.

### Future-owned TODO-style notes intentionally preserved

- `src/wasm/wasm_api.c` future memory-reading opcode planned-read TODO remains deferred. Phase 57L did not add a new opcode or future memory-reading instruction family.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style notes remained after review.
- Stale non-TODO wording discovered during compliance review was corrected, including active spec/test wording that still framed Phase 57L behavior as future or Phase 57K-only characterization.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 57L was implemented as a narrow runtime diagnostic and validation milestone.

Primary design choices:

1. **Central memory-path enforcement.**
   `.code` access denial was added to the checked memory validation path rather than each executor instruction. This preserves the final-effective-address requirement and avoids missing computed or indirect accesses.

2. **Distinct wholly-contained versus cross-region behavior.**
   Wholly contained `.code` reads/writes use `unsupported-code-memory-access`. Cross-region accesses intersecting `.code` use the shared protected-region `region-boundary-crossing` model.

3. **Generalized protected-region context.**
   Existing `.CONST` protected-region overlap logic was generalized so `.CONST` and `.code` can both report correct runtime region names and start addresses.

4. **Mandatory, not configurable.**
   `unsupported-code-memory-access` is implemented as mandatory behavior. It is not an optional warning/error/off teaching-policy family.

5. **Preserved `.CONST` semantics.**
   `.CONST` write protection and `.CONST` cross-region diagnostics remain intact. `.CONST` reads remain valid when otherwise allowed.

6. **No future segment behavior.**
   Diagnostic wording now mentions `.CODE/_TEXT`, but `_TEXT` remains non-addressable. Phase 57M remains the owner of segment/group-symbol diagnostics.

7. **Exact rendered-message testing.**
   User-visible diagnostic copy is covered by exact rendered Simulator Messages tests, and the Prompt 8 wording adjustment was reflected in tests.

## 9. Files changed

Files changed across implementation, reviews, and Prompt 8 wording follow-up:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_diagnostic_policy.c`
- `src/core/vm_diagnostic_policy.h`
- `src/core/vm_memory.c`
- `src/core/vm_memory.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_diagnostic_policy.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_vm_memory.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

Added or updated test coverage includes:

### Native memory/unit tests

- `.code` read denial for byte/word/dword access widths.
- `.code` write denial for byte/word/dword access widths.
- No memory-change rows for denied `.code` writes.
- Cross-region read/write ranges that intersect `.code`.
- Runtime `.code` region metadata used in protected-region diagnostics.
- `.CONST` cross-region regression behavior.
- Wholly contained `.CONST` write permission-denial regression.
- Wholly contained `.CONST` read regression.

### Source-run/executor tests

- Register-indirect `.code` read failure.
- Register-indirect `.code` write failure.
- Partial-overlap `.code` access from before `.code` into `.code`.
- Partial-overlap `.code` access from inside `.code` out of `.code`.
- Read-modify-write failure before mutation and before flag update.
- No `execution-complete` after fatal `.code` access diagnostics.
- No Program Console output or memory-change rows from failing `.code` accesses.
- Normal `.data` memory access regression.

### Rendered Simulator Messages tests

Exact rendered-message coverage for:

- `.CODE/_TEXT` read `unsupported-code-memory-access` diagnostic.
- `.CODE/_TEXT` write `unsupported-code-memory-access` diagnostic.
- `.CODE/_TEXT` cross-region `region-boundary-crossing` diagnostic.

### Diagnostic-policy tests

- `unsupported-code-memory-access` is current/implemented.
- `unsupported-code-memory-access` is mandatory/non-configurable.
- Optional `off` / `warn` / `error` policy routing does not disable `.code` denial.

### Protocol/static/status tests

- Runtime/source-run phase metadata is Phase 57L.
- Repository/archive documentation status is Phase 57L.
- Browser/static status text is Phase 57L.
- Supported-syntax and documentation wording reflects current Phase 57L behavior.
- Static checks prevent stale readable-code-image or x86-opcode claims.

## 11. Commands used to test

### Aggregate command

```bash
python3 scripts/run_tests.py --all
```

Final observed result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Focused group commands

Focused groups run during implementation, compliance review, second review, Prompt 8 follow-up, and final gap check:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused results:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Subgroup or fixture-family commands

No subgroup or individual fixture-family commands were required.

During implementation, one combined chain of focused commands hit the assistant/container timeout after the `--web` group. This was a tool-chain command-chain timeout, not a project test failure. Remaining focused groups were rerun individually and passed. Later aggregate and focused runs completed successfully.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is an expected dependency skip, not a test failure.

## 12. Pass/fail results

Final result classification:

```text
aggregate completed and passed
```

Detailed classification:

- Aggregate completed and passed.
- Focused groups completed and passed.
- No aggregate failure occurred.
- No focused group failed.
- No focused group required subgroup/fixture rerun.
- One earlier combined shell chain timed out in the assistant/container environment after earlier focused groups had passed; the remaining focused groups were rerun individually and passed.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

Final aggregate output ended with:

```text
All implemented milestone tests passed.
```

## 13. Manual/browser testing guidance and expected outputs

Phase 57L is website-testable after rebuilding Wasm with Emscripten.

### Browser setup on Windows CMD

From the repository root:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open:

```text
http://localhost:8000
```

If Emscripten is unavailable, browser/Wasm rebuild is expected to be skipped. In that case, use local tests instead.

### Program 1 - `.code` read must fail

```asm
.code
main PROC
    mov ebx, 00400000h
    mov al, BYTE PTR [ebx]
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] unsupported-code-memory-access line 4, column 5, byte offset 43, span length 22: Memory read at 00400000h for 1 byte overlaps .CODE/_TEXT. The simulator does not expose .CODE/_TEXT as an accessible memory region. Program stopped before access.
```

Expected Program Console:

```text
(empty)
```

Expected key state:

```text
EBX = 00400000h / 4194304
EAX = 00000000h / 0
AL  = 00h / 0
No memory changes.
No execution-complete message.
```

### Program 2 - `.code` write must fail before mutation

```asm
.code
main PROC
    mov ebx, 00400000h
    mov BYTE PTR [ebx], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] unsupported-code-memory-access line 4, column 5, byte offset 43, span length 21: Memory write at 00400000h for 1 byte overlaps .CODE/_TEXT. The simulator does not expose .CODE/_TEXT as an accessible memory region. Program stopped before access.
```

Expected Program Console:

```text
(empty)
```

Expected key state:

```text
EBX = 00400000h / 4194304
EAX = 00000000h / 0
No memory changes.
No execution-complete message.
```

### Program 3 - partial overlap into `.code` must report region boundary crossing

```asm
.code
main PROC
    mov ebx, 003FFFFFh
    mov WORD PTR [ebx], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] region-boundary-crossing line 4, column 5, byte offset 43, span length 21: Cross-region memory write at 003FFFFFh for 2 bytes. The memory address range 003FFFFFh..00400000h crosses/overlaps a no-access memory region, .CODE/_TEXT, that starts at 00400000h. This is not allowed; program stopped before access.
```

Expected Program Console:

```text
(empty)
```

Expected key state:

```text
EBX = 003FFFFFh / 4194303
EAX = 00000000h / 0
No memory changes.
No execution-complete message.
```

### Program 4 - ordinary `.data` memory must still work

```asm
.data
value DWORD 123
.code
main PROC
    mov ebx, OFFSET value
    mov eax, DWORD PTR [ebx]
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key state:

```text
EBX = 00500000h / 5242880
EAX = 0000007Bh / 123
No memory changes.
```

### Windows CMD local testing

From repository root:

```cmd
py scripts\run_tests.py --structure
py scripts\run_tests.py --native
py scripts\run_tests.py --source-run
py scripts\run_tests.py --web
py scripts\run_tests.py --diagnostics
py scripts\run_tests.py --protocol
py scripts\run_tests.py --static
py scripts\run_tests.py --all
```

Expected snippets:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
All implemented milestone tests passed.
```

Acceptable dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Regression signs:

- A `.code` read succeeds or returns zero-filled bytes.
- A `.code` write creates a memory-change row.
- A partial `.code` overlap does not report `region-boundary-crossing`.
- A `.code` failure still reports `execution-complete`.
- Program Console receives output from a failing `.code` access fixture.
- Ordinary `.data` reads fail or report `.code` diagnostics.
- Runtime/source-run status still reports Phase 57J or Phase 57K after rebuilding.
- Aggregate tests do not end with `All implemented milestone tests passed.`, except for the expected `emcc` skip.

## 14. Compliance review summary

First compliance review found no future-milestone scope creep and no behavioral implementation defects. It found three documentation/comment hygiene issues:

- Active spec text still described Phase 57L `.code` behavior as future behavior.
- `tests/core/test_vm_memory.c` file header still described `.code` coverage as Phase 57K characterization.
- `src/core/vm_memory.h` `.code` region comment could be misread as permitting source-level `.code` reads.

Fixes applied:

- Updated active spec text to describe Phase 57L behavior as current implemented behavior.
- Updated the memory-test file header to describe Phase 57L `.code` denial.
- Clarified `.code` region documentation so internal metadata is not confused with supported source-level reads.

Tests rerun after review:

- all focused groups;
- aggregate `--all`.

Result:

- focused groups passed;
- aggregate completed and passed;
- Browser/Wasm smoke skipped because `emcc` was unavailable.

Verdict after first compliance review:

```text
complete
```

## 15. Re-review summary

Second compliance review re-read the Phase 57L guide section, relevant spec sections, changed code, docs, tests, rendered diagnostics, status metadata, and TODO-style notes.

Additional issues found:

```text
None.
```

Additional fixes applied:

```text
None.
```

Final re-review verdicts:

- Scope verdict: complete; no Phase 57M or broader future behavior was implemented.
- Documentation verdict: complete; docs describe Phase 57L current behavior and do not promise future behavior.
- Test coverage verdict: complete for Phase 57L.
- TODO-style note verdict: target-owned `.code` TODOs resolved; future-owned opcode planned-read TODO preserved; no stale TODOs found.

Tests rerun:

- all focused groups;
- aggregate `--all`.

Result:

- focused groups passed;
- aggregate completed and passed;
- Browser/Wasm smoke skipped because `emcc` was unavailable.

## 16. User-test follow-up summary

User manual testing result:

```text
everything appears to pass
```

User feedback:

- Functional behavior was accepted.
- User requested shorter and clearer diagnostic wording using `.CODE/_TEXT` terminology.

Diagnosis:

- Classification: expected behavior and documentation/diagnostic-copy issue.
- No implementation-behavior bug was found.
- The wording change remained within Phase 57L scope because it affects Phase 57L user-visible diagnostics only.
- Phase 57M segment/group-symbol diagnostics were not implemented.

Fixes applied:

- Updated `.code` read/write `unsupported-code-memory-access` messages to the `.CODE/_TEXT` wording.
- Updated `.code` cross-region `region-boundary-crossing` messages to the `.CODE/_TEXT` no-access wording.
- Updated exact rendered Simulator Messages tests and source-run checks.
- Updated docs to clarify that `.CODE/_TEXT` wording does not make `_TEXT` an addressable symbol alias.
- Corrected one active stale future-owned `.code` diagnostic note to current Phase 57L behavior.

Tests rerun after Prompt 8 follow-up:

```bash
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Result:

- all relevant focused groups passed;
- aggregate completed and passed;
- Browser/Wasm smoke skipped because `emcc` was unavailable.

## 17. Known limitations

- Browser/Wasm rebuild smoke could not run in the assistant/container environment because `emcc` was unavailable.
- Served-browser verification requires rebuilding Wasm locally with Emscripten.
- Phase 57M segment/group-symbol diagnostics are not implemented.
- `_TEXT` is not an addressable alias for `.code`; `.CODE/_TEXT` appears only in diagnostic copy.
- `.code` is not a readable byte image, PE `.text` section, x86 opcode buffer, or disassembly source.
- No future control-flow, stack, procedure, debugger, macro, Irvine32 routine, linker, PE, or segment behavior was implemented.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57M - MASM Segment and Group Symbol Diagnostics
```

Expected Phase 57M scope:

- Recognize MASM segment/group names such as `_TEXT`, `_DATA`, `_BSS`, `CONST`, `STACK`, `DGROUP`, and `FLAT` where they appear as addressable source symbols or segment/group references.
- Emit stable structured diagnostics such as `unsupported-segment-symbol`.
- Preserve CASEMAP policy as specified by the Phase 57K/57L documentation.
- Do not make segment/group names aliases for simulator internal regions unless the canonical spec/guide is deliberately changed.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

- `milestone_57L_changed_files.zip`
- `milestone_57L_changed_files_review1.zip`
- `milestone_57L_changed_files_review2.zip`
- `milestone_57L_changed_files_prompt8.zip`
- `milestone_57L_changed_files_final_gap_check.zip`

Most recent package:

```text
milestone_57L_changed_files_final_gap_check.zip
```

This package preserves repository structure for changed files. It is a changed-files package, not a full latest repository archive.

Recommended full repository archive name after applying/reviewing the changed files:

```text
Latest_repository_state_milestone_57L.zip
```

