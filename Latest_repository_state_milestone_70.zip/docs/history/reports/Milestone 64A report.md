# Milestone 64A report - Planned-Read Coverage Correction for Existing Memory-Reading Instructions

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 64A - Planned-Read Coverage Correction for Existing Memory-Reading Instructions
```

Repository/archive milestone after this work:

```text
Phase 64A - Planned-Read Coverage Correction for Existing Memory-Reading Instructions
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 64A - Planned-Read Coverage Correction for Existing Memory-Reading Instructions
```

Scope implemented:

- Corrected source-run planned-read coverage for already implemented memory-reading instructions.
- Focused specifically on memory-destination read-modify-write instructions whose destination memory read must be visible to source-run policy checks before bytes are consumed or write-back occurs.
- Preserved existing executor-level checked memory reads and writes.
- Preserved existing parser/lowering behavior and all accepted MASM syntax from Phase 64.
- Preserved Program Console and Simulator Messages separation.
- Advanced repository/archive and runtime/source-run metadata to Phase 64A because strict/error diagnostic-policy behavior changed for already accepted source programs.
- Updated status surfaces and documentation to say accepted syntax remains the Phase 64 equality-jump subset while Phase 64A corrects diagnostic-policy behavior.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_64A.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 64 report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_64.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, source-run/status hygiene, memory-safety rules, and broad product constraints.
- The implementation guide owns Phase 64A numbering, exact phase scope, required tasks, required tests, acceptance criteria, and milestone-report obligations.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or implementation guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or implementation guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

## 3. Exact requirements implemented

### 3.1 Required current-behavior correction

Phase 64A required source-run planned-read collection to be audited and corrected for all already implemented instruction forms that read simulated memory before completing execution.

Implemented correction:

- Added missing planned-read coverage for these already implemented memory-destination read-modify-write families:
  - `inc mem`
  - `dec mem`
  - `and mem, source`
  - `or mem, source`
  - `xor mem, source`

Audited and preserved existing planned-read coverage for these already implemented families:

- `add mem, source`
- `sub mem, source`
- `adc mem, source`
- `sbb mem, source`
- `not mem`
- `neg mem`
- `shl mem, count`
- `sal mem, count`
- `shr mem, count`
- `sar mem, count`
- `rol mem, count`
- `ror mem, count`
- `xchg reg, mem`
- `xchg mem, reg`
- `mov register, mem`
- `movsx register, mem`
- `movzx register, mem`
- `cmp mem, source`
- `cmp destination, mem`
- `test mem, source`
- `test destination, mem`
- `mul mem`
- `imul mem`
- `div mem`
- `idiv mem`

No listed future instruction family was added merely to satisfy the audit.

### 3.2 Required diagnostic behavior

Implemented and tested behavior for uninitialized-origin memory reads:

- Default warning mode emits existing `uninitialized-read` and continues using deterministic visible bytes.
- Explicit `off` mode suppresses only the `uninitialized-read` teaching diagnostic and continues using deterministic visible bytes.
- Strict/error mode emits existing `uninitialized-read` and stops before the instruction consumes the memory value.
- Strict/error mode stops before write-back for memory-destination read-modify-write instructions.
- Strict/error mode preserves registers, modeled flags, flag-validity metadata, memory bytes, Program Console output, and memory-change rows as they were before the failing instruction began.
- Strict/error mode omits `execution-complete` after a fatal diagnostic.
- Warning-mode read-modify-write behavior continues, writes back deterministic results, and initializes the successfully written destination bytes according to existing uninitialized-origin metadata rules.

No new diagnostic code was added. Phase 64A uses the existing `uninitialized-read` diagnostic family.

### 3.3 Planned-read and planned-access consistency

Phase 64A required the implementation not to update only one policy path.

Implementation result:

- Updated planned memory-read collection in `src/wasm/wasm_api.c` for the current opcode gaps.
- Audited the separate planned object/section access collector and confirmed it already covered the affected current RMW opcode families.
- Kept separate switch-based planned-memory paths instead of introducing a broad descriptor-table refactor.
- Added tests proving the corrected families reach the `uninitialized-read` planned-read policy path and that existing memory-source planned-read behavior remains intact.

### 3.4 Required no-partial-mutation order

Implemented source-run behavior consistent with the required conceptual order:

1. Source is parsed and lowered normally.
2. Effective address and access width are resolved.
3. Planned memory reads are exposed to source-run policy checks before destination values are consumed.
4. Strict/error planned-read failures emit `uninitialized-read` and stop before memory bytes are used for instruction semantics.
5. If planned-read policy allows execution, the executor performs checked VM memory reads and writes through existing central helpers.
6. Memory-change rows are recorded only after successful writes.

Tests verify no partial mutation for strict/error mode and successful write-back plus initialized-byte metadata update in warning/off modes.

### 3.5 Source-location preservation

During second compliance review, direct-symbol uninitialized-read diagnostics were found to preserve only line number in some Phase 64A-touched paths even though source column, byte offset, and span length were available.

Fix implemented:

- Added direct-symbol source-span fallback for uninitialized-read diagnostics in `src/wasm/wasm_api.c`.
- Preserved existing bracketed-memory source-span behavior.
- Updated source-run and rendered-message tests to assert exact source location for direct-symbol RMW diagnostics.

### 3.6 Current-status and metadata

Updated runtime/source-run metadata to:

```json
{
  "phase": 64,
  "phaseSuffix": "A",
  "phaseName": "Phase 64A - Planned-Read Coverage Correction for Existing Memory-Reading Instructions"
}
```

Updated current-status surfaces include:

- source-run JSON metadata;
- protocol metadata;
- protocol tests;
- static status checks;
- README current-status block;
- supported-syntax current-status text;
- milestone history;
- build/development verification docs;
- browser `web/index.html` status/sample text;
- browser protocol constants.

Current supported-syntax wording explicitly says Phase 64A did not add syntax and that accepted MASM syntax remains the Phase 64 equality-jump subset.

### 3.7 Browser page update

`web/index.html` was updated to reflect Phase 64A:

- page title/status text now identifies Phase 64A planned-read correction;
- visible text says accepted syntax remains the Phase 64 equality-jump subset;
- default sample demonstrates the corrected planned-read warning path for an existing memory-destination RMW instruction.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 64A:

- Signed relational conditional jumps:
  - `jl`
  - `jle`
  - `jg`
  - `jge`
  - `jnge`
  - `jng`
  - `jnle`
  - `jnl`
- Unsigned relational conditional jumps:
  - `ja`
  - `jae`
  - `jb`
  - `jbe`
  - `jnbe`
  - `jnb`
  - `jnae`
  - `jna`
- `loop` or loop-family instructions.
- Indirect jumps.
- Register-target, memory-target, or immediate-target branch execution.
- Branch-distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Stack instructions.
- `call`, `ret`, `leave`, `push`, or `pop`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 callable routines beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- New memory addressing forms.
- Object-bounds policy semantic changes beyond preserving existing behavior.
- `.CONST` policy changes.
- Executable QWORD/SQWORD memory operations in MASM32 Educational Mode.
- Browser settings UI.
- Debugger/editor behavior.
- Active-time watchdog behavior.
- Wall-clock execution limits.
- Worker yielding/chunking for responsiveness.
- Macro expansion.
- `OPTION NOKEYWORD` behavior or dynamic keyword-table mutation.
- A new RMW-specific diagnostic code.

Future work intentionally preserved:

- Phase 64B - Simulator Message Runtime Notice Ordering and Grouping.
- Phase 64C - Simulator Message Runtime Notice Suppression and Severity Policy.
- Phase 65 - Signed Relational Conditional Jumps.
- Later unsigned relational conditional jumps.
- Later `loop` runtime behavior.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future Irvine32 routine expansion.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- Future memory-reading opcode planned-access additions when those future opcodes are implemented.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 64A should correct the source-run planned-read/planned-access classification in `src/wasm/wasm_api.c` rather than changing raw executor semantics.
- **Reason:** The guide identifies source-run policy coverage as the issue, and executor-level checked memory helpers already remain mandatory and active.
- **Risk:** If an executor path had a hidden mutation-before-policy issue, planned-read classification alone would not address it.
- **How to change later:** Add executor-level preflight or rollback helpers only if future tests prove mutation occurs before policy rejection outside the source-run planned-access path.

### Assumption 2

- **Assumption:** A smaller correction to existing switch statements was acceptable for Phase 64A instead of a full opcode memory-access descriptor refactor.
- **Reason:** The specific missing current opcode families were localized to planned-read collection. Planned object/section access collection already covered the affected families, and the guide allows a smaller correction if the report documents why and tests prove the affected policies agree.
- **Risk:** Separate switch statements can drift again in later instruction phases.
- **How to change later:** Refactor opcode memory-access classification into a shared descriptor table or helper when a later phase touches this code again, especially before adding many more memory-capable opcodes.

### Assumption 3

- **Assumption:** Runtime/source-run metadata should advance to Phase 64A even though no syntax was added.
- **Reason:** The guide explicitly says Phase 64A changes runtime/source-run diagnostic behavior and strict-mode execution behavior for already accepted programs, so both repository/archive and runtime/source-run labels must advance.
- **Risk:** Documentation could accidentally imply that Phase 64A adds new MASM syntax.
- **How to change later:** Continue using explicit wording in status surfaces: accepted syntax remains the Phase 64 equality-jump subset; Phase 64A corrects diagnostic-policy behavior only.

### Assumption 4

- **Assumption:** Existing `uninitialized-read` diagnostic wording should be reused rather than adding an RMW-specific diagnostic code.
- **Reason:** The guide explicitly requires use of the existing `uninitialized-read` diagnostic family and says not to introduce a new code merely to distinguish RMW cases.
- **Risk:** Users may not immediately know that a destination operand in `inc x` is read before it is written.
- **How to change later:** If a later diagnostics-copy phase changes wording, it can clarify RMW context while preserving the existing diagnostic code and exact rendered-message tests.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in this environment, and the aggregate runner reports the skip explicitly.
- **Risk:** Locally served browser artifacts may remain stale until a developer rebuilds Wasm with Emscripten configured.
- **How to change later:** Run the Windows Emscripten build script after activating the emsdk environment, for example with `call C:\_CPP_TOOLS\emsdk\emsdk_env.bat` before `scripts\windows\build_wasm.cmd`.

## 6. Relevant TODO-style notes reviewed

```text
- Location:
  src/wasm/wasm_api.c, planned-read collection near masm32_sim_wasm_collect_planned_reads
- Note text or summary:
  A future-opcode reminder says future memory-reading opcodes must be added to planned-read collection when their instruction milestones implement them.
- Classification:
  target-owned for current already implemented opcode gaps; future-owned for truly future opcodes.
- Reason:
  Phase 64A directly requires auditing and correcting planned-read coverage for already implemented memory-reading instructions. The same reminder must remain valid for future memory-reading opcodes that are not part of Phase 64A.
- Action for this milestone:
  Resolved for current opcode gaps: inc, dec, and, or, xor memory destinations. Preserved the future-opcode reminder for later milestones.
```

```text
- Location:
  src/wasm/wasm_api.c, planned object/section access collection near masm32_sim_wasm_collect_planned_object_accesses
- Note text or summary:
  Future memory-capable opcodes must extend object/section planned-access collection in their owning phase.
- Classification:
  target-owned audit item; future-owned for future opcodes.
- Reason:
  Phase 64A required auditing all source-run planned-memory paths, not only uninitialized-read planned reads.
- Action for this milestone:
  Audited and confirmed the collector already covered the affected current RMW families. Left future-opcode guidance intact.
```

```text
- Location:
  README.md, docs/SUPPORTED_SYNTAX.md, docs/MILESTONE_HISTORY.md, docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, and related deferred-feature notes
- Note text or summary:
  Later branch families, stack/procedure behavior, Irvine32 callable routines, macro behavior, debugger/editor behavior, executable QWORD/SQWORD memory operations, active-time watchdog behavior, and OPTION NOKEYWORD remain deferred.
- Classification:
  future-owned
- Reason:
  Phase 64A corrects diagnostic-policy behavior only for existing memory-reading instructions and does not add future language/runtime features.
- Action for this milestone:
  Preserved. Documentation updates continued to state these features remain future work.
```

```text
- Location:
  src/core/vm_exec.c / src/core/vm_exec.h / src/wasm/wasm_api.c branch-runtime-deferred and attempted-instruction metadata references
- Note text or summary:
  Transitional branch/status metadata remains in the executor/source-run code.
- Classification:
  irrelevant-to-target
- Reason:
  Phase 64A does not change branch execution, branch target classification, instruction-count watchdog behavior, or debugger/editor branch behavior.
- Action for this milestone:
  Left unchanged.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- The planned-read collector now covers current already implemented RMW memory-destination opcode gaps:
  - `inc mem`
  - `dec mem`
  - `and mem, source`
  - `or mem, source`
  - `xor mem, source`
- Planned object/section access collection was audited and left unchanged because it already covered the affected current opcode families.
- Source-location preservation for the newly surfaced direct-symbol uninitialized-read diagnostics was corrected and tested.

### Future-owned TODO-style notes intentionally preserved

- Future memory-reading opcode reminder in `src/wasm/wasm_api.c` remains valid for later instruction milestones.
- Future branch families remain deferred.
- Stack/procedure/call/return behavior remains deferred.
- Irvine32 callable routines remain deferred.
- Macro behavior remains deferred.
- Debugger/editor behavior remains deferred.
- Executable QWORD/SQWORD memory operations remain deferred.
- Active-time watchdog behavior remains deferred to Phase 200.
- `OPTION NOKEYWORD` keyword-control behavior remains deferred.

### Stale or contradicted TODO-style notes corrected

- No stale or contradicted TODO-style notes were found.
- A stale non-TODO status issue in `README.md` was corrected during compliance/final gap checks.
- A stale internal helper name in `scripts/run_tests.py` was corrected during compliance review.
- A temporary scratch file `manual_render.mjs` was removed during final gap check.

### Unresolved TODO-related risks

- None specific to Phase 64A.

## 8. Design summary

Phase 64A was implemented as a focused source-run policy correction.

Primary design choices:

1. **Minimal planned-read correction.** The implementation added missing existing opcodes to `masm32_sim_wasm_collect_planned_reads` rather than rewriting executor semantics.

2. **Separate planned-access paths retained.** The codebase currently uses separate planned-read and object/section access paths. Phase 64A kept this design because the missing gaps were localized and tests now cover the corrected policy behavior. The report records this explicitly because the guide prefers a single source of truth when practical.

3. **No new diagnostics.** The existing `uninitialized-read` diagnostic family is used for RMW destination reads. This keeps behavior consistent with earlier uninitialized-origin diagnostics.

4. **No syntax or opcode expansion.** All changed behavior applies to source programs that were already accepted and executable before Phase 64A.

5. **No-partial-mutation verified by source-run tests.** Strict/error policy now stops affected RMW instructions before destination bytes are consumed or write-back occurs.

6. **Source locations tightened.** Direct-symbol memory operands now preserve source column, byte offset, and span length for the uninitialized-read diagnostics surfaced by Phase 64A.

7. **Status hygiene.** Because runtime/source-run diagnostic behavior changed, metadata and status surfaces were advanced to Phase 64A while documentation explicitly says accepted syntax remains Phase 64.

## 9. Files changed

Changed project files in the final Phase 64A state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

Generated/native build artifacts were also regenerated by test runs under `build/tests/`, but they are not treated as source changes for milestone design purposes.

## 10. Tests added

### Source-run JSON tests

Added Phase 64A source-run tests covering RMW planned-read policy behavior for:

- `inc mem`
- `dec mem`
- `add mem, imm`
- `sub mem, imm`
- `adc mem, imm`
- `sbb mem, imm`
- `and mem, imm`
- `or mem, imm`
- `xor mem, imm`
- `not mem`
- `neg mem`
- `shl mem, 1`
- `xchg mem, reg`

For the newly corrected families, tests cover:

- warning mode emits `uninitialized-read`, continues, writes deterministic results, and records successful write-back where applicable;
- explicit off mode suppresses only `uninitialized-read` and continues;
- strict/error mode emits `uninitialized-read`, stops before write-back, creates no memory-change rows, and omits `execution-complete`;
- strict/error mode leaves destination bytes with uninitialized-origin metadata;
- warning/off successful write-back initializes destination bytes.

### Regression tests

Added or preserved regression tests for:

- `cmp mem, imm` warning and strict/error planned-read behavior;
- shift/rotate memory destination planned-read behavior;
- `not mem` planned-read behavior;
- memory-source multiply/divide coverage where already implemented;
- source-run phase metadata suffix/name;
- existing `.CONST`, `.code`, and other diagnostic-policy metadata expectations updated to Phase 64A.

### Rendered Simulator Messages tests

Added exact rendered-message tests for:

- Phase 64A RMW planned-read warning plus final `execution-complete`;
- Phase 64A RMW strict/error stop without `execution-complete`.

Updated exact expectations to include preserved line, column, byte offset, and span length for direct-symbol uninitialized-read diagnostics.

### Protocol/static tests

Updated protocol and static tests for Phase 64A metadata and status-surface hygiene.

## 11. Commands used to test

Focused test commands run during implementation and compliance:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate test command run during implementation and compliance:

```bash
python3 scripts/run_tests.py --all
```

No documented subgroup or individual fixture-family reruns were required because focused groups and the aggregate command completed in the assistant/container environment.

Skipped dependency checks:

- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.
- This was reported by the test runner as a dependency skip, not a project failure.

## 12. Pass/fail results

Final verified results:

- `python3 scripts/run_tests.py --structure`: passed.
- `python3 scripts/run_tests.py --native`: passed.
- `python3 scripts/run_tests.py --source-run`: passed.
- `python3 scripts/run_tests.py --web`: passed.
- `python3 scripts/run_tests.py --diagnostics`: passed.
- `python3 scripts/run_tests.py --protocol`: passed.
- `python3 scripts/run_tests.py --static`: passed.
- `python3 scripts/run_tests.py --all`: aggregate completed and passed.

Final aggregate output included:

```text
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

No focused group failed. No focused group timed out. No subgroup or fixture-family rerun was required.

## 13. Manual/browser testing guidance and expected outputs

Phase 64A is website-testable after rebuilding Wasm with Emscripten. It is also testable locally through the native/source-run diagnostic paths.

### Browser setup on Windows

From Windows CMD:

```cmd
cd path\to\project
call C:\_CPP_TOOLS\emsdk\emsdk_env.bat
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the local URL printed by the serve script.

`emcc` is required for browser testing. Without rebuilding Wasm, the served page may still use the old Phase 64 artifact or report a stale-artifact/protocol mismatch.

### Browser Program 1 - default warning behavior

Paste:

```asm
.DATA?
x DWORD ?

.code
main PROC
    inc x
main ENDP
END main
```

Use default uninitialized-read warning mode and click Run.

Expected Simulator Messages:

```text
[simulator-warning] uninitialized-read line 5, column 9, byte offset 41, span length 1: Memory read range 00500000h..00500003h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console: empty.

Expected Memory Changes:

```text
x DWORD
  old | 00000000h / u: 0          / s:  0
  new | 00000001h / u: 1          / s:  1
```

### Browser Program 2 - strict stop before mutation

Use the same program, set uninitialized reads to Strict, and click Run.

Expected Simulator Messages:

```text
[runtime-error] uninitialized-read line 5, column 9, byte offset 41, span length 1: Memory read range 00500000h..00500003h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
```

Expected Program Console: empty.

Expected Memory Changes:

```text
No memory changes.
```

There must be no `execution-complete` message.

### Browser Program 3 - multiple corrected RMW families

Paste:

```asm
.DATA?
a DWORD ?
b DWORD ?
c DWORD ?
d DWORD ?
e DWORD ?

.code
main PROC
    inc a
    dec b
    and c, 0
    or d, 1
    xor e, 1
main ENDP
END main
```

Use default warning mode.

Expected Simulator Messages include five `uninitialized-read` warnings, one for each of `a`, `b`, `c`, `d`, and `e`, followed by `startup-state-notice` and `execution-complete`.

Expected memory-change highlights:

```text
a DWORD: 00000000h -> 00000001h
b DWORD: 00000000h -> FFFFFFFFh
d DWORD: 00000000h -> 00000001h
e DWORD: 00000000h -> 00000001h
```

`c` may not appear as a memory-change row because `and c, 0` writes the same deterministic visible zero value. The required Phase 64A check is the `uninitialized-read` warning for `c`.

### Windows CMD local tests

From project root:

```cmd
py scripts\run_tests.py --source-run
py scripts\run_tests.py --diagnostics
```

Expected snippets:

```text
[source-run] PASS - source-run integration binary passed independently
[diagnostics] PASS - native diagnostic producer and rendered messages passed
Selected test groups passed.
```

Optional full verification:

```cmd
py scripts\run_tests.py --all
```

Expected snippets:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
All implemented milestone tests passed.
```

If Emscripten is not active, the browser/Wasm rebuild smoke skip is acceptable.

Regression signs:

- `inc x` produces no `uninitialized-read` warning in default warning mode.
- `inc x` in strict mode writes `x = 00000001h`.
- Strict mode still reports `execution-complete`.
- The diagnostic lacks line, column, byte offset, or span length.
- Browser status still says Phase 64 after a successful Wasm rebuild.
- Program Console shows diagnostic text.
- New branch, stack, Irvine32, macro, QWORD/SQWORD, or `OPTION NOKEYWORD` behavior appears.

## 14. Compliance review summary

First compliance review found:

- `README.md` still reported Phase 64 instead of Phase 64A.
- `scripts/run_tests.py` had a stale internal static-check helper name for the Phase 64A status-policy check.

Fixes applied:

- Updated README current-status block to Phase 64A.
- Clarified that Phase 64A corrects planned-read behavior without adding syntax.
- Renamed the stale static-check helper in `scripts/run_tests.py`.

Tests rerun:

- all focused groups;
- aggregate `python3 scripts/run_tests.py --all`.

Result:

- all passed;
- browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

## 15. Re-review summary

Second compliance review found:

- Direct-symbol uninitialized-read diagnostics affected by Phase 64A only preserved line number in some cases even though source column, byte offset, and span length were available.
- Rendered-message tests expected the older line-only output.

Fixes applied:

- Added direct-symbol source-span fallback in `src/wasm/wasm_api.c`.
- Updated native/source-run and rendered-message expectations to assert exact source location.
- Confirmed `web/index.html` reflects Phase 64A and states accepted syntax remains the Phase 64 equality-jump subset.

Final gap check found:

- `README.md` had stale Phase 64 status text again and was corrected to Phase 64A.
- A scratch file `manual_render.mjs` remained from manual verification and was removed.

Final test result:

- all focused groups passed;
- aggregate completed and passed;
- `emcc` browser/Wasm rebuild smoke remained dependency-skipped.

## 16. User-test follow-up summary

Prompt 8 was not used because the user reported no discrepancies after Prompt 7 manual-testing guidance. No user-reported targeted fixes were required.

## 17. Known limitations

- Browser/Wasm artifacts in `web/dist` were not rebuilt in the assistant/container environment because `emcc` was unavailable.
- The served website must be rebuilt locally with Emscripten before the browser Wasm runtime reports Phase 64A.
- If the updated JavaScript protocol is served with an older Phase 64 Wasm artifact, the app may report a stale artifact or protocol mismatch until rebuilt.
- Separate planned-memory switch paths remain. They were audited and tested for Phase 64A, but a future descriptor-table refactor may reduce drift risk.
- No future syntax or runtime feature was added by this milestone.

## 18. Next recommended milestone

The next recommended milestone is:

```text
Phase 64B - Simulator Message Runtime Notice Ordering and Grouping
```

If Phase 64B and Phase 64C are not adopted or after they are complete, the next normal control-flow implementation phase remains:

```text
Phase 65 - Signed Relational Conditional Jumps
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

- `milestone_64A_implementation.zip`
- `milestone_64A_first_compliance_check.zip`
- `milestone_64A_second_compliance_check.zip`
- `milestone_64A_final_compliance_check.zip`

Final report file produced:

- `Milestone 64A report.md`

Recommended final repository archive name:

- `Latest_repository_state_milestone_64A.zip`
