# Milestone 60 report - Direct JMP Parsing and Target Lowering

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 60 - Direct JMP Parsing and Target Lowering
```

Repository/archive milestone after this work:

```text
Phase 60 - Direct JMP Parsing and Target Lowering
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 60 - Direct JMP Parsing and Target Lowering
```

Runtime branch execution behavior:

```text
Not implemented in this phase; this phase records metadata, validates labels, classifies targets, and lowers direct branch metadata only.
```

Scope implemented:

- Added direct `jmp label` parsing for executable code-label targets and procedure-entry targets.
- Added direct branch target classification for `jmp` using the shared branch target classifier rules from the implementation guide.
- Added branch-target IR metadata so later phases can execute already-lowered direct branches without reclassifying source-level labels.
- Added transitional Phase 60 runtime behavior for a valid lowered direct `jmp`:
  - stop with `branch-runtime-deferred`;
  - do not apply branch transfer;
  - do not mutate instruction pointer, registers, modeled flags, Phase 50A flag-validity metadata, memory, Program Console output, or memory-change rows;
  - do not execute instructions after the `jmp`;
  - do not emit `execution-complete`.
- Preserved Phase 59 source-run instruction-accounting fields:
  - `instructionLimit`;
  - `executedInstructionCount`;
  - `attemptedNextInstructionIndex`;
  - `currentInstructionIndex`.
- Added invalid direct-JMP target diagnostics for the rejected target classes required by the guide.
- Updated documentation/status surfaces to Phase 60 while clearly stating that runtime branch transfer remains deferred to Phase 61.
- Updated the website default editor sample to visibly exercise the new `jmp done` syntax.

Scope intentionally not implemented:

- Runtime instruction-pointer transfer for `jmp`.
- Executable branch transfer to target labels.
- Branch-loop behavior.
- Conditional jumps.
- `loop`.
- `call`, `ret`, `leave`, procedure invocation, stack behavior, or stack-frame behavior.
- Procedure-entry semantics beyond direct target metadata.
- Debugger stepping over branch execution.
- Indirect jumps, register-target jumps, memory-target jumps, or immediate-target jumps.
- `SHORT`, `NEAR PTR`, or `FAR PTR` branch-distance/type override support.
- Irvine32 routine calls.
- Windows API, PE loader/linker, object-file linkage, or host include behavior.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 59 report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_59.zip
```

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_60.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, current-status surface hygiene, and broad product constraints.
- The implementation guide owns Phase 60 numbering, exact phase scope, tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

## 3. Exact requirements implemented

### 3.1 Accepted direct JMP syntax

Implemented accepted syntax:

```asm
jmp codeLabel
jmp procedureEntryLabel
```

Accepted target classes:

- Code label from `name:` with an executable target instruction.
- Procedure-entry label from `name PROC` when the procedure body has a first executable instruction.

Procedure-entry targets are treated as direct branch targets only. They do not imply `CALL`, `RET`, stack mutation, calling-convention behavior, `USES`, `LOCAL`, `PROTO`, `INVOKE`, procedure frames, or Irvine32 routine behavior.

### 3.2 Shared direct branch target classification

Phase 60 uses the shared direct branch target classification required by the guide.

Implemented/rejected target behavior includes:

- Accepted: executable code labels.
- Accepted: procedure-entry labels with a first executable target instruction.
- Rejected: code labels with no executable target.
- Rejected: procedure-entry labels with no executable target.
- Rejected: data symbols.
- Rejected: numeric equates or constant symbols.
- Rejected: Irvine32 virtual routine or virtual terminator names such as `exit` as direct JMP targets.
- Rejected: unknown identifiers.
- Rejected: empty/missing operands.
- Rejected: immediate numeric targets.
- Rejected: register targets.
- Rejected: memory targets.
- Rejected: distance/type override forms such as `SHORT`, `NEAR PTR`, and `FAR PTR`.
- Rejected: directive-name and instruction-name targets.
- Rejected: Windows/API/external-symbol-style targets where applicable.

Rejected-target diagnostics point at the branch operand whenever the operand exists. Missing-target diagnostics point at the malformed `jmp` site using the existing parser diagnostic mechanism.

### 3.3 IR/lowering metadata

Implemented IR support for a lowered direct branch target:

- Added a `jmp` IR opcode.
- Added a branch-target operand kind/metadata path for resolved VM instruction indexes.
- Added parser lowering from valid source-level `jmp label` to IR branch-target metadata.
- Kept label metadata as parser/source metadata until consumed by direct branch lowering.

This makes Phase 61 able to consume already-lowered target metadata without reclassifying source-level symbols during normal runtime execution.

### 3.4 Deferred runtime behavior

Implemented the Phase 60 transitional runtime boundary:

```text
branch-runtime-deferred
```

When execution reaches a valid lowered `jmp`, the executor/source-run path stops before applying branch transfer.

Required no-partial-mutation behavior was implemented:

- no branch decision is applied;
- instruction pointer is not mutated for control transfer;
- registers are unchanged by the `jmp`;
- modeled flags are unchanged by the `jmp`;
- Phase 50A flag-validity metadata is unchanged by the `jmp`;
- memory is unchanged by the `jmp`;
- Program Console output is unchanged by the `jmp`;
- no memory-change row is created by the `jmp`;
- instructions after the `jmp` do not execute;
- `execution-complete` is not emitted.

Rendered user-facing wording uses stable future-phase wording and does not say “not implemented in this milestone,” “unsupported by the current milestone,” or equivalent milestone-relative wording.

### 3.5 Phase 59 accounting integration

Implemented required metadata behavior for a deferred `jmp`:

```text
executedInstructionCount = number of previously committed VM instructions
attemptedNextInstructionIndex = index of the lowered jmp instruction that was reached but not executed
currentInstructionIndex = last committed instruction index, or null if no instruction committed before the jmp
```

Preserved existing public JSON field names from Phase 59. No new public source-run JSON fields were added just for Phase 60.

Instruction-limit precedence was preserved: if `instructionLimit` blocks a later `jmp` before it is reached, the diagnostic remains `instruction-limit-exceeded`, not `branch-runtime-deferred`.

### 3.6 Diagnostics implemented

Added or extended structured diagnostics for:

- `branch-runtime-deferred` runtime error;
- `invalid-branch-target` assembly errors;
- `unsupported-branch-target-form` assembly errors;
- existing malformed/missing-operand diagnostic paths for missing `jmp` target.

Rendered Simulator Messages coverage was added for the Phase 60 user-visible diagnostic paths, including all rejected target classes required by the guide after the second compliance pass.

### 3.7 Current-status and user-visible documentation

Updated status surfaces to Phase 60:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- browser-visible status in `web/index.html`
- worker/protocol status surfaces
- tests asserting phase/status metadata

Documentation now states that direct `jmp label` parser/lowering is current behavior, while runtime branch transfer remains deferred to Phase 61 - Direct JMP Runtime Execution.

### 3.8 Browser visible syntax sample

A user-test follow-up identified that `web/index.html` still showed an older default sample. This was corrected so the page-load editor sample visibly includes the newly accepted direct-JMP syntax:

```asm
.code
main PROC
    mov eax, 1
    jmp done
    mov ebx, 2
done:
    mov ecx, 3
main ENDP
END main
```

Static test coverage was added so the default page sample must include `jmp done` / `done:`.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 60:

- Direct `jmp` runtime branch transfer.
- Runtime instruction-pointer mutation for branch execution.
- Branch-loop behavior or backward-branch execution.
- Conditional jumps.
- `loop`.
- `call`, `ret`, `leave`, stack instructions, stack-frame setup, call depth limits, or call tracing.
- Procedure invocation semantics.
- Direct branch execution count as a committed instruction. That belongs to Phase 61.
- Runtime diagnostics for malformed branch metadata beyond the deferred boundary. Phase 61 owns runtime execution and malformed-target runtime behavior.
- Indirect branch support.
- Register-target or memory-target `jmp` support.
- Immediate-target `jmp` support.
- `SHORT`, `NEAR PTR`, or `FAR PTR` branch-distance/type overrides.
- Irvine32 routine calls beyond already-existing virtual `exit` behavior.
- Windows API calls, PE loading/linking, host filesystem include loading, or object-file linkage.
- Debugger stepping, breakpoints, source navigation, or editor branch navigation.
- High-level MASM flow such as `.IF`, `.ELSE`, `.ENDIF`, `.WHILE`, `.REPEAT`, `.BREAK`, or `.CONTINUE`.

Future work intentionally preserved:

- Phase 61 - Direct JMP Runtime Execution.
- Later conditional jump phases.
- Later `loop` phase.
- Later `cmp` phases and conditional branch consumers.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Later execution-control UI and settings phases if the guide requires them.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 60 advances both repository/archive milestone and runtime/source-run MASM behavior phase.
- **Reason:** Phase 60 changes parser behavior, IR lowering, source-run runtime diagnostics, user-visible Simulator Messages, status documentation, protocol/status metadata, and the default website sample.
- **Risk:** Status surfaces must consistently report Phase 60 even though executable branch transfer is still deferred.
- **How to change later:** If a reviewed guide revision reclassifies Phase 60 as parser-only without runtime/source-run metadata advancement, use the repository/runtime split block and keep runtime/source-run behavior metadata at Phase 59. The current guide does not support that interpretation.

### Assumption 2

- **Assumption:** `branch-runtime-deferred` is a runtime error, not an assembly error.
- **Reason:** A valid `jmp label` parses, classifies, and lowers successfully in Phase 60. The failure occurs only when runtime reaches the accepted-but-not-yet-executable branch instruction.
- **Risk:** Users may interpret “runtime error” as a program bug rather than a simulator phase boundary.
- **How to change later:** Phase 61 must remove the transitional runtime-deferred diagnostic for valid direct `jmp label` and replace it with actual instruction-pointer transfer.

### Assumption 3

- **Assumption:** Existing Phase 58 code-label metadata is the correct source for direct branch target resolution.
- **Reason:** The guide requires Phase 60 to use the shared direct branch target classifier and Phase 58 already records code labels, procedure-entry labels, executable-target availability, and target instruction indexes.
- **Risk:** If future branch families require richer target metadata, Phase 60’s minimal branch-target metadata may need extension.
- **How to change later:** Add documented helper APIs or metadata fields in the owning future branch phase without reclassifying source-level labels during runtime.

### Assumption 4

- **Assumption:** A lowered direct branch target should use an explicit IR branch-target operand/metadata representation rather than reusing an unrelated immediate/register/memory operand form.
- **Reason:** A branch target is not an arithmetic immediate or data memory operand. A distinct representation makes Phase 61 runtime consumption clearer.
- **Risk:** The IR surface grows slightly before executable branch behavior exists.
- **How to change later:** Phase 61 may refine branch-target validation helpers while preserving the public/parser semantics added in Phase 60.

### Assumption 5

- **Assumption:** Rejected target diagnostics should use a small set of stable diagnostic codes with target-specific messages rather than one code per target class.
- **Reason:** This keeps diagnostics structured but avoids unnecessary diagnostic-code explosion.
- **Risk:** Tests must assert the message text for each target class to preserve user-facing precision.
- **How to change later:** A later diagnostic-cleanup phase can split diagnostic codes more granularly while preserving exact rendered-message coverage.

### Assumption 6

- **Assumption:** Website manual verification requires a fresh Emscripten/Wasm rebuild after C changes.
- **Reason:** Phase 60 changes C parser/core/source-run behavior, and stale `web/dist` artifacts would not reflect the updated behavior.
- **Risk:** A user may run the old served artifacts and see Phase 59 behavior.
- **How to change later:** Rebuild with `scripts\windows\build_wasm.cmd` in an Emscripten-enabled environment before browser testing.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning, implementation, compliance review, and final gap check:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Shared Direct Branch Target Classification section
- Note text or summary:
  The shared classifier applies to Phase 58, Phase 60, Phase 61, and later direct branch phases. Direct branches must use the same target classifier and must reject data symbols, equates, Irvine32 symbols, unknown targets, register targets, memory targets, and distance/type overrides unless a later phase changes the rule.
- Classification:
  target-owned
- Reason:
  Phase 60 is the first direct `jmp` parser/lowering phase and must consume this classifier.
- Action for this milestone:
  Implemented and tested for direct `jmp`.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 60 - Direct JMP Parsing and Target Lowering
- Note text or summary:
  Phase 60 accepts, classifies, and lowers direct `jmp label`, but runtime branch execution remains deferred to Phase 61. Reaching a lowered `jmp` must stop with `branch-runtime-deferred`.
- Classification:
  target-owned
- Reason:
  This is the central runtime boundary for TARGET_MILESTONE.
- Action for this milestone:
  Implemented and tested with structured source-run and rendered-message coverage.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 60 deferred JMP execution-count and diagnostic metadata
- Note text or summary:
  A deferred `jmp` is an attempted instruction, not a committed instruction. Source-run metadata should preserve `executedInstructionCount`, `attemptedNextInstructionIndex`, and `currentInstructionIndex` semantics.
- Classification:
  target-owned
- Reason:
  Phase 60 must integrate with Phase 59 instruction-count accounting without inventing unnecessary new JSON fields.
- Action for this milestone:
  Implemented and tested.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 60 required tests
- Note text or summary:
  Required tests include accepted code-label and procedure-entry targets; rejected data/equate/Irvine/unknown/register/memory/distance targets; source-run `branch-runtime-deferred`; no-partial-mutation; rendered diagnostics.
- Classification:
  target-owned
- Reason:
  These are acceptance tests for TARGET_MILESTONE.
- Action for this milestone:
  Implemented. Second compliance review added exact rendered-message coverage for all remaining rejected target classes.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md deferred-feature sections
- Note text or summary:
  Control flow was previously listed as deferred after Phase 59.
- Classification:
  target-owned
- Reason:
  Phase 60 changes current parser/lowering behavior for direct `jmp label`, while executable branch transfer remains future work.
- Action for this milestone:
  Updated wording to distinguish direct-JMP parser/lowering support from deferred runtime branch execution.
```

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  Future memory-reading opcodes should be added to the planned-access classification path when implemented.
- Classification:
  future-owned
- Reason:
  Phase 60 direct `jmp` is not a memory-reading opcode.
- Action for this milestone:
  Left in place.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61 - Direct JMP Runtime Execution
- Note text or summary:
  Phase 61 owns actual instruction-pointer transfer for already-lowered direct branch instructions.
- Classification:
  future-owned
- Reason:
  TARGET_MILESTONE is Phase 60, which explicitly must not execute branches.
- Action for this milestone:
  Left for Phase 61. No runtime branch transfer was implemented.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Shared direct branch target classification was consumed for direct `jmp`.
- Phase 60 parser/lowering behavior was implemented.
- Phase 60 transitional `branch-runtime-deferred` runtime boundary was implemented.
- Phase 59 instruction-count metadata integration for attempted-but-not-committed `jmp` was implemented.
- Supported-syntax/status wording was updated to distinguish direct-JMP parser/lowering support from future runtime branch transfer.
- Rendered-message coverage was added for every Phase 60 rejected-target diagnostic class required by the guide.

### Future-owned TODO-style notes intentionally preserved

- Future memory-reading opcode planned-access note in `src/wasm/wasm_api.c`.
- Phase 61 direct JMP runtime execution.
- Conditional jumps.
- `loop`.
- `call`, `ret`, stack behavior, procedure frames, and call-depth behavior.
- Indirect branches, register/memory jumps, branch-distance override support, and debugger branch behavior.
- Irvine32 callable routines beyond already-existing virtual `exit` termination.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style notes were found.

Stale non-TODO wording/comments corrected during review:

- Rejected-JMP diagnostic wording that referenced Phase 60 too locally was changed to stable future-feature wording.
- `docs/SUPPORTED_SYNTAX.md` wording that still said control-flow target resolution was not implemented was corrected.
- `tests/core/test_parser.c` stale file/comment wording was updated through Phase 60.
- `src/core/vm_exec.h` and `src/parser/parser.h` file headers were updated to include Phase 60 direct-JMP deferred-runtime/lowering metadata.
- `web/index.html` default visible sample was updated to include `jmp done`.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 60 was implemented as a parser/lowering and transitional-runtime-boundary milestone.

Primary design choices:

1. **Use shared branch target classification.** Direct `jmp` target handling uses the shared rules from the guide instead of adding a separate `jmp`-specific target classifier.

2. **Reuse Phase 58 label metadata.** Existing code-label/procedure-entry metadata is the authoritative source for target classification and target instruction indexes.

3. **Lower valid direct JMP into IR metadata.** Valid `jmp label` source is converted into a `jmp` IR instruction with branch-target metadata, preparing Phase 61 to implement branch transfer without source-level reclassification.

4. **Defer runtime transfer explicitly.** A lowered `jmp` does not silently fall through or act as a no-op. Reaching it returns `branch-runtime-deferred` and stops execution.

5. **Preserve no-partial-mutation guarantees.** The deferred boundary stops before branch mutation or subsequent-instruction execution, preserving registers, flags, memory, Program Console, and memory-change rows.

6. **Preserve Phase 59 accounting schema.** Existing source-run fields represent the deferred `jmp` as an attempted but uncommitted instruction.

7. **Keep diagnostics stable and source-span-aware.** Rejected target diagnostics point at the target operand where possible and avoid milestone-relative wording.

8. **Keep user-visible status precise.** Documentation and website text say direct-JMP parsing/lowering is current, while runtime branch execution remains future Phase 61 work.

9. **Avoid future control flow.** No branch execution, conditional jumps, stack/procedure behavior, or indirect branch behavior was implemented.

## 9. Files changed

Files changed across implementation, first compliance review, second compliance review, user-test follow-up, and final gap check:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_ir.c`
- `src/core/vm_ir.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`
- `web/src/worker.js`

No C++ core files were introduced. Core implementation remains C99.

## 10. Tests added

### Parser tests

Added or extended tests for:

- `jmp codeLabel` accepted and lowered.
- `jmp procedureEntryLabel` accepted as a direct target only.
- Data-symbol target rejection.
- Numeric equate target rejection.
- Unknown target rejection.
- Missing/empty target rejection.
- Register target rejection.
- Memory target rejection.
- Irvine32 virtual symbol target rejection.
- Immediate numeric target rejection.
- Directive-name target rejection.
- Instruction-name target rejection.
- Windows/API/external-style target rejection.
- Code label with no executable target rejection.
- Procedure-entry label with no executable target rejection.
- `SHORT label`, `NEAR PTR label`, and `FAR PTR label` rejection.
- Source-span behavior for rejected targets.
- Stable future-feature wording for distance/type override diagnostics.

### Source-run and executor tests

Added or extended tests for:

- Valid lowered `jmp` after one committed instruction.
- Valid lowered `jmp` as the first executable instruction.
- `branch-runtime-deferred` source-run status.
- No `execution-complete` after reaching a lowered `jmp`.
- Instructions after `jmp` do not execute.
- No register, flag, memory, Program Console, or memory-change mutation caused by the deferred `jmp`.
- `executedInstructionCount`, `attemptedNextInstructionIndex`, and `currentInstructionIndex` behavior.
- Phase 59 instruction-limit precedence before a later `jmp`.

### Rendered Simulator Messages tests

Added exact rendered-message coverage for:

- `branch-runtime-deferred`.
- Data-symbol invalid target.
- Numeric equate invalid target.
- Unknown target.
- Label with no executable target.
- Irvine32 virtual symbol target.
- Register target.
- Memory target.
- Distance/type override target.
- Immediate numeric target.
- Directive-name target.
- Instruction-name target.
- Windows/API external-style target.
- Missing target / expected operand.

### Protocol/status/static tests

Added or updated tests for:

- Phase 60 repository/runtime status metadata.
- Worker/protocol Phase 60 status strings.
- Browser-visible status text.
- `web/index.html` default visible sample containing `jmp done` / `done:`.
- Documentation/status consistency.
- Supported syntax text distinguishing parser/lowering support from future runtime branch execution.

### Regression tests

Added or preserved regressions for:

- Phase 58 label metadata remains parser/source metadata.
- Labels still do not count as executable instructions by themselves.
- Phase 59 instruction-limit behavior remains authoritative when the limit blocks a next instruction before `jmp` is reached.
- Unsupported `call`, `ret`, `loop`, conditional jumps, indirect branch forms, and stack/procedure behavior remain unsupported.
- Program Console and Simulator Messages remain separate.
- Existing virtual `exit` behavior remains available as a terminator when `INCLUDE Irvine32.inc` is active, while `jmp exit` remains invalid as a direct branch target.

## 11. Commands used to test

### Aggregate commands

Pre-implementation repository verification aggregate command:

```bash
python3 scripts/run_tests.py --all
```

Observed result:

```text
Timed out in the assistant/container environment before final aggregate status.
```

Implementation-pass aggregate command:

```bash
python3 scripts/run_tests.py --all
```

Observed result:

```text
Timed out in the assistant/container environment before final aggregate status.
```

Compliance/final aggregate command:

```bash
python3 scripts/run_tests.py --all
```

Observed final result after compliance fixes:

```text
All implemented milestone tests passed.
```

### Focused group commands

Focused commands run during verification, implementation, compliance review, re-review, user-test follow-up, and final gap check:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused results across final passing runs:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Subgroup or fixture-family commands

No documented subgroup or individual fixture-family reruns were required. When chained focused commands timed out in the assistant/container environment, the remaining focused groups were rerun individually.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is a dependency skip, not a project test failure. Served-browser testing with freshly rebuilt Wasm requires Emscripten locally or in CI.

## 12. Pass/fail results

Final result classification:

```text
aggregate completed and passed
group skipped because a dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

Detailed classification:

- The initial aggregate run during repository verification timed out in the assistant/container environment; focused groups passed.
- The implementation-pass aggregate run timed out in the assistant/container environment; focused groups passed.
- Later compliance/final aggregate runs completed and passed.
- All focused groups completed and passed in final verification:
  - `--structure`
  - `--native`
  - `--source-run`
  - `--web`
  - `--diagnostics`
  - `--protocol`
  - `--static`
- One or more chained focused-command runs timed out after `--web` completed. Remaining groups were rerun individually and passed. This was an assistant/container command-chain timeout, not a project test failure.
- No focused group failed.
- No focused group timeout remained unresolved.
- No subgroup or fixture-family rerun was required.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Phase 60 is website-testable after rebuilding Wasm with Emscripten.

### Browser setup on Windows

From the project root in an Emscripten-enabled Windows CMD environment:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the served URL, usually:

```text
http://localhost:8000
```

### Browser program 1 - default Phase 60 JMP sample

The default editor should contain:

```asm
.code
main PROC
    mov eax, 1
    jmp done
    mov ebx, 2
done:
    mov ecx, 3
main ENDP
END main
```

Expected Simulator Messages include:

```text
[runtime-error] branch-runtime-deferred line 4, column 5, byte offset 35, span length 8: Direct JMP was parsed and resolved, but runtime branch execution is deferred to Phase 61 - Direct JMP Runtime Execution. Execution stopped before applying the jump.
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

Expected key final registers:

```text
EAX = 00000001h / u: 1 / s: 1
EBX = 00000000h / u: 0 / s: 0 [unchanged]
ECX = 00000000h / u: 0 / s: 0 [unchanged]
```

Regression signs:

- `jmp done` is rejected as unsupported or unknown.
- `EBX` becomes `2`.
- `ECX` becomes `3`.
- `execution-complete` appears after reaching `jmp done`.
- Browser status still reports Phase 59.
- Default editor does not show `jmp done`.

### Browser program 2 - data symbol target rejection

```asm
.data
value DWORD 1
.code
main PROC
    jmp value
    mov eax, 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-branch-target line 5, column 9, byte offset 44, span length 5: JMP target cannot be a data symbol. Direct JMP accepts only code labels with executable instruction targets.
```

Expected behavior:

- Program Console empty.
- No memory changes.
- No register state available.
- Execution does not begin.

Regression signs:

- Program executes.
- `EAX` becomes `1`.
- Diagnostic uses vague or stale milestone-relative wording.
- Diagnostic points at the `jmp` mnemonic rather than target operand `value`.

### Browser program 3 - register target remains unsupported

```asm
.code
main PROC
    jmp eax
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-branch-target-form line 3, column 9, byte offset 24, span length 3: JMP register targets are not supported for direct JMP. Indirect branch behavior is deferred to a later branch phase.
```

Expected behavior:

- Program Console empty.
- No memory changes.
- No register state available.
- Execution does not begin.

Regression signs:

- `jmp eax` is accepted.
- Diagnostic implies indirect jumps are implemented.
- Message uses Phase 60 as a permanent limitation rather than saying indirect behavior is deferred.

### Browser program 4 - unknown target rejection

```asm
.code
main PROC
    jmp missingLabel
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-branch-target line 3, column 9, byte offset 24, span length 12: JMP target is not a known code label or procedure-entry label.
```

Expected behavior:

- Program Console empty.
- No memory changes.
- No register state available.
- Execution does not begin.

Regression signs:

- Program executes.
- Unknown label is silently accepted.
- Diagnostic lacks line, column, byte offset, or span length.

### Local Windows CMD test-suite checks

`program.asm` is not applicable for the local focused test-suite checks. Phase 60 fixtures are already embedded in the project tests.

From the project root:

```cmd
python scripts\run_tests.py --source-run
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --web
python scripts\run_tests.py --static
```

Expected snippets:

```text
[source-run] PASS - source-run integration binary passed independently
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[web] PASS - browser-side Node module tests passed
[static] PASS - runner/documentation consistency checks passed
Selected test groups passed.
```

Optional full suite:

```cmd
python scripts\run_tests.py --all
```

Expected snippet if the local machine completes the aggregate run:

```text
All implemented milestone tests passed.
```

If `emcc` is unavailable, the test runner may print:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

That skip is acceptable for local non-Wasm verification. It is not sufficient for browser runtime verification after C changes; website runtime testing requires a fresh Wasm rebuild.

## 14. Compliance review summary

First compliance review found and fixed:

- A rejected-JMP diagnostic used phase-local wording: “not supported in Phase 60 direct JMP parsing.” It was changed to stable future-feature wording.
- `docs/SUPPORTED_SYNTAX.md` still had stale wording saying control-flow target resolution was not implemented. It was corrected to parser/lowering-only support.
- `tests/core/test_parser.c` had a stale comment saying parser tests were “through Milestone 57.” It was updated.
- Parser coverage was short for some rejected-target classes. Tests were added for `NEAR PTR`, `FAR PTR`, immediate target, directive-name target, instruction-name target, and Windows/API external target.
- Rendered-message coverage did not include `unsupported-branch-target-form` or missing-target `expected-operand`. Exact rendered-message tests were added.

First compliance review test result:

- Focused groups passed.
- Aggregate completed and passed.
- Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

Verdict after first compliance review:

```text
complete
```

## 15. Re-review summary

Second compliance review found:

- Rendered Simulator Messages tests still did not cover every Phase 60 rejected direct-JMP target class required by the guide.

Second review fixes:

- Added exact rendered-message coverage for:
  - numeric equate target;
  - unknown target;
  - label with no executable target;
  - Irvine32 virtual symbol target;
  - memory target;
  - distance/type override target;
  - immediate numeric target;
  - directive-name target;
  - instruction-name target;
  - Windows/API external target.

Second compliance review test result:

- Focused groups passed.
- Aggregate completed and passed.
- Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

Final scope verdict from second review:

```text
complete
```

Final documentation verdict from second review:

```text
complete
```

Final test coverage verdict from second review:

```text
complete
```

Final TODO-style note verdict from second review:

```text
complete
```

## 16. User-test follow-up summary

The user observed that `web/index.html` did not visibly show the newly accepted syntax in the default web editor sample.

Follow-up fix:

- Updated the default editor sample in `web/index.html` to include `jmp done` and `done:`.
- Added static-test coverage so the default sample must include `jmp done` / `done:`.

Follow-up tests run:

```bash
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --structure
```

Observed result:

```text
PASS
```

Browser/Wasm rebuild smoke remained skipped because `emcc` was unavailable in the assistant/container environment.

## 17. Known limitations

Known limitations after Phase 60:

- Runtime branch transfer is not implemented. Phase 61 owns direct `jmp` execution.
- Valid direct `jmp label` stops with `branch-runtime-deferred` when reached.
- Conditional jumps are not implemented.
- `loop` is not implemented.
- `call`, `ret`, stack behavior, procedure frames, and call depth behavior are not implemented.
- Indirect, register-target, memory-target, immediate-target, `SHORT`, `NEAR PTR`, and `FAR PTR` branch forms remain rejected.
- Debugger branch stepping/navigation behavior is not implemented.
- Browser/Wasm artifacts must be rebuilt with Emscripten for served-browser testing; this environment could not run the browser/Wasm rebuild smoke because `emcc` was unavailable.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 61 - Direct JMP Runtime Execution
```

Expected Phase 61 direction:

- Execute already-lowered direct branch instructions.
- Branch to the target VM instruction index.
- Count `jmp` as an executed instruction.
- Preserve modeled flags.
- Produce no memory-change row.
- Respect the Phase 59 instruction-count watchdog.
- Keep conditional jumps, `loop`, stack/procedure behavior, indirect branches, and Irvine32 routine calls deferred unless their own later phase explicitly implements them.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during this milestone:

- `phase60_changed_files.zip`
- `milestone_60_first_compliance_check.zip`
- `milestone_60_second_compliance_check.zip`
- `milestone_60_index_html_visible_syntax_fix.zip`
- `milestone_60_final_compliance_check.zip`

Final changed-files package from final compliance pass:

```text
milestone_60_final_compliance_check.zip
```

Recommended full repository archive name after applying all Phase 60 changes:

```text
Latest_repository_state_milestone_60.zip
```

A full repository archive was not created as part of this report prompt. The changed-files ZIP packages listed above preserve repository structure for the files changed in their respective passes.
