# Milestone 50 report - ROR

## 1. Milestone title and scope

Milestone 50 implements **Phase 50 - ROR** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added executable runtime support for `ror`.
- Supported register destinations at 8-bit, 16-bit, and 32-bit widths.
- Supported unambiguous memory destinations through:
  - typed data symbols;
  - symbol offsets;
  - explicit unsigned `BYTE PTR`, `WORD PTR`, and `DWORD PTR` forms;
  - explicit signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases.
- Supported immediate byte rotate counts and `CL` as the only register rotate-count operand.
- Applied the existing MASM/x86-compatible count masking policy for 32-bit educational mode:

```text
effective_count = raw_count & 31
```

- Applied rotate amount calculation for operand width:

```text
rotate_amount = effective_count % operand_width
```

- Preserved effective-count-zero no-op behavior: destination and modeled flags are unchanged and no warning is emitted.
- Implemented rotate-right semantics: bits shifted out of bit 0 are rotated into the most significant bit of the selected operand width.
- Updated `CF` for nonzero effective counts from the most significant bit of the rotated result.
- Preserved `ZF` and `SF` for all nonzero `ROR` counts because `ROR` does not define them.
- Defined `OF` for effective count `1` as the XOR of the two most significant bits of the rotated result.
- Implemented default-mode `undefined-modeled-flag` warnings for non-one nonzero `ROR` counts where `OF` is architecturally undefined while allowing execution to complete.
- Preserved strict undefined-shift validation as shift-only; `ROR` undefined modeled-flag warnings do not become strict-mode runtime errors in this milestone.
- Preserved all prior milestone behavior, especially Phase 46 `shl`/`sal`, Phase 47 `shr`, Phase 48 `sar`, and Phase 49 `rol` behavior.
- Updated source-run and browser metadata to report phase `50`.
- Added native C, parser, executor, source-run JSON, rendered Simulator Messages, protocol/static, documentation, manual-testing, compliance, re-review, user-test follow-up, and final gap-check coverage.

The implementation stayed within the milestone boundary. No future smart flag-validity metadata, flag-consumer diagnostics, carry rotates, control-flow, stack, procedure, Irvine32 expansion, QWORD/SQWORD execution, PF/AF, WinAPI, PE, linker, or macro behavior was implemented.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 49 report.md`

Repository archive used as the implementation base:

- `Latest_repository_state_milestone_49.zip`

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.
- Phase 50 is the only target milestone for this work session.

## 3. Exact requirements implemented

Phase 50 required `ror` as the rotate-right counterpart to Phase 49 `rol`, while reusing the existing rotate destination/count policy.

Accepted syntax implemented:

```asm
ror reg, 1
ror reg, imm
ror reg, cl
ror mem, 1
ror mem, imm
ror mem, cl
```

Supported register destinations:

```text
reg8
reg16
reg32
```

Supported memory destinations:

```asm
ror BYTE PTR [eax], 1
ror WORD PTR [eax], 1
ror DWORD PTR [eax], 1
ror SBYTE PTR [eax], 1
ror SWORD PTR [eax], 1
ror SDWORD PTR [eax], 1
ror value, 1
ror values[4], 1
```

Rejected syntax verified:

```asm
ror 1, al
ror eax, ebx
ror eax, cx
ror eax, ecx
ror eax
ror eax, 1, 2
ror [eax], 1
ror QWORD PTR q, 1
ror SQWORD PTR q, 1
```

Runtime semantics implemented:

- Raw count source:
  - immediate byte count; or
  - low 8 bits of `ECX` when the count operand is `CL`.
- Effective count:

```text
effective_count = raw_count & 31
```

- Rotate amount:

```text
rotate_amount = effective_count % operand_width
```

- Effective count `0`:
  - destination unchanged;
  - `CF`, `ZF`, `SF`, and `OF` unchanged;
  - no `undefined-modeled-flag` warning.
- Nonzero effective count:
  - destination is rotated right within the selected operand width;
  - bits leaving bit 0 re-enter at the most significant bit;
  - `CF` receives the most significant bit of the rotated result;
  - `ZF` is preserved;
  - `SF` is preserved.
- Effective count `1`:
  - `OF` is set to the XOR of the two most significant bits of the rotated result;
  - no `undefined-modeled-flag` warning.
- Effective count not equal to `1` and nonzero:
  - `OF` is architecturally undefined;
  - the simulator preserves the previous `OF` deterministically;
  - default mode emits `undefined-modeled-flag` warning;
  - execution continues and may still complete successfully.
- Counts such as `ror al, 8` or `ror ax, 16` are not full no-ops under this project policy because `effective_count` is nonzero. Their destination bits are unchanged because `rotate_amount` is zero, but nonzero rotate flag behavior still applies and a warning is emitted for undefined `OF`.
- Counts such as `ror eax, 32` are full no-ops because `effective_count` is zero.

Diagnostics implemented or verified:

- `undefined-modeled-flag` warning for non-one nonzero `ROR` counts where `OF` is architecturally undefined.
- Warning text includes both `effective_count` and `rotate_amount`, so operand-width wrap cases such as 8-bit count 8 and 16-bit count 16 are explicit.
- `ambiguous-memory-width` for untyped memory destinations such as `ror [eax], 1`.
- `invalid-instruction-operands` for immediate destinations, missing counts, extra operands, and invalid count registers such as `EBX`, `CX`, and `ECX`.
- Existing unsupported-runtime diagnostics for executable `QWORD PTR` and `SQWORD PTR` memory operations remain in force.
- Existing runtime memory diagnostics for invalid addresses and `.CONST` permission failures remain structured and rendered.
- Diagnostic source location data remains preserved: line, column, byte offset, and span length where applicable.

Acceptance example:

```asm
.code
main PROC
    mov al, 01h
    ror al, 1
main ENDP
END main
```

Expected final state:

```text
EAX = 00000080h / 128
EFLAGS = 00000801h / 2049
```

Warning example:

```asm
.code
main PROC
    mov al, 80h
    ror al, 8
main ENDP
END main
```

Expected behavior:

```text
[simulator-warning] undefined-modeled-flag ... ROR count 8 has effective count 8 and rotate amount 0 for an 8-bit destination ...
[info] execution-complete: Execution completed successfully.
EAX = 00000080h / 128
EFLAGS = 00000001h / 1
```

Count-zero example:

```asm
.code
main PROC
    mov eax, 80000001h
    stc
    ror eax, 32
main ENDP
END main
```

Expected behavior:

```text
No warning.
Destination and modeled flags unchanged by ROR because effective_count is 0.
EAX = 80000001h / 2147483649
EFLAGS = 00000001h / 1
```

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 50:

- `rcl`, `rcr`, or other carry rotates.
- New shift behavior.
- Smart undefined-flag validity metadata.
- `undefined-flag-use` consumer diagnostics.
- Strict-before-mutation producer errors for `ROR`.
- `cmp`.
- Labels, `jmp`, conditional jumps, or `loop`.
- `lea`.
- `mul`, `imul`, `div`, or `idiv`.
- `push`, `pop`, `call`, `ret`, `leave`, or stack behavior.
- Procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`.
- Irvine32 routine bodies beyond the existing `exit` virtual terminator.
- Program Console input/output routines.
- Scaled-index addressing.
- Executable QWORD/SQWORD memory operations.
- PF/AF integration for rotates.
- Browser UI setting for strict undefined-shift validation.
- Windows API, PE loading, object linking, host include loading, or macro behavior.

Compile-time expression operator behavior remains separate from runtime instruction behavior. Existing expression behavior was preserved.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `ror` should be represented as a dedicated IR opcode.
- **Reason:** Dedicated opcode identity preserves source mnemonic clarity for diagnostics, tests, protocol/debug display, and future debugger output.
- **Risk:** Adds another opcode and executor case instead of using one generic rotate opcode with direction metadata.
- **How to change later:** A future internal normalization pass can share a lower-level rotate helper while preserving public opcode identity and original source mnemonic.

### Assumption 2

- **Assumption:** `ror` should reuse the existing Phase 49 rotate destination/count parser validation path where appropriate.
- **Reason:** Phase 50 uses the same destination forms, immediate count policy, and `CL`-only register count rule as Phase 49 `rol`.
- **Risk:** Reusing shared shift/rotate validation could accidentally inherit shift-specific diagnostic wording or behavior.
- **How to change later:** Keep mnemonic-specific diagnostics and tests; if future carry rotates are implemented, factor a neutral rotate validation helper with explicit direction and flag-policy parameters.

### Assumption 3

- **Assumption:** `ROR` undefined `OF` should use `undefined-modeled-flag`, not `undefined-shift-flag`.
- **Reason:** The guide and Phase 49 precedent use the general modeled-flag producer warning for rotate instructions while shifts use `undefined-shift-flag`.
- **Risk:** Existing UI/tests already know `undefined-shift-flag`, so the rotate warning code requires separate rendered-message coverage.
- **How to change later:** Keep the diagnostic code stable unless a diagnostic catalog revision intentionally changes it; if revised, update structured tests and rendered golden tests together.

### Assumption 4

- **Assumption:** Strict undefined-shift validation remains shift-only and does not reject `ROR` before mutation.
- **Reason:** Phase 50 excludes strict-before-mutation producer errors and smart flag-validity metadata for rotates.
- **Risk:** Users may expect strict shift validation to cover rotates too.
- **How to change later:** A future smart flag-validity phase can add producer validity tracking or consumer diagnostics without changing Phase 50 rotate execution semantics.

### Assumption 5

- **Assumption:** Phase metadata should advance to `50` in source-run JSON and browser protocol metadata.
- **Reason:** Prior runtime instruction milestones advanced metadata, and the test suite verifies current implemented phase information.
- **Risk:** Metadata updates touch browser/protocol files even though the primary behavior is in parser/executor code.
- **How to change later:** Centralize feature-level metadata if the project later separates runtime feature support from UI sample/status metadata.

### Assumption 6

- **Assumption:** PF and AF remain unmodeled and untouched in Phase 50.
- **Reason:** The current stable modeled flag set is `CF`, `ZF`, `SF`, and `OF`; PF/AF integration is outside Phase 50 scope.
- **Risk:** Future PF/AF implementation must revisit rotate helpers.
- **How to change later:** Implement PF/AF in a dedicated later flag-integration phase without changing the Phase 50 `CF/ZF/SF/OF` contract.

### Assumption 7

- **Assumption:** For nonzero rotate counts whose `rotate_amount` is zero, destination bits are unchanged but nonzero-count rotate flag behavior still applies.
- **Reason:** The guide distinguishes `effective_count` from `rotate_amount`; true no-op behavior applies only when `effective_count` is zero.
- **Risk:** Users may expect `ror al, 8` or `rol ax, 16` to behave like a complete no-op because the data value is unchanged.
- **How to change later:** If the project policy changes, update the guide/spec first, then adjust `ROL`/`ROR` runtime behavior, diagnostics, and regression tests together.

## 6. Design summary

### IR changes

One new opcode was added:

```text
VM_IR_OPCODE_ROR
```

The opcode-name helper was updated so diagnostics, tests, and future debugging output can identify the opcode as:

```text
ror
```

### Parser changes

The parser recognizes `ror` as a binary destination-mutating rotate instruction.

Parser behavior:

- Accepts register destinations.
- Accepts direct typed symbols and typed symbol offsets as memory destinations.
- Accepts explicit `BYTE PTR`, `WORD PTR`, and `DWORD PTR` memory forms.
- Accepts signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases by width.
- Accepts immediate byte rotate counts.
- Accepts `CL` as the only register count operand.
- Rejects immediate destinations.
- Rejects missing count and extra operands with `invalid-instruction-operands`.
- Rejects count registers other than `CL`, including `CX`, `ECX`, and general registers such as `EBX`.
- Rejects untyped memory destinations such as `ror [eax], 1` with `ambiguous-memory-width`.
- Preserves existing QWORD/SQWORD executable memory-operation rejection.
- Emits static `.CONST` write diagnostics for direct `.CONST` destinations where existing static detection applies.

### Executor changes

The executor handles `ROR` through a rotate-right read-modify-write path.

Execution algorithm:

1. Resolve and validate destination and rotate-count operands.
2. Resolve raw count from immediate or `CL`.
3. Compute effective count as `raw_count & 31`.
4. If effective count is zero, return success without mutation.
5. Read destination value.
6. Save pre-instruction CPU/flag state for rollback on failed writes.
7. Compute rotate amount as `effective_count % operand_width`.
8. Rotate the destination right within the operand width.
9. Update or preserve modeled flags according to Phase 50 rules.
10. Write result back to register or memory destination.
11. If a memory write fails, restore CPU/flag state so no partial mutation is visible.

Memory behavior:

- All memory reads go through checked VM read helpers.
- All memory writes go through checked VM write helpers.
- `.CONST` permission checks remain enforced by final address range.
- Invalid reads occur before write-back.
- Failed writes do not create successful memory-change rows.

### Source-run and diagnostics changes

The source-run path emits default-mode `undefined-modeled-flag` warnings before executing `ROR` instructions where `OF` is architecturally undefined.

Warning-only runs continue to execute and may end with both:

```text
[simulator-warning] undefined-modeled-flag ...
[info] execution-complete: Execution completed successfully.
```

Strict undefined-shift validation remains shift-only. It does not convert `ROR` producer warnings into runtime errors.

The warning message includes both `effective_count` and `rotate_amount` to avoid confusion for operand-width wrap cases:

```text
ROR count 8 has effective count 8 and rotate amount 0 for an 8-bit destination.
```

### Documentation and metadata

Updated documentation and metadata to describe Phase 50 as the current implemented milestone and list `ror` as a supported runtime instruction.

## 7. Files changed

Final Phase 50 implementation, compliance, diagnostic-quality, user-test follow-up, and final gap-check work touched these files across the cumulative milestone work:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

## 8. Tests added

### Parser tests

Added or expanded coverage for:

- `ror al, 1`
- `ror ax, 1`
- `ror eax, 1`
- `ror eax, 0`
- `ror eax, 32`
- `ror eax, cl`
- mixed-case mnemonic recognition such as `RoR`
- explicit `BYTE PTR`, `WORD PTR`, and `DWORD PTR` memory destinations
- explicit signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases
- direct typed symbol destinations
- symbol-offset destinations
- immediate destination rejection
- missing count rejection
- extra operand rejection
- invalid count register rejection for `EBX`, `CX`, and `ECX`
- ambiguous memory-width rejection for `ror [eax], 1`
- executable QWORD/SQWORD memory-operation rejection
- direct `.CONST` write rejection where applicable

### Executor tests

Added or expanded coverage for:

- 8-bit register rotate-right by one.
- 16-bit register rotate-right by one.
- 32-bit register rotate-right by one.
- Count masking.
- Count-zero no-op behavior.
- `CL` count behavior using only the low 8 bits of `ECX`.
- Nonzero count with `rotate_amount` zero, such as 8-bit count 8.
- `CF` update from the rotated result.
- `OF` definition for effective count `1`.
- `OF` preservation for other nonzero counts.
- `ZF` and `SF` preservation for all nonzero counts.
- Memory read-modify-write success for byte, word, and dword destinations.
- Invalid memory read failure.
- `.CONST` permission failure.
- No partial mutation and no successful memory-change rows on failed memory writes.

### Source-run JSON tests

Added or expanded coverage for:

- Successful register acceptance program.
- Successful memory destination program.
- `ror eax, 32` no-warning effective-count-zero behavior.
- Warning-producing `ror al, 8` behavior with `rotate_amount 0` in the message.
- `CL` count behavior.
- Invalid immediate destination.
- Missing count.
- Extra operand count.
- Invalid count register.
- Ambiguous memory-width diagnostic.
- Direct `.CONST` assembly diagnostic.
- Computed `.CONST` runtime failure.
- Invalid memory destination runtime failure.
- Strict undefined-shift validation remains warning-only for `ROR`.
- Phase metadata reporting `50`.

### Rendered Simulator Messages tests

Added or expanded exact rendered-message coverage for:

- Successful `ror al, 1` execution line.
- `undefined-modeled-flag` warning from `ror al, 8`, including `effective count 8 and rotate amount 0` wording.
- `ambiguous-memory-width` from `ror [eax], 1`.
- `invalid-instruction-operands` from `ror eax, ebx`.
- `invalid-instruction-operands` from missing count `ror eax`.
- Runtime invalid-address diagnostic from `ror DWORD PTR [eax], 1`.
- Strict undefined-shift validation warning-only behavior for `ROR`.

### Regression tests

Regression coverage confirms:

- Existing Phase 49 `ROL` behavior remains intact.
- Existing `ROL` warning wording also reports `rotate_amount` for operand-width wrap cases.
- Existing Phase 46 `SHL`/`SAL` behavior remains intact.
- Existing Phase 47 `SHR` behavior remains intact.
- Existing Phase 48 `SAR` behavior remains intact.
- Existing `undefined-shift-flag` shift diagnostics remain distinct from `undefined-modeled-flag` rotate diagnostics.
- Existing memory-width diagnostics remain MASM-compatible.
- Existing QWORD/SQWORD unsupported-runtime behavior remains unchanged.
- Existing Milestone 42 `exit` behavior remains intact.

### Static/protocol checks

Updated `scripts/run_tests.py` and web protocol tests to verify Phase 50 artifacts, including:

- `VM_IR_OPCODE_ROR`
- parser support
- executor tests
- source-run tests
- rendered diagnostic tests
- protocol metadata phase `50`
- browser/index visible milestone text

## 9. Commands used to test

Primary aggregate test command:

```sh
cd /mnt/data/repo_m49_work
python3 -u scripts/run_tests.py
```

Wasm rebuild check attempted in this container:

```sh
cd /mnt/data/repo_m49_work
bash scripts/build_wasm.sh
```

Additional user-test follow-up command used to confirm aggregate tests after warning wording investigation:

```sh
cd /mnt/data/repo_m49_work
python3 scripts/run_tests.py > /tmp/m50_followup_tests.log 2>&1
```

## 10. Pass/fail results

Primary aggregate suite result:

```text
All implemented milestone tests passed.
```

Representative pass coverage reported by the aggregate runner included:

```text
Executor tests through Milestone 50 passed.
Source execution tests through Phase 50 regression coverage passed.
Milestone structure tests passed.
All implemented milestone tests passed.
```

Wasm rebuild check result in this container:

```text
emcc: command not found
```

This is an environment limitation. Native C and Node tests pass, but this container cannot rebuild `web/dist` because Emscripten is not installed.

## 11. Manual/browser testing guidance and expected outputs

Browser testing is applicable after rebuilding Wasm in an Emscripten-enabled environment. If `web/dist` is stale, the served website may still show Milestone 49 behavior or older warning wording.

### Manual setup on Windows

From a Windows CMD prompt in the project root:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

Stop the server from another CMD window:

```cmd
scripts\windows\stop_web.cmd
```

### Browser test 1 - one-bit ROR success

Program:

```asm
.code
main PROC
    mov al, 01h
    ror al, 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key registers:

```text
EAX    00000080h / 128
EFLAGS 00000801h / 2049
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `ror` is reported as unknown.
- `EAX` is not `00000080h`.
- `EFLAGS` is not `00000801h`.
- A warning appears for `ror al, 1`.

### Browser test 2 - warning with rotate amount zero

Program:

```asm
.code
main PROC
    mov al, 80h
    ror al, 8
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-modeled-flag line 4, column 5, byte offset 36, span length 9: ROR count 8 has effective count 8 and rotate amount 0 for an 8-bit destination. CF was updated from the most significant bit of the rotated result. ZF and SF were preserved because ROR does not define them. OF is architecturally undefined because the effective count is not 1. The simulator preserved OF deterministically.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key registers:

```text
EAX    00000080h / 128
EFLAGS 00000001h / 1
```

Regression signs:

- The warning blocks execution.
- The warning code is `undefined-shift-flag` instead of `undefined-modeled-flag`.
- The message omits `rotate amount 0`.
- `execution-complete` is missing.
- `ZF` or `SF` changes because of `ROR`.

### Browser test 3 - count masking zero no-op

Program:

```asm
.code
main PROC
    mov eax, 80000001h
    stc
    ror eax, 32
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX    80000001h / 2147483649
EFLAGS 00000001h / 1
```

Expected Program Console:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- Any warning appears for `ror eax, 32`.
- `EAX` changes.
- `CF` is cleared.

### Browser test 4 - memory destinations and memory changes

Program:

```asm
.data
d DWORD 80000001h
w WORD 8001h
b BYTE 81h
.code
main PROC
    ror d, 1
    mov ecx, d
    ror w, 4
    mov bx, w
    mov esi, OFFSET b
    ror BYTE PTR [esi], 1
    mov al, b
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-modeled-flag line 9, column 5, byte offset 96, span length 8: ROR count 4 has effective count 4 and rotate amount 4 for a 16-bit destination. CF was updated from the most significant bit of the rotated result. ZF and SF were preserved because ROR does not define them. OF is architecturally undefined because the effective count is not 1. The simulator preserved OF deterministically.
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX    000000C0h / 192
EBX    00001800h / 6144
ECX    C0000000h / 3221225472
ESI    00500006h / 5242886
EFLAGS 00000001h / 1
```

Expected memory changes:

```text
d: 80000001h / 2147483649 -> C0000000h / 3221225472
w: 8001h / 32769 -> 1800h / 6144
b: 81h / 129 -> C0h / 192
```

### Browser test 5 - ambiguous memory width rejected

Program:

```asm
.code
main PROC
    ror [eax], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 3, column 9, byte offset 24, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Expected behavior:

- No execution-complete message.
- Program Console remains empty.

### Browser test 6 - invalid count register rejected

Program:

```asm
.code
main PROC
    ror eax, ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 3, column 14, byte offset 29, span length 3: ROR count must be an immediate byte count or CL.
```

Expected behavior:

- No execution-complete message.
- Program Console remains empty.

### Browser test 7 - runtime invalid address

Program:

```asm
.code
main PROC
    mov eax, 0
    ror DWORD PTR [eax], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] invalid-address line 4: Invalid memory read at 00000000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

Expected behavior:

- `mov eax, 0` executes.
- `ror DWORD PTR [eax], 1` fails at runtime.
- No execution-complete message.
- No memory changes.

### Windows CMD local testing

Run the full aggregate test suite:

```cmd
cd /d C:\path\to\project
python scripts\run_tests.py
```

Expected final line:

```text
All implemented milestone tests passed.
```

If the suite succeeds, it builds:

```text
build\tests\diagnostic_json_producer.exe
```

To test one program manually from `program.asm` at the project root:

```cmd
notepad program.asm
build\tests\diagnostic_json_producer.exe program.asm
```

Example `program.asm`:

```asm
.code
main PROC
    mov al, 01h
    ror al, 1
main ENDP
END main
```

Expected JSON fragments:

```text
"phase":50
"ok":true
"status":"ok"
"instructionCount":2
"EAX":{"hex":"00000080h","unsigned":128}
"EFLAGS":{"hex":"00000801h","unsigned":2049}
"code":"execution-complete"
```

## 12. Compliance review summary

First compliance review found and fixed:

- Missing explicit parser acceptance coverage for `ror eax, 0`.
- Missing rendered Simulator Messages coverage for successful `ror al, 1`.
- Missing rendered runtime diagnostic coverage for invalid `ROR` memory destination.
- Stale docs wording that still referred only to `ROL` rather than `ROL` and `ROR`.
- A duplicated parser diagnostic formatting line.

Fixes applied:

- Added `ror eax, 0` parser acceptance coverage.
- Added exact rendered test for successful `ROR` execution.
- Added exact rendered test for `ROR` invalid destination-address runtime diagnostic.
- Updated static structure checks for the new rendered tests.
- Corrected stale supported-syntax wording.
- Removed the duplicated parser diagnostic formatting line.

Review result:

```text
All implemented milestone tests passed.
```

## 13. Re-review summary

Second compliance review found and fixed maintenance-quality issues only:

- Stale Phase 49 wording in regression comments and rendered-test fixture reasons for older regression cases now running under Phase 50.
- One duplicate source-run assertion for computed `ROR` `.CONST` runtime error.
- One duplicated Doxygen `@return` line in a changed parser helper comment.

No semantic defects were found. No accidental future-milestone implementation was found.

Review result:

```text
All implemented milestone tests passed.
```

## 14. User-test follow-up summary

The user observed a warning line for:

```asm
.code
main PROC
    mov al, 80h
    ror al, 8
main ENDP
END main
```

The user's observed diagnostic said:

```text
ROR count 8 has effective count 8 for an 8-bit destination...
```

The user questioned whether `effective_count` should be `0` for an 8-bit rotate count of `8`.

Diagnosis:

- No runtime behavior bug was found.
- Under the guide policy, `effective_count` means `raw_count & 31`, so count `8` has effective count `8`.
- The separate `rotate_amount` is `effective_count % operand_width`, so for 8-bit `ROR`, rotate amount is `0`.
- `ror al, 8` is therefore not a full no-op. Destination bits are unchanged, but nonzero-count rotate flag behavior still applies.
- For 32-bit `ror eax, 32`, `effective_count` is `0`, so it is a true no-op with no warning.
- The source tree had already been updated to include `rotate amount 0` in warning text. The user's output likely came from stale website/Wasm artifacts or an older changed-files package.

Follow-up provided:

- Full repository package: `milestone50_full_repository_state.zip`
- Diagnostic reproduction programs package: `milestone50_rotate_diagnostic_programs.zip`
- Exact reproduction programs for `ROR` and `ROL` count-8 warnings.

No code fix was required for the user-test discrepancy.

## 15. Known limitations

Known limitations after Milestone 50:

- Wasm/browser distribution artifacts were not rebuilt in this container because Emscripten is not installed.
- Served website testing requires rebuilding `web/dist` in an environment with `emcc`.
- If the browser shows old warning wording that omits `rotate amount`, the served artifacts are stale.
- Strict undefined-shift validation remains shift-only and does not reject rotate producer warnings.
- Smart flag-validity metadata is not implemented.
- Consumer diagnostics for reads of architecturally undefined flags are not implemented.
- Carry rotates are not implemented.
- PF/AF integration for rotates is not implemented.
- Executable QWORD/SQWORD memory operations remain unsupported in MASM32 Educational Mode.
- No stack, procedure, control-flow, broader Irvine32, WinAPI, PE, linker, host include loading, macro, or scaled-index behavior was added.

## 16. Next recommended milestone

Next recommended milestone:

```text
Phase 50A - Smart Undefined-Flag Validity Metadata
```

This is the next canonical guide phase after Phase 50. It should be implemented separately. It should not be backfilled into Milestone 50.

## 17. Changed-files ZIP/package produced

Changed-files and handoff packages produced during Milestone 50:

```text
/mnt/data/milestone50_changed_files.zip
/mnt/data/milestone50_compliance_review_changed_files.zip
/mnt/data/milestone50_second_review_changed_files.zip
/mnt/data/milestone50_user_followup_changed_files.zip
/mnt/data/milestone50_final_gap_changed_files.zip
/mnt/data/milestone50_full_repository_state.zip
/mnt/data/milestone50_rotate_diagnostic_programs.zip
```

Latest changed-files package recommendation:

```text
/mnt/data/milestone50_final_gap_changed_files.zip
```

Latest full repository/archive recommendation:

```text
Latest_repository_state_milestone_50.zip
```

Because `milestone50_full_repository_state.zip` was produced from the final reviewed working tree, it can be renamed to the recommended archive name for the next session if desired.

