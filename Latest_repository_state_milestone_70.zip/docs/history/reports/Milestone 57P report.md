# Milestone 57P report - Host Include Path Diagnostics

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57P - Host Include Path Diagnostics
```

Repository/archive milestone after this work:

```text
Phase 57P - Host Include Path Diagnostics
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 57P - Host Include Path Diagnostics
```

Scope implemented:

- Added narrow, line-oriented recognition for host/path-like `INCLUDE` directive operands.
- Replaced repeated lexer-level path separator noise for recognized host/path-like `INCLUDE` lines with one structured directive-level diagnostic per unsupported include directive.
- Added parser/source-run diagnostics for unsupported host include paths, MASM32 SDK include paths, and Windows/API include paths.
- Preserved supported virtual include behavior for `INCLUDE Irvine32.inc` and `INCLUDE Macros.inc`.
- Preserved future-owned `INCLUDELIB` behavior for Phase 57Q.
- Updated source-run/runtime status metadata, browser/protocol status surfaces, supported syntax documentation, milestone history, README/status documentation, and static checks to Phase 57P.
- Added lexer, parser, source-run, rendered Simulator Messages, protocol, and static/status test coverage.

Representative accepted-for-diagnosis source forms include:

```asm
include \masm32\include\masm32.inc
include \masm32\include\kernel32.inc
include C:\masm32\include\kernel32.inc
include ..\include\something.inc
include .\local.inc
include /usr/local/include/file.inc
```

These forms are not accepted as executable include loading. They are recognized only to produce stable, user-friendly diagnostics and prevent low-level repeated lexer errors.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status and verification files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57O report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_57O.zip
```

Repository archive recommended after implementation:

```text
Latest_repository_state_milestone_57P.zip
```

A full latest repository archive was not produced during this milestone-report step. Changed-files packages were produced and are listed in Section 19.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, memory safety, and status-surface hygiene.
- The incremental implementation guide owns phase numbering, target milestone scope, per-phase implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only. They do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

## 3. Exact requirements implemented

### 3.1 Host/path-like INCLUDE diagnostics

Phase 57P adds targeted handling for path-like `INCLUDE` directive operands. The implementation recognizes host/path-like include tails only in a line-leading `INCLUDE` directive context and then emits one structured assembly diagnostic for the include directive.

The milestone implements distinct diagnostics:

```text
unsupported-host-include-path
unsupported-masm32-library-include
unsupported-windows-api-include
```

The implementation covers these path categories:

- MASM32 SDK paths such as `\masm32\include\masm32.inc`.
- Windows/API include paths such as `\masm32\include\kernel32.inc` and `C:\masm32\include\kernel32.inc`.
- Relative host include paths such as `..\include\file.inc` and `.\local.inc`.
- Unix-style absolute host include paths such as `/usr/local/include/file.inc`.

The implementation preserves source metadata for diagnostics:

- source line;
- source column;
- byte offset;
- span length.

### 3.2 Repeated lexer-noise suppression for recognized INCLUDE paths

Before Phase 57P, path-like include directives containing backslashes could degrade into repeated low-level lexer diagnostics such as `unexpected-character`. Phase 57P avoids that result for recognized line-leading `INCLUDE` directives by treating the path tail as a single include-path token for parser diagnostics.

The implementation does not make backslashes or host paths generally valid MASM syntax. The path-tail handling is limited to `INCLUDE` directive context.

### 3.3 Virtual include behavior preserved

The following existing behavior was preserved:

```asm
INCLUDE Irvine32.inc
INCLUDE Macros.inc
```

`INCLUDE Irvine32.inc` remains a supported virtual include and continues to enable existing virtual Irvine32 behavior, including the virtual `exit` terminator.

`INCLUDE Macros.inc` remains limited compatibility metadata/notice behavior and does not implement macro expansion.

### 3.4 Future-owned INCLUDELIB behavior preserved

`INCLUDELIB` was intentionally not implemented or reclassified as part of Phase 57P. It remains owned by:

```text
Phase 57Q - INCLUDELIB and External Library Diagnostics
```

Regression coverage verifies that Phase 57P did not accidentally implement or alter the future-owned `INCLUDELIB` diagnostic path.

### 3.5 Status surfaces updated

Because Phase 57P changes runtime-visible source parsing and diagnostics, both status values advanced:

```text
Repository/archive milestone:
Phase 57P - Host Include Path Diagnostics

Runtime/source-run MASM behavior phase:
Phase 57P - Host Include Path Diagnostics
```

Updated status surfaces include:

- `README.md`;
- `docs/SUPPORTED_SYNTAX.md`;
- `docs/MILESTONE_HISTORY.md`;
- `docs/BUILDING_AND_DEVELOPMENT.md`;
- source-run/Wasm status metadata;
- browser static status text;
- worker/protocol metadata;
- protocol/static tests.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57P:

- Host filesystem include loading.
- MASM32 SDK file loading.
- Include search paths.
- Real preprocessing of included source files.
- `INCLUDELIB` diagnostics or linking behavior.
- Object-file linking.
- PE loading.
- Windows imports.
- WinAPI execution.
- External library resolution.
- Macro expansion.
- Real `Windows.inc` declarations.
- Broader MASM preprocessor behavior.
- New virtual include behavior beyond preserving existing `Irvine32.inc` and `Macros.inc` behavior.
- General path expression grammar.
- General backslash token support outside the narrow include-directive path.
- Future realistic playground fixture recovery work.
- Procedure, stack, control-flow, debugger, or Irvine32 routine expansion.

Future work intentionally preserved:

- Phase 57Q - `INCLUDELIB` and External Library Diagnostics.
- Later WinAPI/non-goal diagnostics where explicitly scheduled.
- Later macro/high-level-flow/procedure/debugger milestones.
- Later realistic playground or multi-feature recovery fixtures.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 57P should use distinct diagnostic codes for host paths, MASM32 SDK include paths, and Windows/API include paths when the category is recognizable.
- **Reason:** The guide calls for clear user-facing diagnostics and examples distinguish MASM32 SDK loading from Windows/API include behavior.
- **Risk:** Multiple codes require more parser, JSON, rendered-message, and documentation updates than a single generic code.
- **How to change later:** Collapse categories to one `unsupported-host-include-path` code only if a future guide revision deliberately simplifies diagnostic taxonomy. Preserve user-facing wording through compatibility tests if that happens.

### Assumption 2

- **Assumption:** The diagnostic source span should point to the unsupported path tail when available.
- **Reason:** The path tail is the user-actionable source text. This also proves the lexer/parser preserved useful source metadata after suppressing separator noise.
- **Risk:** Path-tail spans require the narrow lexer handling to preserve the exact tail range.
- **How to change later:** A future diagnostic-quality phase could instead standardize include diagnostics on directive-token spans, but tests and documentation should be updated together.

### Assumption 3

- **Assumption:** `INCLUDE Windows.inc` without a path separator should remain on the existing generic unsupported include path during Phase 57P.
- **Reason:** Phase 57P focuses on host/path-like include directives. Existing behavior already covered basename-only unsupported includes, and broad basename reclassification could exceed the target milestone.
- **Risk:** Users might expect basename-only Windows SDK includes to receive the same Windows/API wording as path-qualified `kernel32.inc` includes.
- **How to change later:** A later diagnostic refinement phase can classify known basename-only Windows SDK includes more specifically, with parser/source-run/rendered-message tests.

### Assumption 4

- **Assumption:** Line-oriented include path recognition is the correct implementation shape for this milestone.
- **Reason:** The target phase explicitly allows host paths to be recognized for diagnostics without becoming general expressions or general MASM tokens.
- **Risk:** Line-oriented lexer handling can become brittle if it escapes directive context.
- **How to change later:** Replace the implementation with a more formal directive-tail lexer state or parser-owned token mode while preserving the same diagnostics and tests.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can be reported as skipped when `emcc` is unavailable in the assistant/container environment.
- **Reason:** Emscripten is not installed in this environment.
- **Risk:** Served browser artifacts can remain stale until rebuilt locally or in CI.
- **How to change later:** Rebuild with Emscripten locally or in CI and run the manual browser verification programs in Section 13.

## 6. Relevant TODO-style notes reviewed

Target-owned TODO-style notes and TODO-style evidence reviewed:

- Phase 57P requirements in `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` for host include path diagnostics.
- Existing generic unsupported include behavior in `src/parser/parser.c`.
- Existing lexer behavior that reported path separators as low-level unexpected characters.
- Current supported-syntax documentation describing unsupported include behavior.
- Existing parser/source-run/rendered-message tests around virtual includes and unsupported include handling.

Future-owned TODO-style notes reviewed:

- Phase 57Q `INCLUDELIB` and external library diagnostics.
- Later WinAPI, PE/linker, macro, procedure, high-level-flow, debugger, and playground-fixture work.
- Future realistic fixture notes that combine host include paths with other unsupported constructs.

Broad TODO-style categories reviewed and excluded as irrelevant to Phase 57P:

- Future QWORD/SQWORD execution.
- Future Irvine32 routines beyond existing virtual `exit` behavior.
- Future stack/procedure/debugger behavior.
- Future macro/high-level-flow support.
- Future branch/control-flow milestones.
- Historical milestone report text and generated artifacts, which are not source-note authority.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 57P host/path-like `INCLUDE` diagnostics implemented and tested.
- Repeated path-separator lexer noise eliminated for recognized line-leading include path directives.
- Supported-syntax and current-status documentation updated for Phase 57P.
- Existing parser/source-run/rendered-message include coverage expanded for Phase 57P.

### Future-owned TODO-style notes intentionally preserved

- Phase 57Q `INCLUDELIB` diagnostics remain future-owned.
- Later WinAPI, PE/linker, macro, procedure, control-flow, debugger, and playground-fixture work remain deferred.
- Existing non-goal behavior around host filesystem loading and external library loading remains intact.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style notes required correction.
- Related documentation/status wording was updated where Phase 57P changed current behavior, including README and milestone-history status hygiene.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 57P was implemented as a narrow diagnostics-quality milestone.

Primary design choices:

1. **Keep host paths out of general MASM syntax.** The lexer recognizes include path tails only when `INCLUDE` appears as the line-leading directive. Backslashes and slashes were not made valid general tokens.

2. **Use one token for the unsupported path tail.** The lexer emits a dedicated include-path token for the directive tail so the parser can emit one structured diagnostic rather than receiving many separator-related lexer errors.

3. **Classify path categories in the parser.** The parser maps include path tails to host path, MASM32 SDK path, or Windows/API include diagnostics.

4. **Preserve virtual include behavior.** `Irvine32.inc` and `Macros.inc` remain on their existing virtual include paths and are not reclassified as host filesystem include attempts.

5. **Do not implement Phase 57Q.** `INCLUDELIB` behavior was intentionally left unchanged and regression-tested.

6. **Keep Program Console and Simulator Messages separate.** All Phase 57P diagnostics are assembly diagnostics rendered through Simulator Messages. Program Console output remains empty for these failures.

7. **Advance runtime/source-run metadata.** Phase 57P changes source-visible parser/diagnostic behavior, so repository/archive and runtime/source-run phase metadata both advance to Phase 57P.

## 9. Files changed

Files changed across implementation, compliance reviews, second review, and final gap check:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/lexer.c`
- `src/parser/lexer.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_lexer.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

### Lexer tests

Added coverage for:

- line-leading `include` with host/path-like path tail;
- indented mixed-case `INCLUDE` with path tail and trailing comment;
- path-tail token name helper behavior;
- ordinary non-include text with path separators not being accepted as a generic path token;
- include directive context preserving source position and span.

### Parser tests

Added coverage for:

- `include \masm32\include\masm32.inc` producing `unsupported-masm32-library-include`;
- `include \masm32\include\kernel32.inc` producing `unsupported-windows-api-include`;
- `include C:\masm32\include\kernel32.inc` producing `unsupported-windows-api-include`;
- `include ..\include\file.inc` producing `unsupported-host-include-path`;
- `include .\local.inc` producing `unsupported-host-include-path`;
- `include /usr/local/include/file.inc` producing `unsupported-host-include-path`;
- multiple host include diagnostics in stable source order;
- indented mixed-case include path source location details;
- preserved `INCLUDE Windows.inc` generic unsupported include behavior.

### Source-run tests

Added coverage for:

- source-run JSON exposing Phase 57P diagnostic codes;
- source-run JSON preserving line, column, byte offset, and span length;
- host include diagnostics preventing execution;
- no `execution-complete` message after host include assembly errors;
- no repeated `unexpected-character` diagnostics for recognized include paths;
- virtual include regression behavior;
- future-owned `INCLUDELIB` behavior remaining unchanged.

### Rendered Simulator Messages tests

Added exact rendered-message tests for:

- unsupported MASM32 SDK include path;
- unsupported Windows/API include path;
- multiple host include diagnostics in one source file.

### Protocol/static/status tests

Updated tests for:

- repository/archive milestone Phase 57P;
- runtime/source-run MASM behavior phase Phase 57P;
- browser status text Phase 57P;
- supported syntax/status documentation Phase 57P;
- milestone history Phase 57P;
- README/status wording after final cleanup.

## 11. Commands used to test

### Aggregate command

```bash
cd /mnt/data/repo_57O_verify
python3 scripts/run_tests.py --all
```

Observed final aggregate result:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Focused group commands

The following focused groups were run during implementation, compliance review, re-review, and final gap check:

```bash
cd /mnt/data/repo_57O_verify
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused results:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Subgroup or fixture-family commands

No subgroup or individual fixture-family reruns were required. No focused group timed out.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is a dependency skip, not a test failure. Served browser testing requires rebuilding Wasm in an environment with Emscripten.

## 12. Pass/fail results

Final result classification:

```text
aggregate completed and passed
```

Detailed classification:

- Aggregate command completed and returned final success status.
- Focused groups completed and passed:
  - `--structure`
  - `--native`
  - `--source-run`
  - `--web`
  - `--diagnostics`
  - `--protocol`
  - `--static`
- No focused group failed.
- No focused group timed out.
- No subgroup reruns were required.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Phase 57P is browser-testable after rebuilding the Wasm artifact. Because the milestone changes C lexer/parser behavior, the served website must use a rebuilt `web/dist/masm32_sim_core.wasm`. If the browser serves the old Phase 57O artifact, old behavior may still appear.

### Browser setup on Windows

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the served page and paste the following programs.

### Program 1 - MASM32 SDK include path

```asm
include \masm32\include\masm32.inc

.code
main PROC
    mov eax, 123
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-masm32-library-include line 1, column 9, byte offset 8, span length 26: Host filesystem include path '\masm32\include\masm32.inc' is not supported. This browser simulator does not read the local MASM32 SDK; use supported virtual includes only.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message.
- No register result from `mov eax, 123`.

### Program 2 - Windows/API include path

```asm
include C:\masm32\include\kernel32.inc

.code
main PROC
    mov eax, 123
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-windows-api-include line 1, column 9, byte offset 8, span length 30: Windows API include path 'C:\masm32\include\kernel32.inc' is not supported. Windows API execution is outside this simulator; PE loading, imports, and WinAPI calls are not performed.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message.
- No register result from `mov eax, 123`.

### Program 3 - Multiple host include diagnostics

```asm
include ..\include\file.inc
include \masm32\include\kernel32.inc

.code
main PROC
    mov eax, 123
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-host-include-path line 1, column 9, byte offset 8, span length 19: Host filesystem include path '..\include\file.inc' is not supported. This browser simulator does not read local include files, relative include paths, or include search paths; use supported virtual includes only.
[unsupported-feature] unsupported-windows-api-include line 2, column 9, byte offset 36, span length 28: Windows API include path '\masm32\include\kernel32.inc' is not supported. Windows API execution is outside this simulator; PE loading, imports, and WinAPI calls are not performed.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- Exactly one diagnostic per include line.
- No repeated `unexpected-character` diagnostics for backslashes.

### Program 4 - Virtual include regression

```asm
INCLUDE Irvine32.inc
.code
main PROC
    mov eax, 42
    exit
    mov eax, 99
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected register result:

```text
EAX = 0000002Ah / u: 42 / s: 42
```

`EAX` must not become `99`, because virtual `exit` terminates execution before `mov eax, 99`.

### Windows CMD local testing

Emscripten is not required for local native/source-run/Node verification. Visual Studio tooling, Python 3, and Node.js are required.

Focused tests:

```cmd
python scripts\run_tests.py --native
python scripts\run_tests.py --source-run
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --web
python scripts\run_tests.py --protocol
python scripts\run_tests.py --static
```

Expected snippets:

```text
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[web] PASS - browser-side Node module tests passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

Aggregate test:

```cmd
python scripts\run_tests.py --all
```

Expected result:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

If Emscripten is installed, the Browser/Wasm rebuild smoke may run instead of skipping. That is acceptable if it passes.

### Regression signs

The following indicate regressions:

- Host include paths produce repeated `unexpected-character` diagnostics.
- `include \masm32\include\masm32.inc` does not produce `unsupported-masm32-library-include`.
- `include C:\masm32\include\kernel32.inc` does not produce `unsupported-windows-api-include`.
- Multiple include path lines collapse into one diagnostic or produce diagnostics out of source order.
- `INCLUDE Irvine32.inc` stops enabling virtual `exit`.
- `INCLUDELIB` behavior changes during Phase 57P.
- Browser results differ from local tests after rebuilding Wasm.

## 14. Compliance review summary

First compliance review found minor issues only:

- Duplicated Doxygen-style parser helper comment.
- Missing explicit edge coverage for indented mixed-case `INCLUDE` host paths with trailing comments.
- A newly added parser test initially referenced the wrong diagnostic struct field for span length; this was corrected before final testing.

Fixes applied:

- Removed duplicated parser helper comment.
- Added lexer and parser edge tests for indented mixed-case `INCLUDE` path tails with comments.
- Corrected parser test span assertion to use the proper diagnostic field.

First compliance review result:

- All focused groups passed.
- Aggregate completed and passed.
- Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.
- Verdict: complete.

## 15. Re-review summary

Second compliance review found documentation/status hygiene issues only:

- README had duplicate Phase 57O NOP status wording after the Phase 57P update.
- `docs/MILESTONE_HISTORY.md` concise ledger listed Phase 57P before Phase 57O, which was chronologically wrong.

Fixes applied:

- Cleaned README Phase 57O wording while preserving static-check-required status content.
- Reordered the concise milestone-history ledger so Phase 57O precedes Phase 57P.

Second review result:

- All focused groups passed.
- Aggregate completed and passed.
- Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.
- Final scope, documentation, test coverage, and TODO-style note verdicts were complete.

Final gap check found one additional documentation/static-check hygiene issue:

- README still had awkward/redundant Phase 57O wording, and the static check expected that redundant phrase.

Fixes applied:

- Reworded README Phase 57O sentence to remove redundant phrasing.
- Updated the static documentation check expectation.

Final gap check result:

- Static tests passed.
- Aggregate completed and passed.
- Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.
- Final verdict: complete.

## 16. User-test follow-up summary

No Prompt 8 user-test triage occurred. The user indicated everything appeared to pass and proceeded directly to final gap check.

No user-reported discrepancies were triaged for Phase 57P.

## 17. Known limitations

Known limitations after Phase 57P:

- Host include files are not loaded.
- Local MASM32 SDK files are not read.
- Include search paths are not implemented.
- `INCLUDELIB` remains future-owned by Phase 57Q.
- Windows API execution remains a non-goal.
- PE loading, imports, external linking, and object-file behavior remain non-goals.
- Macro expansion is not implemented.
- Served browser behavior requires rebuilding the Wasm artifact with Emscripten; this environment could not run that rebuild because `emcc` was unavailable.
- `INCLUDE Windows.inc` without a path separator remains on the existing generic unsupported include path unless a future diagnostic-quality milestone deliberately reclassifies basename-only SDK includes.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57Q - INCLUDELIB and External Library Diagnostics
```

Phase 57Q should add diagnostics for `INCLUDELIB` and external library/linker behavior while preserving Phase 57P host include path diagnostics.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

- `phase57p_changed_files.zip`
- `phase57p_compliance_changed_files.zip`
- `phase57p_second_review_changed_files.zip`
- `phase57p_final_gap_changed_files.zip`

The final changed-files package to use is:

```text
phase57p_final_gap_changed_files.zip
```

It preserves repository structure and contains these 20 changed files:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/lexer.c`
- `src/parser/lexer.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_lexer.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

A full repository archive was not produced in this milestone-report step. After applying the final changed-files package to the Phase 57O repository and verifying locally, the recommended full archive name is:

```text
Latest_repository_state_milestone_57P.zip
```
