# Milestone 59 report - Control-Flow Instruction Limit

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 59 - Control-Flow Instruction Limit
```

Repository/archive milestone after this work:

```text
Phase 59 - Control-Flow Instruction Limit
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 59 - Control-Flow Instruction Limit
```

Scope implemented:

- Added a source-run/test-facing instruction-count watchdog for VM execution.
- Added the `instructionLimit` setting with a documented default of `1,000,000` executed VM instructions.
- Counted executed VM instructions rather than source lines, labels, or visible state mutations.
- Stopped execution before instruction `limit + 1` when the configured limit had already been reached.
- Added the structured runtime diagnostic code `instruction-limit-exceeded`.
- Preserved all state committed by the first `limit` instructions and prevented partial execution of the blocked next instruction.
- Ensured `execution-complete` is not emitted after an instruction-limit failure.
- Added source-run JSON accounting fields:
  - `instructionLimit`
  - `executedInstructionCount`
  - `attemptedNextInstructionIndex`
  - `currentInstructionIndex`
- Added settings/protocol validation for invalid instruction-limit values.
- Updated current-status surfaces to Phase 59.
- Preserved Phase 58 label semantics: labels remain parser/source metadata only and do not count as executable instructions.

Scope intentionally not implemented:

- Direct `jmp` parsing, target lowering, or runtime execution.
- Conditional jumps.
- `loop`.
- `call`, `ret`, stack behavior, procedure invocation, procedure frame setup, or call depth tracking.
- Branch target classification consumption by executable instructions.
- Debugger stepping, breakpoints, or UI label/source navigation.
- Browser UI controls for `instructionLimit`.
- Time limits, host cancellation, worker chunking, or stop-button behavior.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status and verification files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 58 report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_58.zip
```

The pre-change static test expectation in the initial milestone 58 archive was stale relative to the current concise documentation status wording. The corrected milestone 58 static-test-fix state was used as the practical Phase 59 baseline.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_59.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, current-status surface hygiene, and resource-limit expectations.
- The implementation guide owns Phase 59 numbering, exact tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the spec/guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the spec/guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone.

## 3. Exact requirements implemented

### 3.1 Configurable instruction-count limit

Implemented source-run/test-facing option:

```text
instructionLimit
```

The setting must be a positive integer. If omitted, the simulator uses the documented default:

```text
1,000,000 executed VM instructions
```

The browser/protocol settings path validates the setting and normalizes accepted integer values. Invalid values produce structured configuration diagnostics rather than silently falling back.

### 3.2 Instruction counting semantics

Implemented counting of fully executed VM instructions.

Counting behavior:

- Normal executable VM instructions count.
- `nop` counts even though it intentionally does not mutate registers, flags, memory, or console output.
- Labels do not count, because labels are metadata and do not emit executable IR instructions.
- Source lines do not count by themselves.
- Metadata-only source constructs do not count as executable instructions.

### 3.3 Limit check before next instruction

Implemented the Phase 59 stop rule:

```text
If executed_count == limit and another instruction would be fetched, stop before executing instruction limit + 1.
```

A three-instruction program with `instructionLimit = 2` behaves as required:

```text
instruction 1 executes and commits state
instruction 2 executes and commits state
instruction 3 does not execute
instruction-limit-exceeded is emitted
execution-complete is not emitted
```

### 3.4 No partial mutation on limit failure

The failed limit check occurs before the blocked instruction is fetched/executed. Therefore the blocked instruction cannot mutate:

- registers;
- modeled flags;
- flag-validity metadata;
- memory;
- Program Console output;
- memory-change rows.

The state committed by the first `limit` instructions is preserved and visible in the result.

### 3.5 Structured diagnostic

Added structured runtime diagnostic:

```text
instruction-limit-exceeded
```

The final user-facing wording after user-test follow-up is:

```text
Instruction limit exceeded: attempted to execute instruction #3 (limit: 2). Program stopped before executing that instruction.
```

The rendered message uses a 1-based instruction number for readability. The JSON fields continue to expose the existing internal 0-based instruction indexes.

The diagnostic preserves source location for the blocked next instruction when source metadata is available, including line, column, byte offset, and span length.

### 3.6 Source-run JSON accounting fields

Added these JSON fields with the exact names required by the guide:

```text
instructionLimit
executedInstructionCount
attemptedNextInstructionIndex
currentInstructionIndex
```

Field behavior:

- `instructionLimit`: configured limit used by the run.
- `executedInstructionCount`: number of VM instructions fully executed and committed before stop or completion.
- `attemptedNextInstructionIndex`: the 0-based internal instruction index that would have been fetched next and was blocked by the limit; `null` on normal completion.
- `currentInstructionIndex`: the 0-based internal index of the last instruction that fully executed and committed state; `null` if no instruction executed.

### 3.7 Invalid settings diagnostics

Added validation for invalid `instructionLimit` values, including:

- zero;
- negative values;
- non-integer values;
- non-numeric JSON values;
- values above the implementation maximum.

Invalid settings produce structured configuration diagnostics and do not silently fall back to the default limit.

### 3.8 Determinism

The same source and same settings produce the same instruction-limit result, diagnostic, JSON fields, and committed state.

### 3.9 Current-status updates

Updated current-status surfaces and tests to reflect:

```text
Repository/archive milestone:
Phase 59 - Control-Flow Instruction Limit

Runtime/source-run MASM behavior phase:
Phase 59 - Control-Flow Instruction Limit
```

Phase 59 changes runtime/source-run behavior, so both values advance to Phase 59.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 59:

- Direct `jmp` parsing, target lowering, or runtime execution.
- Conditional jump parsing or execution.
- `loop` parsing or execution.
- `call`, `ret`, `leave`, stack instructions, stack-frame setup, call depth limit, or call tracing.
- Procedure invocation semantics.
- Branch target classifier consumption by executable branch instructions.
- Instruction-pointer mutation for control flow.
- High-level flow constructs such as `.IF`, `.ELSE`, `.ENDIF`, `.WHILE`, `.REPEAT`, `.BREAK`, or `.CONTINUE`.
- Irvine32 routine implementation beyond already-existing virtual `exit` behavior.
- Debugger stepping, breakpoints, or source navigation.
- Public label-table/debugger JSON API.
- Browser UI controls for `instructionLimit`.
- Time limits, wall-clock limits, worker cancellation, or chunked execution.

Future work intentionally preserved:

- Phase 60 - Direct JMP Parsing and Target Lowering.
- Phase 61 - Direct JMP Runtime Execution.
- Later conditional jump, signed/unsigned relational jump, and `loop` phases.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Later execution-control UI and settings phases, if the guide requires them.

## 5. Assumptions used

### Assumption 1

- **Assumption:** The corrected milestone 58 static-test-fix repository is the baseline for Phase 59.
- **Reason:** The initial milestone 58 archive had stale static assertions that expected old README wording, while the current concise README/status wording was accepted as correct.
- **Risk:** Reapplying Phase 59 to the original uncorrected milestone 58 archive would reproduce the stale static-test failure.
- **How to change later:** Treat the static-test-fix state as the accepted Milestone 58 baseline, or apply the same static-test correction before applying Phase 59 changes.

### Assumption 2

- **Assumption:** Phase 59 advances both repository/archive milestone and runtime/source-run MASM behavior phase.
- **Reason:** Phase 59 changes runtime behavior, source-run JSON output, diagnostics, and protocol/settings validation.
- **Risk:** Status surfaces and tests must consistently expect Phase 59, not Phase 58.
- **How to change later:** If a future reviewed guide revision reclassifies Phase 59 as maintenance-only, keep runtime metadata at the previous runtime phase and use the repository/runtime split block. The current guide does not support that interpretation.

### Assumption 3

- **Assumption:** `instructionLimit` remains source-run/test-facing in Phase 59 rather than becoming a visible browser UI control.
- **Reason:** The guide requires a source-run/test-facing option and does not require a browser settings control.
- **Risk:** Users cannot manually lower the limit from the served page without a developer/protocol test path.
- **How to change later:** Add a dedicated UI/settings phase with DOM tests, protocol tests, persistence rules, and manual browser coverage.

### Assumption 4

- **Assumption:** The configured instruction limit can remain a bounded 32-bit unsigned setting, while the executed-instruction counter remains `uint64_t`.
- **Reason:** The setting maximum is far above practical browser educational examples, and moving 64-bit settings through Wasm/JS would add avoidable protocol/API complexity.
- **Risk:** A future project goal for extremely large programs may require wider setting fields and JavaScript-safe integer handling.
- **How to change later:** Introduce a later resource-limit/API phase that deliberately widens the public setting and updates C, Wasm, JS, JSON, and tests together.

### Assumption 5

- **Assumption:** Rendered diagnostics should use a 1-based instruction number while JSON keeps existing 0-based internal instruction indexes.
- **Reason:** User feedback identified the original message as repetitive. A 1-based display number is clearer for humans, while the required JSON fields already expose internal indexes.
- **Risk:** If not documented/tested, future readers might confuse the rendered instruction number with `attemptedNextInstructionIndex`.
- **How to change later:** Add explicit documentation if future user-facing instruction-index displays are expanded, or expose a separate display-number field if needed.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning and verification:

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  Future instruction milestones should add future memory-reading opcodes to the planned-access classification path when those opcodes are implemented.
- Classification:
  future-owned
- Reason:
  Phase 59 does not add a memory-reading opcode or any memory-capable instruction.
- Action for this milestone:
  Leave in place.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 59 and Shared Direct Branch Target Classification sections
- Note text or summary:
  Direct branch target classification is forward-looking guidance for Phase 60, Phase 61, and later branch phases; it does not expand Phase 59 scope.
- Classification:
  future-owned
- Reason:
  Phase 59 is only the instruction-count watchdog phase.
- Action for this milestone:
  Preserve as a boundary rule. Do not implement branch behavior.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md deferred-feature sections
- Note text or summary:
  Control flow, stack initialization, push/pop/call/ret, Irvine32 routines beyond exit, debugger stepping, breakpoints, scaled-index addressing, carry rotates, macro expansion, Windows API modeling, and full MASM expression compatibility remain deferred.
- Classification:
  future-owned
- Reason:
  Phase 59 does not implement those features.
- Action for this milestone:
  Preserve deferred status. Update only Phase 59 watchdog/status documentation.
```

```text
- Location:
  docs/FULL_IMPLEMENTATION_SPEC.md branch/control-flow discussion
- Note text or summary:
  Unsupported indirect, register, memory, SHORT, NEAR PTR, and FAR PTR branch forms remain unavailable until a later phase explicitly implements them.
- Classification:
  future-owned
- Reason:
  Phase 59 must not add branch operands or branch execution.
- Action for this milestone:
  Leave unchanged.
```

No target-owned TODO-style note was identified for Phase 59.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- None found.

### Future-owned TODO-style notes intentionally preserved

- Future memory-reading opcode TODO in `src/wasm/wasm_api.c`.
- Shared direct branch target classification notes for Phase 60, Phase 61, and later branch phases.
- Deferred control-flow, stack, procedure, debugger, macro, WinAPI, and related feature notes.

### Stale or contradicted TODO-style notes corrected

- None found.

Stale non-TODO items corrected during review:

- Phase 57F fallback metadata in a response-truncation path.
- Internal test failure text that still referenced Phase 58 runtime metadata after Phase 59 advanced runtime/source-run metadata.
- JSDoc return type missing the invalid-instruction-limit diagnostic variant.
- MILESTONE_HISTORY concise ledger ordering around Phase 57T, Phase 58, and Phase 59.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 59 was implemented as a narrow runtime/source-run watchdog.

Primary design choices:

1. **Check the limit before the next VM step.** The watchdog checks whether `executed_count == instructionLimit` before fetching/executing another instruction. This guarantees no partial mutation from the blocked instruction.

2. **Count executable VM instructions only.** Labels remain parser/source metadata. `nop` counts because it is an executable instruction even though it has no visible state mutation.

3. **Preserve committed state.** Registers, flags, memory, Program Console output, and memory-change rows from completed instructions remain visible after a limit failure.

4. **Keep JSON accounting explicit.** Required fields expose the configured limit, completed-instruction count, blocked next internal index, and last completed internal index.

5. **Separate display numbering from internal indexing.** Rendered diagnostics use a 1-based instruction number for user readability. JSON internal indexes remain 0-based.

6. **Validate settings at the boundary.** Invalid `instructionLimit` values are rejected by structured settings/configuration diagnostics rather than falling back silently.

7. **Avoid future control flow.** No branch parser, label target consumption, control-flow instruction, stack, or procedure behavior was added.

8. **Keep browser UI unchanged.** Protocol/settings support was added, but no visible browser UI control for the limit was introduced.

## 9. Files changed

Files changed across implementation, compliance review, second review, user-test follow-up, and final gap check:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/build_wasm.sh`
- `scripts/run_tests.py`
- `scripts/windows/build_wasm.cmd`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/wasm/wasm_api.c`
- `src/wasm/wasm_api.h`
- `tests/core/diagnostic_json_producer.c`
- `tests/core/test_data_section.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `tests/web/test_settings.mjs`
- `web/index.html`
- `web/src/protocol.js`
- `web/src/settings.js`
- `web/src/worker.js`

No C++ core files were introduced. Core implementation remains C99.

## 10. Tests added

### Source-run tests

Added or updated tests for:

- straight-line program below limit succeeds;
- three-instruction program with `instructionLimit = 2` fails before the third instruction;
- final register state after limit failure proves first two instructions committed and third instruction did not execute;
- JSON fields `instructionLimit`, `executedInstructionCount`, `attemptedNextInstructionIndex`, and `currentInstructionIndex`;
- labels do not count as executable instructions;
- `nop` counts as an executable instruction;
- no partial mutation from a blocked instruction;
- no `execution-complete` after limit failure;
- default instruction limit behavior;
- invalid instruction-limit values.

### Settings/protocol tests

Added or updated tests for:

- default `instructionLimit` setting;
- accepted explicit positive integer limits;
- rejection of zero;
- rejection of negative values;
- rejection of non-integer values;
- rejection of non-numeric values;
- rejection of values above the implementation maximum;
- structured-clone-safe protocol payloads.

### Rendered Simulator Messages tests

Added exact rendered-message coverage for `instruction-limit-exceeded`, including final user-test-follow-up wording:

```text
[runtime-error] instruction-limit-exceeded line 5, column 5, byte offset 50, span length 10: Instruction limit exceeded: attempted to execute instruction #3 (limit: 2). Program stopped before executing that instruction.
```

### Static/status tests

Updated tests for:

- Phase 59 repository/archive status;
- Phase 59 runtime/source-run MASM behavior phase;
- documentation/status consistency;
- build-script export/status consistency;
- concise public-facing status wording.

### Regression tests

Added or preserved regressions for:

- Phase 58 label metadata and straight-line behavior;
- unsupported `jmp`, `loop`, `call`, and `ret` behavior;
- previous runtime diagnostics;
- startup-state notice behavior;
- Program Console and Simulator Messages stream separation;
- no future control-flow behavior.

## 11. Commands used to test

### Aggregate command

Final aggregate command:

```bash
python3 scripts/run_tests.py --all
```

Observed final result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Focused group commands

Focused commands run during implementation and review:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused results across final passing runs:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Compliance and follow-up focused commands

Additional focused commands rerun after specific fixes:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --native
```

Final gap-check commands included:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

### Subgroup or fixture-family commands

No documented subgroup or individual fixture-family reruns were required after final fixes. Focused groups were sufficient.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is a dependency skip, not a test failure. Served browser testing with freshly rebuilt Wasm requires Emscripten locally or in CI.

## 12. Pass/fail results

Final result classification:

```text
aggregate completed and passed
group skipped because a dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

Detailed classification:

- Aggregate command completed and returned final success status.
- Focused groups completed and passed:
  - `--structure`
  - `--native`
  - `--source-run`
  - `--web`
  - `--diagnostics`
  - `--protocol`
  - `--static`
- One chained focused-command run during first compliance review timed out after `--web` completed. The remaining focused groups were rerun individually and passed. This was an assistant/container command-chain timeout, not a project test failure.
- No focused group failed.
- No focused group timeout remained unresolved.
- No subgroup or fixture-family rerun was required.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Phase 59 is partially website-testable after rebuilding Wasm. The default website path verifies normal execution under the default instruction limit. The low-limit failure path is source-run/test-facing and does not have a visible browser UI control in Phase 59.

### Browser setup on Windows

From the project root in an Emscripten-enabled Windows CMD environment:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the served URL, paste the program below, and click **Run**.

If `emcc` is unavailable, use the local test-suite commands instead.

### Browser program - default limit successful run

```asm
.code
main PROC
    mov eax, 1
    mov ebx, 2
    mov ecx, 3
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

Expected key final registers:

```text
EAX = 00000001h / u: 1 / s: 1
EBX = 00000002h / u: 2 / s: 2
ECX = 00000003h / u: 3 / s: 3
```

Regression signs:

- Any `instruction-limit-exceeded` diagnostic with the default page run.
- Missing `execution-complete`.
- `ECX` remains `0`.
- Browser status still reports Phase 58.
- Program Console contains diagnostic text.

### Local CMD setup

From the project root:

```cmd
python scripts\run_tests.py --diagnostics
```

Expected output snippet:

```text
[diagnostics] PASS - native diagnostic producer and rendered messages passed
Selected test groups passed.
```

Create `program.asm` at the project root:

```cmd
type nul > program.asm
notepad program.asm
```

Paste this source:

```asm
.code
main PROC
    mov eax, 1
    mov ebx, 2
    mov ecx, 3
main ENDP
END main
```

### Local test 1 - default instruction limit allows completion

Run:

```cmd
build\tests\diagnostic_json_producer.exe program.asm > phase59_default.json
python -m json.tool phase59_default.json
```

Expected JSON snippets:

```json
"phase": 59
```

```json
"phaseName": "Phase 59 - Control-Flow Instruction Limit"
```

```json
"ok": true
```

```json
"status": "ok"
```

```json
"instructionCount": 3
```

```json
"instructionLimit": 1000000
```

```json
"executedInstructionCount": 3
```

```json
"attemptedNextInstructionIndex": null
```

```json
"currentInstructionIndex": 2
```

Expected register snippets:

```json
"EAX": {
    "hex": "00000001h",
    "unsigned": 1
}
```

```json
"EBX": {
    "hex": "00000002h",
    "unsigned": 2
}
```

```json
"ECX": {
    "hex": "00000003h",
    "unsigned": 3
}
```

Expected message snippets:

```json
"code": "startup-state-notice"
```

```json
"code": "execution-complete"
```

### Local test 2 - low instruction limit stops before third instruction

Run:

```cmd
set MASM32_DIAGNOSTIC_INSTRUCTION_LIMIT=2
build\tests\diagnostic_json_producer.exe program.asm > phase59_limit.json
set MASM32_DIAGNOSTIC_INSTRUCTION_LIMIT=
python -m json.tool phase59_limit.json
```

Expected JSON snippets:

```json
"phase": 59
```

```json
"ok": false
```

```json
"status": "execution-error"
```

```json
"instructionCount": 2
```

```json
"instructionLimit": 2
```

```json
"executedInstructionCount": 2
```

```json
"attemptedNextInstructionIndex": 2
```

```json
"currentInstructionIndex": 1
```

Expected register snippets:

```json
"EAX": {
    "hex": "00000001h",
    "unsigned": 1
}
```

```json
"EBX": {
    "hex": "00000002h",
    "unsigned": 2
}
```

```json
"ECX": {
    "hex": "00000000h",
    "unsigned": 0
}
```

Expected diagnostic snippets:

```json
"kind": "runtime-error"
```

```json
"code": "instruction-limit-exceeded"
```

```json
"message": "Instruction limit exceeded: attempted to execute instruction #3 (limit: 2). Program stopped before executing that instruction."
```

```json
"line": 5
```

```json
"column": 5
```

```json
"byteOffset": 50
```

```json
"spanLength": 10
```

Confirm this is absent:

```text
execution-complete
```

Regression signs:

- `ECX` becomes `00000003h`, meaning the blocked instruction executed.
- `execution-complete` appears after the runtime error.
- `attemptedNextInstructionIndex` is not `2`.
- Diagnostic does not point to line 5, column 5.
- Program reports an assembly error instead of a runtime error.

### Local test-suite commands

```cmd
python scripts\run_tests.py --source-run
python scripts\run_tests.py --web
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --protocol
python scripts\run_tests.py --static
```

Expected snippets:

```text
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

Optional full suite:

```cmd
python scripts\run_tests.py --all
```

Expected final snippet:

```text
All implemented milestone tests passed.
```

If Emscripten is unavailable, this skip is expected:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

This skip is not a Phase 59 failure.

## 14. Compliance review summary

First compliance review found:

- A stale response-truncation fallback in `src/wasm/wasm_api.c` hardcoded Phase 57F metadata.
- Some internal test failure messages still referenced Phase 58 runtime status.

Fixes applied:

- Updated the truncation fallback to use Phase 59 constants and include Phase 59 instruction-limit fields.
- Updated stale internal test comments/failure text to the current runtime phase wording.
- Reran focused groups and aggregate tests.

Result:

```text
Verdict: complete
```

## 15. Re-review summary

Second compliance review found:

- One JSDoc return type in `web/src/settings.js` did not include the Phase 59 invalid instruction-limit diagnostic variant.
- One internal source-run test assertion message still used Phase 58 wording.

Fixes applied:

- Updated the JSDoc return union.
- Updated the stale internal assertion wording.
- Reran source-run, web, static, and aggregate tests.

Result:

```text
Verdict: complete
```

## 16. User-test follow-up summary

User manual tests reported no functional discrepancies.

User feedback identified the original diagnostic wording as repetitive:

```text
Execution stopped after 2 executed VM instructions because the configured instruction limit (2) was reached before instruction index 2.
```

Accepted new wording:

```text
Instruction limit exceeded: attempted to execute instruction #3 (limit: 2). Program stopped before executing that instruction.
```

Fixes applied:

- Updated `instruction-limit-exceeded` runtime diagnostic wording.
- Computed a widened 1-based display instruction number for the rendered/raw diagnostic.
- Preserved JSON internal indexes and required field names.
- Updated exact rendered-message expectations.
- Reran source-run, diagnostics, web, protocol, static, native, and aggregate tests.

Result:

```text
All tests passed. No functional behavior changes were required.
```

## 17. Known limitations

- Browser/Wasm rebuild smoke could not run in the assistant/container environment because `emcc` was unavailable.
- Served website testing requires a fresh Emscripten rebuild.
- No visible browser UI control for `instructionLimit` exists in Phase 59; this is intentional because the guide requires a source-run/test-facing option.
- Phase 59 does not implement branch/control-flow instructions. `jmp`, conditional jumps, `loop`, calls, returns, stack behavior, and procedure behavior remain future work.
- The rendered diagnostic uses a 1-based instruction number, while source-run JSON fields use internal 0-based indexes.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 60 - Direct JMP Parsing and Target Lowering
```

Phase 60 should implement only direct `jmp` parsing/target lowering according to the implementation guide. Runtime jump execution remains owned by the later runtime execution phase unless the guide says otherwise.

## 19. Changed-files ZIP/package produced

Packages produced during this milestone:

- `milestone59_changed_files.zip`
- `milestone59.patch`
- `Latest_repository_state_milestone_59.zip`
- `milestone_59_first_compliance_check.zip`
- `milestone_59_second_compliance_check.zip`
- `milestone_59_user_test_followup.zip`
- `milestone_59_user_test_followup.patch`
- `milestone_59_final_compliance_check.zip`

Final recommended archive:

```text
Latest_repository_state_milestone_59.zip
```
