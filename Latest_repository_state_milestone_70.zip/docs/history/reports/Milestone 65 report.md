# Milestone 65 report - Signed Relational Conditional Jumps

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 65 - Signed Relational Conditional Jumps
```

Repository/archive milestone after this work:

```text
Phase 65 - Signed Relational Conditional Jumps
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 65 - Signed Relational Conditional Jumps
```

Status interpretation:

Phase 65 adds accepted MASM syntax, parser lowering, VM execution behavior, source-run diagnostics, and runtime phase metadata for signed relational conditional jumps. Repository/archive status and runtime/source-run MASM behavior status therefore match after this milestone.

Scope implemented:

- Direct-label signed relational conditional jumps are parsed, lowered, and executed:
  - `jl label` and `jnge label`
  - `jle label` and `jng label`
  - `jg label` and `jnle label`
  - `jge label` and `jnl label`
- Accepted targets match the existing direct branch target model used by direct `jmp` and equality conditional jumps: executable code labels and procedure-entry labels only.
- Signed relational jumps evaluate the correct modeled flags for each mnemonic:
  - `JL` / `JNGE`: `SF` and `OF`
  - `JGE` / `JNL`: `SF` and `OF`
  - `JLE` / `JNG`: `ZF`, `SF`, and `OF`
  - `JG` / `JNLE`: `ZF`, `SF`, and `OF`
- No signed relational jump consumes `CF`.
- `JL`, `JNGE`, `JGE`, and `JNL` do not consume `ZF`.
- The existing Phase 50B undefined-flag-use policy is applied before the branch decision.
- Warning mode emits `undefined-flag-use` diagnostics and continues with the deterministic preserved flag value.
- Off mode suppresses only the `undefined-flag-use` consumer diagnostic.
- Strict/error mode emits the diagnostic and stops before the branch decision, with no partial mutation and no `execution-complete` message.
- Taken and not-taken signed relational jumps count as one executed VM instruction.
- Signed relational jumps preserve registers, memory, modeled flag bits, flag-validity metadata, Program Console output, and memory-change rows.
- Signed relational jumps produce no memory-change rows of their own.
- Valid signed relational jumps no longer use or emit the deferred runtime branch diagnostic path.
- `web/index.html` was updated to identify Phase 65 and use a default source program demonstrating signed relational branching.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_65.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, audit, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 64D report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_64D.zip
```

Changed-files packages produced during implementation and review:

```text
milestone_65_implementation.zip
milestone_65_first_compliance_check.zip
milestone_65_second_compliance_check.zip
```

No `milestone_65_final_compliance_check.zip` was produced because the final gap check found no project-file changes to apply.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, UI stream separation, C99 core policy, diagnostic policy, and status-surface hygiene.
- The incremental implementation guide owns Phase 65 numbering, scope, tasks, required tests, acceptance criteria, branch-status reporting obligations, and milestone-report obligations.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or guide.
- TODO-style notes are implementation-risk evidence only and do not override the target milestone, canonical guide, or canonical specification.

## 3. Exact requirements implemented

### 3.1 Accepted signed relational conditional jump syntax

The parser now accepts the Phase 65 direct-label signed relational jump mnemonics:

```asm
jl label
jnge label
jle label
jng label
jg label
jnle label
jge label
jnl label
```

Mnemonic matching follows the existing case-insensitive instruction keyword policy. The new mnemonics are also reserved words and cannot be used as user-defined symbols.

### 3.2 Direct branch target validation

The implementation reuses the existing direct branch target classification model. Accepted Phase 65 targets are executable code labels and procedure-entry labels. Rejected targets include:

- unknown labels;
- data symbols;
- Irvine32 virtual routine/terminator names such as `exit` when used as a branch target;
- register targets;
- memory targets;
- immediate or numeric targets;
- branch distance/type override target forms that remain future work.

Target diagnostics preserve source line, column, byte offset, and span length, and rendered Simulator Messages tests cover the relevant UI-visible errors.

### 3.3 Signed branch condition behavior

The implemented branch conditions are:

```text
JL / JNGE:  branch if SF != OF
JGE / JNL:  branch if SF == OF
JLE / JNG:  branch if ZF == 1 or SF != OF
JG / JNLE:  branch if ZF == 0 and SF == OF
```

Functional source-run tests cover taken and not-taken paths, alias equivalence, equality behavior, signed less-than behavior, signed greater-than behavior, and signed-vs-unsigned raw-value behavior.

### 3.4 Modeled flag consumption and undefined-flag-use policy

The implementation routes flag consumption through the existing shared undefined-flag-use policy path before evaluating the branch decision.

Consumed-flag sets are exact:

- `JL` / `JNGE`: `SF`, `OF`
- `JGE` / `JNL`: `SF`, `OF`
- `JLE` / `JNG`: `ZF`, `SF`, `OF`
- `JG` / `JNLE`: `ZF`, `SF`, `OF`

Explicit test coverage verifies that:

- signed relational jumps do not consume `CF`;
- `JL`, `JNGE`, `JGE`, and `JNL` do not consume `ZF`;
- default warning mode emits a warning and continues;
- off mode suppresses only the consumer warning;
- strict/error mode stops before the branch decision;
- strict/error mode preserves registers, flags, flag-validity metadata, memory, Program Console output, and memory-change rows;
- strict/error mode does not emit `execution-complete`.

### 3.5 Instruction-count watchdog behavior

Taken and not-taken signed relational jumps count as executed VM instructions. Backward taken signed relational jump loops are covered by the existing instruction-count watchdog behavior and can produce the existing `instruction-limit-exceeded` runtime diagnostic.

No active-time or wall-clock watchdog behavior was added.

### 3.6 Runtime/source-run metadata and status surfaces

Runtime/source-run MASM behavior metadata advances to Phase 65 because this phase adds accepted syntax and executable runtime behavior.

Updated current-status surfaces include:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `web/index.html`
- source-run/status JSON/protocol-facing constants and tests

### 3.7 Browser/default source update

`web/index.html` now identifies Milestone 65 and its default editor source demonstrates a signed comparison and `jl` branch.

The default program is a smoke demonstration, not exhaustive coverage. The full test suite covers all primary and alias signed jump groups, diagnostics, and edge cases.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 65:

- Unsigned relational conditional jumps, including `ja`, `jae`, `jb`, `jbe`, `jna`, `jnae`, `jnb`, and `jnbe`.
- `loop` or loop-family instructions.
- Indirect branch targets.
- Register-target branches.
- Memory-target branches.
- Immediate or numeric-address branch targets.
- Branch distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Anonymous labels.
- `call`, `ret`, `leave`, stack execution, stack frames, procedure invocation, arguments, locals, `USES`, `PROTO`, or `INVOKE` behavior.
- Irvine32 callable routines beyond already-existing virtual behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Macro expansion.
- Debugger/editor branch behavior, including breakpoints, current-instruction highlighting, source navigation, CodeMirror gutter behavior, or branch-target highlighting.
- Active-time or wall-clock watchdog behavior.
- New memory operand behavior.
- New memory-validation policy behavior.
- New Program Console behavior.
- New browser UI controls.

Future work intentionally preserved:

- Phase 66 - Unsigned Relational Conditional Jumps.
- Later `loop` runtime behavior.
- Later indirect/register/memory/immediate branch target phases.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future Irvine32 routine expansion.
- Future `OPTION NOKEYWORD` keyword-control compatibility.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Runtime/source-run MASM behavior metadata should advance to Phase 65.
- **Reason:** Phase 65 adds accepted MASM syntax, parser lowering, VM execution behavior, source-run diagnostics, and protocol-visible runtime metadata.
- **Risk:** Status surfaces could be updated inconsistently if repository/archive status and runtime/source-run status are confused with prior maintenance/display-only phase behavior.
- **How to change later:** If a later phase is maintenance-only, preserve runtime/source-run metadata at the latest executable MASM behavior phase and state both status values explicitly.

### Assumption 2

- **Assumption:** Existing direct branch target validation should be extended rather than replaced.
- **Reason:** Phase 65 requires signed conditional jumps to accept the same executable label/procedure-entry targets as equality conditional jumps and reject the same future target categories.
- **Risk:** A broad rewrite could accidentally alter Phase 61 direct `jmp` or Phase 64 equality conditional jump diagnostics.
- **How to change later:** Refactor to a shared branch descriptor/table only with regression tests proving existing diagnostic wording, source spans, and behavior remain stable.

### Assumption 3

- **Assumption:** Source-run tests should provide most Phase 65 coverage, with native helper tests used for exact flag-consumption sets.
- **Reason:** Source-run tests exercise parser, labels, lowering, VM execution, diagnostics, JSON/status output, and rendered-message paths. Native helper tests can more precisely prove that unconsumed flags such as `CF`, and `ZF` for `JL`/`JGE`, are not checked.
- **Risk:** Too much reliance on helper tests could under-test the real source-run policy path.
- **How to change later:** Continue to add source-run fixtures for user-visible behavior and reserve native/helper tests for exact internal policy facts that are difficult to isolate through source alone.

### Assumption 4

- **Assumption:** Phase 65 should not add planned-read or planned-write memory access coverage.
- **Reason:** Signed relational jumps read modeled flags and instruction metadata only. They do not read or write simulated memory.
- **Risk:** Touching planned-access tables unnecessarily could regress Phase 64A memory-read validation behavior.
- **How to change later:** Future memory-capable branch, stack, call, procedure, debugger, or Irvine32 features must complete the planned-read/planned-write audit required by the guide.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in the assistant/container environment.
- **Risk:** A locally served browser could show stale Phase 64D behavior if Wasm artifacts are not rebuilt after applying Phase 65 C source changes.
- **How to change later:** On Windows, activate Emscripten with the local `emsdk_env.bat`, run `scripts\windows\build_wasm.cmd`, then serve the site with `scripts\windows\serve_web.cmd`.

## 6. Relevant TODO-style notes reviewed

```text
- Location:
  README.md and docs/SUPPORTED_SYNTAX.md current-status/future-work text
- Note text or summary:
  Signed relational jumps were listed as future work while equality conditional jumps were already implemented.
- Classification:
  target-owned
- Reason:
  Phase 65 directly implements signed relational conditional jumps.
- Action for this milestone:
  Resolved. Current-status and supported-syntax wording now describe signed relational direct-label jumps as implemented and preserve future-work wording for unsigned jumps and other branch families.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 65 section
- Note text or summary:
  Phase 65 implements only direct-label signed relational conditional jumps and requires exact consumed-flag behavior, undefined-flag-use policy integration, no-partial-mutation behavior, instruction-count watchdog coverage, target diagnostics, and branch-status reporting.
- Classification:
  target-owned
- Reason:
  This is the canonical target milestone scope and acceptance contract.
- Action for this milestone:
  Resolved by implementation, documentation/status updates, and tests. The implementation does not broaden beyond Phase 65.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 65 rejected-syntax and Phase 66 section
- Note text or summary:
  Unsigned relational jump mnemonics remain unimplemented until Phase 66.
- Classification:
  future-owned
- Reason:
  Phase 65 explicitly excludes unsigned relational jumps.
- Action for this milestone:
  Preserved. Unsigned relational jumps remain unsupported/deferred and are used in regression coverage as the still-future branch family.
```

```text
- Location:
  README.md, docs/SUPPORTED_SYNTAX.md, docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md Phase 65 non-goals and later branch sections
- Note text or summary:
  Loop-family instructions, indirect branches, stack/procedure transfer, active-time watchdog behavior, and debugger/editor branch behavior remain future-owned.
- Classification:
  future-owned
- Reason:
  These features are explicitly outside Phase 65.
- Action for this milestone:
  Preserved. Documentation and tests keep these deferrals intact.
```

```text
- Location:
  src/parser/parser.c direct-branch target handling
- Note text or summary:
  Branch distance/type overrides, memory targets, register targets, and immediate targets are deferred to later branch phases.
- Classification:
  future-owned
- Reason:
  Phase 65 accepts only direct executable label/procedure-entry targets.
- Action for this milestone:
  Preserved. The implementation extends existing direct-branch validation to signed relational jumps without enabling deferred target forms.
```

```text
- Location:
  src/wasm/wasm_api.c branch-runtime-deferred path
- Note text or summary:
  `branch-runtime-deferred` reports that a branch form was accepted for metadata, but runtime branch execution is deferred to a later branch phase.
- Classification:
  unclear during planning, resolved during implementation review
- Reason:
  Valid Phase 65 signed relational jumps must execute and must not use the deferred-runtime diagnostic path. The path remains valid only for explicitly deferred metadata-only branch forms.
- Action for this milestone:
  Resolved by inspection and regression tests proving valid signed relational jumps do not emit `branch-runtime-deferred`.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Signed relational jumps are no longer documented as future work in current status/syntax surfaces after Phase 65 implementation.
- Phase 65 implementation requirements from the guide are implemented and tested.
- The `branch-runtime-deferred` concern was resolved with tests proving valid Phase 65 signed jumps execute normally.

### Future-owned TODO-style notes intentionally preserved

- Unsigned relational conditional jumps remain deferred to Phase 66.
- `loop`, indirect/register/memory/immediate branches, branch distance/type overrides, stack/procedure transfer, debugger/editor behavior, and active-time watchdog behavior remain deferred.
- Future memory-reading opcode planned-access reminders remain future-owned and were not changed by this non-memory-access phase.

### Stale or contradicted TODO-style notes corrected

- No stale repository TODO-style notes required correction.
- Second compliance review corrected stale test-only wording that still referred to Phase 64/64A after runtime/source-run metadata advanced to Phase 65.

### Unresolved TODO-related risks

- None identified for Phase 65.

### New TODO-style notes added

- None.

## 8. Design summary

Phase 65 was implemented as a focused branch-runtime feature.

Primary design choices:

1. **Reuse the existing direct-branch target model.** Signed relational jumps share direct branch target classification and fixup behavior with already implemented direct `jmp` and equality conditional jumps.

2. **Add signed relational IR/runtime opcodes.** The IR and executor now distinguish Phase 65 signed relational jump opcodes and evaluate each mnemonic's signed condition from modeled flags.

3. **Use exact flag-consumption sets.** The implementation calls the shared undefined-flag-use helper with only the flags each mnemonic actually consumes.

4. **Preserve no-mutation branch behavior.** Signed relational jumps affect only control flow and instruction count. They do not change registers, memory, modeled flags, Program Console output, or memory-change rows.

5. **Keep future branch forms rejected.** Register, memory, immediate, numeric, indirect, and distance/type override targets remain rejected or deferred according to existing branch-target diagnostics.

6. **Advance runtime metadata intentionally.** Because Phase 65 adds accepted syntax and executable behavior, source-run/runtime status surfaces advance to Phase 65.

7. **Avoid planned-access changes.** Signed conditional jumps do not read or write simulated memory, so memory planned-read/planned-write collection was not changed.

8. **Update reserved-word behavior.** The new signed jump mnemonics are treated as reserved words and cannot be user-defined symbols.

## 9. Files changed

Changed project files in the final Phase 65 state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_ir.c`
- `src/core/vm_ir.h`
- `src/parser/parser.c`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

Generated/native build artifacts may have been created or updated by local test runs under build directories. They are not treated as source changes for milestone design purposes.

## 10. Tests added

### 10.1 Native executor and helper tests

Added or updated tests covering:

- signed relational jump runtime behavior;
- taken and not-taken branch paths;
- alias equivalence for `JL`/`JNGE`, `JLE`/`JNG`, `JG`/`JNLE`, and `JGE`/`JNL`;
- exact consumed-flag sets;
- no `CF` consumption by signed relational jumps;
- no `ZF` consumption by `JL`, `JNGE`, `JGE`, and `JNL`;
- preservation of registers, memory, modeled flag values, and flag-validity metadata where applicable.

### 10.2 Source-run tests

Added or updated source-run fixtures covering:

- `jl` taken and not taken;
- `jle` taken for less-than and equality, and not taken for greater-than;
- `jg` taken for greater-than and not taken for equality;
- `jge` taken for greater-than and equality, and not taken for less-than;
- alias behavior for `jnge`, `jng`, `jnle`, and `jnl`;
- signed-vs-unsigned raw-value behavior, such as `FFFFFFFFh` compared with `1`;
- valid Phase 65 branches not emitting `branch-runtime-deferred`;
- invalid targets;
- instruction-count watchdog behavior for signed conditional jump loops;
- undefined-flag-use warning, off, and strict/error policy behavior;
- no partial mutation on strict/error undefined-flag-use failure;
- no memory-change rows created by signed relational jumps.

### 10.3 Parser/reserved-word tests

Added or updated tests covering:

- signed relational jump mnemonic recognition;
- reserved-word rejection for new Phase 65 mnemonics used as data symbols or code labels;
- case-insensitive reserved-word behavior for new signed jump mnemonics;
- regression coverage for still-future unsigned relational jump mnemonics.

### 10.4 Rendered Simulator Messages tests

Added or updated Node/rendering integration tests covering:

- invalid signed branch targets;
- data-symbol target diagnostics;
- register/memory/immediate target forms where applicable;
- unknown target diagnostics;
- Irvine32 virtual routine/terminator target diagnostics;
- `undefined-flag-use` warning messages for signed branch consumers;
- strict/error undefined-flag-use messages and absence of `execution-complete`;
- Phase 64B message grouping/order preservation.

### 10.5 Protocol/status/static tests

Added or updated tests covering:

- source-run/runtime metadata reports Phase 65;
- worker/protocol-facing status reports Phase 65;
- documentation and `web/index.html` current-status surfaces report Phase 65;
- future branch families remain documented as future work;
- default web source demonstrates signed relational branching.

### 10.6 Regression tests preserved

Retained and reran regression coverage for:

- Phase 61 direct `jmp` runtime execution;
- Phase 64 equality conditional jumps;
- Phase 64A `cmp` memory planned-read behavior;
- Phase 64B message grouping/order;
- Phase 64C expanded EFLAGS display;
- Phase 64D memory-change source attribution display;
- undefined-flag-use behavior for prior flag consumers such as `adc`, `sbb`, and `cmc`;
- Program Console and Simulator Messages stream separation;
- `.CONST` write failure behavior;
- source-run and web formatter behavior.

## 11. Commands used to test

### 11.1 Implementation test pass

Focused commands run after implementation:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command run after implementation:

```bash
python3 scripts/run_tests.py --all
```

Implementation pass result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate completed and passed
```

Skipped dependency check:

```text
group skipped because dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

### 11.2 First compliance review test pass

Commands rerun after first compliance review fixes:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

First compliance result:

```text
--source-run: PASS
--native: PASS
--diagnostics: PASS
--static: PASS
--all: PASS - all implemented milestone tests passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate completed and passed
```

### 11.3 Second compliance review test pass

Commands rerun after second compliance review fixes:

```bash
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --all
```

Second compliance result:

```text
--native: PASS
--source-run: PASS
--diagnostics: PASS
--static: PASS
--structure: PASS
--web: PASS
--protocol: PASS
--all: timed out in the assistant/container environment
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate timed out but focused groups passed
```

### 11.4 Final gap-check test pass

Commands rerun during final gap check:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Final gap-check result:

```text
--structure: PASS
--native: PASS
--source-run: PASS
--web: PASS
--diagnostics: PASS
--protocol: PASS
--static: PASS
--all: timed out in the assistant/container environment
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate timed out but focused groups passed
```

No subgroup or fixture-family reruns were needed because each focused group completed and passed.

## 12. Pass/fail result distinction

Observed result categories across the milestone:

- **aggregate completed and passed:** yes, during implementation and first compliance review.
- **aggregate timed out but focused groups passed:** yes, during second compliance review and final gap check in the assistant/container environment.
- **aggregate failed:** no.
- **focused group failed:** no.
- **focused group timed out and was rerun by subgroup/fixture:** no.
- **group skipped because dependency was unavailable:** yes, browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

The latest final gap-check verification should be interpreted as focused verification passed with aggregate timeout in the assistant/container environment. Earlier in the milestone, the aggregate command completed and passed.

## 13. Manual/browser testing guidance and expected outputs

Phase 65 is website-testable after rebuilding Wasm with Emscripten because it changes C parser/executor behavior.

### Required setup on Windows

From a Visual Studio/Emscripten-ready environment:

```bat
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Then open:

```text
http://localhost:8000
```

If `emcc` is unavailable, browser/Wasm testing is expected to be skipped or stale. Local native/source-run/Node tests can still run without Emscripten.

### Browser smoke test: signed relational jump matrix

Paste this program into the web editor:

```asm
.code
main PROC
    mov ebx, 0
    mov eax, -1
    cmp eax, 1
    jl jl_taken
    mov ebx, 0BAD0001h
jl_taken:
    or ebx, 1
    cmp eax, 1
    jge bad_ge_less
    or ebx, 2
    jmp after_ge_less
bad_ge_less:
    mov ebx, 0BAD0002h
after_ge_less:
    mov eax, 5
    cmp eax, 5
    jle jle_equal
    mov ebx, 0BAD0003h
jle_equal:
    or ebx, 4
    cmp eax, 4
    jg jg_greater
    mov ebx, 0BAD0004h
jg_greater:
    or ebx, 8
    cmp eax, 4
    jge jge_greater
    mov ebx, 0BAD0005h
jge_greater:
    or ebx, 10h
    cmp eax, 4
    jle bad_jle_greater
    or ebx, 20h
    jmp after_jle_greater
bad_jle_greater:
    mov ebx, 0BAD0006h
after_jle_greater:
    cmp eax, 4
    jnle jnle_greater
    mov ebx, 0BAD0007h
jnle_greater:
    or ebx, 40h
endlabel:
    nop
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected relevant final registers:

```text
EAX    | 00000005h / u: 5          / s:  5
EBX    | 0000007Fh / u: 127        / s:  127
EFLAGS | 00000000h / 0
  CF   | 0
  ZF   | 0
  SF   | 0
  OF   | 0
```

Expected memory changes:

```text
No memory changes.
```

A final `EBX` value beginning with `0BAD` indicates a signed branch decision regression.

### Browser diagnostic test: invalid signed branch target

Paste this program:

```asm
.data
target DWORD 0
.code
main PROC
    cmp eax, eax
    jl target
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-branch-target line 6, column 8, byte offset 61, span length 6: JL target cannot be a data symbol. Direct conditional jumps accept only code labels with executable instruction targets.
```

Expected Program Console:

```text
(empty)
```

There must be no `execution-complete` message.

### Browser diagnostic test: undefined flag-use warning path

With undefined-flag-use policy at default warning mode, paste:

```asm
.code
main PROC
    mov al, 1
    shl al, 8
    jl target
    mov ebx, 1
target:
    nop
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[simulator-warning] undefined-shift-flag line 4, column 5, byte offset 34, span length 9: SHL count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
[simulator-warning] undefined-flag-use line 5, column 5, byte offset 48, span length 9: JL reads OF, but OF is architecturally undefined from SHL at line 4. The simulator preserved the flag deterministically; this flag-dependent behavior is not portable.

[info] execution-complete: Execution completed successfully.
```

Warning mode should still execute. If execution stops in default warning mode, the undefined-flag-use policy regressed.

### Windows CMD local testing

From the project root:

```bat
py scripts\run_tests.py --source-run
py scripts\run_tests.py --diagnostics
py scripts\run_tests.py --web
py scripts\run_tests.py --protocol
py scripts\run_tests.py --static
```

Expected result snippets:

```text
[source-run] PASS
[diagnostics] PASS
[web] PASS
[protocol] PASS
[static] PASS
```

Optional aggregate command:

```bat
py scripts\run_tests.py --all
```

Expected success when the local environment allows the aggregate to complete:

```text
All implemented milestone tests passed.
```

If Emscripten is not available, this skip is expected:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

## 14. Compliance review summary

### First compliance review

Issue found:

- Source-run tests did not explicitly exercise every primary signed mnemonic edge required by the guide.

Fix applied:

- Added focused source-run coverage for primary `jle`, `jg`, and `jge` taken/not-taken cases.

Files changed during first compliance review:

- `tests/core/test_wasm_source_run.c`

Verification:

- `--source-run`: PASS
- `--native`: PASS
- `--diagnostics`: PASS
- `--static`: PASS
- `--all`: PASS

### Second compliance review

Issues found:

- Stale test-only wording still referred to Phase 64/64A after runtime metadata advanced to Phase 65.
- A small reserved-word regression gap existed for new signed jump mnemonics.

Fixes applied:

- Updated stale test-only comments/assertion descriptions and diagnostic fixture reasons.
- Added parser reserved-word regression tests for `jl` as a data symbol and `JGE` as a code label.

Verification:

- Focused groups passed: `--native`, `--source-run`, `--diagnostics`, `--static`, `--structure`, `--web`, `--protocol`.
- Aggregate timed out in the assistant/container environment after focused groups passed.

## 15. Re-review summary

The final gap check found no missing Phase 65 implementation, documentation, test coverage, package, TODO, or web-status work.

Final gap-check findings:

- No missing work found.
- No target-owned TODO-style notes remained unresolved.
- Future-owned branch/control-flow deferrals remained accurate.
- No stale TODO-style note was introduced.
- No files were changed during the final gap check.
- Focused groups passed.
- Aggregate timed out in the assistant/container environment.

## 16. User-test follow-up summary

Prompt 8 was skipped because no user-reported discrepancies were provided after the manual testing instructions. No user-test follow-up fixes were applied.

## 17. Known limitations

- Browser/Wasm artifacts were not rebuilt in the assistant/container environment because `emcc` was unavailable.
- Served-website verification requires a local Emscripten rebuild.
- Unsigned relational jumps remain future work for Phase 66.
- `loop`, indirect/register/memory/immediate branches, branch distance/type overrides, stack/procedure transfer, debugger/editor branch behavior, and active-time watchdog behavior remain future work.
- Phase 65 does not add any new Program Console behavior or browser UI controls.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 66 - Unsigned Relational Conditional Jumps
```

The next implementation should begin from the accepted Phase 65 repository state and use this archive name:

```text
Latest_repository_state_milestone_65.zip
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced:

```text
milestone_65_implementation.zip
milestone_65_first_compliance_check.zip
milestone_65_second_compliance_check.zip
```

No final compliance package was produced because the final gap check found no file changes.

Latest repository/archive recommendation after acceptance:

```text
Latest_repository_state_milestone_65.zip
```
