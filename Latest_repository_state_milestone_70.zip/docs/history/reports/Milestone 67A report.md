# Milestone 67A report - Entry Procedure Runtime Boundary and END Entry Selection

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 67A - Entry Procedure Runtime Boundary and END Entry Selection
```

Repository/archive milestone after this work:

```text
Phase 67A - Entry Procedure Runtime Boundary and END Entry Selection
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 67A - Entry Procedure Runtime Boundary and END Entry Selection
```

Scope implemented:

- `END entryName` is now authoritative for source-run startup.
- Source-run starts at the first executable instruction inside the selected entry procedure.
- Empty selected entry procedures complete successfully without executing another procedure or source-order code block.
- Ordinary fallthrough at the selected entry procedure `ENDP` boundary completes successfully exactly once.
- Helper procedures before the selected entry no longer execute automatically by lowered-instruction order.
- Helper procedures after the selected entry no longer execute by ordinary fallthrough from the selected entry.
- Existing explicit supported control flow, including direct `jmp label` to ordinary labels or procedure-entry labels, remains supported.
- Existing Irvine32-style `exit` termination remains supported inside the selected entry procedure.
- Existing runtime diagnostics and instruction-count watchdog behavior remain active inside the selected entry procedure.
- Runtime/source-run metadata advanced from Phase 66 to Phase 67A because the milestone changes runtime-visible source-run behavior.
- Current-status documentation and `web/index.html` were updated to describe Phase 67A without appending milestone-history clutter.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_67A.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, audit, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 67 report.md`
- latest repository archive derived from `LATEST_COMPLETED_MILESTONE = 67`:

```text
Latest_repository_state_milestone_67.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, procedure-boundary contract, diagnostic policy, memory-safety policy, C99 core policy, and current-status surface hygiene.
- The incremental implementation guide owns Phase 67A numbering, scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or guide.
- The Milestone 42 audit/handoff report is historical navigation only. It was reviewed for regression risk, but it does not override later canonical docs, later milestone reports, or the Phase 67 repository state.
- TODO-style notes are implementation-risk evidence only and do not override Phase 67A, the canonical guide, or the canonical specification.

## 3. Exact requirements implemented

### 3.1 Procedure-range metadata

Added parser result metadata for accepted `PROC` / `ENDP` ranges. Each accepted range records:

- procedure name;
- declaration source location;
- first lowered instruction index;
- exclusive end instruction index;
- whether the procedure contains an executable instruction.

The parser also records which accepted procedure is selected by `END entryName` when the caller provides procedure-range storage. Existing parser callers that do not request procedure-range metadata retain their previous behavior.

### 3.2 Selected-entry source-run startup

Source-run now loads the program and sets the VM instruction pointer to the selected entry procedure's first executable instruction. When the selected entry procedure is empty, source-run halts immediately and reports successful completion without executing any earlier or later procedure.

### 3.3 Selected-entry fallthrough boundary

After each successful VM step, source-run detects ordinary fallthrough to the selected entry procedure's exclusive end boundary and halts successfully. This prevents accidental execution of later procedures by source-order fallthrough.

The boundary check distinguishes ordinary fallthrough from explicit supported control flow. Existing direct `jmp label` behavior remains executable, including jumps to procedure-entry labels.

### 3.4 Existing termination and diagnostic behavior preserved

Existing Irvine32-style `exit` terminates successfully from inside the selected entry procedure. Existing runtime diagnostics, such as divide-by-zero, still stop execution and suppress `execution-complete`. Existing instruction-count watchdog behavior continues to apply after corrected entry startup.

### 3.5 Runtime/source-run metadata advanced

Runtime/source-run phase metadata now reports Phase 67A because this milestone changes runtime-visible source-run behavior.

### 3.6 Current-status surfaces updated

Concise current-status surfaces were updated to identify Phase 67A while replacing active current-status text rather than appending another milestone ledger.

Updated status surfaces include:

- `README.md`;
- `docs/SUPPORTED_SYNTAX.md`;
- `docs/BUILDING_AND_DEVELOPMENT.md`;
- `docs/MILESTONE_HISTORY.md`;
- `web/index.html`;
- `web/src/protocol.js`;
- source-run/Wasm runtime metadata strings and phase fields;
- tests that assert current status and runtime metadata.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 67A:

- `CALL`.
- `RET`.
- root `RET`.
- `PUSH` or `POP`.
- `LEAVE`.
- `RET imm16`.
- stack mutation.
- procedure frames.
- `PROC USES`.
- `LOCAL`.
- `PROTO`.
- `INVOKE`.
- `ADDR`.
- Irvine32 routine dispatch beyond existing `exit` behavior.
- Phase 68 call-target classification.
- call-depth diagnostics.
- debugger stack display.
- debugger/editor procedure navigation.
- new branch target forms.
- `loop` or loop-family instructions.
- indirect/register/memory/immediate branch targets.
- branch distance/type overrides.
- new memory operand behavior.
- new memory-validation policy behavior.
- new Program Console behavior.
- `OPTION NOKEYWORD` keyword-control behavior.
- macro, WinAPI, PE/linker, host-filesystem, or object-file behavior.

Future work intentionally preserved:

- Phase 68 - Call Target Classification and Procedure Entry Metadata.
- Later CALL/RET/stack/procedure-frame phases.
- Later Irvine32 routine dispatch phases.
- Later debugger/editor navigation phases.
- Later branch target expansion phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 67A advances runtime/source-run MASM behavior metadata.
- **Reason:** It changes where source-run execution starts and where ordinary selected-entry fallthrough stops.
- **Risk:** Tests that previously asserted Phase 66 metadata needed intentional updates, and over-broad status updates could hide unrelated status drift.
- **How to change later:** If project policy later treats Phase 67A as non-runtime metadata work, revert runtime/source-run metadata to Phase 66 and keep the entry-boundary implementation as a documented exception.

### Assumption 2

- **Assumption:** Phase 67A should stop only ordinary source-order fallthrough, not explicit supported branch transfer.
- **Reason:** The specification says instructions before or after the selected entry can execute only through explicit supported control flow, and direct `jmp label` is already implemented.
- **Risk:** Later CALL/RET phases may need stricter procedure-entry and procedure-exit rules.
- **How to change later:** Extend the Phase 67A boundary metadata in Phase 68 and later CALL/RET phases with explicit transfer-kind and call-stack state.

### Assumption 3

- **Assumption:** No new user-visible diagnostic code is needed for ordinary selected-entry fallthrough.
- **Reason:** The canonical guide requires successful completion at the selected entry boundary and no warning for ordinary selected-entry fallthrough.
- **Risk:** Internal invalid procedure metadata states still need defensive handling.
- **How to change later:** Add a specific internal/runtime diagnostic only if a later source path makes invalid procedure metadata user-reachable.

### Assumption 4

- **Assumption:** The minimal Phase 67A procedure-range metadata must not become the Phase 68 call-target classifier.
- **Reason:** Phase 68 owns richer target classification for future CALL/INVOKE behavior.
- **Risk:** Future assistants might infer CALL support from procedure metadata alone.
- **How to change later:** Keep Phase 68 changes explicit: add call-target classifications separately without treating Phase 67A metadata as executable CALL behavior.

### Assumption 5

- **Assumption:** Browser/Wasm smoke testing can remain dependency-skipped in the assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in this environment, and the native/source-run/web/protocol/diagnostic/static groups verify the changed behavior without requiring Emscripten.
- **Risk:** A locally served browser could still use stale Wasm artifacts if the user does not rebuild locally.
- **How to change later:** On Windows, activate Emscripten with `emsdk_env.bat`, run `scripts\windows\build_wasm.cmd`, then serve with `scripts\windows\serve_web.cmd` before browser testing.

## 6. Relevant TODO-style notes reviewed

```text
- Location:
  docs/SUPPORTED_SYNTAX.md, procedure and entry-point status
- Note text or summary:
  Known pre-Phase-67A defect: source-run may start at the first lowered instruction in source order instead of the procedure named by END entryName; helper procedures before main can execute accidentally; helper procedures after main can execute by fallthrough.
- Classification:
  target-owned
- Reason:
  This is exactly the runtime-boundary defect Phase 67A corrects.
- Action for this milestone:
  Resolved with implementation, source-run tests, rendered-message tests, and supported-syntax documentation updates.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md, future/unsupported procedure status
- Note text or summary:
  Corrected END entryName source-run entry behavior is listed as future/unsupported in Phase 67 repository state.
- Classification:
  target-owned
- Reason:
  Phase 67A moves this behavior from future/unsupported to implemented.
- Action for this milestone:
  Resolved by replacing current-status and procedure-status text after implementation and tests.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 67A - Entry Procedure Runtime Boundary and END Entry Selection
- Note text or summary:
  Phase 67A owns runtime startup from END entryName, selected-entry procedure fallthrough termination, and prevention of accidental execution outside the selected procedure.
- Classification:
  target-owned
- Reason:
  This is the canonical target milestone scope and acceptance contract.
- Action for this milestone:
  Resolved with minimal procedure-range metadata and source-run boundary behavior.
```

```text
- Location:
  src/parser/parser.c, Irvine32 symbol-use helper comment
- Note text or summary:
  CALL target classification is deferred until CALL exists; the current helper handles only currently recognized bare mnemonic-like Irvine32 forms.
- Classification:
  future-owned
- Reason:
  Phase 67A does not implement CALL or full call-target classification.
- Action for this milestone:
  Preserved. No Phase 68 call-target classification was implemented.
```

```text
- Location:
  src/wasm/wasm_api.c, planned-read/planned-write future instruction reminder
- Note text or summary:
  Future memory-reading opcodes must be added to planned-read collection when implemented.
- Classification:
  future-owned
- Reason:
  Phase 67A does not add a memory-reading opcode or change simulated memory access behavior.
- Action for this milestone:
  Preserved. No planned-read/planned-write path changed.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md and guide future-work sections
- Note text or summary:
  CALL, RET, root RET, stack mutation, PUSH/POP, PROC USES, LOCAL, PROTO, INVOKE, ADDR, and Irvine32 routine calls remain future work.
- Classification:
  future-owned
- Reason:
  Phase 67A corrects selected-entry startup and selected-entry fallthrough only.
- Action for this milestone:
  Preserved as future work.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- The pre-Phase-67A selected-entry startup/fallthrough defect note was resolved.
- The supported-syntax future-status note for corrected `END entryName` runtime behavior was replaced with implemented behavior wording.
- The Phase 67A guide-owned target scope was implemented.

### Future-owned TODO-style notes intentionally preserved

- CALL target classification.
- CALL/RET/root-RET behavior.
- Stack mutation and procedure-frame behavior.
- Irvine32 routine dispatch beyond existing `exit`.
- Planned-read/planned-write reminders for future memory-reading opcodes.
- Future branch target forms.
- Future debugger/editor procedure navigation.
- Future `OPTION NOKEYWORD` keyword-control behavior.

### Stale or contradicted TODO-style notes corrected

- The first compliance pass corrected stale planned Phase 67A history text in `docs/MILESTONE_HISTORY.md`.
- The final gap check corrected stale Phase 66 assertion wording in `tests/core/test_wasm_source_run.c`. That item was stale test wording, not a TODO-style note.
- No stale target-owned TODO-style note remains.

### Unresolved TODO-related risks

- None identified for Phase 67A.

## 8. Design summary

Phase 67A uses parser-owned procedure-range metadata and source-run-owned startup/boundary control.

The parser now optionally records accepted procedure ranges for source-run callers. This avoids broad rewrites of existing parser callers while giving source-run enough metadata to honor `END entryName`.

Source-run sets the VM instruction pointer to the selected entry procedure's first executable instruction after loading the lowered program. Empty entries halt immediately with success.

The source-run execution loop detects ordinary fallthrough to the selected entry procedure's exclusive boundary after successful instruction execution. It halts successfully only for fallthrough, not for explicit supported branch transfer. That preserves direct `jmp label` behavior and keeps CALL/RET semantics deferred.

The new metadata remains intentionally narrower than Phase 68 call-target classification. It is sufficient for startup and fallthrough boundaries, but it does not classify user procedures as callable targets or add call-stack behavior.

## 9. Procedure and entry-boundary disposition

- Selected END entry procedure:
  - Implemented. `END entryName` selects an accepted `PROC` range for source-run startup.
- Source-run startup begins at selected entry procedure:
  - Yes. The VM instruction pointer is initialized to the selected procedure's first executable instruction.
- Instructions before selected entry procedure can execute only through explicit supported control flow:
  - Yes. They do not execute automatically by source order.
- Instructions after selected entry procedure can execute only through explicit supported control flow:
  - Yes. Ordinary fallthrough at the selected entry `ENDP` boundary completes instead of continuing into later procedures.
- Entry procedure fallthrough behavior:
  - Ordinary fallthrough at the selected entry procedure boundary completes successfully exactly once.
- Non-entry procedure fallthrough behavior:
  - Not implemented as CALL/RET behavior. Non-entry procedures do not execute automatically by source-order fallthrough from the selected entry, but existing explicit direct branches may still transfer to labels or procedure-entry labels.
- CALL behavior changed:
  - No.
- RET behavior changed:
  - No.
- Stack mutation changed:
  - No.
- Irvine32 registry/user procedure namespace boundary preserved:
  - Yes. Existing `exit` behavior is preserved; no Irvine32 routine dispatch or user-procedure CALL namespace behavior was added.
- Source-run tests added:
  - Yes.
- Rendered Simulator Messages tests added:
  - Yes. Exact rendered-message tests cover selected-entry fallthrough success, empty selected-entry success, and fatal runtime diagnostics inside the selected entry procedure suppressing `execution-complete`. Existing rendered diagnostic coverage was also updated to Phase 67A metadata where fixtures assert current runtime phase fields.
- Runtime/source-run MASM behavior phase advanced:
  - Yes, to Phase 67A.

## 10. Planned-read/planned-write coverage

Phase 67A did not add, change, correct, or reclassify simulated memory access behavior. It did not add a memory-capable opcode, runtime routine, debugger action, stack feature, call/return feature, string/buffer feature, or memory-validation policy path.

Applicable review result:

- Newly added simulated memory reads:
  - None.
- Newly added simulated memory writes:
  - None.
- Changed simulated memory reads:
  - None.
- Changed simulated memory writes:
  - None.
- Read-modify-write forms added or changed:
  - None.
- Implicit memory accesses added or changed:
  - None.
- Planned-read collection updated:
  - No; not applicable.
- Planned-write collection updated:
  - No; not applicable.
- Object/declared-bounds planned-access collection updated:
  - No; not applicable.
- Section-capacity planned-access collection updated:
  - No; not applicable.
- Section-image planned-access collection updated:
  - No; not applicable.
- Uninitialized-read policy coverage applies:
  - No new policy coverage required by Phase 67A. Existing policy behavior remains unchanged.
- `.CONST` or protected-region write protection can apply:
  - No new write behavior was added.
- Cross-region protected-region diagnostics can apply:
  - No new memory access behavior was added.
- Source line, column, byte offset, and span length preservation:
  - Existing diagnostics remain source-span aware. Phase 67A did not add a new user-visible diagnostic path.

## 11. Current-status documentation disposition

Current-status documentation disposition:

- README changed:
  - Yes.
- README current-status block replaced rather than appended:
  - Yes.
- README current-scope block remains concise:
  - Yes.
- SUPPORTED_SYNTAX opening status block replaced rather than appended:
  - Yes.
- BUILDING_AND_DEVELOPMENT avoided feature-history accumulation:
  - Yes.
- MILESTONE_HISTORY updated for historical detail:
  - Yes.
- Browser/protocol/source-run status text changed:
  - Yes. Browser `web/index.html`, protocol constants, and source-run runtime metadata now identify Phase 67A.
- Runtime/source-run metadata advanced:
  - Yes.
- Reason runtime/source-run metadata did or did not advance:
  - Phase 67A changes runtime-visible source-run startup and selected-entry fallthrough behavior.
- Static documentation checks added or updated:
  - Yes. Runner documentation/status checks now verify Phase 67A current-status surfaces.
- Manual documentation checks performed, if static checks were skipped:
  - Static checks were run and passed.
- Clutter risk remaining:
  - Low. Current-status surfaces were replaced with concise Phase 67A wording and history was kept in `docs/MILESTONE_HISTORY.md`.

## 12. Files changed

Changed project files in the final Phase 67A state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`
- `Milestone 67A report.md`

Generated native test binaries under `build/tests/` may have been created or updated by local test runs. They are not treated as source changes for milestone design purposes.

## 13. Tests added

### 13.1 Parser tests

Added:

- `test_phase67a_procedure_range_metadata`
- `test_phase67a_procedure_range_capacity_diagnostic`

Coverage includes:

- multiple accepted procedure ranges;
- selected `END entryName` procedure metadata;
- first and exclusive-end instruction indexes;
- empty procedure metadata;
- source location and span retention for procedure declarations;
- structured parser status for procedure-range capacity exhaustion;
- structured diagnostic code and source span for the rejected procedure range;
- no insertion of the rejected procedure range after capacity exhaustion.

### 13.2 Source-run tests

Added:

- `test_phase67a_entry_procedure_runtime_boundary_source_run`
- `test_phase67a_entry_boundary_error_and_transfer_regressions`

Coverage includes:

- helper procedure before selected entry does not execute automatically;
- helper procedure after selected entry does not execute by ordinary fallthrough;
- empty selected entry completes successfully;
- non-`main` selected entry starts correctly;
- fatal runtime diagnostic inside selected entry prevents completion and avoids helper side effects;
- existing `exit` behavior inside selected entry remains successful;
- existing explicit direct `jmp` to a procedure-entry label remains executable;
- non-taken conditional jump at the selected entry boundary halts successfully rather than falling into a later procedure.

### 13.3 Metadata/protocol/rendered-message tests

Added exact rendered Simulator Messages tests:

- `phase67aSelectedEntryFallthroughCompletion`
- `phase67aEmptySelectedEntryCompletion`
- `phase67aSelectedEntryFatalDiagnostic`

Coverage includes:

- selected-entry fallthrough emits exactly one `execution-complete`;
- empty selected entry emits exactly one `execution-complete`;
- fatal runtime diagnostics inside the selected entry procedure suppress `execution-complete`;
- ordinary selected-entry fallthrough emits no procedure-boundary warning.

Updated existing tests to expect Phase 67A runtime/source-run metadata where the runtime reports current phase fields. Existing rendered diagnostic coverage remains active and was updated to Phase 67A metadata where fixtures assert current runtime phase fields.

### 13.4 Static/status tests

Updated the runner/static status checks to verify Phase 67A current-status surfaces and prevent stale Phase 66 runtime metadata text from remaining in active status surfaces.

## 14. Commands used to test and pass/fail results

### 14.1 Focused group commands

Focused groups run:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused result summary:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
Selected test groups passed.
```

Focused group classification:

```text
focused groups passed
```

No focused group failed. No focused group timed out. No subgroup or fixture-family rerun was needed.

### 14.2 Aggregate command

Aggregate command run during implementation and compliance review:

```bash
python3 scripts/run_tests.py --all
```

During the final gap check, the aggregate command timed out in the assistant/container environment before completion, but every focused group passed afterward.

During the second compliance review, the aggregate command completed and passed in the assistant/container environment with this result summary:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Aggregate result classification:

```text
aggregate completed and passed during second compliance review
aggregate timed out in final gap-check assistant/container rerun, focused groups passed
```

This means the project had at least one completed aggregate pass after Phase 67A implementation and compliance fixes, and the last final-gap rerun was verified through focused groups because of the container timeout.

### 14.3 Skipped dependency checks

Skipped dependency check:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
group skipped because a dependency was unavailable
```

This is an environment limitation, not a Phase 67A implementation failure. Website verification requires a local Emscripten rebuild.

## 15. Manual/browser testing guidance and expected outputs

Phase 67A is website-testable after rebuilding Wasm locally.

### Required browser setup on Windows CMD

```cmd
cd C:\path\to\project
call C:\path\to\emsdk\emsdk_env.bat
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the local URL printed by the server script.

### Browser test 1: default Phase 67A selected-entry behavior

Paste or use the default page-load program:

```asm
.code
helperBefore PROC
    mov ecx, 111      ; does not run automatically
helperBefore ENDP

main PROC
    mov eax, 100      ; END main starts here
    cmp eax, 100
    je selectedPath
    mov ebx, 999
selectedPath:
    mov ebx, 1
main ENDP             ; normal fallthrough completes here

helperAfter PROC
    mov edx, 222      ; does not run by fallthrough
helperAfter ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected key final registers:

```text
EAX = 00000064h / 100
EBX = 00000001h / 1
ECX = 00000000h / 0
EDX = 00000000h / 0
ZF  = 1
```

Expected Program Console:

```text
(empty)
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `ECX = 0000006Fh / 111` means helper-before-entry ran incorrectly.
- `EDX = 000000DEh / 222` means helper-after-entry ran by fallthrough incorrectly.
- `EBX = 000003E7h / 999` means existing `je` behavior regressed.
- Missing `execution-complete` means ordinary selected-entry fallthrough did not complete correctly.

### Browser test 2: empty selected entry

```asm
.code
main PROC
main ENDP
helper PROC
    mov ecx, 2
helper ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected key final registers:

```text
EAX = 00000000h / 0
EBX = 00000000h / 0
ECX = 00000000h / 0
EDX = 00000000h / 0
```

Regression signs:

- `ECX = 00000002h / 2` means an empty selected entry incorrectly fell into the later helper procedure.
- Any assembly or runtime error means empty selected entry completion regressed.

### Browser test 3: non-main selected entry

```asm
.code
main PROC
    mov eax, 9
main ENDP
helper PROC
    mov ebx, 7
helper ENDP
END helper
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected key final registers:

```text
EAX = 00000000h / 0
EBX = 00000007h / 7
ECX = 00000000h / 0
EDX = 00000000h / 0
```

Regression signs:

- `EAX = 00000009h / 9` means execution incorrectly started at source-order `main` instead of `END helper`.
- `EBX = 00000000h / 0` means the selected helper procedure did not run.

### Browser test 4: fatal diagnostic inside selected entry

```asm
.code
helper PROC
    mov ecx, 55
helper ENDP
main PROC
    mov eax, 5
    mov ebx, 0
    div ebx
main ENDP
after PROC
    mov edx, 99
after ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[runtime-error] divide-by-zero line 8, column 5, byte offset 90, span length 7: DIV divisor operand EBX evaluated to zero. Division by zero is not allowed. Execution stopped before updating the quotient register EAX and remainder register EDX.
```

Expected key final registers:

```text
EAX = 00000005h / 5
EBX = 00000000h / 0
ECX = 00000000h / 0
EDX = 00000000h / 0
```

Regression signs:

- Seeing `execution-complete` after the divide-by-zero error is a regression.
- `ECX = 00000037h / 55` means the helper before `main` ran incorrectly.
- `EDX = 00000063h / 99` means the later procedure ran after the fatal diagnostic.

### Local Windows CMD verification

`program.asm` is not required for the built-in local tests. Use repository fixtures:

```cmd
cd C:\path\to\project
python scripts\run_tests.py --source-run
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --web
python scripts\run_tests.py --protocol
python scripts\run_tests.py --static
python scripts\run_tests.py --all
```

Expected focused snippets:

```text
[source-run] PASS - source-run integration binary passed independently
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[web] PASS - browser-side Node module tests passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

Expected aggregate final snippet:

```text
All implemented milestone tests passed.
```

An `emcc` skip is acceptable for local non-browser verification. It is not acceptable for browser verification if testing the served website with the new Wasm behavior.

## 16. Compliance review summary

### First compliance review

Issues found:

- Missing required exact rendered Simulator Messages tests for Phase 67A success/failure boundary behavior.
- `docs/MILESTONE_HISTORY.md` still contained stale planned Phase 67A text after implementation.
- Older Phase 64A/64B/64C/64D status paragraphs remained in the active milestone-history status area.
- `Milestone 67A report.md` understated rendered-message coverage.

Fixes applied:

- Added exact rendered-message tests for selected-entry fallthrough success, empty selected-entry success, and fatal selected-entry runtime diagnostic.
- Removed stale planned Phase 67A history text.
- Cleaned active status clutter in milestone history.
- Updated the milestone report.

Test result:

- Focused groups passed.
- Aggregate timed out in that compliance pass, but focused groups passed.

Package produced:

```text
milestone_67A_first_compliance_check.zip
```

### Second compliance review

Issues found:

- Misplaced Doxygen block in `src/wasm/wasm_api.c`.
- Stale Phase 66 wording in source-run and rendered-message test metadata comments.
- Missing direct parser test for the procedure-range capacity diagnostic path.
- Milestone report still described aggregate as timeout-limited after a later aggregate pass completed.

Fixes applied:

- Restored Doxygen placement above the correct source-run internal function.
- Corrected stale test wording to Phase 67A.
- Added `test_phase67a_procedure_range_capacity_diagnostic`.
- Updated the milestone report with the new test and completed aggregate result.

Test result:

- All focused groups passed.
- Aggregate `python3 scripts/run_tests.py --all` completed and passed.

Package produced:

```text
milestone_67A_second_compliance_check.zip
```

## 17. Re-review and final gap-check summary

Final gap check found one remaining stale assertion-message issue in `tests/core/test_wasm_source_run.c`: several assertions still described “Phase 66 metadata” while asserting Phase 67A runtime metadata.

Fix applied:

- Updated the stale assertion messages to describe current Phase 67A runtime metadata.

Final focused test result:

- `--source-run`: PASS
- `--static`: PASS
- `--structure`: PASS
- `--native`: PASS
- `--web`: PASS
- `--diagnostics`: PASS
- `--protocol`: PASS

Final aggregate status:

- The final gap-check aggregate run timed out in the assistant/container environment before completion.
- Because the second compliance aggregate completed and passed, and every focused group passed after the final assertion-message fix, this was treated as an environment limitation rather than a project failure.

Package produced:

```text
milestone_67A_final_compliance_check.zip
```

## 18. User-test follow-up summary

Prompt 8 was conditional and was not run. No user-provided discrepancy report was received after manual testing guidance.

Status:

```text
No user-test fixes were required because no user-test discrepancies were provided.
```

## 19. Known limitations

- Browser/Wasm smoke testing was not run in the assistant/container environment because `emcc` is unavailable.
- Website testing requires a local Emscripten rebuild after applying the changed files.
- Phase 67A does not implement CALL, RET, stack mutation, procedure frames, CALL target classification, Irvine32 callable routine dispatch, or debugger procedure navigation.
- Explicit `jmp` to a procedure-entry label remains direct branch behavior, not procedure-call behavior.
- Phase 67A procedure metadata is intentionally minimal and should be extended by Phase 68 rather than treated as full call-target classification.

## 20. Next recommended milestone

```text
Phase 68 - Call Target Classification and Procedure Entry Metadata
```

Reason:

- Phase 67A establishes selected-entry startup and selected-entry fallthrough boundaries.
- Phase 68 is the next canonical guide phase and should add richer procedure/call-target metadata without implementing CALL execution unless the guide says so.

## 21. Changed-files ZIP/packages produced

Packages produced during this milestone session:

- `milestone_67A_implementation.zip`
- `milestone_67A_first_compliance_check.zip`
- `milestone_67A_second_compliance_check.zip`
- `milestone_67A_final_compliance_check.zip`

Report file produced:

```text
Milestone 67A report.md
```

Recommended full repository/archive package:

```text
Latest_repository_state_milestone_67A.zip
```

