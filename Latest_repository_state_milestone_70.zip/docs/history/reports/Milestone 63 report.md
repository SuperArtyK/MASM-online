# Milestone 63 report - CMP Memory Operand Forms

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 63 - CMP Memory Operand Forms
```

Repository/archive milestone after this work:

```text
Phase 63 - CMP Memory Operand Forms
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 63 - CMP Memory Operand Forms
```

Scope implemented:

- Added executable CMP memory operand forms:
  - `cmp reg, mem`
  - `cmp mem, reg`
  - `cmp mem, imm`
- Preserved Phase 62 CMP register/register and register/immediate behavior.
- Implemented CMP memory reads through the existing checked VM memory helpers.
- Routed CMP memory reads through source-run planned-read validation before flags are updated.
- Preserved CMP as a read-only comparison instruction:
  - compared operands are not mutated;
  - memory is not mutated;
  - successful CMP execution creates no memory-change rows;
  - Program Console output is unchanged.
- Advanced runtime/source-run metadata and browser/protocol status surfaces to Phase 63.
- Updated user-facing documentation and the default `web/index.html` sample to reflect Phase 63.
- Preserved conditional jumps and later branch/control-flow work as future scope.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_63.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 62 report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_62.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, source-run/status hygiene, and broad product constraints.
- The implementation guide owns Phase 63 numbering, exact phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or implementation guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or implementation guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

## 3. Exact requirements implemented

### 3.1 CMP memory operand syntax

Implemented parser and runtime support for:

```asm
cmp reg, mem
cmp mem, reg
cmp mem, imm
```

Examples now accepted:

```asm
.data
value DWORD 6

.code
main PROC
    mov eax, 6
    cmp eax, value
    cmp value, eax
    cmp value, 7
main ENDP
END main
```

### 3.2 Width resolution for memory operands

CMP memory operands use existing memory-width resolution rules. Memory width may come from:

- declared symbol metadata, such as `value DWORD 6`;
- explicit `PTR` overrides, such as `BYTE PTR [eax]`, `WORD PTR [eax]`, or `DWORD PTR [eax]`;
- existing global memory-width resolution rules where another operand supplies an unambiguous width.

Ambiguous memory/immediate forms remain rejected with `ambiguous-memory-width` diagnostics. For example:

```asm
cmp [eax], 1
```

still requires an explicit width override such as:

```asm
cmp DWORD PTR [eax], 1
```

### 3.3 Checked memory reads

CMP memory forms read memory through existing checked VM memory helpers. Invalid Level 1 memory accesses stop execution before CMP consumes the memory value or mutates flags.

Example failure case:

```asm
.code
main PROC
    mov eax, 0
    cmp DWORD PTR [eax], 1
main ENDP
END main
```

Expected runtime diagnostic category:

```text
runtime-error / invalid-address
```

### 3.4 Planned-read validation before flags update

CMP memory reads now participate in the source-run/Wasm planned-read policy path before flags are updated.

Covered planned-read behavior includes:

- default region-only Level 1 behavior;
- uninitialized-read warning mode;
- uninitialized-read strict/error mode;
- section-capacity warning and strict behavior;
- section-image warning and strict behavior;
- declared-object warning and strict behavior.

Strict planned-read failures preserve the no-partial-mutation guarantee:

- registers retain their pre-instruction values;
- modeled flags retain their pre-instruction values;
- flag-validity metadata is preserved;
- memory is unchanged;
- Program Console output is unchanged;
- no memory-change rows are created;
- no `execution-complete` message is emitted after a fatal diagnostic.

### 3.5 Flag-only subtraction semantics

CMP memory forms use the same subtraction/compare flag behavior as Phase 62 CMP and earlier subtraction helpers.

Implemented modeled flags updated on successful comparison:

- `CF`
- `ZF`
- `SF`
- `OF`

`PF` and `AF` remain unimplemented because they are not currently modeled flags.

### 3.6 Operand preservation and no memory-change rows

CMP remains read-only. Successful CMP memory comparisons:

- do not write the result anywhere;
- do not mutate registers or memory;
- do not create successful memory-change rows;
- do not write to `.CONST` or any other section.

### 3.7 `.CONST` read behavior

CMP can read initialized `.CONST` storage when the read range is otherwise valid.

Example:

```asm
.CONST
limit DWORD 10

.code
main PROC
    cmp limit, 10
main ENDP
END main
```

This is accepted because `.CONST` is read-only, not read-prohibited.

### 3.8 Uninitialized-origin read diagnostics

CMP memory reads preserve existing uninitialized-origin teaching diagnostics. In default warning mode, CMP reads from `.DATA?`, `?`, `DUP(?)`, and accepted `.CONST ?` / `.CONST DUP(?)` uninitialized-origin bytes warn and continue. In strict/error mode, execution stops before flags are updated.

### 3.9 Unsupported executable QWORD/SQWORD memory operations remain rejected

CMP memory forms do not enable executable QWORD/SQWORD memory operations in MASM32 Educational Mode.

Examples that remain rejected:

```asm
cmp QWORD PTR qval, eax
cmp SQWORD PTR qval, 1
```

Rendered diagnostic coverage was added for these rejection paths.

### 3.10 Runtime/source-run metadata advancement

Because Phase 63 changes accepted executable MASM/source behavior, runtime/source-run metadata was advanced to:

```json
{
  "phase": 63,
  "phaseSuffix": "",
  "phaseName": "Phase 63 - CMP Memory Operand Forms"
}
```

Status surfaces and tests were updated consistently.

### 3.11 Browser page default sample update

`web/index.html` was updated so the page header/sample reflects Phase 63. The default editor program now demonstrates CMP memory operand forms.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 63:

- Phase 64 equality conditional jumps:
  - `je`
  - `jz`
  - `jne`
  - `jnz`
- Signed relational conditional jumps.
- Unsigned relational conditional jumps.
- `loop`, `loope`, `loopne`, `jcxz`, or `jecxz`.
- Indirect jumps.
- Register-target, memory-target, or immediate-target `jmp` execution.
- Branch-distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Relative branch encoding or real x86 instruction encoding.
- Native x86 execution.
- Stack or procedure execution semantics.
- `call`, `ret`, `leave`, `push`, or `pop`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 callable routines beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Active-time watchdog behavior.
- Wall-clock execution limits.
- Worker yielding/chunking for responsiveness.
- Browser UI controls for execution time or capacity limits.
- Macro expansion.
- Debugger stepping, breakpoints, breakpoint binding, editor source navigation, current-instruction highlighting, CodeMirror gutter behavior, or branch-target editor highlighting.
- PF/AF flag storage or display.
- Executable QWORD/SQWORD memory operations in MASM32 Educational Mode.
- New scaled-index addressing forms.
- `OPTION NOKEYWORD` behavior or dynamic keyword-table mutation.

Future work intentionally preserved:

- Phase 64 - Equality Conditional Jumps.
- Later conditional and relational jump phases.
- Later `loop` phase.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future Irvine32 routine expansion.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- Future memory-reading opcode planned-access work noted in `src/wasm/wasm_api.c`.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 63 should reuse the existing `VM_IR_OPCODE_CMP` rather than add a new IR opcode for memory forms.
- **Reason:** Phase 62 already introduced CMP as the semantic instruction opcode; Phase 63 expands operand forms and validation only.
- **Risk:** If the existing executor dispatch had been too register/immediate-specific, a larger refactor could have been required.
- **How to change later:** Refactor CMP execution around a more general operand-read helper while preserving the same opcode and adding regression tests.

### Assumption 2

- **Assumption:** CMP memory forms should use the existing memory-width resolution paths wherever possible.
- **Reason:** The implementation guide requires memory width to come from symbol metadata, explicit `PTR`, or existing global width-resolution rules.
- **Risk:** Helpers originally used by write-capable instructions could accidentally classify read-only CMP memory operands as writes if reused carelessly.
- **How to change later:** Keep a CMP-specific validation wrapper around shared width inference when read/write classification matters.

### Assumption 3

- **Assumption:** `cmp mem, imm` immediate validation should use the resolved memory width.
- **Reason:** Existing instruction behavior validates immediates against the destination or resolved operand width, and Phase 63 requires known memory width.
- **Risk:** Future MASM compatibility work may choose to model narrower x86 immediate-encoding/sign-extension details.
- **How to change later:** Add a later compatibility correction phase if the project deliberately models more detailed MASM/x86 immediate encoding semantics.

### Assumption 4

- **Assumption:** `.CONST` operands are valid CMP read operands when the read range is otherwise valid.
- **Reason:** Stable `.CONST` behavior prohibits writes, not reads. CMP is read-only.
- **Risk:** A cross-region or strict validation setting may still reject a specific read for another reason, which can confuse users if they infer that `.CONST` itself is read-prohibited.
- **How to change later:** Keep diagnostics specific to the actual failure condition and preserve `.CONST` read behavior unless the canonical spec deliberately changes.

### Assumption 5

- **Assumption:** Runtime/source-run phase metadata should advance from Phase 62 to Phase 63.
- **Reason:** Phase 63 changes executable MASM/source behavior by accepting and executing CMP memory operand forms.
- **Risk:** Missing a status surface would leave stale documentation or failing static/protocol tests.
- **How to change later:** Update the standard metadata/status surfaces and static checks together when the next runtime-visible phase is implemented.

### Assumption 6

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in this environment.
- **Risk:** Locally served browser artifacts may remain stale until a developer rebuilds Wasm with Emscripten configured.
- **How to change later:** Run the Windows Emscripten build script in an environment where `emcc` is available.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning, implementation, compliance review, second review, manual-test preparation, and final gap check:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 63 - CMP Memory Operand Forms
- Note text or summary:
  Phase 63 implements CMP memory operand forms, including `cmp reg, mem`, `cmp mem, reg`, and `cmp mem, imm`; memory reads must use checked helpers and planned-read validation before flags are updated.
- Classification:
  target-owned
- Reason:
  This is the selected TARGET_MILESTONE.
- Action for this milestone:
  Implemented CMP memory operand behavior and tests.
```

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
- Classification:
  target-owned for CMP in Phase 63; future-owned for later memory-reading opcodes.
- Reason:
  CMP becomes a memory-reading opcode in Phase 63.
- Action for this milestone:
  Added CMP to planned-read/planned-object-access collection. Preserved the general future-opcode TODO for later instruction milestones.
```

```text
- Location:
  src/parser/parser.c, CMP validation logic
- Note text or summary:
  Phase 62 CMP validation rejected memory operands with deferral wording naming Phase 63.
- Classification:
  target-owned
- Reason:
  Phase 63 must replace deferral with accepted memory operand validation.
- Action for this milestone:
  Replaced memory-form deferral with Phase 63 supported validation and preserved invalid-form diagnostics.
```

```text
- Location:
  tests/core/test_parser.c and tests/web/test_diagnostic_rendering.mjs
- Note text or summary:
  Existing tests asserted CMP memory operands were deferred to Phase 63.
- Classification:
  target-owned
- Reason:
  These tests became stale once Phase 63 implemented the memory forms.
- Action for this milestone:
  Replaced or revised tests to assert Phase 63 accepted/rejected behavior and rendered diagnostics.
```

```text
- Location:
  README.md, docs/SUPPORTED_SYNTAX.md, docs/MILESTONE_HISTORY.md, docs/BUILDING_AND_DEVELOPMENT.md, web/index.html, web/src/protocol.js, scripts/run_tests.py
- Note text or summary:
  Status text, syntax text, sample code, protocol metadata, and static checks reflected Phase 62 and treated CMP memory operands as future Phase 63 work.
- Classification:
  target-owned
- Reason:
  Phase 63 changes runtime/source-run MASM behavior and current-status surfaces.
- Action for this milestone:
  Updated status surfaces, syntax documentation, sample code, and static checks to Phase 63.
```

```text
- Location:
  docs/FULL_IMPLEMENTATION_SPEC.md, read-only instruction behavior
- Note text or summary:
  Read-only instructions such as `cmp`, `test`, `lea`, and jumps must not create successful memory-change rows.
- Classification:
  target-owned
- Reason:
  Phase 63 CMP memory forms read memory but remain read-only comparisons.
- Action for this milestone:
  Implemented and tested no operand mutation and no memory-change rows.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, later branch/control-flow phases
- Note text or summary:
  Equality conditional jumps and later branch behavior follow CMP support.
- Classification:
  future-owned
- Reason:
  Phase 63 updates comparison support only; it does not implement flag-consuming branches.
- Action for this milestone:
  Left conditional jumps and later branch behavior unimplemented.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 63 CMP memory operand behavior was implemented.
- CMP was added to planned-read/planned-object-access routing in `src/wasm/wasm_api.c`.
- Phase 62 CMP memory deferral parser logic was replaced with Phase 63 validation.
- Phase 62 deferral tests were replaced or revised.
- Status docs, syntax docs, milestone history, protocol metadata, `index.html`, and static checks were advanced to Phase 63.
- CMP no-memory-change behavior was preserved and tested.

### Future-owned TODO-style notes intentionally preserved

- The general future memory-reading opcode TODO in `src/wasm/wasm_api.c` remains accurate for later memory-reading instruction milestones.
- Conditional jump phases remain future-owned.
- Later `loop` runtime behavior remains future-owned.
- Stack/procedure/call/return phases remain future-owned.
- Debugger/editor/source-map behavior remains future-owned.
- Active-time watchdog behavior remains future-owned.
- Irvine32 routine expansion remains future-owned.
- Macro/linker/WinAPI behavior remains future-owned.
- `OPTION NOKEYWORD` keyword-control compatibility remains future-owned.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style notes were found.
- Non-TODO stale comments/assertion descriptions found during compliance review were corrected:
  - stale Phase 62 assertion descriptions in source-run tests;
  - stale parser file/header or Doxygen wording that did not reflect Phase 63 coverage.

### Unresolved TODO-related risks

- None specific to Phase 63.

## 8. Design summary

Phase 63 was implemented as a focused parser/executor/source-run policy/status milestone.

Primary design choices:

1. **Single CMP opcode.** The existing `VM_IR_OPCODE_CMP` now supports both Phase 62 register/immediate forms and Phase 63 memory forms.

2. **Shared width rules.** CMP memory operands use existing memory-width resolution paths so they behave consistently with the rest of the implemented MASM subset.

3. **Read-before-update execution.** The executor reads operands first and updates flags only after all required reads succeed.

4. **No write classification.** CMP memory first operands are read operands, not write destinations. This is important for `.CONST` reads and for no-memory-change behavior.

5. **Planned-read integration.** Source-run planned-read collection includes CMP so optional teaching policies can warn or stop before CMP consumes memory or updates flags.

6. **Failure no-partial-mutation.** Invalid reads and strict planned-read failures stop before flags, flag-validity metadata, memory, console output, or memory-change rows are changed.

7. **Current-status hygiene.** Because Phase 63 changes runtime-visible MASM/source behavior, source-run metadata and status surfaces were advanced to Phase 63.

8. **Future-scope protection.** Conditional jumps and later branch/control-flow work were not implemented.

## 9. Files changed

Changed files in the final Phase 63 state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/parser/parser.c`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

Added or strengthened tests/checks:

- Parser tests for accepted CMP memory forms:
  - `cmp reg, mem`
  - `cmp mem, reg`
  - `cmp mem, imm`
  - direct symbol operands;
  - explicit `PTR` operands;
  - symbol-offset operands.
- Parser tests for rejected forms:
  - ambiguous memory width;
  - memory-to-memory CMP;
  - width mismatches;
  - QWORD/SQWORD executable memory operations;
  - malformed CMP operands.
- Executor tests for CMP memory forms:
  - memory source comparisons;
  - memory first-operand comparisons;
  - memory/immediate comparisons;
  - equality and inequality;
  - signed-negative bit patterns;
  - unsigned carry cases;
  - operand preservation;
  - no memory-change rows;
  - invalid memory-read failure with flag preservation.
- Source-run tests for:
  - Phase 63 metadata;
  - CMP memory success paths;
  - `.CONST` CMP reads;
  - uninitialized-read warning mode;
  - uninitialized-read strict/error mode;
  - section-capacity warning and strict paths;
  - section-image warning and strict paths;
  - declared-object warning and strict paths;
  - invalid Level 1 memory read behavior;
  - no partial mutation on strict/fatal planned-read failures.
- Rendered Simulator Messages tests for:
  - CMP memory success;
  - ambiguous memory width;
  - uninitialized-read warning and strict diagnostics;
  - unsupported QWORD/SQWORD executable memory operation diagnostics.
- Protocol/status tests updated for Phase 63.
- Static checks updated for Phase 63 status and `index.html` sample text.
- Regression coverage preserving Phase 62 CMP register/register and register/immediate behavior, direct `jmp`, watchdog, reserved-word behavior, and prior memory validation behavior.

## 11. Commands used to test

### Pre-implementation repository verification

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Implementation verification

Focused commands run:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
All focused groups passed.
```

Aggregate command run:

```bash
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### First compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
All focused groups passed after correcting one declared-object warning assertion from object-bounds-violation to object-bounds-warning.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Second compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
All focused groups passed.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Final gap-check verification

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

## 12. Pass/fail result classification

- Pre-implementation aggregate: aggregate completed and passed.
- Implementation verification focused groups: focused groups passed.
- Implementation aggregate: aggregate completed and passed.
- First compliance review: focused groups passed and aggregate completed and passed.
- Second compliance review: focused groups passed and aggregate completed and passed.
- Final gap check: aggregate completed and passed.
- Browser/Wasm rebuild smoke: group skipped because dependency was unavailable (`emcc` unavailable in this environment).
- No aggregate failure occurred.
- No focused group remained failing.
- No focused group timeout required subgroup/fixture-family reruns.

## 13. Manual/browser testing guidance and expected outputs

### Browser testing applicability

Phase 63 is website-testable after rebuilding browser Wasm artifacts with Emscripten. In this assistant/container environment, `emcc` was unavailable, so browser/Wasm rebuild smoke was skipped. Local native/source-run/Node tests passed.

### Windows/browser setup

From Windows CMD in the project root:

```cmd
set EMSDK_ROOT=C:\_CPP_TOOLS\emsdk
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Then open:

```text
http://localhost:8000/web/
```

If `build_wasm.cmd` reports that `emcc` was not found, the browser may still be using stale Wasm artifacts. Fix the Emscripten environment before treating browser results as authoritative.

### Manual program 1: all Phase 63 CMP memory forms

```asm
.data
value DWORD 6

.code
main PROC
    mov eax, 6
    cmp eax, value
    cmp value, eax
    cmp value, 7
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected key Final Registers lines:

```text
EAX    | 00000006h / u: 6          / s:  6
EFLAGS | 00000081h / 129
```

Expected Memory Changes:

```text
No memory changes.
```

Expected Program Console: empty.

### Manual program 2: ambiguous memory width diagnostic

```asm
.code
main PROC
    mov eax, 00500000h
    cmp [eax], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 4, column 9, byte offset 47, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Expected behavior:

- No execution success message.
- No memory changes.
- Execution must not start because this is an assembly error.

### Manual program 3: runtime memory-read failure

```asm
.code
main PROC
    mov eax, 0
    cmp DWORD PTR [eax], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] invalid-address line 4: Invalid memory read at 00000000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

Expected key Final Registers lines:

```text
EAX    | 00000000h / u: 0          / s:  0
EFLAGS | 00000000h / 0                                  [unchanged]
```

Expected Memory Changes:

```text
No memory changes.
```

### Manual program 4: uninitialized-read warning with CMP

```asm
.DATA?
buf DWORD ?

.code
main PROC
    cmp buf, 0
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] uninitialized-read line 5: Memory read range 00500000h..00500003h reads 4 bytes from buf + 0; 4 of those bytes still originated from uninitialized storage.
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected key Final Registers line:

```text
EFLAGS | 00000040h / 64
```

Expected Memory Changes:

```text
No memory changes.
```

### Windows CMD local test commands

Aggregate test command:

```cmd
py scripts\run_tests.py --all --quiet
```

Expected output includes:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
All implemented milestone tests passed.
```

Acceptable skip when `emcc` is unavailable:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

## 14. Compliance review summary

First compliance review found and fixed test coverage and wording gaps:

- stale Phase 62 assertion descriptions in tests;
- missing SQWORD executable-memory rejection coverage;
- missing section-capacity strict planned-read coverage;
- missing declared-object warning planned-read coverage;
- missing rendered unsupported `QWORD/SQWORD PTR` CMP diagnostics;
- incorrect expected declared-object warning code, corrected from `object-bounds-violation` to `object-bounds-warning`.

Files changed during first compliance review:

- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`

Result after fixes:

```text
Focused groups passed.
Aggregate completed and passed.
Browser/Wasm rebuild smoke skipped because emcc unavailable.
```

## 15. Re-review summary

Second compliance review found and fixed stale comments/descriptions only:

- stale file header in `tests/core/test_parser.c` that described parser coverage only through Phase 60 direct JMP lowering;
- stale Doxygen comment in `src/parser/parser.c` that described CMP validation as register/immediate-only;
- source-run assertion descriptions that referred too broadly to “Phase 62 CMP fixture” instead of “Phase 62 CMP register/immediate fixture.”

No behavior changes were made during the second review.

Result after fixes:

```text
Focused groups passed.
Aggregate completed and passed.
Browser/Wasm rebuild smoke skipped because emcc unavailable.
```

## 16. User-test follow-up summary

Prompt 8 user-test triage was not provided because the user reported no discrepancies and proceeded directly to the final gap check.

Manual testing guidance was provided in Prompt 7, including concrete browser programs, exact expected Simulator Messages, expected register/memory behavior, Windows CMD local commands, and regression signs.

## 17. Known limitations

- Browser/Wasm artifacts were not rebuilt in this environment because `emcc` is unavailable.
- Served website behavior requires a local Emscripten rebuild before browser artifacts are authoritative.
- Executable QWORD/SQWORD CMP memory operations remain unsupported in MASM32 Educational Mode.
- Memory-to-memory CMP remains rejected.
- Conditional jumps remain future work.
- Relational jumps remain future work.
- `loop` and related branch families remain future work.
- Stack/procedure/call/return behavior remains future work.
- Debugger/editor branch behavior remains future work.
- PF/AF flags remain unimplemented.
- No new Irvine32 routines were implemented.
- No WinAPI, PE loading/linking, object-file, import-library, host include loading, or macro expansion behavior was implemented.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 64 - Equality Conditional Jumps
```

Phase 64 should use Phase 63 CMP flag results as input to implement equality conditional jumps, while applying the standing undefined-flag-use helper rule for modeled flag consumers.

## 19. Changed-files ZIP/package produced

Changed-files and compliance packages produced during this milestone:

- `phase63_changed_files.zip`
- `milestone_63_first_compliance_check.zip`
- `milestone_63_second_compliance_check.zip`

No final compliance ZIP was produced because the final gap check made no file changes.

