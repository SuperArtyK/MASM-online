# Milestone 56A report - Test Runner Decomposition and Assistant Verification Ergonomics

## 1. Milestone title and scope

Milestone 56A implements **Phase 56A - Test Runner Decomposition and Assistant Verification Ergonomics** for the Online MASM32 Educational Simulator.

This milestone is a test-runner, test-documentation, and verification-ergonomics milestone. It does not add new MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser UI behavior, diagnostic codes, diagnostic JSON fields, or rendered Simulator Messages wording.

Scope implemented:

- Added focused test-runner groups so expensive test families can be run independently.
- Preserved the default aggregate command as full verification.
- Added `--all`, `--quick`, `--quiet`, and `--verbose` runner modes.
- Added compact summary reporting with selected groups and not-run groups.
- Added bounded but useful failure reporting that identifies the group, command, exit code, and stdout/stderr context.
- Made source-run integration tests independently runnable through `--source-run`.
- Made rendered Simulator Messages diagnostics independently runnable through `--diagnostics`.
- Made protocol tests independently runnable through `--protocol`.
- Added runner/static self-checks for help output, accepted flags, documentation consistency, source-run fixture inventory, timeout guidance, and failure-reporting policy.
- Reviewed `tests/core/test_wasm_source_run.c`; kept it whole because the new `--source-run` group runs it independently within the assistant/container limit.
- Added source-run fixture inventory and fixture-size guidance to the testing documentation.
- Added timeout-safe assistant/container verification guidance to testing documentation.
- Updated README test-command guidance.
- Preserved all completed Milestone 56 behavior.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/TESTING_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`, reviewed for non-impact and not changed
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 56 report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_56.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, phase tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Phase 56A is the only target milestone for this implementation session.
- Phase 56A is inserted after Phase 56 and before Phase 57. It does not renumber Phase 57.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- User-visible diagnostic tests and rendered Simulator Messages tests were preserved.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

### 3.1 Focused runner groups

Implemented these test-runner entry points:

```text
python3 scripts/run_tests.py
python3 scripts/run_tests.py --all
python3 scripts/run_tests.py --quick
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

The default command remains equivalent to full verification through `--all`.

Focused groups implemented:

- `structure`: repository structure, metadata, and C99/static structure checks.
- `native`: native C tests except source-run integration and diagnostic JSON producer tests that have dedicated groups.
- `source-run`: source-run integration binary, including `tests/core/test_wasm_source_run.c`.
- `web`: browser-side Node module tests that are not owned by the diagnostics or protocol groups.
- `diagnostics`: native diagnostic JSON producer plus exact rendered Simulator Messages tests.
- `protocol`: protocol tests.
- `static`: runner/documentation consistency checks and Phase 56A self-checks.

### 3.2 Aggregate and quick modes

Implemented:

```text
--all
--quick
```

Behavior:

- `--all` runs the full implemented test suite groups and prints the final success line only when every selected group passes.
- `--quick` runs a smoke subset and explicitly reports that full verification was not performed.
- `--quick` does not print `All implemented milestone tests passed.` because it is not full verification.

### 3.3 Output controls

Implemented:

```text
--quiet
--verbose
```

Behavior:

- Default output remains compact.
- `--quiet` still prints required group start/status lines, the final summary, and failure details.
- `--verbose` prints command-level details before running selected commands.
- Failure output is intentionally not hidden by quiet mode.

### 3.4 Failure reporting

Implemented bounded failure reporting that includes:

- selected group name;
- command;
- exit code;
- stdout context;
- stderr context.

The runner no longer relies on a single long aggregate stream as the only practical verification path.

### 3.5 Summary table

Implemented a final summary table with selected and non-selected groups. Status values include:

```text
PASS
FAIL
NOT-RUN
```

Emscripten/browser rebuild smoke is reported separately. When `emcc` is unavailable, the report says the Wasm rebuild smoke was skipped because `emcc` is unavailable.

### 3.6 Source-run test review

Reviewed `tests/core/test_wasm_source_run.c` as required by Phase 56A.

Disposition:

- Kept whole for Phase 56A.
- Added independent `--source-run` group so the file can be compiled and run without the full aggregate suite.
- Verified the group passes independently in the assistant/container environment.
- Documented that future subdivision is only needed if `--source-run` later becomes too large or times out.

### 3.7 Diagnostic-rendering test review

Rendered Simulator Messages tests are independently runnable through:

```text
python3 scripts/run_tests.py --diagnostics
```

This group builds/runs the native diagnostic JSON producer and then runs the Node rendered-message test harness. Exact rendered diagnostic assertions were preserved.

### 3.8 Documentation updates

Updated testing documentation with:

- focused group commands;
- quick mode warning;
- quiet/verbose behavior;
- Windows CMD command examples;
- source-run fixture inventory;
- large fixture and fixture-splitting policy;
- timeout-safe assistant/container verification guidance;
- aggregate-versus-focused reporting guidance;
- Emscripten/browser smoke skip reporting.

Updated README with focused test-runner command guidance.

### 3.9 Static/self-check coverage

Added `--static` checks for Phase 56A runner and documentation expectations, including:

- required help flags;
- accepted flags;
- unknown flag failure behavior;
- documentation consistency for required commands;
- source-run fixture inventory presence;
- timeout-safe verification guidance presence;
- failure-reporting policy presence.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 56A:

- signed `idiv`;
- any new instruction;
- any parser behavior;
- any VM or executor behavior;
- any memory model behavior;
- any Wasm API behavior;
- any browser UI behavior;
- any Program Console behavior;
- any diagnostic code, diagnostic JSON field, or rendered Simulator Messages wording change;
- any change to MASM syntax support;
- source-run subgroups beyond the required independent `--source-run` group;
- diagnostic subgroups beyond the required independent `--diagnostics` group;
- physical splitting of `tests/core/test_wasm_source_run.c`, because independent focused execution passed;
- physical splitting of rendered diagnostic tests, because independent focused execution passed;
- broader CI configuration;
- Emscripten build changes.

Future work intentionally left deferred:

- Phase 57 - Signed IDIV.
- Future test-runner decomposition if `--source-run` or `--diagnostics` later grows large enough to require subgroups.
- Future instruction opcode TODO in `src/wasm/wasm_api.c`.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `scripts/run_tests.py` should remain the central test-runner entry point instead of adding several wrapper scripts.
- **Reason:** Phase 56A names `scripts/run_tests.py` as the interface and requires portable focused commands.
- **Risk:** The runner file becomes more complex.
- **How to change later:** Extract helper modules under `scripts/` later while preserving the public command-line interface.

### Assumption 2

- **Assumption:** `tests/core/test_wasm_source_run.c` can remain whole in Phase 56A.
- **Reason:** The new `--source-run` group compiles and runs it independently within the assistant/container limit.
- **Risk:** The file may still be large enough to become difficult to maintain later.
- **How to change later:** Split it into behavior-family source-run test files in a future test-runner decomposition phase if focused execution starts timing out or the file becomes too hard to maintain.

### Assumption 3

- **Assumption:** Diagnostic subgroups are not required in Phase 56A.
- **Reason:** The new `--diagnostics` group runs independently and passes.
- **Risk:** Future diagnostic coverage growth may make the group too large.
- **How to change later:** Add diagnostic subgroups such as memory, directives, compatibility, arithmetic, shift/rotate, and mul/div while keeping `--diagnostics` as the all-diagnostics umbrella.

### Assumption 4

- **Assumption:** `--quick` should be explicitly smoke-only and must not claim full verification.
- **Reason:** The guide requires `--quick` as a smoke subset and requires honest reporting.
- **Risk:** Users could mistake quick-mode success for full suite success if documentation is ignored.
- **How to change later:** Add stronger wording or a separate final quick-mode summary if user confusion appears.

### Assumption 5

- **Assumption:** The website does not need manual browser testing for this milestone.
- **Reason:** Phase 56A did not change browser runtime behavior, worker protocol shape, formatter public API, Wasm output, or served UI behavior.
- **Risk:** A documentation-only or runner-only change could still accidentally affect files used by the browser if future edits expand scope.
- **How to change later:** Require manual browser smoke when `web/src`, `web/dist`, Wasm artifacts, or formatter APIs are touched.

## 6. Relevant TODO-style notes reviewed

### Note 1

- **Location:** `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, Phase 56A and related test-runner guidance.
- **Note text or summary:** Future milestone reports must distinguish aggregate completion, focused group runs, subgroup/fixture reruns, and browser/Wasm smoke availability.
- **Classification:** target-owned.
- **Reason:** This is directly part of Phase 56A verification ergonomics.
- **Action for this milestone:** Implemented runner support and documentation that allow this distinction. This report records the distinction explicitly.

### Note 2

- **Location:** `src/wasm/wasm_api.c`.
- **Note text or summary:** Future opcode TODO for memory-reading opcodes when future instruction milestones implement them.
- **Classification:** future-owned.
- **Reason:** It concerns future instruction behavior, not test-runner decomposition.
- **Action for this milestone:** Left unchanged.

### Note 3

- **Location:** source-run diagnostic fixture expectations in `tests/core/test_wasm_source_run.c`.
- **Note text or summary:** Expected strings mention deferred QWORD/SQWORD execution, Irvine32 routine bodies, and stack behavior.
- **Classification:** irrelevant-to-target / future-owned behavior preserved.
- **Reason:** They are expected diagnostic text for already deferred behavior, not implementation TODOs for Phase 56A.
- **Action for this milestone:** Preserved exact assertions.

### Note 4

- **Location:** broad TODO search false positive in `scripts/run_tests.py`.
- **Note text or summary:** Search term `TEMP` matched ordinary text inside the word `attempt`.
- **Classification:** irrelevant-to-target false positive.
- **Reason:** It is not a TODO-style note.
- **Action for this milestone:** No action required.

## 7. TODO-style note disposition

Target-owned TODO-style notes resolved:

- The Phase 56A timeout-safe verification/reporting note was resolved through focused runner groups, static runner checks, documentation updates, and this milestone report.

Future-owned TODO-style notes intentionally preserved:

- `src/wasm/wasm_api.c` future opcode TODO.
- Deferred behavior references for future stack, Irvine32, QWORD/SQWORD, and related features in existing diagnostics/tests.

Stale or contradicted TODO-style notes corrected:

- None found.

Unresolved TODO-related risks:

- None for Phase 56A.
- Future test-runner decomposition may be needed if source-run or diagnostic groups grow enough to time out in hosted assistant/container environments.

## 8. Design summary

The design keeps `scripts/run_tests.py` as the single public test-runner interface and adds a small grouping layer around the existing build/test commands.

The runner now tracks group results explicitly. Each group records:

- group name;
- status;
- details;
- failing command context when applicable.

The implementation distinguishes:

- full verification (`--all` and default command);
- smoke verification (`--quick`);
- focused verification (`--structure`, `--native`, `--source-run`, `--web`, `--diagnostics`, `--protocol`, `--static`).

This design lets hosted assistants and developers rerun expensive families independently after an aggregate timeout, without weakening test coverage or deleting large fixtures.

No simulator semantics were touched. The milestone deliberately focuses on verification reliability rather than runtime features.

## 9. Files changed

Changed files:

- `scripts/run_tests.py`
- `docs/TESTING_GUIDE.md`
- `README.md`

No core C source, parser source, Wasm API source, browser UI source, supported syntax documentation, or diagnostic formatter source was changed.

## 10. Tests added

Added test coverage through runner/static self-checks, including checks for:

- required help flags;
- accepted command-line flags;
- unknown flag failure behavior;
- documentation and runner command consistency;
- source-run fixture inventory presence;
- timeout-safe verification guidance;
- failure-reporting policy;
- independent focused group behavior.

No MASM runtime tests were added because Phase 56A does not add simulator runtime behavior.

## 11. Commands used to test

Commands run during implementation and review:

```bash
python3 scripts/run_tests.py --help
python3 scripts/run_tests.py --quick
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --quiet --structure
python3 scripts/run_tests.py --verbose --static
python3 scripts/run_tests.py
python3 scripts/run_tests.py --all
python3 scripts/run_tests.py --quiet --all
```

Manual-testing guidance was verified locally with equivalent commands after applying the final Phase 56A changed files.

## 12. Pass/fail results

Final results:

- `--help`: passed.
- `--quick`: passed and correctly reported smoke-only verification.
- `--structure`: passed.
- `--native`: passed.
- `--source-run`: passed.
- `--web`: passed.
- `--diagnostics`: passed.
- `--protocol`: passed.
- `--static`: passed.
- `--quiet --structure`: passed with compact required status output.
- `--verbose --static`: passed with verbose command output.
- default command: passed and printed `All implemented milestone tests passed.`
- `--all`: passed and printed `All implemented milestone tests passed.`
- `--quiet --all`: passed and printed compact per-group status plus `All implemented milestone tests passed.`

Environment result:

- Browser/Wasm rebuild smoke was skipped because `emcc` is unavailable in the assistant/container environment.

## 13. Manual/browser testing guidance and expected outputs

Website testing:

- Website-testable: no.
- This milestone has no MASM program to paste into the web editor.
- The default page-load program does not test Phase 56A because Phase 56A changes only local test-runner behavior and documentation.

Windows CMD setup assumptions:

- Run from the repository root.
- Use a Visual Studio Developer Command Prompt or a CMD environment where these are available:

```bat
py
cl
node
```

- `emcc` is optional. If Emscripten is unavailable, the runner should report browser/Wasm rebuild smoke as skipped.

Recommended Windows CMD tests:

```bat
py scripts\run_tests.py --help
py scripts\run_tests.py --quick
py scripts\run_tests.py --quiet --structure
py scripts\run_tests.py --static
py scripts\run_tests.py --source-run
py scripts\run_tests.py --diagnostics
py scripts\run_tests.py --all
py scripts\run_tests.py --does-not-exist
```

Expected outputs:

- `--help` lists all required flags.
- `--quick` passes and states full verification was not performed.
- `--quiet --structure` prints group start/status lines, final summary, and selected-groups-passed message.
- `--static` passes runner/documentation consistency checks.
- `--source-run` passes source-run integration independently.
- `--diagnostics` passes native diagnostic producer plus rendered messages independently.
- `--all` passes and prints `All implemented milestone tests passed.`
- `--does-not-exist` fails with an unrecognized-arguments error and exit code 2.

Regression signs:

- Required flags are missing from help.
- `--quick` claims full verification.
- `--source-run` cannot run independently.
- `--diagnostics` skips rendered Simulator Messages checks.
- Quiet mode hides all group status lines or omits the final summary.
- The final full-suite success line appears after a failing group.
- Unknown flags are silently ignored.

## 14. Compliance review summary

First compliance review found two quality issues:

1. `--quiet` was parsed but effectively identical to default output.
2. `docs/TESTING_GUIDE.md` had one duplicated phrase.

Fixes applied:

- Improved `--quiet` behavior.
- Cleaned duplicated documentation wording.
- Reran relevant tests and aggregate verification.

Result:

- Passed after fixes.

## 15. Re-review summary

Second compliance review found two additional issues:

1. The first quiet-mode fix made `--quiet` too quiet relative to Phase 56A, which requires group start/status lines and final summary.
2. `docs/TESTING_GUIDE.md` had a duplicated source-run fixture inventory row.

Fixes applied:

- Adjusted `--quiet` to keep group start/status lines and final summary while reducing noise.
- Removed duplicate fixture inventory row.
- Reran focused and aggregate tests.

Final gap check:

- No missing work found.
- No stale TODO-style notes introduced.
- No target-owned TODO-style note remained unresolved.
- Final changed-files package was produced.

## 16. User-test follow-up summary, if any

Manual testing instructions were prepared for Windows CMD.

Because Phase 56A is local-test-runner-only, no MASM `program.asm` manual source files were provided. The user-facing manual tests are command-line runner tests with exact expected pass/fail behavior.

No post-manual-test bug report was received during this milestone session.

## 17. Known limitations

Known limitations after Phase 56A:

- `tests/core/test_wasm_source_run.c` remains physically large, but it is independently runnable through `--source-run` and passed in the assistant/container environment.
- `--diagnostics` is not subdivided further because it runs independently and passed.
- `--quick` is intentionally not full verification.
- Browser/Wasm rebuild smoke could not be run in the assistant/container environment because `emcc` is unavailable.
- No served-website behavior changes exist to manually test in the browser.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57 - Signed IDIV
```

Implementation should start from the Phase 56A repository state and follow the canonical guide. Phase 57 should not be started from the raw Milestone 56 archive without applying the Phase 56A changed files.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

- `milestone_56A_changed_files.zip`
- `milestone_56A_compliance_review_changed_files.zip`
- `milestone_56A_second_review_changed_files.zip`
- `milestone_56A_final_gap_check_changed_files.zip`

Recommended final changed-files package:

```text
milestone_56A_final_gap_check_changed_files.zip
```

A full repository archive was also prepared for handoff:

```text
Latest_repository_state_milestone_56A.zip
```

Recommended archive for the next implementation session:

```text
Latest_repository_state_milestone_56A.zip
```
