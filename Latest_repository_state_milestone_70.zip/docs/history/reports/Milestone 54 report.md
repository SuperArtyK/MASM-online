# Milestone 54 report - One-Operand Signed IMUL

## 1. Milestone title and scope

Milestone 54 implements **Phase 54 - One-Operand Signed IMUL** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added executable runtime support for one-operand signed `imul`.
- Supported register source operands at 8-bit, 16-bit, and 32-bit widths.
- Supported unambiguous memory source operands through:
  - typed data symbols;
  - typed symbol offsets;
  - explicit unsigned `BYTE PTR`, `WORD PTR`, and `DWORD PTR` forms;
  - explicit signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases by width.
- Implemented x86-style implicit signed-accumulator result behavior for MASM32 Educational Mode:
  - `imul r/m8`: `signed(AL) * signed(r/m8) -> AX`;
  - `imul r/m16`: `signed(AX) * signed(r/m16) -> DX:AX`;
  - `imul r/m32`: `signed(EAX) * signed(r/m32) -> EDX:EAX`.
- Implemented signed overflow flag behavior:
  - `CF = 0` and `OF = 0` when the full signed product is exactly the sign extension of the lower half;
  - `CF = 1` and `OF = 1` otherwise.
- Preserved `ZF` and `SF` deterministically.
- Routed all memory sources through checked VM memory reads.
- Ensured failed memory reads do not partially mutate result registers, flags, Program Console output, or memory-change rows.
- Ensured memory-source reads do not create memory-change rows.
- Integrated `imul` with existing planned memory-read validation and default/strict uninitialized-read diagnostics.
- Added explicit rejection for deferred two- and three-operand `imul` forms.
- Updated source-run and browser metadata to report runtime phase `54`.
- Updated documentation and default/sample UI text for Phase 54.
- Added exact structured and rendered Simulator Messages tests for new user-visible diagnostics and warning paths.

This milestone also includes a user-requested **Milestone 53E addendum** completed before Phase 55:

- Converted the browser **Diagnostic settings** panel from a static always-expanded block into a collapsible panel.
- The panel starts collapsed by default to reduce visual clutter.
- The toggle uses an accessible button with `aria-expanded` state.
- Existing settings, defaults, backend setting routing, and worker protocol semantics are unchanged.
- Collapsing and expanding the panel does not reset selected diagnostic settings.

The Phase 53E addendum is UI-only. It does not change Phase 54 runtime behavior and does not implement any Phase 55 feature.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 53E report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_53E.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 54 is the target runtime milestone.
- The collapsible Diagnostic settings panel is a small user-requested addendum to Milestone 53E, explicitly performed before Phase 55 and kept UI-only.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- All mandatory memory safety remains routed through checked VM memory helpers.
- User-visible diagnostics require structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

### 3.1 One-operand signed `imul`

Accepted syntax implemented:

```asm
imul reg8
imul reg16
imul reg32
imul BYTE PTR [reg32]
imul WORD PTR [reg32]
imul DWORD PTR [reg32]
imul symbol
imul symbol[offset]
```

Signed PTR aliases were accepted by width because prior memory-capable instruction milestones established them as executable 8-bit, 16-bit, and 32-bit width aliases:

```asm
imul SBYTE PTR [reg32]
imul SWORD PTR [reg32]
imul SDWORD PTR [reg32]
```

Case-insensitive mnemonics remain supported through the existing instruction-matching policy:

```asm
IMUL ebx
Imul ebx
imul ebx
```

Rejected syntax implemented or preserved:

```asm
imul 5
imul eax, ebx
imul eax, ebx, 5
imul [eax]
imul QWORD PTR q
imul SQWORD PTR q
imul
imul eax, ebx, ecx
```

Diagnostic behavior:

- `imul 5` reports `invalid-instruction-operands`.
- `imul eax, ebx` reports `unsupported-instruction-form` and states that two- and three-operand `IMUL` forms are deferred to Phase 55.
- `imul eax, ebx, 5` reports `unsupported-instruction-form` and states that two- and three-operand `IMUL` forms are deferred to Phase 55.
- `imul` with no operand reports `invalid-instruction-operands`.
- `imul eax, ebx, ecx` reports `unsupported-instruction-form` because it is a future three-operand form shape.
- `imul [eax]` reports `ambiguous-memory-width`.
- `imul QWORD PTR q` and `imul SQWORD PTR q` preserve the existing executable-64-bit memory-operation rejection with `unsupported-ptr-width`.

### 3.2 Runtime semantics

For 8-bit source operands:

```text
AX = signed(AL) * signed(source8)
```

For 16-bit source operands:

```text
DX:AX = signed(AX) * signed(source16)
```

For 32-bit source operands:

```text
EDX:EAX = signed(EAX) * signed(source32)
```

The multiplication is signed. Source operands and implicit accumulator inputs are interpreted at the selected operand width before multiplication.

### 3.3 Flag behavior

For all supported widths:

- If the full signed product is exactly representable as the sign extension of the lower half:
  - `CF = 0`
  - `OF = 0`
- Otherwise:
  - `CF = 1`
  - `OF = 1`
- `ZF` is preserved deterministically.
- `SF` is preserved deterministically.
- Other x86 flags remain unmodeled.

### 3.4 Memory behavior

Implemented memory behavior:

- Register-source `imul` does not touch memory.
- Memory-source `imul` performs a checked read through the VM memory helper path.
- Memory-source `imul` does not write memory.
- Memory-source `imul` does not create memory-change rows.
- `.CONST` memory sources are readable.
- Invalid memory-source reads fail at runtime and stop execution before result-register or flag mutation.
- Default uninitialized-read warning mode detects `imul` memory sources that read bytes still carrying uninitialized-origin metadata.
- Strict uninitialized-read mode stops before consuming the uninitialized-origin bytes and before mutating implicit result registers.
- Explicit uninitialized-read opt-out suppresses the teaching warning while preserving deterministic execution.

### 3.5 Source-run and browser metadata

Implemented metadata and browser updates:

- Runtime source-run metadata now reports phase `54`.
- Browser status text identifies Phase 54 support.
- The browser default/sample page program demonstrates one-operand signed `imul`:

```asm
.code
main PROC
    mov eax, -2
    mov ebx, 3
    imul ebx
main ENDP
END main
```

Expected key result:

```text
EAX = FFFFFFFAh / u: 4294967290 / s: -6
EDX = FFFFFFFFh / u: 4294967295 / s: -1
EFLAGS = 00000000h / 0
```

### 3.6 Milestone 53E addendum - collapsible Diagnostic settings panel

Implemented UI addendum behavior:

- The Diagnostic settings section is collapsed on page load.
- The header remains visible and clearly labeled.
- A real button toggles the section.
- `aria-expanded="false"` is used when collapsed.
- `aria-expanded="true"` is used when expanded.
- The visible state text changes between `Show` and `Hide`.
- Collapsing the panel does not reset setting selections.
- Expanding the panel shows the current setting selections.
- Running source while the panel is collapsed still sends the selected diagnostic settings.
- No backend diagnostic behavior changed.
- No new settings were added.
- No URL or local-storage persistence was added.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 54:

- Two-operand `imul`.
- Three-operand `imul`.
- `div`.
- `idiv`.
- New unsigned `mul` behavior.
- Labels, direct jumps, conditional jumps, `loop`, `SETcc`, or `CMOVcc`.
- `push`, `pop`, `call`, `ret`, `leave`, or stack behavior.
- Procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`.
- Irvine32 routine bodies beyond the existing `exit` virtual terminator.
- Program Console input/output routines.
- Scaled-index addressing.
- Executable QWORD/SQWORD memory operations in MASM32 Educational Mode.
- Extended 32-bit / 64-bit register behavior.
- Macro expansion.
- Real include-file loading.
- Windows API simulation.
- PE loading, object linking, or host filesystem behavior.
- New diagnostic policy families.
- New worker protocol setting fields.
- Share-URL persistence or localStorage persistence for the collapsible panel state.

Next signed multiplication work is Phase 55 - Two- and Three-Operand IMUL.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `imul` should use a distinct IR opcode rather than reusing `mul`.
- **Reason:** Signed and unsigned multiplication differ in operand interpretation, flag overflow tests, future debugger identity, and diagnostics.
- **Risk:** Adds a new opcode and executor dispatch case.
- **How to change later:** A future internal multiplication helper could share implementation between `mul` and `imul` while preserving distinct public opcode identity.

### Assumption 2

- **Assumption:** Phase 54 one-operand `imul` should reuse the existing one-source implicit-accumulator parser shape while keeping mnemonic-specific validation.
- **Reason:** `mul` and one-operand `imul` have nearly identical source operand shapes, but `imul` has future two-/three-operand forms that need clear deferral diagnostics.
- **Risk:** Shared parsing could accidentally blur `mul` and `imul` diagnostics if later edits are too broad.
- **How to change later:** Keep the shared source operand parsing narrow and preserve opcode-specific rejected-form tests.

### Assumption 3

- **Assumption:** Signed PTR aliases should be accepted for `imul` memory sources by width.
- **Reason:** Existing post-30 memory-capable instructions accept `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` as executable width aliases. The signedness affects interpretation for `imul`, but the aliases still resolve the memory access width.
- **Risk:** The Phase 54 guide's accepted syntax examples list only unsigned PTR names explicitly.
- **How to change later:** If a stricter interpretation is desired, signed PTR alias acceptance tests could be removed, but that would be inconsistent with established executable memory-width behavior.

### Assumption 4

- **Assumption:** Two- and three-operand `imul` should receive an explicit `unsupported-instruction-form` diagnostic rather than generic `invalid-instruction-operands`.
- **Reason:** The Phase 54 guide specifically defers those valid MASM forms to Phase 55. A precise diagnostic prevents users and future assistants from mistaking them for current malformed one-operand syntax.
- **Risk:** Adds a new diagnostic code that may need reuse by later deferred valid instruction forms.
- **How to change later:** Future parser diagnostics can generalize this code for other explicitly deferred valid forms while preserving Phase 54 tests.

### Assumption 5

- **Assumption:** The collapsible Diagnostic settings panel should start collapsed by default.
- **Reason:** The user requested reduced visual footprint because the panel is not always needed.
- **Risk:** Users may miss the settings if they expect the Phase 53E panel to be immediately visible.
- **How to change later:** The default could be changed to expanded, or panel state could be persisted, in a future UI preferences or URL-state milestone.

### Assumption 6

- **Assumption:** The collapsible panel state should not be persisted.
- **Reason:** The request was a small UI polish before Phase 55, and Phase 53E explicitly kept diagnostic settings as local page-session preferences because share URLs are not implemented yet.
- **Risk:** Users must re-expand the panel on each fresh page load.
- **How to change later:** A later UI preferences or URL-sharing milestone can add explicit persistence without changing diagnostic policy semantics.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and documentation notes reviewed before and during implementation:

- Location: `src/wasm/wasm_api.c`
  - Summary: future instruction milestones must add each future memory-reading opcode to the planned memory-read handling path when that opcode is implemented.
  - Classification: `target-owned` for Phase 54 as applied to `imul`; still `future-owned` for later memory-reading opcodes.
  - Phase 54 action: `imul` was added to the planned memory-read path so memory validation and uninitialized-read policies apply.

- Location: `README.md`
  - Summary: signed multiplication was listed as not implemented.
  - Classification: `target-owned`.
  - Phase 54 action: documentation was updated to state that one-operand signed `imul` is implemented while future forms and division remain deferred.

- Location: `docs/SUPPORTED_SYNTAX.md`
  - Summary: signed multiplication was listed among deferred systems.
  - Classification: `target-owned`.
  - Phase 54 action: documentation was updated to describe one-operand signed `imul` as supported while two-/three-operand forms remain deferred.

- Location: `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, Phase 54 rejected syntax
  - Summary: `imul eax, ebx` and `imul eax, ebx, 5` are deferred to Phase 55 - Two- and Three-Operand IMUL.
  - Classification: `future-owned`.
  - Phase 54 action: these forms were explicitly rejected with `unsupported-instruction-form`; no Phase 55 behavior was implemented.

- Location: `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, Phase 54 rejected syntax and memory-width notes
  - Summary: `imul QWORD PTR q` and `imul SQWORD PTR q` remain deferred because executable QWORD/SQWORD memory operations remain deferred.
  - Classification: `future-owned`.
  - Phase 54 action: existing QWORD/SQWORD executable memory operation rejection was preserved.

No new TODO-style notes were added.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- `src/wasm/wasm_api.c` planned memory-read handling now includes the new `imul` opcode path.
- README signed multiplication status was updated.
- `docs/SUPPORTED_SYNTAX.md` signed multiplication status was updated.

### Future-owned TODO-style notes intentionally preserved

- The generic future memory-reading opcode TODO remains accurate for later milestones that add memory-reading instructions.
- Phase 55 two-/three-operand `imul` remains intentionally deferred.
- Executable QWORD/SQWORD memory operation support remains intentionally deferred.

### Stale or contradicted TODO-style notes corrected

- No stale or contradicted TODO-style notes were found.
- During compliance review, stale non-TODO test assertion text that still said "Milestone 53" while checking phase `54` was corrected.
- During second review, README detailed milestone bullet ordering was corrected so Milestone 54 appears after Milestones 53A-53E.

### Unresolved TODO-related risks

- Future instruction milestones must continue updating the planned memory-read/planned-access hook when adding opcodes that read memory.
- A future assistant must not treat the Phase 55 `imul` deferral text as current Phase 54 scope.

## 8. Design summary

### IR design

A new opcode was added:

```text
VM_IR_OPCODE_IMUL
```

The opcode-name helper identifies it as:

```text
imul
```

This keeps signed multiply distinct from unsigned `mul` for executor dispatch, diagnostics, future debugger display, and future instruction-family expansion.

### Parser design

The parser accepts exactly one-source `imul` forms for Phase 54.

Accepted source kinds:

- register source with width 8, 16, or 32;
- explicit memory source with supported 8-, 16-, or 32-bit width;
- typed symbol source;
- typed symbol-offset source;
- `.CONST` source, because reads from `.CONST` are legal.

Rejected forms:

- immediate-only source operands;
- missing source operands;
- ambiguous memory source operands such as `imul [eax]`;
- executable QWORD/SQWORD memory source operands in MASM32 Educational Mode;
- two- and three-operand `imul` forms, which are valid MASM forms but deferred to Phase 55.

### Executor design

The executor handles `VM_IR_OPCODE_IMUL` through a signed multiply path:

1. Resolve source width.
2. Read the source operand.
3. Sign-extend the source and implicit accumulator input from the selected width.
4. Compute the full signed product.
5. Write the architectural implicit result register pair for the selected width.
6. Set `CF` and `OF` based on whether the full product is exactly the sign extension of the lower half.
7. Preserve `ZF` and `SF`.
8. Preserve no-partial-mutation behavior for failed memory reads and strict diagnostic failures.

### Memory and diagnostics design

Memory-source reads use the existing checked memory helper path and the source-run planned-read path.

Effects:

- invalid addresses remain runtime errors;
- `.CONST` sources are readable;
- default uninitialized-read warnings work for `imul` memory sources;
- strict uninitialized-read mode stops before mutation;
- memory reads do not produce memory-change rows;
- Program Console and Simulator Messages remain separate.

### UI addendum design

The Diagnostic settings panel was changed from always-expanded markup to a collapsible section:

- existing control IDs were preserved;
- a small `web/src/collapsible.js` helper owns the toggle behavior;
- the settings collection logic remains independent of visual expanded/collapsed state;
- tests verify that collapsed settings still affect `RUN_SOURCE` messages.

## 9. Files changed

Files changed for Phase 54 and the 53E addendum:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_ir.c`
- `src/core/vm_ir.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_collapsible_settings.mjs`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_settings.mjs`
- `web/index.html`
- `web/src/collapsible.js`
- `web/src/main.js`
- `web/src/settings.js`
- `web/src/styles.css`

No core C++ files were added.

## 10. Tests added

### Native executor tests

Added coverage for:

- 8-bit signed `imul` success.
- 8-bit signed `imul` overflow (`CF`/`OF` set).
- 16-bit signed `imul` success.
- 16-bit signed overflow edge cases.
- 32-bit signed `imul` success.
- 32-bit signed overflow edge cases.
- Preservation of `ZF` and `SF`.
- Failed memory-source reads preserving result registers, flags, Program Console, and memory-change rows.
- Regression preservation for existing unsigned `mul` behavior.

### Parser tests

Added coverage for accepted forms:

```asm
imul al
imul ax
imul eax
imul BYTE PTR [esi]
imul WORD PTR [esi]
imul DWORD PTR [esi]
imul SBYTE PTR [esi]
imul SWORD PTR [esi]
imul SDWORD PTR [esi]
imul value
imul arr[8]
imul factor
```

Added coverage for rejected forms:

```asm
imul 5
imul eax, ebx
imul eax, ebx, 5
imul [eax]
imul QWORD PTR q
imul SQWORD PTR q
imul
imul eax, ebx, ecx
```

### Source-run tests

Added coverage for:

- Phase 54 default acceptance program.
- Register-source signed `imul` at representative widths.
- Direct memory source.
- Symbol-offset memory source.
- Explicit PTR memory source.
- `.CONST` readable source.
- No memory-change rows for memory-source reads.
- Invalid register-indirect source address runtime error.
- Default `uninitialized-read` warning for `.DATA?` memory source.
- Strict uninitialized-read mode stopping before mutation.
- Explicit uninitialized-read opt-out preserving deterministic execution.
- Phase `54` metadata.

### Rendered Simulator Messages tests

Added exact rendered message coverage for:

- invalid `imul` immediate source;
- ambiguous `imul [eax]` memory-width diagnostic;
- deferred two-operand `imul` form;
- deferred three-operand `imul` form;
- unsupported QWORD/SQWORD executable memory source;
- invalid memory-source runtime error;
- default uninitialized-read warning from an `imul` memory source.

### Web/UI tests for the 53E addendum

Added coverage for:

- Diagnostic settings panel starts collapsed.
- Toggle expands and collapses the panel.
- Toggle updates `aria-expanded`.
- Selected diagnostic settings persist across collapse/expand.
- Settings are still sent in `RUN_SOURCE` messages when the panel is collapsed.

### Aggregate runner updates

Updated `scripts/run_tests.py` so the new web test is run by the aggregate test command.

## 11. Commands used to test

Primary aggregate test command:

```bash
cd /mnt/data/repo_m53E
python3 scripts/run_tests.py
```

This command compiles and runs native C tests with:

```text
cc -std=c99 -Wall -Wextra -Werror -pedantic
```

It also runs the Node-based web tests, including protocol/settings/formatter/diagnostic rendering/collapsible settings coverage.

## 12. Pass/fail results

Final observed aggregate result:

```text
All implemented milestone tests passed.
```

Environment limitation reported by the test runner:

```text
Phase 51 browser manual smoke after rebuilding Wasm: not run; emcc is unavailable in this environment.
```

Interpretation:

- Native C tests passed.
- Parser tests passed.
- Executor tests passed.
- Source-run tests passed.
- Diagnostic JSON producer build passed.
- Node web tests passed.
- Browser manual smoke after a rebuilt Wasm artifact was not run in this environment because Emscripten is unavailable.

## 13. Manual/browser testing guidance and expected outputs

The milestone is website-testable after rebuilding the Wasm artifact in an Emscripten environment.

### Required setup assumptions

For browser testing on Windows:

```text
- Emscripten SDK environment is active.
- Node.js is available.
- The Wasm artifact has been rebuilt after applying the Phase 54 changes.
```

Typical Windows CMD flow:

```bat
cd path\to\project
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Then open the local URL printed by the serve script.

### Browser test 1 - default Phase 54 success program

Program:

```asm
.code
main PROC
    mov eax, -2
    mov ebx, 3
    imul ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key Final Registers:

```text
EAX    | FFFFFFFAh / u: 4294967290 / s: -6
EDX    | FFFFFFFFh / u: 4294967295 / s: -1
EFLAGS | 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `imul ebx` is rejected.
- `EAX` is not `FFFFFFFAh`.
- `EDX` is not `FFFFFFFFh`.
- `CF`/`OF` are set for this no-overflow signed result.
- Program Console output appears unexpectedly.

### Browser test 2 - 8-bit overflow sets CF and OF

Program:

```asm
.code
main PROC
    mov al, 7Fh
    mov bl, 2
    imul bl
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key Final Registers:

```text
EAX    | 000000FEh / u: 254        / s:  254
  AX   |     00FEh / u: 254        / s:  254
    AL |       FEh / u: 250        / s: -2
EBX    | 00000002h / u: 2          / s:  2
EFLAGS | 00000801h / 2049
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `AX` is not `00FEh`.
- `EFLAGS` is not `00000801h`.
- The simulator behaves like unsigned `mul` rather than signed `imul`.

### Browser test 3 - readable `.CONST` memory source

Program:

```asm
.CONST
factor SDWORD -3
.code
main PROC
    mov eax, 7
    imul factor
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key Final Registers:

```text
EAX    | FFFFFFEBh / u: 4294967275 / s: -21
EDX    | FFFFFFFFh / u: 4294967295 / s: -1
EFLAGS | 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `.CONST` source is rejected.
- Memory-source `imul` creates a memory-change row.
- `EAX` is not `FFFFFFEBh`.
- `EDX` is not `FFFFFFFFh`.

### Browser test 4 - default uninitialized-read warning through `imul`

Program:

```asm
.DATA?
factor SDWORD ?
.code
main PROC
    mov eax, 5
    imul factor
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] uninitialized-read line 6: Memory read range 00500000h..00500003h reads 4 bytes from factor + 0; 4 of those bytes still originated from uninitialized storage.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key Final Registers:

```text
EAX    | 00000000h / u: 0          / s:  0
EDX    | 00000000h / u: 0          / s:  0
EFLAGS | 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- No `uninitialized-read` warning appears in default settings.
- Execution stops in default warning mode.
- A memory-change row appears.
- The warning appears in Program Console instead of Simulator Messages.

### Browser test 5 - ambiguous memory width diagnostic

Program:

```asm
.code
main PROC
    mov eax, 0
    imul [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 4, column 10, byte offset 40, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Expected Program Console:

```text
(empty)
```

Expected Final Registers:

```text
No register state available.
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- The program executes.
- The diagnostic describes the form as a future unsupported feature instead of ambiguous memory width.
- Source location metadata is missing.

### Browser test 6 - two-operand `imul` remains deferred

Program:

```asm
.code
main PROC
    imul eax, ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-instruction-form line 3, column 13, byte offset 28, span length 1: Two- and three-operand IMUL forms are deferred to Phase 55 - Two- and Three-Operand IMUL.
```

Expected Program Console:

```text
(empty)
```

Expected Final Registers:

```text
No register state available.
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `imul eax, ebx` executes before Phase 55.
- The diagnostic does not clearly state the Phase 55 deferral.

### Browser test 7 - invalid memory-source runtime error

Program:

```asm
.code
main PROC
    mov eax, 0
    imul DWORD PTR [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] invalid-address line 4: Invalid memory read at 00000000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

Expected Program Console:

```text
(empty)
```

Expected key Final Registers:

```text
EAX    | 00000000h / u: 0          / s:  0
EDX    | 00000000h / u: 0          / s:  0
EFLAGS | 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- Invalid address is accepted silently.
- Result registers mutate after the failed read.
- A memory-change row appears.

### Browser test 8 - 53E addendum collapsible Diagnostic settings panel

Expected page-load behavior:

- The Diagnostic settings header/button is visible.
- The button state text says `Show`.
- The settings body is hidden/collapsed.
- The toggle button has `aria-expanded="false"`.

After clicking the Diagnostic settings button:

- The settings body is visible.
- The state text changes to `Hide`.
- The toggle button has `aria-expanded="true"`.

After changing **Uninitialized reads** to `Off / I know what I'm doing`, collapsing, and re-expanding:

- The selected value remains `Off / I know what I'm doing`.

Run Browser test 4 while **Uninitialized reads** is off.

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Regression signs:

- Collapsing resets settings.
- Running while collapsed ignores selected settings.
- `uninitialized-read` still appears when the setting is off.
- The panel is expanded by default.
- The toggle is not accessible by click/keyboard.

### Windows CMD local testing

From the project root:

```bat
set CC=clang
py scripts\run_tests.py
```

Expected final result:

```text
All implemented milestone tests passed.
```

Optional command-line spot check:

Create `program.asm` at the project root:

```asm
.code
main PROC
    mov eax, -2
    mov ebx, 3
    imul ebx
main ENDP
END main
```

Build native test tools if not already built:

```bat
set CC=clang
py scripts\run_tests.py
```

Run the diagnostic JSON producer:

```bat
build\tests\diagnostic_json_producer.exe program.asm
```

Expected JSON contains at least:

```text
"status":"ok"
"phase":54
"kind":"info"
"code":"execution-complete"
"message":"Execution completed successfully."
"register":"EAX"
"valueHex":"FFFFFFFAh"
"register":"EDX"
"valueHex":"FFFFFFFFh"
"register":"EFLAGS"
"valueHex":"00000000h"
```

Regression signs:

- `"phase":54` is missing.
- `"status":"ok"` is not present.
- `EAX` is not `FFFFFFFAh`.
- `EDX` is not `FFFFFFFFh`.
- An assembly or runtime error appears for valid one-operand `imul`.

## 14. Compliance review summary

First compliance review checked:

- scope control;
- completeness against the guide;
- code quality and C99 boundary;
- Doxygen/file-level comment requirements;
- diagnostics and rendered-message coverage;
- test coverage;
- documentation updates;
- TODO-style note disposition.

Issues found:

- Some test assertion descriptions still said "Milestone 53" while checking phase `54`.
- Phase 54 had structured/source-run coverage for `imul` uninitialized-read warnings, but no exact rendered Simulator Messages test for that `imul` warning path.

Fixes applied:

- Corrected stale test assertion descriptions to "Milestone 54".
- Added exact rendered Simulator Messages test coverage for the default `uninitialized-read` warning produced by `imul` memory-source reads.

Result after fixes:

```text
All implemented milestone tests passed.
```

Verdict after first compliance review:

```text
complete
```

## 15. Re-review summary

Second compliance review checked:

- target milestone guide section;
- relevant spec sections;
- changed code and docs;
- changed-file TODO-style notes;
- tests for quality, not only existence;
- exact diagnostics and rendered messages;
- accidental future milestone implementation.

Additional issue found:

- README detailed milestone bullet ordering placed Milestone 54 before Milestones 53A-53E, which was potentially misleading even though the top-level status sentence was correct.

Fix applied:

- Moved the README Milestone 54 one-operand signed `imul` bullet after the Milestone 53E diagnostic-settings bullet.

Result after fix:

```text
All implemented milestone tests passed.
```

Final re-review verdicts:

- Scope: complete.
- Documentation: complete after README ordering fix.
- Test coverage: complete for the available native/Node environment.
- TODO-style notes: target-owned notes resolved; future-owned notes accurately preserved.

## 16. User-test follow-up summary

A user-requested follow-up was performed before Phase 55:

```text
Addendum to Milestone 53E - Collapsible Diagnostic Settings Panel
```

Reason:

- The Phase 53E Diagnostic settings panel was previously a static block of text and drop-down lists.
- The user noted that it consumed page space and was not always necessary.

Implemented follow-up:

- The Diagnostic settings panel now starts collapsed.
- It can be expanded and collapsed on demand.
- It preserves selected settings across collapse/expand.
- It remains accessible through an ARIA-expanded toggle button.
- Existing settings are still sent in `RUN_SOURCE` messages even while the panel is collapsed.
- No backend behavior changed.

Tests added for the follow-up:

- `tests/web/test_collapsible_settings.mjs`
- Additional settings-preservation regression coverage in the web settings test path.

This follow-up is intentionally reported as a **Milestone 53E addendum**, not as Phase 55 work.

## 17. Known limitations

Known limitations after Milestone 54:

- Two-operand `imul` is not implemented.
- Three-operand `imul` is not implemented.
- `div` is not implemented.
- `idiv` is not implemented.
- Executable QWORD/SQWORD memory operations remain unsupported in MASM32 Educational Mode.
- Extended 32-bit / 64-bit register behavior remains future work.
- Control flow, conditional jumps, labels beyond currently supported structural parsing, `loop`, `SETcc`, and `CMOVcc` remain future work.
- Stack/procedure runtime behavior remains future work.
- Irvine32 routine bodies beyond `exit` remain future work.
- Macro expansion remains future work.
- Browser/Wasm manual smoke after rebuild could not be run in this environment because `emcc` is unavailable.
- The Diagnostic settings panel collapsed/expanded state is not persisted across page reloads; this is intentional for the small UI addendum.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 55 - Two- and Three-Operand IMUL
```

Expected next work:

- Add two-operand signed `imul` forms.
- Add three-operand signed `imul` forms.
- Preserve the Phase 54 one-operand behavior unchanged.
- Preserve executable QWORD/SQWORD memory operation deferral unless Phase 55 explicitly changes that, which it should not unless the canonical guide says so.
- Continue using checked memory helpers and rendered Simulator Messages tests for user-visible diagnostics.

## 19. Changed-files ZIP/package produced

Final changed-files package produced:

```text
milestone_54_final_changed_files.zip
```

Package path in this environment:

```text
/mnt/data/milestone_54_final_changed_files.zip
```

The package preserves repository structure for all changed files.

Separate intermediate packages were also produced during implementation/review:

- `milestone_54_changed_files.zip`
- `milestone_54_changed_files_review.zip`
- `milestone_54_changed_files_second_review.zip`
- `milestone_53E_addendum_collapsible_settings_changed_files.zip`

Recommended package to use:

```text
milestone_54_final_changed_files.zip
```

Recommended repository/archive naming after applying the final changed-files package and rebuilding/validating Wasm in an Emscripten environment:

```text
Latest_repository_state_milestone_54.zip
```

A full repository archive was not produced as the authoritative latest archive in this environment because the Wasm rebuild/manual browser smoke step requires Emscripten, and `emcc` is unavailable here.
