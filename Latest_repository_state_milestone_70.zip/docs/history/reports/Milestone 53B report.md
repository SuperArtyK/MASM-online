# Milestone 53B report - Section-Capacity and Section-Image Validation Modes

## 1. Milestone title and scope

Milestone 53B implements **Phase 53B - Section-Capacity and Section-Image Validation Modes** for the Online MASM32 Educational Simulator.

This milestone adds opt-in educational memory-boundary diagnostics for two validation layers that were defined by the Phase 53A memory-validation policy split but intentionally left unimplemented until Phase 53B:

- **Level 2 - section-capacity validation**: reports accesses that pass mandatory VM region checks but fall outside known MASM section capacity metadata.
- **Level 3 - section-image validation**: reports accesses that pass mandatory VM region checks and section-capacity checks but leave the initialized/declared section image range.

Scope implemented:

- Added local/source-run selectable policies for Level 2 section-capacity validation:
  - `off`
  - `warn`
  - `strict`
- Added local/source-run selectable policies for Level 3 section-image validation:
  - `off`
  - `warn`
  - `strict`
- Added structured diagnostic code `section-capacity-violation`.
- Added structured diagnostic code `section-image-violation`.
- Implemented warning mode as a `simulator-warning` that allows execution to continue.
- Implemented strict mode as a `runtime-error` that stops before instruction mutation.
- Preserved default behavior: section-capacity and section-image validation are off by default.
- Preserved mandatory Level 1 region-only validation through existing checked VM memory helpers.
- Preserved mandatory `.CONST` write protection and diagnostic precedence.
- Preserved existing Level 4 allocated-object validation behavior.
- Preserved existing uninitialized-read diagnostics as an orthogonal read-origin policy.
- Added diagnostic JSON producer environment controls for local testing.
- Added source-run and rendered Simulator Messages coverage for the new diagnostics.
- Updated documentation and browser status text to describe Phase 53B as implemented.

The implementation stayed within the target milestone boundary. It did not add new MASM syntax, new runtime instructions, browser settings UI, default teaching diagnostics, Phase 54 signed `imul`, executable QWORD/SQWORD memory operations, or future validation/provenance features.

## 2. Source-of-truth files used

Canonical repository files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 53 report.md`
- `Milestone 53A report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_53A.zip
```

Important source-of-truth interpretation used:

- The full implementation specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- The uploaded Prompt 1 variable said `LATEST_COMPLETED_MILESTONE = 53`, but available repository evidence and archive availability showed the actual implementation base was Milestone 53A.
- The practical implementation base was therefore `Latest_repository_state_milestone_53A.zip`, and the target phase was the guide's next phase, Phase 53B.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- All mandatory memory safety remains routed through checked VM memory helpers.
- User-visible diagnostics require structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

### 3.1 Section-capacity policy

Added a source-run/test-facing section-capacity validation policy with three modes:

```text
off
warn
strict
```

Behavior:

- `off`: no section-capacity diagnostic is emitted.
- `warn`: emit `section-capacity-violation` as a `simulator-warning` and continue execution.
- `strict`: emit `section-capacity-violation` as a `runtime-error` and stop before instruction mutation.

The policy applies only after mandatory Level 1 memory validation has already accepted the final effective address/range. Lower-level invalid address, range, region, or permission errors remain authoritative and are not reclassified as section-capacity diagnostics.

### 3.2 Section-image policy

Added a source-run/test-facing section-image validation policy with three modes:

```text
off
warn
strict
```

Behavior:

- `off`: no section-image diagnostic is emitted.
- `warn`: emit `section-image-violation` as a `simulator-warning` and continue execution.
- `strict`: emit `section-image-violation` as a `runtime-error` and stop before instruction mutation.

The policy applies only after mandatory Level 1 memory validation succeeds and after section-capacity validation does not stop execution. The section-image check reports cases where the access leaves the known section image range while still being representable and Level 1-valid.

### 3.3 New diagnostics

Added structured diagnostics:

```text
section-capacity-violation
section-image-violation
```

Diagnostic payloads and rendered messages include:

- diagnostic kind (`simulator-warning` or `runtime-error`);
- access kind (`read` or `write`);
- computed effective address;
- access width in bytes;
- final inclusive byte range;
- owning region/section when known;
- section capacity or section image boundary range when known;
- source line;
- source column;
- byte offset;
- span length.

Example warning form:

```text
[simulator-warning] section-image-violation line 7, column 24, byte offset 92, span length 5: Memory read at 00500004h for 4 bytes covers range 00500004h..00500007h and leaves the section image range for .data/.DATA? (00500000h..00500003h).
```

Example strict form:

```text
[runtime-error] section-capacity-violation line 4, column 19, byte offset 57, span length 5: Memory write at 00700000h for 4 bytes covers range 00700000h..00700003h but does not start inside a known section capacity range for heap.
```

### 3.4 Configuration paths

Added local/test configuration for diagnostic JSON producer and source-run coverage.

Diagnostic JSON producer environment controls:

```text
MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=off
MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=warn
MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=strict

MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=off
MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=warn
MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=strict
```

Source-run/test-facing API policy values were added for:

```text
MASM32_SIM_WASM_SECTION_VALIDATION_OFF
MASM32_SIM_WASM_SECTION_VALIDATION_WARN
MASM32_SIM_WASM_SECTION_VALIDATION_STRICT
```

Browser UI settings were not added because they are outside Phase 53B scope.

### 3.5 Precedence and no-partial-mutation behavior

Implemented and tested precedence:

1. Mandatory Level 1 memory errors remain first: invalid address/range/region/permission diagnostics are not reclassified as section diagnostics.
2. `.CONST` read-only write protection remains mandatory and wins before optional section diagnostics.
3. Section-capacity validation runs before section-image validation.
4. Section-image validation runs before Level 4 declared-object validation for the same access.
5. Existing allocated-object warning/strict behavior is preserved.
6. Existing uninitialized-read warning/strict behavior remains separate and orthogonal.

Strict section validation stops before mutation:

- no destination register mutation;
- no memory mutation;
- no committed memory-change rows;
- no Program Console changes from the stopped instruction;
- no execution-complete message after the runtime error.

Warning section validation continues execution and permits normal completion unless another later fatal diagnostic occurs.

### 3.6 Documentation/status updates

Updated documentation and status text to describe Phase 53B as current implemented behavior rather than future work.

Updated documents include:

- `README.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `web/index.html`

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 53B:

- Phase 53C default teaching diagnostics.
- Any default behavior change for section-capacity or section-image policies.
- Browser UI controls or settings for section validation.
- Phase 54 one-operand signed `imul`.
- New runtime instructions.
- New MASM syntax.
- New parser grammar.
- New provenance validation semantics.
- New uninitialized-read behavior.
- New allocated-object validation semantics beyond preserving existing behavior.
- New Program Console behavior.
- New raw JSON protocol fields for browser UI state.
- Signed multiplication behavior.
- Division behavior.
- Labels, jumps, conditional jumps, `loop`, `SETcc`, or `CMOVcc`.
- Stack, procedure, `call`, `ret`, `leave`, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR` behavior.
- Irvine32 routine expansion beyond existing behavior.
- Macro expansion.
- Scaled-index addressing.
- Executable QWORD/SQWORD memory operations.
- Extended 32-bit Mode 64-bit arithmetic.
- Windows API simulation.
- PE loading.
- Object linking.
- Host filesystem behavior.

Next planned work is Phase 53C - Default Teaching Diagnostics for Existing Warning Modes.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `Latest_repository_state_milestone_53A.zip` is the correct implementation base.
- **Reason:** The requested `Latest_repository_state_milestone_53.zip` was unavailable, while repository evidence and milestone reports showed Milestone 53A was complete and Phase 53B was next.
- **Risk:** If a separate Milestone 53-only archive is later supplied, it may differ from the 53A base used here.
- **How to change later:** Re-run repository verification against the newly supplied archive and compare before applying Phase 53B changes.

### Assumption 2

- **Assumption:** Phase 53B policies should be implemented in the source-run/Wasm planned-access validation layer, not as mandatory low-level VM memory-helper enforcement.
- **Reason:** Level 2 and Level 3 are optional educational policies; Level 1 remains the mandatory checked-memory enforcement layer.
- **Risk:** Future direct executor APIs that bypass source-run planned-access validation would not see optional section diagnostics.
- **How to change later:** Add an executor-level optional validation hook if a later milestone requires policy parity for non-source-run execution paths.

### Assumption 3

- **Assumption:** Default source-run and browser behavior should remain section-validation off.
- **Reason:** The guide defines these modes as selectable policy layers and does not authorize a default behavior change in Phase 53B.
- **Risk:** Users cannot observe the new warnings from the served website until a later settings/default milestone exposes or enables them.
- **How to change later:** Phase 53C or a later UI settings phase can change defaults or add browser controls while reusing the 53B policy implementation.

### Assumption 4

- **Assumption:** Current fixed-layout section representation should be documented as implemented rather than reworked.
- **Reason:** Phase 53B is a validation-policy milestone, not a layout rewrite. Current representation has `.data` and `.DATA?` sharing the writable data VM region and `.CONST` using a separate read-only region.
- **Risk:** Some section-capacity cases are only reachable through selected test layout policies because fixed layout often gives the parser image buffer the same capacity as the VM region.
- **How to change later:** A future layout milestone can expose richer section-capacity metadata or separate regions without changing the 53B diagnostic contract.

### Assumption 5

- **Assumption:** Runtime/browser numeric phase metadata remains `53` rather than becoming a string-like `53B`.
- **Reason:** Earlier suffix milestones already used this convention to avoid destabilizing numeric protocol fields.
- **Risk:** The default website status does not encode suffix milestones in numeric runtime metadata.
- **How to change later:** Add a separate milestone label/capability field in a later protocol/UI milestone if suffix visibility is required.

## 6. Relevant TODO-style notes reviewed

The implementation and reviews considered these relevant TODO-style notes and deferred-feature notes:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 53A validation-level definitions
- Note text or summary:
  Level 2 section-capacity validation and Level 3 section-image validation are future Phase 53B work.
- Classification:
  target-owned
- Action:
  Implemented by Phase 53B and updated/superseded documentation so this is no longer described as future work.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 53B section
- Note text or summary:
  Add selectable section_capacity_validation and section_image_validation policies: off, warn, strict.
- Classification:
  target-owned
- Action:
  Implemented as the primary milestone scope.
```

```text
- Location:
  README.md, Milestone 53A status wording
- Note text or summary:
  Level 2 section-capacity and Level 3 section-image validation remain future Phase 53B work.
- Classification:
  target-owned
- Action:
  Updated to current Phase 53B implemented behavior.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md, memory validation status wording
- Note text or summary:
  Level 2 section-capacity and Level 3 section-image validation are future Phase 53B policies.
- Classification:
  target-owned
- Action:
  Updated to current Phase 53B implemented behavior.
```

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  Future memory-reading opcode collector reminder.
- Classification:
  future-owned
- Action:
  Preserved. Phase 53B adds validation modes, not new memory-reading opcodes.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Level 2 section-capacity and Level 3 section-image future-53B documentation/status notes were resolved by implementing the policies and updating documentation.
- The Phase 53B guide requirements were implemented and tested.

### Future-owned TODO-style notes intentionally preserved

- The future memory-reading opcode collector TODO-style note in `src/wasm/wasm_api.c` remains intentionally preserved because it belongs to future instruction milestones.

### Stale or contradicted TODO-style notes corrected

- Compliance review corrected stale wording in `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` that described section validation as a generic later phase after Phase 53B had implemented it.
- Re-review confirmed no stale Phase 53B TODO-style notes remained in changed files.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 53B adds an optional section-boundary validation layer around already-planned memory accesses in the source-run/Wasm path.

Design points:

- The implementation does not move optional section checks into the mandatory VM memory helper layer.
- Mandatory Level 1 memory safety remains the source of truth for real memory validity.
- Optional section diagnostics inspect planned memory reads/writes only after Level 1 checks succeed.
- Strict checks run before instruction execution when the access can be planned, preserving no-partial-mutation behavior.
- Warning checks are emitted after successful instruction execution so warning-only behavior remains non-fatal.
- Section-capacity checks precede section-image checks.
- Section-image checks precede allocated-object validation for the same access.
- Existing allocated-object and uninitialized-read policies remain separate.
- `.CONST` writes still fail through mandatory permission/read-only validation and are not reclassified as optional section diagnostics.
- Diagnostic messages use concrete address/range data so users can understand what address was accessed and which section boundary was crossed.

Current representation documented and tested:

- `.data` and `.DATA?` share one writable `.data/.DATA?` VM region.
- `.CONST` is a separate read-only `.const` VM region.
- Heap and stack are valid VM regions but are not MASM source sections, so section-capacity policy can report that accesses do not start inside a known section capacity range when enabled.

## 9. Files changed

Final changed-files package includes these repository files:

```text
README.md
docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md
docs/SUPPORTED_SYNTAX.md
docs/TESTING_GUIDE.md
scripts/run_tests.py
src/wasm/wasm_api.c
src/wasm/wasm_api.h
tests/core/diagnostic_json_producer.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
web/index.html
```

No generated build outputs or manual `program.asm` files are included in the final changed-files package.

## 10. Tests added

### Source-run/native tests

Added Phase 53B source-run coverage for:

- default section-validation-off behavior;
- section-image warning mode;
- section-image strict mode;
- section-capacity warning mode;
- section-capacity strict mode;
- section-capacity warning/strict behavior for known `.data/.DATA?` capacity crossing;
- lower-level invalid-region diagnostic precedence;
- `.CONST` permission/read-only diagnostic precedence;
- interaction with allocated-object warning mode;
- no-partial-mutation behavior for strict diagnostics;
- no memory-change rows committed when strict mode stops a write;
- preservation of default region-only source execution.

### Rendered Simulator Messages tests

Added exact rendered-message tests for:

- `section-image-violation` warning;
- `section-image-violation` runtime error;
- `section-capacity-violation` warning;
- `section-capacity-violation` runtime error.

### Diagnostic JSON producer tests/configuration

Added environment-variable support and test coverage for:

- `MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=off|warn|strict`
- `MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=off|warn|strict`

### Static/structure test coverage

Updated milestone structure checks to require Phase 53B implementation hooks, tests, and diagnostic names.

## 11. Commands used to test

Commands run during implementation/review included:

```bash
cd /mnt/data/work_m53B && python3 scripts/run_tests.py
```

During compliance review, targeted aggregate components were also run directly through the test runner functions because the full aggregate command hit the tool execution timeout in that review pass:

```bash
cd /mnt/data/work_m53B && python3 - <<'PY'
import scripts.run_tests as rt
rt.run_structure_tests()
rt.run_c_tests()
PY
```

```bash
cd /mnt/data/work_m53B && MASM32_DIAGNOSTIC_JSON_PRODUCER=$(pwd)/build/tests/diagnostic_json_producer node tests/web/test_diagnostic_rendering.mjs
```

```bash
cd /mnt/data/work_m53B && python3 - <<'PY'
import scripts.run_tests as rt
rt.build_diagnostic_json_producer()
rt.run_js_tests()
rt.report_phase51_smoke_harness_status()
PY
```

During second review, focused C/source-run and structure/JS checks were rerun:

```bash
cd /mnt/data/work_m53B && cc -std=c99 -Wall -Wextra -Werror -pedantic -Isrc/core -Isrc/parser tests/core/test_wasm_source_run.c src/core/masm32_sim_api.c src/core/vm_cpu.c src/core/vm_memory.c src/core/vm_layout.c src/core/vm_ir.c src/core/vm_exec.c src/parser/lexer.c src/parser/parser.c src/parser/symbols.c src/parser/object_map.c src/wasm/wasm_api.c -o build/tests/test_wasm_source_run && build/tests/test_wasm_source_run
```

Final gap-check command:

```bash
cd /mnt/data/work_m53B && python3 scripts/run_tests.py
```

## 12. Pass/fail results

Final aggregate result:

```text
PASS
All implemented milestone tests passed.
```

Important observed coverage lines included:

```text
Source execution tests through Phase 53B section-boundary validation coverage passed.
Rendered diagnostic tests passed.
Milestone structure tests passed.
All implemented milestone tests passed.
```

Environment limitation:

```text
emcc unavailable
```

Because Emscripten was unavailable in this environment, Wasm rebuild and served-browser smoke testing could not be performed here. Native C and Node tests passed.

## 13. Manual/browser testing guidance and expected outputs

### Website testing status

The new Phase 53B warning/strict modes are **not directly testable on the served website** because Phase 53B did not add browser UI controls for section-validation policies.

The website can still be used for default-behavior regression testing. No `section-capacity-violation` or `section-image-violation` diagnostic should appear by default.

Optional default website sanity program:

```asm
.data
x DWORD 1
.code
main PROC
    mov eax, OFFSET x
    add eax, 4
    mov ebx, DWORD PTR [eax]
main ENDP
END main
```

Expected default website behavior:

```text
Simulator Messages:
[info] execution-complete: Execution completed successfully.

Program Console:
empty

Final registers:
EAX = 00500004h / u: 5242884 / s: 5242884
EBX = 00000000h / u: 0 / s: 0

Memory Changes:
No memory changes.
```

Regression signs:

- Any `section-image-violation` or `section-capacity-violation` appears by default.
- Program Console receives simulator diagnostics.
- The program fails by default.

### Windows CMD local testing

Use Visual Studio Developer Command Prompt from the project root.

Build native tests:

```cmd
set CC=clang
py scripts\run_tests.py
```

Expected final output:

```text
All implemented milestone tests passed.
```

Use the diagnostic JSON producer for manual local tests:

```cmd
build\tests\diagnostic_json_producer.exe program.asm > out.json
```

Clear policy variables between tests:

```cmd
set MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=
set MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=
```

#### Manual Program 1 - default behavior remains region-only

`program.asm`:

```asm
.data
x DWORD 1
.code
main PROC
    mov eax, OFFSET x
    add eax, 4
    mov ebx, DWORD PTR [eax]
main ENDP
END main
```

Run:

```cmd
set MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=
set MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=
build\tests\diagnostic_json_producer.exe program.asm > out.json
```

Expected:

```text
"ok":true
"status":"ok"
"instructionCount":3
[info] execution-complete: Execution completed successfully.
No section-image-violation.
No section-capacity-violation.
Program Console is empty.
Memory changes are empty.
EAX is 00500004h.
EBX is 00000000h.
```

#### Manual Program 2 - section-image warning continues execution

Use Manual Program 1 source.

Run:

```cmd
set MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=warn
set MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=
build\tests\diagnostic_json_producer.exe program.asm > out.json
```

Expected rendered Simulator Messages:

```text
[simulator-warning] section-image-violation line 7, column 24, byte offset 92, span length 5: Memory read at 00500004h for 4 bytes covers range 00500004h..00500007h and leaves the section image range for .data/.DATA? (00500000h..00500003h).
[info] execution-complete: Execution completed successfully.
```

#### Manual Program 3 - section-image strict stops before mutation

`program.asm`:

```asm
.data
x DWORD 1
.code
main PROC
    mov eax, OFFSET x
    add eax, 4
    mov DWORD PTR [eax], 123
main ENDP
END main
```

Run:

```cmd
set MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=strict
set MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=
build\tests\diagnostic_json_producer.exe program.asm > out.json
```

Expected rendered Simulator Messages:

```text
[runtime-error] section-image-violation line 7, column 19, byte offset 87, span length 5: Memory write at 00500004h for 4 bytes covers range 00500004h..00500007h and leaves the section image range for .data/.DATA? (00500000h..00500003h).
```

Expected state:

```text
"ok":false
"status":"execution-error"
"instructionCount":2
No execution-complete message.
Program Console is empty.
Memory changes are empty.
EAX is 00500004h.
```

#### Manual Program 4 - section-capacity warning continues execution

`program.asm`:

```asm
.code
main PROC
    mov eax, 00700000h
    mov DWORD PTR [eax], 123
main ENDP
END main
```

Run:

```cmd
set MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=
set MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=warn
build\tests\diagnostic_json_producer.exe program.asm > out.json
```

Expected rendered Simulator Messages:

```text
[simulator-warning] section-capacity-violation line 4, column 19, byte offset 57, span length 5: Memory write at 00700000h for 4 bytes covers range 00700000h..00700003h but does not start inside a known section capacity range for heap.
[info] execution-complete: Execution completed successfully.
```

#### Manual Program 5 - section-capacity strict stops before mutation

Use Manual Program 4 source.

Run:

```cmd
set MASM32_DIAGNOSTIC_SECTION_IMAGE_VALIDATION=
set MASM32_DIAGNOSTIC_SECTION_CAPACITY_VALIDATION=strict
build\tests\diagnostic_json_producer.exe program.asm > out.json
```

Expected rendered Simulator Messages:

```text
[runtime-error] section-capacity-violation line 4, column 19, byte offset 57, span length 5: Memory write at 00700000h for 4 bytes covers range 00700000h..00700003h but does not start inside a known section capacity range for heap.
```

Expected state:

```text
"ok":false
"status":"execution-error"
"instructionCount":1
No execution-complete message.
Program Console is empty.
Memory changes are empty.
EAX is 00700000h.
```

Additional exact test-suite checks:

```cmd
build\tests\test_wasm_source_run.exe
```

Expected final line:

```text
Source execution tests through Phase 53B section-boundary validation coverage passed.
```

```cmd
set MASM32_DIAGNOSTIC_JSON_PRODUCER=%CD%\build\tests\diagnostic_json_producer.exe
node tests\web\test_diagnostic_rendering.mjs
```

Expected:

```text
Command exits successfully with no assertion failure.
```

## 14. Compliance review summary

First compliance review found one documentation hygiene issue:

- Two older guide notes still described section-capacity/section-image validation as a possible later phase after Phase 53B had implemented those layers.

Fixes applied:

- Updated the stale notes in `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` to name Phase 53B as the implemented Level 2 / Level 3 policy layer.
- Removed generated `scripts/__pycache__` from the working tree.

Compliance review results:

- Scope remained limited to Phase 53B.
- No accidental future milestone behavior was found.
- New public/test-facing APIs and internal entities were documented.
- New diagnostics were structured and rendered.
- Existing defaults were preserved.
- Future-owned TODO-style notes remained deferred.

Targeted tests rerun during compliance review passed.

## 15. Re-review summary

Second review found one test-quality gap:

- Initial Phase 53B section-capacity tests covered non-section heap storage but did not cover the separate case where an access starts inside a known `.data/.DATA?` region and leaves known section capacity while still passing Level 1 validation.

Fixes applied:

- Added source-run tests for `.data/.DATA?` section-capacity warning and strict modes using an automatic-layout test policy with a data VM region larger than section capacity.
- Added structure-runner checks requiring those tests.

Re-review results:

- Source-run C test passed with the new Phase 53B data section-capacity cases.
- Structure tests passed.
- Native C tests passed.
- Node protocol, formatter, and rendered diagnostic tests passed.
- No production behavior changes were needed during the second review.

Final gap check found no remaining milestone requirement gaps. A stale manual `program.asm` artifact in the workspace root was removed before packaging.

## 16. User-test follow-up summary

Manual testing instructions were prepared for Windows CMD users.

Key guidance:

- The new 53B policy modes are local-test-only in this milestone because no browser UI controls were added.
- The served website can test only default-behavior regression: section diagnostics must not appear by default.
- Manual source files should be saved as `program.asm` at repository root.
- Local manual tests use `build\tests\diagnostic_json_producer.exe program.asm > out.json` with the new environment variables.
- Expected outputs were provided for default mode, section-image warning, section-image strict, section-capacity warning, and section-capacity strict.

No user-reported follow-up defects were received after those instructions within this session.

## 17. Known limitations

- Emscripten `emcc` was unavailable in this environment, so Wasm rebuild and served-browser smoke testing were not performed here.
- The new section-capacity and section-image policies are not exposed in browser UI controls.
- Default website behavior remains region-only and does not show the new diagnostics.
- Phase 53B diagnostics are currently testable through local/source-run/diagnostic-producer configuration paths.
- Runtime/browser phase metadata remains numeric `53` because suffix milestone labels are not represented in existing numeric metadata fields.
- Current fixed-layout capacity representation limits some section-capacity boundary cases; tests cover reachable behavior and use selected test layout policies where needed.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 53C - Default Teaching Diagnostics for Existing Warning Modes
```

The next implementation session should not skip to Phase 54 until Phase 53C is either completed or explicitly deferred by the user.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

```text
milestone53B_changed_files.zip
milestone53B_compliance_review_changed_files.zip
milestone53B_second_review_changed_files.zip
milestone53B_final_gap_check_changed_files.zip
```

Final recommended changed-files package:

```text
milestone53B_final_gap_check_changed_files.zip
```

Final changed-files package contents:

```text
README.md
docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md
docs/SUPPORTED_SYNTAX.md
docs/TESTING_GUIDE.md
scripts/run_tests.py
src/wasm/wasm_api.c
src/wasm/wasm_api.h
tests/core/diagnostic_json_producer.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
web/index.html
```

Recommended next full repository archive name after applying the final changed-files package:

```text
Latest_repository_state_milestone_53B.zip
```
