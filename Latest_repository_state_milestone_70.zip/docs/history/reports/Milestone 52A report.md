# Milestone 52A report - Signed Register and Memory Value Display

## 1. Milestone title and scope

Milestone 52A implements **Phase 52A - Signed Register and Memory Value Display** for the Online MASM32 Educational Simulator.

This milestone is a display-formatting milestone. It improves how already-existing final register values and memory-change rows are presented in the browser/Node formatter layer.

Scope implemented:

- Added signed decimal interpretation for known-width 8-bit, 16-bit, and 32-bit integer display values.
- Preserved existing hexadecimal display.
- Preserved existing unsigned decimal display.
- Rendered known-width values in the form:

  ```text
  <hex> / u: <unsigned decimal> / s: <signed decimal>
  ```

- Applied signed display to final register rows where display width is known.
- Added display-derived register aliases under their canonical 32-bit parent registers.
- Kept `EFLAGS` in its prior hex/unsigned format.
- Applied signed display to symbol-aware memory changes where `widthBits` is known and supported.
- Improved final-register readability with grouped register families, indentation, a `|` separator, and aligned numeric columns.
- Improved memory-change readability with old/new block formatting and aligned numeric columns.
- Preserved Program Console output exactly.
- Preserved Simulator Messages text exactly.
- Preserved source-run JSON semantics and existing unsigned fields.
- Preserved all parser, IR, VM, executor, memory, flag, and diagnostic behavior.

This milestone was inserted after Milestone 52 and before Phase 53. It does not renumber Phase 53 or later phases.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 52 report.md`, as latest milestone evidence/history when available in the session context

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_52.zip
```

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history unless explicitly reclassified as canonical.
- Phase 52A is the only target milestone for this implementation session.

Relevant stable behavior from the spec:

- The simulator should show register, flag, memory-change, stack, and debugging state in a clear educational form.
- Integer register and memory values should include width-aware hexadecimal, unsigned decimal, and signed decimal interpretations where display width is known.
- The simulator remains a MASM32 educational simulator, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

Implemented Phase 52A requirements:

1. **Known-width signed decimal display**
   - Added signed decimal display for known-width 8-bit, 16-bit, and 32-bit values.
   - Signed values are computed from display width, not declaration signedness and not the parent register width.

2. **Register display**
   - Final register rows now show signed display for supported integer widths.
   - Canonical 32-bit registers use 32-bit signed interpretation.
   - 16-bit aliases use 16-bit signed interpretation.
   - 8-bit aliases use 8-bit signed interpretation.
   - High-byte aliases (`AH`, `BH`, `CH`, `DH`) are derived from bits 8-15 of the canonical parent register.
   - Low-byte aliases (`AL`, `BL`, `CL`, `DL`) are derived from bits 0-7 of the canonical parent register.
   - 16-bit aliases (`AX`, `BX`, `CX`, `DX`, `SI`, `DI`, `BP`, `SP`) are derived from bits 0-15 of the canonical parent register.
   - `EIP` receives the same 32-bit signed display as other known-width 32-bit integer register rows.
   - `EFLAGS` remains hex/unsigned only.

3. **Register grouping and alignment follow-up**
   - Register aliases are visually grouped under their parent register.
   - A blank line separates independent register groups.
   - One composition level is indented by two spaces.
   - Two composition levels are indented by four spaces.
   - Numeric values use aligned columns with a `|` separator.

   Example:

   ```text
   EAX    | 000000FFh / u: 255        / s:  255       
     AX   |     00FFh / u: 255        / s:  255       
       AH |       00h / u: 0          / s:  0         
       AL |       FFh / u: 255        / s: -1         
   ```

4. **Memory-change display**
   - Memory-change rows now show signed display when `widthBits` is known and supported.
   - Display uses the already-resolved memory access width.
   - `BYTE` and `SBYTE` rows use 8-bit interpretation.
   - `WORD` and `SWORD` rows use 16-bit interpretation.
   - `DWORD` and `SDWORD` rows use 32-bit interpretation.
   - Explicit `PTR` memory-change rows use the access width already present in the source-run payload.
   - Symbol-derived memory-change rows use the already-resolved access width already present in the source-run payload.

5. **Memory-change block formatting follow-up**
   - Memory changes now render as one block per changed memory row.
   - Each block has a symbol/address header line.
   - Old and new values are shown on separate aligned rows.
   - Separate changes are separated by blank lines.
   - Symbol-offset metadata is preserved in an `info|` row when available.

   Example:

   ```text
   value DWORD
     old | 00000000h / u: 0          / s:  0         
     new | FFFFFFFFh / u: 4294967295 / s: -1         

   b BYTE
     old |       00h / u: 0          / s:  0         
     new |       FFh / u: 255        / s: -1         
   ```

6. **Unknown or unsupported width handling**
   - Missing, invalid, or unsupported display widths do not guess signedness.
   - Unsupported display widths fall back to the legacy `hex / unsigned` display shape.
   - Signed 64-bit display was not added.

7. **Protocol and core preservation**
   - No new source-run JSON fields were added.
   - Existing unsigned fields remain unsigned.
   - No source-run semantic payload was reinterpreted.
   - No parser behavior changed.
   - No VM/executor behavior changed.
   - No memory bytes or flags changed.
   - No diagnostic behavior changed.

8. **Documentation and metadata**
   - README and supported-syntax documentation were updated to describe Milestone 52A as display-only formatting.
   - Website page text was updated to identify Milestone 52A display behavior while runtime MASM behavior remains through Milestone 52 LEA.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 52A:

- No new MASM syntax.
- No new parser behavior.
- No new IR opcode.
- No new VM/executor runtime behavior.
- No new memory model behavior.
- No new flags behavior.
- No new instruction support.
- No Phase 53 `mul` behavior.
- No division behavior.
- No labels, jumps, conditional jumps, `loop`, `SETcc`, or `CMOVcc`.
- No stack, procedure, `call`, `ret`, `leave`, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR` behavior.
- No Irvine32 routine expansion beyond existing behavior.
- No Program Console changes.
- No Simulator Messages changes.
- No new structured diagnostics.
- No signed QWORD/SQWORD decimal display.
- No JavaScript `BigInt` protocol payloads.
- No raw memory viewer.
- No watch window.
- No debugger stepping UI implementation.
- No automatic sign extension from signed memory.
- No executable QWORD/SQWORD memory operations.
- No scaled-index addressing.
- No Windows API simulation.
- No PE loading.
- No object linking.
- No macro expansion.
- No host filesystem behavior.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Signed display should be implemented in `web/src/formatters.js`, not in the C99 core.
- **Reason:** Phase 52A is display-only, and the guide prefers deriving signed display in the browser/Node formatter layer from existing numeric or hex fields.
- **Risk:** Raw source-run JSON still does not include signed display fields for consumers that bypass the formatter.
- **How to change later:** Add explicit additive JSON fields in a later protocol/display milestone if external consumers need signed values in raw source-run payloads.

### Assumption 2

- **Assumption:** Register aliases should be display-derived from existing canonical 32-bit register payloads.
- **Reason:** The existing source-run JSON reports canonical registers. Deriving aliases in the formatter preserves the display-only boundary and avoids core changes.
- **Risk:** Raw JSON consumers still see only canonical register objects.
- **How to change later:** Add additive alias-register entries to the source-run protocol in a future protocol milestone, with compatibility tests proving old fields remain intact.

### Assumption 3

- **Assumption:** `EFLAGS` should remain in its prior hex/unsigned display shape.
- **Reason:** Phase 52A does not require signed decimal display for `EFLAGS`, and flags are not usually interpreted as signed integers.
- **Risk:** Final register rows have one special-case display style.
- **How to change later:** A later UI consistency pass can explicitly add or reject signed `EFLAGS` display and update tests accordingly.

### Assumption 4

- **Assumption:** Unknown or unsupported memory widths should not show signed decimal.
- **Reason:** Signed interpretation is only meaningful when display width is known. Guessing signedness would be misleading.
- **Risk:** Some legacy or future rows may continue to display in the old `hex / unsigned` form until width metadata is supplied.
- **How to change later:** Ensure future memory/debug payloads carry explicit width metadata, then route those rows through the signed display helper.

### Assumption 5

- **Assumption:** Register and memory alignment refinements are within Phase 52A scope.
- **Reason:** They are display-only readability improvements over the signed-display work and do not alter runtime semantics or future syntax.
- **Risk:** Manual testing instructions produced before the follow-up refinements can become stale.
- **How to change later:** Keep future manual testing instructions synchronized with the final aligned register and block-style memory output.

### Assumption 6

- **Assumption:** Existing numeric source-run phase metadata should remain `52` rather than attempting to encode `52A` in numeric metadata fields.
- **Reason:** Phase 52A is a display-only inserted milestone; runtime MASM behavior remains through Milestone 52 LEA, and the current metadata path is numeric.
- **Risk:** The protocol does not distinguish display milestone `52A` from runtime milestone `52`.
- **How to change later:** Add a separate string field such as `implementedMilestoneLabel` in a later protocol milestone if suffix milestones need to be surfaced explicitly.

## 6. Design summary

### Formatter-layer implementation

The implementation is centralized in `web/src/formatters.js`.

Key helper behavior:

- `formatIntegerDisplay(value, widthBits)` formats known-width values in compact signed-display form.
- Aligned internal display helpers format register and memory values into fixed visual columns.
- Values are normalized to the selected display width before rendering.
- Hex strings are normalized to uppercase zero-padded MASM-style text for known-width signed display.
- Signed values use two's-complement interpretation at the selected width.
- Unsupported or missing widths fall back to legacy unsigned display.

### Register display design

Final register display now uses a table-like text layout:

```text
<indented name padded>| <hex padded> / u: <unsigned padded> / s: <signed padded>
```

Independent register families are separated by blank lines. Composed aliases appear under their parent register.

Representative grouping:

```text
EAX
  AX
    AH
    AL

EBX
  BX
    BH
    BL
```

The source payload remains canonical-register based. Alias values are derived in the formatter by masking and shifting the canonical unsigned value.

### Memory display design

Memory changes now use a block format:

```text
<label>
  old | <aligned value>
  new | <aligned value>
  info| <optional offset/index metadata>
```

This makes before/after changes easier to scan and avoids overly long one-line rows.

### Diagnostic preservation

Simulator Messages continue to use the existing formatter path and exact diagnostic text. Phase 52A deliberately avoids inserting signed display into diagnostics.

### Core preservation

No C99 core, parser, executor, IR, memory, or Wasm API behavior was changed for Phase 52A.

## 7. Files changed

Final Phase 52A changed files:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
tests/web/test_diagnostic_rendering.mjs
tests/web/test_formatters.mjs
web/index.html
web/src/formatters.js
```

No C source or header files were changed.

## 8. Tests added

### Formatter tests

Added/updated `tests/web/test_formatters.mjs` coverage for:

- 8-bit signed display boundaries:
  - `00h -> u:0 / s:0`
  - `01h -> u:1 / s:1`
  - `7Fh -> u:127 / s:127`
  - `80h -> u:128 / s:-128`
  - `FFh -> u:255 / s:-1`
- 16-bit signed display boundaries:
  - `0000h -> u:0 / s:0`
  - `0001h -> u:1 / s:1`
  - `7FFFh -> u:32767 / s:32767`
  - `8000h -> u:32768 / s:-32768`
  - `FFFFh -> u:65535 / s:-1`
- 32-bit signed display boundaries:
  - `00000000h -> u:0 / s:0`
  - `00000001h -> u:1 / s:1`
  - `7FFFFFFFh -> u:2147483647 / s:2147483647`
  - `80000000h -> u:2147483648 / s:-2147483648`
  - `FFFFFFFFh -> u:4294967295 / s:-1`
- Unsupported/missing-width fallback behavior.
- Hex normalization for known-width signed display.
- Malformed hex with valid unsigned fallback.
- Single register-row display.
- Legacy fallback register-row display when width is unknown.
- Canonical register and alias stable order.
- Blank-line separation between independent register groups.
- Alias-width display independent from parent register width.
- Missing register-state fallback.
- Simulator Messages unchanged formatting.
- Single memory-change block display.
- Multiple memory-change block separation.
- Offset-zero bracketed symbol display.
- Symbol-offset display with byte offset and element index.
- Unaligned symbol-offset display without element index.
- DWORD and BYTE signed memory-change display by access width.
- Unknown-width memory-change fallback.

### Source-run-backed web tests

Added/updated `tests/web/test_diagnostic_rendering.mjs` coverage for:

- Source-run register signed display from existing JSON.
- Register aliases using alias display width.
- Source-run memory changes with signed display.
- Ordinary `mov` signed-memory semantics preserved.

These tests run real source programs through the native JSON producer and then use the real browser formatter module.

### Aggregate runner structure checks

Updated `scripts/run_tests.py` structure checks to require Phase 52A formatter and source-run display tests.

## 9. Commands used to test

Commands run during implementation, compliance review, user follow-up, final gap check, and final report verification:

```bash
cd /mnt/data/repo_m52_verify
node tests/web/test_formatters.mjs
```

```bash
cd /mnt/data/repo_m52_verify
node tests/web/test_diagnostic_rendering.mjs
```

```bash
cd /mnt/data/repo_m52_verify
python3 scripts/run_tests.py
```

The aggregate runner compiles/runs the native C tests, builds/runs the native diagnostic JSON producer, and runs Node web tests including protocol, formatter, and diagnostic rendering coverage.

## 10. Pass/fail results

Final verification results:

```text
node tests/web/test_formatters.mjs
Result: PASS
```

```text
node tests/web/test_diagnostic_rendering.mjs
Result: PASS
```

```text
python3 scripts/run_tests.py
Result: PASS
Final line: All implemented milestone tests passed.
```

Environment notes:

- `cc` was available and used by the aggregate test runner.
- `python3` was available.
- `node` was available.
- `emcc` was unavailable in this environment.
- Because `emcc` was unavailable, fresh Wasm rebuild and browser manual smoke after rebuild were not performed here.

## 11. Manual/browser testing guidance and expected outputs

Phase 52A is website-testable because it changes browser/Node display formatting. It is also local-testable through the Node and aggregate test commands above.

A fresh Wasm rebuild is not required for the formatter-only display changes unless the local served site uses bundled/stale assets. Normal release validation should still include a browser smoke pass in an Emscripten-capable environment.

### Browser setup

From the project root on Windows CMD:

```bat
scripts\windows\serve_web.cmd
```

Open the served URL, paste each program into the editor, click **Run**, and inspect Final Registers, Memory Changes, Program Console, and Simulator Messages.

### Manual program 1 - 32-bit `-1` and alias display

```asm
.code
main PROC
    mov eax, 0FFFFFFFFh
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

Expected Final Registers include:

```text
EAX    | FFFFFFFFh / u: 4294967295 / s: -1         
  AX   |     FFFFh / u: 65535      / s: -1         
    AH |       FFh / u: 255        / s: -1         
    AL |       FFh / u: 255        / s: -1         
```

Regression signs:

- `EAX` lacks signed `-1`.
- Alias rows are missing.
- Alias rows are not indented.
- `EFLAGS` unexpectedly receives signed display.
- Simulator Messages include register display text.

### Manual program 2 - parent register and byte alias differ

```asm
.code
main PROC
    mov eax, 000000FFh
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Memory Changes:

```text
No memory changes.
```

Expected Final Registers include:

```text
EAX    | 000000FFh / u: 255        / s:  255       
  AX   |     00FFh / u: 255        / s:  255       
    AH |       00h / u: 0          / s:  0         
    AL |       FFh / u: 255        / s: -1         
```

Regression signs:

- `EAX` displays signed `-1` instead of signed `255`.
- `AL` displays signed `255` instead of signed `-1`.

### Manual program 3 - memory changes use access width

```asm
.data
value DWORD 0
b BYTE 0
.code
main PROC
    mov value, 0FFFFFFFFh
    mov b, 0FFh
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
value DWORD
  old | 00000000h / u: 0          / s:  0         
  new | FFFFFFFFh / u: 4294967295 / s: -1         

b BYTE
  old |       00h / u: 0          / s:  0         
  new |       FFh / u: 255        / s: -1         
```

Regression signs:

- Memory changes still render as long one-line rows.
- Signed display is missing.
- BYTE `FFh` displays signed `255` instead of `-1`.
- DWORD `FFFFFFFFh` loses unsigned `4294967295`.

### Manual program 4 - signed declarations do not imply sign extension

```asm
.data
sd SDWORD -1
sb SBYTE -1
.code
main PROC
    mov al, sb
    mov ebx, sd
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Memory Changes:

```text
No memory changes.
```

Expected Final Registers include:

```text
EAX    | 000000FFh / u: 255        / s:  255       
  AX   |     00FFh / u: 255        / s:  255       
    AH |       00h / u: 0          / s:  0         
    AL |       FFh / u: 255        / s: -1         

EBX    | FFFFFFFFh / u: 4294967295 / s: -1         
  BX   |     FFFFh / u: 65535      / s: -1         
    BH |       FFh / u: 255        / s: -1         
    BL |       FFh / u: 255        / s: -1         
```

Regression signs:

- `mov al, sb` sign-extends into `EAX`.
- `EAX` becomes `FFFFFFFFh` after `mov al, sb`.
- Program behavior changes instead of only display changing.

### Windows CMD local testing

From the project root:

```bat
node tests\web\test_formatters.mjs
```

Expected: Phase 52A formatter tests print `PASS` lines, including:

```text
PASS formats Phase 52A signed integer boundary values
PASS separates independent register groups with blank lines
PASS formats register alias widths independently from parent register width
PASS formats DWORD and BYTE memory changes with signed interpretation by access width
```

Run the full suite:

```bat
python scripts\run_tests.py
```

Expected final line:

```text
All implemented milestone tests passed.
```

## 12. Compliance review summary

First compliance review checked:

- Scope control.
- Completeness against Phase 52A.
- Accidental future behavior.
- C99 core boundary.
- Doxygen/file-header expectations for changed files.
- Diagnostic preservation.
- Test coverage.
- Documentation/status updates.

Issue found and fixed:

- `formatIntegerDisplay` could preserve a non-normalized or malformed `hex` string when a valid unsigned value was also present.
- Fix: known-width signed display now renders normalized zero-padded MASM-style hex from the normalized unsigned value.
- Regression coverage added for lowercase hex normalization and malformed hex with valid unsigned fallback.

Tests rerun:

```bash
node tests/web/test_formatters.mjs
python3 scripts/run_tests.py
```

Result: PASS. Aggregate final line: `All implemented milestone tests passed.`

Compliance verdict: complete.

## 13. Re-review summary

Second compliance review checked:

- Target milestone section.
- Relevant spec sections.
- Changed files.
- Test quality.
- Diagnostic text preservation.
- Documentation wording.
- Future-scope exclusion.

Additional issues found: none.

Tests rerun:

```bash
node tests/web/test_formatters.mjs
python3 scripts/run_tests.py
```

Result: PASS. Aggregate final line: `All implemented milestone tests passed.`

Second review verdict: complete.

## 14. User-test follow-up summary

The user manually tested four browser programs.

Observed results:

- Program 1 produced correct signed display for `EAX = FFFFFFFFh` and aliases.
- Program 2 proved display width controls signed interpretation: `EAX = 000000FFh` displays signed `255`, while `AL = FFh` displays signed `-1`.
- Program 3 produced correct signed display for DWORD and BYTE memory changes.
- Program 4 preserved ordinary `mov` semantics from signed memory while showing correct width-specific signed display.

User-requested follow-up 1:

- Add blank lines between independent register groups.
- Indent composed registers by two spaces per level.

Implemented:

- Register groups now include blank lines between independent groups.
- 16-bit aliases are indented by two spaces.
- 8-bit aliases are indented by four spaces.

User-requested follow-up 2:

- Improve register alignment and spacing with a `|` separator and aligned numeric columns.

Implemented:

- Final register rows now use fixed name and value columns.
- Hex, unsigned, and signed columns are aligned.

User-requested follow-up 3:

- Improve memory-change readability.

Implemented:

- Memory changes now use block-style `old`/`new` rows.
- Memory values use the same aligned integer formatting style.
- Symbol-offset metadata remains visible in `info|` rows.

Tests rerun after follow-ups:

```bash
node tests/web/test_formatters.mjs
node tests/web/test_diagnostic_rendering.mjs
python3 scripts/run_tests.py
```

Result: PASS. Aggregate final line: `All implemented milestone tests passed.`

## 15. Known limitations

- No signed QWORD/SQWORD decimal display.
- No `BigInt` support or 64-bit signed JavaScript display path.
- Raw source-run JSON remains canonical-register based and does not include alias register rows.
- Alias rows are display-derived in the formatter.
- Source-run numeric phase metadata remains `52`; Phase 52A is documented in UI/status text and docs as a display-only milestone.
- `EFLAGS` remains hex/unsigned only.
- Missing or unsupported memory widths fall back to legacy unsigned display rather than guessing signedness.
- Fresh Wasm rebuild and browser smoke after rebuild were not run in this environment because `emcc` was unavailable.
- Browser validation should be repeated in a full Emscripten-capable Windows environment before release packaging if Wasm or bundled assets are rebuilt.

## 16. Next recommended milestone

Next recommended milestone:

```text
Phase 53 - Unsigned MUL
```

Phase 53 should be implemented only after archiving the Phase 52A repository state. It should not retroactively modify Phase 52A display behavior unless a regression is found.

## 17. Changed-files ZIP/package produced

Changed-files packages produced during the session:

```text
/mnt/data/milestone52A_changed_files.zip
/mnt/data/milestone52A_compliance_review_changed_files.zip
/mnt/data/milestone52A_second_review_changed_files.zip
/mnt/data/milestone52A_user_followup_changed_files.zip
/mnt/data/milestone52A_register_alignment_changed_files.zip
/mnt/data/milestone52A_memory_display_changed_files.zip
```

The latest and recommended Phase 52A changed-files package is:

```text
/mnt/data/milestone52A_memory_display_changed_files.zip
```

It preserves repository structure and contains:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
tests/web/test_diagnostic_rendering.mjs
tests/web/test_formatters.mjs
web/index.html
web/src/formatters.js
```

## 18. Final status

Milestone 52A is complete.

Final verification command:

```bash
cd /mnt/data/repo_m52_verify
python3 scripts/run_tests.py
```

Final result:

```text
All implemented milestone tests passed.
```
