# Milestone 49 report - ROL

## 1. Milestone title and scope

Milestone 49 implements **Phase 49 - ROL** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added executable runtime support for `rol`.
- Supported register destinations at 8-bit, 16-bit, and 32-bit widths.
- Supported unambiguous memory destinations through:
  - typed data symbols;
  - symbol offsets;
  - explicit unsigned `BYTE PTR`, `WORD PTR`, and `DWORD PTR` forms;
  - explicit signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases.
- Supported immediate byte rotate counts and `CL` as the only register rotate-count operand.
- Applied the existing MASM/x86-compatible count masking policy for 32-bit educational mode:

```text
effective_count = raw_count & 31
```

- Preserved effective-count-zero no-op behavior: destination and modeled flags are unchanged and no warning is emitted.
- Implemented rotate-left semantics: bits shifted out of the most significant bit are rotated into the least significant bit.
- Implemented default-mode undefined modeled-flag warnings for architecturally undefined `OF` cases while allowing execution to complete.
- Preserved `ZF` and `SF` for all nonzero `ROL` counts because `ROL` does not define them.
- Preserved all prior milestone behavior, especially Phase 46 `shl`/`sal`, Phase 47 `shr`, and Phase 48 `sar` behavior.
- Updated source-run and browser metadata to report phase 49.
- Added native C, parser, executor, source-run JSON, rendered Simulator Messages, protocol/static, documentation, manual-testing, compliance, re-review, and gap-check coverage.

The implementation stayed within the milestone boundary. No future rotate-right, carry-rotate, control-flow, stack, procedure, Irvine32 expansion, QWORD/SQWORD execution, PF/AF, WinAPI, PE, linker, macro, or smart flag-consumer behavior was implemented.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 48 report.md`

Repository archive used as the implementation base:

- `Latest_repository_state_milestone_48.zip`

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.
- Phase 49 is the only target milestone for this work session.

## 3. Exact requirements implemented

Phase 49 required `rol` as the rotate-left counterpart after the shift milestones, while reusing the existing shift/rotate destination and count policy.

Accepted syntax implemented:

```asm
rol reg, 1
rol reg, imm
rol reg, cl
rol mem, 1
rol mem, imm
rol mem, cl
```

Supported register destinations:

```text
reg8
reg16
reg32
```

Supported memory destinations:

```asm
rol BYTE PTR [eax], 1
rol WORD PTR [eax], 1
rol DWORD PTR [eax], 1
rol SBYTE PTR [eax], 1
rol SWORD PTR [eax], 1
rol SDWORD PTR [eax], 1
rol value, 1
rol values[4], 1
```

Rejected syntax verified:

```asm
rol 1, al
rol eax, ebx
rol eax, cx
rol eax, ecx
rol eax
rol eax, 1, 2
rol [eax], 1
rol QWORD PTR q, 1
rol SQWORD PTR q, 1
```

Runtime semantics implemented:

- Raw count source:
  - immediate byte count; or
  - low 8 bits of `ECX` when the count operand is `CL`.
- Effective count:

```text
effective_count = raw_count & 31
```

- Effective count `0`:
  - destination unchanged;
  - `CF`, `ZF`, `SF`, and `OF` unchanged;
  - no `undefined-modeled-flag` warning.
- Nonzero effective count:
  - rotate amount is `effective_count % operand_width`;
  - destination is rotated left within the selected operand width;
  - bits leaving the most significant bit re-enter at bit 0;
  - `CF` receives the least significant bit of the rotated result;
  - `ZF` is preserved;
  - `SF` is preserved.
- Effective count `1`:
  - `OF = new_most_significant_bit XOR CF`;
  - no undefined-modeled-flag warning.
- Effective count not equal to `1` and nonzero:
  - `OF` is architecturally undefined;
  - the simulator preserves the previous `OF` deterministically;
  - default mode emits `undefined-modeled-flag` warning;
  - execution continues and may still complete successfully.
- Strict shift validation remains shift-only. `ROL` undefined modeled-flag warnings do not become strict-mode runtime errors.

Diagnostics implemented or verified:

- `undefined-modeled-flag` warning for non-one nonzero `ROL` counts where `OF` is architecturally undefined.
- `ambiguous-memory-width` for untyped memory destinations such as `rol [eax], 1`.
- `invalid-instruction-operands` for immediate destinations, missing counts, extra operands, and invalid count registers such as `EBX`, `CX`, and `ECX`.
- Existing unsupported-runtime diagnostics for executable `QWORD PTR` and `SQWORD PTR` memory operations remain in force.
- Existing runtime memory diagnostics for invalid addresses and `.CONST` permission failures remain structured and rendered.
- Diagnostic source location data remains preserved: line, column, byte offset, and span length where applicable.

Acceptance example:

```asm
.code
main PROC
    mov al, 80h
    rol al, 1
main ENDP
END main
```

Expected final state:

```text
EAX = 00000001h / 1
EFLAGS = 00000801h / 2049
```

Warning example:

```asm
.code
main PROC
    mov al, 80h
    rol al, 8
main ENDP
END main
```

Expected behavior:

```text
[simulator-warning] undefined-modeled-flag ...
[info] execution-complete: Execution completed successfully.
EAX = 00000080h / 128
EFLAGS = 00000000h / 0
```

Count-zero example:

```asm
.code
main PROC
    mov eax, 80000001h
    rol eax, 32
main ENDP
END main
```

Expected behavior:

```text
No warning.
Destination and modeled flags unchanged by ROL because effective_count is 0.
```

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 49:

- `ror`.
- `rcl`, `rcr`, or other carry rotates.
- New shift behavior.
- Smart flag-validity metadata.
- `undefined-flag-use` consumer diagnostics.
- Strict-before-mutation producer errors for `ROL`.
- `cmp`.
- labels, `jmp`, conditional jumps, or `loop`.
- `lea`.
- `mul`, `imul`, `div`, or `idiv`.
- `push`, `pop`, `call`, `ret`, `leave`, or stack behavior.
- procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`.
- Irvine32 routine bodies beyond the existing `exit` virtual terminator.
- Program Console input/output routines.
- scaled-index addressing.
- executable QWORD/SQWORD memory operations.
- PF/AF integration for rotates.
- browser UI setting for strict undefined-shift validation.
- Windows API, PE loading, object linking, host include loading, or macro behavior.

Compile-time expression operator behavior remains separate from runtime instruction behavior. Existing expression behavior was preserved.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `rol` should be represented as a dedicated IR opcode.
- **Reason:** Dedicated opcode identity preserves source mnemonic clarity for diagnostics, tests, protocol/debug display, and future debugger output.
- **Risk:** Adds another opcode and executor case instead of using one generic rotate opcode with direction metadata.
- **How to change later:** A future internal normalization pass can share a lower-level rotate helper while preserving public opcode identity and original source mnemonic.

### Assumption 2

- **Assumption:** `rol` should reuse the existing shift destination/count parser validation path where appropriate.
- **Reason:** Phase 49 uses the same destination forms, immediate count policy, and `CL`-only register count rule as the prior shift phases.
- **Risk:** Reusing a shift parser helper could accidentally inherit shift-specific diagnostic wording or behavior.
- **How to change later:** Keep instruction-specific diagnostic wording and tests; factor a neutral shift/rotate validation helper later if Phase 50 introduces `ROR`.

### Assumption 3

- **Assumption:** `ROL` undefined `OF` should use `undefined-modeled-flag`, not `undefined-shift-flag`.
- **Reason:** The Phase 49 guide and stable spec prefer the general modeled-flag producer warning for rotate instructions, while previous shifts already use `undefined-shift-flag`.
- **Risk:** Existing UI/tests already know `undefined-shift-flag`, so the new warning code requires additional rendered-message coverage.
- **How to change later:** Keep the diagnostic code stable unless the diagnostic catalog is intentionally revised; if revised, update structured tests and rendered-message golden tests together.

### Assumption 4

- **Assumption:** Strict undefined-shift validation remains shift-only and does not reject `ROL` before mutation.
- **Reason:** Phase 49 explicitly excludes strict-before-mutation producer errors and smart flag-validity metadata for `ROL`.
- **Risk:** Users may expect strict shift validation to cover rotates too.
- **How to change later:** A future smart flag-validity phase can add producer validity tracking or consumer diagnostics without changing Phase 49 rotate execution semantics.

### Assumption 5

- **Assumption:** Phase metadata should advance to `49` in source-run JSON and browser protocol metadata.
- **Reason:** Prior milestones advanced metadata, and the test suite verifies current implemented phase information.
- **Risk:** Metadata updates touch browser/protocol files even though the primary behavior is in parser/executor code.
- **How to change later:** Centralize feature-level metadata if the project later separates runtime support metadata from browser sample/status metadata.

### Assumption 6

- **Assumption:** PF and AF remain unmodeled and untouched in Phase 49.
- **Reason:** The current stable modeled flag set is `CF`, `ZF`, `SF`, and `OF`; PF/AF integration is outside Phase 49 scope.
- **Risk:** Future PF/AF implementation must revisit rotate helpers.
- **How to change later:** Implement PF/AF in a dedicated later flag-integration phase without changing the Phase 49 `CF/ZF/SF/OF` contract.

## 6. Design summary

### IR changes

One new opcode was added:

```text
VM_IR_OPCODE_ROL
```

The opcode-name helper was updated so diagnostics, tests, and future debugging output can identify the opcode as:

```text
rol
```

### Parser changes

The parser recognizes `rol` as a binary destination-mutating rotate instruction.

Parser behavior:

- Accepts register destinations.
- Accepts direct typed symbols and typed symbol offsets as memory destinations.
- Accepts explicit `BYTE PTR`, `WORD PTR`, and `DWORD PTR` memory forms.
- Accepts signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases by width.
- Accepts immediate byte rotate counts.
- Accepts `CL` as the only register count operand.
- Rejects immediate destinations.
- Rejects missing count and extra operands with `invalid-instruction-operands`.
- Rejects count registers other than `CL`, including `CX`, `ECX`, and general registers such as `EBX`.
- Rejects untyped memory destinations such as `rol [eax], 1` with `ambiguous-memory-width`.
- Preserves existing QWORD/SQWORD executable memory-operation rejection.
- Emits static `.CONST` write diagnostics for direct `.CONST` destinations where existing static detection applies.

### Executor changes

The executor handles `ROL` through a rotate-left read-modify-write path.

Execution algorithm:

1. Resolve and validate destination and rotate-count operands.
2. Resolve raw count from immediate or `CL`.
3. Compute effective count as `raw_count & 31`.
4. If effective count is zero, return success without mutation.
5. Read destination value.
6. Save pre-instruction CPU/flag state for rollback on failed writes.
7. Compute rotate amount as `effective_count % operand_width`.
8. Rotate the destination left within the operand width.
9. Update or preserve modeled flags according to Phase 49 rules.
10. Write result back to register or memory destination.
11. If a memory write fails, restore CPU/flag state so no partial mutation is visible.

Memory behavior:

- All memory reads go through checked VM read helpers.
- All memory writes go through checked VM write helpers.
- `.CONST` permission checks remain enforced by final address range.
- Invalid reads occur before write-back.
- Failed writes do not create successful memory-change rows.

### Source-run and diagnostics changes

The source-run path emits default-mode `undefined-modeled-flag` warnings before executing `ROL` instructions where `OF` is architecturally undefined.

Warning-only runs continue to execute and may end with both:

```text
[simulator-warning] undefined-modeled-flag ...
[info] execution-complete: Execution completed successfully.
```

Strict undefined-shift validation does not convert the `ROL` warning into a runtime error.

### Documentation and metadata

Updated documentation and metadata to describe Phase 49 as the current implemented milestone and list `rol` as a supported runtime instruction.

## 7. Files changed

Final Phase 49 implementation, compliance, second-review, and final gap-check work touched these files across the cumulative milestone work:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

Review-only documentation/comment cleanup touched:

```text
docs/SUPPORTED_SYNTAX.md
src/wasm/wasm_api.c
```

## 8. Tests added

### Parser tests

Added or expanded coverage for:

- `rol al, 1`
- `rol ax, 1`
- `rol eax, 1`
- `rol eax, 0`
- `rol eax, 32`
- `rol eax, cl`
- mixed-case `RoL eax, cl`
- `rol BYTE PTR [eax], 1`
- `rol WORD PTR [eax], 1`
- `rol DWORD PTR [eax], 1`
- `rol SBYTE PTR [eax], 1`
- `rol SWORD PTR [eax], 1`
- `rol SDWORD PTR [eax], 1`
- direct typed symbol destinations
- symbol-offset destinations
- immediate destination rejection
- missing count rejection
- extra operand rejection
- invalid count register rejection for `EBX`, `CX`, and `ECX`
- ambiguous memory-width rejection
- QWORD/SQWORD executable memory-operation rejection
- direct `.CONST` write rejection

### Executor tests

Added or expanded coverage for:

- `rol al, 1`: `80h -> 01h`, `CF=1`, defined `OF`.
- `rol al, 1`: result-sign/overflow edge cases.
- `rol ax, 1` width-specific behavior.
- `rol eax, 1` width-specific behavior.
- `rol al, 8`: nonzero effective count with rotate amount zero; destination unchanged, `CF` updated, `OF` preserved.
- `rol eax, 32`: effective count zero no-op.
- `rol eax, cl`: uses low 8 bits of `ECX` only.
- Preservation of `ZF` and `SF` for nonzero rotates.
- Preservation of `OF` for non-one nonzero rotates.
- Memory read-modify-write success.
- Invalid memory read failure.
- `.CONST` permission failure.
- No partial mutation on failed memory writes.
- No memory-change rows on failed writes.

### Source-run JSON tests

Added or expanded coverage for:

- successful register acceptance program
- successful BYTE, WORD, and DWORD memory destination program
- warning-producing non-one nonzero count
- effective count zero no-op
- invalid immediate destination
- missing count
- extra operand count
- invalid count register
- ambiguous memory-width diagnostic
- direct `.CONST` assembly diagnostic
- computed `.CONST` runtime failure
- invalid memory destination runtime failure
- strict shift validation not rejecting `ROL`
- phase metadata reporting `49`

### Rendered Simulator Messages tests

Added or expanded exact rendered-message coverage for:

- successful execution line
- `undefined-modeled-flag` warning from non-one nonzero `ROL`
- `ROL` warning still executing under strict shift validation
- `ambiguous-memory-width` from `rol [eax], 1`
- `invalid-instruction-operands` from `rol eax, ebx`
- `invalid-instruction-operands` from `rol eax`
- direct `.CONST` write diagnostic
- runtime permission failure from computed `.CONST` `ROL`
- runtime invalid-address diagnostic for invalid memory destination

### Protocol/static tests

Updated coverage for:

- browser/worker protocol metadata reporting Phase 49.
- static structure checks requiring `VM_IR_OPCODE_ROL`, parser tests, executor tests, source-run tests, rendered diagnostic tests, and phase metadata updates.

### Regression tests

Regression coverage confirms:

- Existing `shl`/`sal` behavior remains intact.
- Existing `shr` behavior remains intact.
- Existing `sar` behavior remains intact.
- Existing `undefined-shift-flag` diagnostics remain shift-specific.
- Existing strict shift validation remains shift-only.
- Existing `inc`, `dec`, `and`, `or`, `xor`, `not`, `test`, `neg`, `adc`, `sbb`, carry-control, `xchg`, `nop`, and `exit` behavior remains intact.
- Existing `.CONST`, object-bounds, uninitialized-read, invalid-address, and memory-permission validation paths remain intact.
- Program Console remains separate from Simulator Messages.
- No `ROR` support exists after Phase 49.

## 9. Commands used to test

Primary aggregate test command after final gap check:

```sh
cd /mnt/data/repo_m49_gapcheck
python3 scripts/run_tests.py
```

Observed result:

```text
All implemented milestone tests passed.
```

Earlier implementation/compliance commands also included targeted rebuilds and reruns, for example:

```sh
cd /mnt/data/repo_m48_verify
cc -std=c99 -Wall -Wextra -Werror -pedantic -Isrc/core -Isrc/parser tests/core/test_parser.c src/core/vm_cpu.c src/core/vm_memory.c src/core/vm_layout.c src/core/vm_ir.c src/core/vm_exec.c src/parser/lexer.c src/parser/parser.c src/parser/symbols.c src/parser/object_map.c -o build/tests/test_parser
build/tests/test_parser
```

Observed result:

```text
Minimal parser tests passed.
```

```sh
cd /mnt/data/repo_m48_verify
cc -std=c99 -Wall -Wextra -Werror -pedantic -Isrc/core -Isrc/parser tests/core/test_vm_exec.c src/core/masm32_sim_api.c src/core/vm_cpu.c src/core/vm_memory.c src/core/vm_layout.c src/core/vm_ir.c src/core/vm_exec.c src/parser/lexer.c src/parser/parser.c src/parser/symbols.c src/parser/object_map.c src/wasm/wasm_api.c -o build/tests/test_vm_exec
build/tests/test_vm_exec
```

Observed result:

```text
Executor tests through Milestone 49 passed.
```

```sh
cd /mnt/data/repo_m48_verify
cc -std=c99 -Wall -Wextra -Werror -pedantic -Isrc/core -Isrc/parser tests/core/test_wasm_source_run.c src/core/masm32_sim_api.c src/core/vm_cpu.c src/core/vm_memory.c src/core/vm_layout.c src/core/vm_ir.c src/core/vm_exec.c src/parser/lexer.c src/parser/parser.c src/parser/symbols.c src/parser/object_map.c src/wasm/wasm_api.c -o build/tests/test_wasm_source_run
build/tests/test_wasm_source_run
```

Observed result:

```text
Source execution tests through Phase 49 regression coverage passed.
```

```sh
cd /mnt/data/repo_m48_verify
cc -std=c99 -Wall -Wextra -Werror -pedantic -Isrc/core -Isrc/parser tests/core/diagnostic_json_producer.c src/core/masm32_sim_api.c src/core/vm_cpu.c src/core/vm_memory.c src/core/vm_layout.c src/core/vm_ir.c src/core/vm_exec.c src/parser/lexer.c src/parser/parser.c src/parser/symbols.c src/parser/object_map.c src/wasm/wasm_api.c -o build/tests/diagnostic_json_producer
MASM32_DIAGNOSTIC_JSON_PRODUCER=$(pwd)/build/tests/diagnostic_json_producer node tests/web/test_diagnostic_rendering.mjs
node tests/web/test_protocol.mjs
node tests/web/test_formatters.mjs
```

Observed result:

```text
All listed Node diagnostic rendering, protocol, and formatter tests passed.
```

Static structure check:

```sh
cd /mnt/data/repo_m48_verify
python3 - <<'PY'
import scripts.run_tests as rt
rt.run_structure_tests()
print('structure-ok')
PY
```

Observed result:

```text
Milestone structure tests passed.
structure-ok
```

Wasm rebuild check:

```sh
cd /mnt/data/repo_m48_verify
bash scripts/build_wasm.sh
```

Observed result in this container:

```text
scripts/build_wasm.sh: line 18: emcc: command not found
```

Interpretation:

- Native C and Node tests pass.
- This container cannot rebuild Wasm because Emscripten is not installed.
- Served website behavior requires a local Wasm rebuild in an Emscripten-enabled environment.

## 10. Pass/fail results

Final automated test status:

```text
PASS - native C tests
PASS - parser tests
PASS - executor tests
PASS - source-run JSON tests
PASS - diagnostic JSON producer build
PASS - rendered Simulator Messages tests
PASS - protocol tests
PASS - formatter tests
PASS - static structure checks
PASS - aggregate runner in final gap-check repository
LIMITED - Wasm rebuild could not be tested because emcc is unavailable
```

No test failures remained after the final gap check.

## 11. Manual/browser testing guidance and expected outputs

Browser testing is applicable after rebuilding Wasm in an Emscripten-enabled environment.

Required setup on Windows:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the served page, typically:

```text
http://localhost:8000/web/
```

The page should identify the project as Milestone 49 / ROL. Program Console should remain empty for all tests below.

### Manual test 1 - Basic ROL success

```asm
.code
main PROC
    mov al, 80h
    rol al, 1
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[info] execution-complete: Execution completed successfully.

Program Console:
(empty)

Registers:
EAX = 00000001h / 1
EFLAGS = 00000801h / 2049
```

Regression signs:

- `rol` is rejected.
- `EAX` is not `00000001h`.
- A warning appears for `rol al, 1`.
- Program Console receives output.

### Manual test 2 - Undefined modeled flag warning, execution continues

```asm
.code
main PROC
    mov al, 80h
    rol al, 8
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[simulator-warning] undefined-modeled-flag line 4, column 5, byte offset 36, span length 9: ROL count 8 has effective count 8 for an 8-bit destination. CF was updated from the least significant bit of the rotated result. ZF and SF were preserved because ROL does not define them. OF is architecturally undefined because the effective count is not 1. The simulator preserved OF deterministically.
[info] execution-complete: Execution completed successfully.

Program Console:
(empty)

Registers:
EAX = 00000080h / 128
EFLAGS = 00000000h / 0
```

Regression signs:

- Warning code is `undefined-shift-flag` instead of `undefined-modeled-flag`.
- Execution stops instead of completing.
- `EAX` changes from `00000080h`.
- `execution-complete` is missing.

### Manual test 3 - Memory ROL

```asm
.data
value BYTE 81h
wordval WORD 8001h
dwordval DWORD 80000001h

.code
main PROC
    rol value, 1
    rol WORD PTR wordval, 4
    rol DWORD PTR dwordval, 1
    rol DWORD PTR dwordval, 32
    mov al, value
    mov bx, wordval
    mov ecx, dwordval
main ENDP
END main
```

Expected key results:

```text
Simulator Messages:
Several unaligned-memory-access warnings may appear for wordval and dwordval because their addresses are intentionally unaligned.
One undefined-modeled-flag warning appears for rol WORD PTR wordval, 4.
[info] execution-complete: Execution completed successfully.

Program Console:
(empty)

Registers:
EAX = 00000003h / 3
EBX = 00000018h / 24
ECX = 00000003h / 3
EFLAGS = 00000801h / 2049

Memory Changes:
value: 81h / 129 -> 03h / 3
wordval: 8001h / 32769 -> 0018h / 24
dwordval: 80000001h / 2147483649 -> 00000003h / 3
```

Regression signs:

- No memory changes are reported.
- `rol DWORD PTR dwordval, 32` changes `dwordval`; effective count `32 & 31` should be zero.
- The `ROL` warning prevents execution.
- QWORD/SQWORD behavior appears to be accepted or used.

### Manual test 4 - Ambiguous memory width diagnostic

```asm
.code
main PROC
    rol [eax], 1
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[assembly-error] ambiguous-memory-width line 3, column 9, byte offset 24, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.

Program Console:
(empty)

Execution:
Does not run.
No execution-complete message.
```

### Manual test 5 - Invalid count register

```asm
.code
main PROC
    rol eax, ebx
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[assembly-error] invalid-instruction-operands line 3, column 14, byte offset 29, span length 3: ROL count must be an immediate byte count or CL.

Program Console:
(empty)

Execution:
Does not run.
No execution-complete message.
```

### Manual test 6 - Missing count

```asm
.code
main PROC
    rol eax
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[assembly-error] invalid-instruction-operands line 3, column 9, byte offset 24, span length 3: ROL takes exactly two operands.

Program Console:
(empty)

Execution:
Does not run.
No execution-complete message.
```

### Manual test 7 - Computed .CONST write runtime failure

```asm
.CONST
limit DWORD 10

.code
main PROC
    mov eax, OFFSET limit
    rol DWORD PTR [eax], 1
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[runtime-error] permission-denied line 6: Memory write at 00600000h for 4 bytes is not permitted in .const.

Program Console:
(empty)

Registers:
EAX = 00600000h / 6291456

Memory Changes:
[]
```

### Manual test 8 - Invalid runtime address

```asm
.code
main PROC
    mov eax, 0
    rol DWORD PTR [eax], 1
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[runtime-error] invalid-address line 4: Invalid memory read at 00000000h for 4 bytes. The address is outside the simulator's configured memory regions.

Program Console:
(empty)

Registers:
EAX = 00000000h / 0

Memory Changes:
[]
```

## 12. Compliance review summary

First compliance review findings:

- Found that `rol eax` was still reported as generic `expected-comma` instead of `invalid-instruction-operands`.
- Found missing rendered Simulator Messages coverage for the missing-count `ROL` diagnostic.
- Found README/supported-syntax wording for previous shift milestones that could imply the wrong diagnostic code.

Fixes applied:

- Updated `ROL` missing-count parsing to emit:

```text
invalid-instruction-operands: ROL takes exactly two operands.
```

- Added parser and source-run coverage for:

```asm
rol eax
rol eax, 1, 2
```

- Added exact rendered Simulator Messages coverage for `rol eax`.
- Corrected docs to describe shift diagnostics as `undefined-shift-flag` while preserving `ROL` as `undefined-modeled-flag`.

Compliance review test result:

- Relevant parser, executor, source-run, rendered-message, protocol, formatter, and static-structure checks passed.
- Aggregate runner exceeded the tool execution window during that pass, so constituent checks were rerun individually and passed.

Verdict after first compliance review:

```text
complete
```

## 13. Re-review summary

Second compliance review findings:

- Found one stale file-level comment in `src/wasm/wasm_api.c` that listed older instruction families but omitted newer supported behavior including `TEST`, `INC/DEC`, bitwise logical instructions, shifts, `ROL`, and the virtual Irvine32 `exit` terminator.
- Found one supported-syntax sentence describing shift behavior using “undefined-modeled-flag policy,” which could be confused with the newer `ROL` diagnostic code.

Fixes applied:

- Updated the `src/wasm/wasm_api.c` file header to accurately describe current source-run instruction coverage through Phase 49.
- Clarified `docs/SUPPORTED_SYNTAX.md` shift wording to say “deterministic undefined-flag policy,” while preserving the actual shift diagnostic code as `undefined-shift-flag`.
- No runtime behavior changes were needed.

Second review test result:

- Relevant parser, executor, source-run, rendered Simulator Messages, protocol, formatter, and structure tests passed.

Final gap-check findings:

- Found one minor stale internal comment in `src/wasm/wasm_api.c` describing shared shift/rotate diagnostics as shift-only.
- No missing implementation, behavior, test coverage, or documentation requirement was found for Phase 49 `ROL`.

Final gap-check fix:

- Updated internal Doxygen comments in `src/wasm/wasm_api.c` to describe shared shift/rotate modeled-flag diagnostics accurately.
- No runtime behavior changed.

Final gap-check test result:

```text
All implemented milestone tests passed.
```

Final verdict:

```text
complete
```

## 14. User-test follow-up summary

The user reported that everything appeared to pass from the provided tests and no discrepancy was found.

Manual-testing package was provided with:

- browser testing steps;
- Windows CMD local testing steps;
- concrete MASM programs;
- exact expected Simulator Messages, Program Console state, registers, memory changes, and diagnostics;
- specific regression signs for each program.

No user-reported discrepancy required additional behavior changes.

## 15. Known limitations

- The container does not have Emscripten installed, so `web/dist` could not be rebuilt here.
- The served website must be rebuilt locally with Emscripten before browser Wasm execution reflects Phase 49 behavior.
- Browser users cannot toggle strict undefined-shift validation through the UI; this remains consistent with prior shift milestones and outside Phase 49 scope.
- `ROR` is not implemented yet.
- Carry rotates are not implemented.
- PF/AF remain unmodeled.
- Smart flag-validity metadata and flag-consumer diagnostics remain future work.
- Executable QWORD/SQWORD memory operations remain unsupported in MASM32 Educational Mode.

## 16. Next recommended milestone

Next recommended milestone:

```text
Milestone 50 / Phase 50 - ROR
```

Suggested Phase 50 focus:

- Implement rotate-right `ror` using the Phase 49 rotate infrastructure and tests as a model.
- Preserve the same scope discipline: no carry rotates, no control flow, no smart flag-validity metadata, no QWORD/SQWORD execution, and no future features.

## 17. Changed-files ZIP/package produced

Packages produced during Phase 49:

```text
/mnt/data/milestone49_changed_files.zip
/mnt/data/milestone49_compliance_review_changed_files.zip
/mnt/data/milestone49_second_review_changed_files.zip
/mnt/data/milestone49_final_gap_check_changed_files.zip
```

Latest package:

```text
/mnt/data/milestone49_final_gap_check_changed_files.zip
```

Recommended next full repository archive name after applying the final package and rebuilding as needed:

```text
Latest_repository_state_milestone_49.zip
```

## 18. Final status

Milestone 49 is complete.

Summary:

- `ROL` is parsed, lowered to IR, executed, diagnosed, documented, and covered by tests.
- Phase metadata is updated to `49`.
- Native and Node tests pass.
- Final gap-check aggregate tests pass.
- Wasm rebuild remains an external environment step because `emcc` is unavailable in this container.
