# Milestone 57-CORR1 report - `.CONST` Cross-Region Diagnostic Clarification

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57-CORR1 - .CONST Cross-Region Diagnostic Clarification
```

Repository/archive milestone:

```text
Phase 57-CORR1 - .CONST Cross-Region Diagnostic Clarification
```

Runtime/source-run MASM behavior phase:

```text
Phase 57 - Signed IDIV
```

Status interpretation:

Phase 57-CORR1 is a corrective diagnostic-quality milestone after Phase 57 - Signed IDIV and before Phase 57A - README Landing Page Cleanup. It advances repository/archive status but intentionally does not advance runtime/source-run MASM behavior metadata. Source-run JSON phase fields, worker/protocol phase values, and browser runtime/source-run behavior phase remain Phase 57.

Scope implemented:

- Added a precise structured diagnostic code for the cross-region/protected-region overlap case:

  ```text
  region-boundary-crossing
  ```

- Applied the new diagnostic code only when one memory access crosses independent VM memory-region boundaries and the requested final byte range overlaps protected `.CONST` storage.
- Added rendered Simulator Messages wording for cross-region `.CONST` read and write failures.
- Preserved direct or wholly-contained `.CONST` writes as `permission-denied`.
- Preserved ordinary cross-region failures that do not overlap `.CONST` as the existing ordinary Level 1 region/range diagnostic, such as `invalid-address`.
- Preserved the rule that a single source-level memory access cannot be split, stitched, or partially executed across independent VM memory regions.
- Preserved no-partial-mutation behavior for fatal cross-region/protected-region failures.
- Added source-run, unit, rendered-message, and regression coverage.
- Updated the full specification, implementation guide, supported-syntax documentation, and README so the documentation now matches the accepted `region-boundary-crossing` implementation.
- Added future-owned TODO guidance for later `.code` memory-access-denial milestones without implementing `.code` access denial now.

This milestone is diagnostic and documentation work. It does not add new MASM syntax, parser acceptance behavior, executable instruction semantics, memory layout behavior, browser controls, or runtime/source-run phase metadata advancement.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57 report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_57.zip
```

Final repository archive produced after completion:

```text
Latest_repository_state_milestone_57-CORR1.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, cross-cutting diagnostic policy, current/future/non-goal distinctions, and memory-validation invariants.
- The incremental implementation guide owns phase numbering, phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 57-CORR1 is the only target milestone for this work.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- All mandatory memory safety remains routed through checked memory helpers.
- User-visible diagnostics have structured tests and exact rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, WinAPI simulator, host include loader, or macro assembler.

## 3. Exact requirements implemented

### 3.1 Structured diagnostic code

Implemented a new core memory status and rendered diagnostic code:

```text
region-boundary-crossing
```

This code is used for cross-region memory accesses that overlap protected `.CONST` storage. The implemented behavior is deliberately narrow:

- Cross-region `.CONST` write overlap: `region-boundary-crossing`.
- Cross-region `.CONST` read overlap: `region-boundary-crossing`.
- Direct or wholly-contained `.CONST` write: `permission-denied`.
- Cross-region access that does not overlap `.CONST`: ordinary region/range diagnostic, such as `invalid-address`.

The new code remains a mandatory Level 1 diagnostic. It is not an optional teaching diagnostic and is not controlled by browser diagnostic settings.

### 3.2 Protected-region diagnostic metadata

Extended `VmMemoryDiagnostic` to record optional `.CONST` overlap context for failed cross-region accesses:

- `has_const_overlap`
- `const_region_start`
- `const_overlap_start`
- `const_overlap_end`

The implementation records the runtime `.CONST` base address from active memory layout metadata. It does not hardcode the fixed-layout default `.CONST` address.

The metadata is collected when checked memory validation fails to find one containing VM region for the full requested range and can prove that the requested range overlaps the active `.CONST` region.

### 3.3 Rendered Simulator Messages

Implemented the accepted rendered-message shape:

```text
Cross-region memory <read|write> at <address> for <N> bytes. The memory address range <start>..<end> crosses/overlaps a protected memory region, .CONST, that starts at <runtime .CONST start address>. This is not allowed; program stopped before access.
```

Fixed-layout example for a write:

```text
[runtime-error] region-boundary-crossing line 9: Cross-region memory write at 005FFFFEh for 4 bytes. The memory address range 005FFFFEh..00600001h crosses/overlaps a protected memory region, .CONST, that starts at 00600000h. This is not allowed; program stopped before access.
```

Fixed-layout example for a read:

```text
[runtime-error] region-boundary-crossing line 8: Cross-region memory read at 005FFFFEh for 4 bytes. The memory address range 005FFFFEh..00600001h crosses/overlaps a protected memory region, .CONST, that starts at 00600000h. This is not allowed; program stopped before access.
```

The wording intentionally says `program stopped before access` so the same phrase is suitable for read and write failures.

### 3.4 `.CONST` read/write distinction preserved

Implemented and documented the following distinction:

```text
Wholly-contained write overlapping `.CONST`:
  permission-denied

Cross-region read or write whose final range intersects `.CONST`:
  region-boundary-crossing

Wholly-contained read from `.CONST`:
  allowed, unless another mandatory or enabled strict validation rejects it

Cross-region access that does not intersect `.CONST` or another known protected region:
  ordinary Level 1 region/range diagnostic
```

This prevents future assistants from misreading `.CONST` as generally unreadable. `.CONST` remains read-only, not no-access.

### 3.5 Dynamic layout metadata requirement

The implementation and documentation require the protected-region base address to come from active runtime layout metadata. The diagnostic must not hardcode addresses such as `00600000h`. This is necessary so the behavior remains correct under fixed educational layout, automatic deterministic layout, seeded randomized layout, and future fresh randomized layout.

### 3.6 Documentation updates

Updated the source-of-truth documents to make the implemented behavior canonical:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
  - Updated cross-region/protected-region rules.
  - Updated memory diagnostic precedence.
  - Defined intersects/overlaps/crosses-overlaps as byte-range intersection.
  - Clarified `.CONST` is protected against writes, not ordinary reads.
  - Added future `.code` protected-region guidance as future behavior only.

- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
  - Replaced Phase 57-CORR1 with the finalized behavior, test requirements, non-goals, and acceptance criteria.
  - Updated the standing memory-capable-feature rule with the new `region-boundary-crossing` diagnostic model.
  - Added a future-owned TODO for later `.code` memory-access-denial phases.

- `docs/SUPPORTED_SYNTAX.md`
  - Added a Phase 57-CORR1 memory diagnostic clarification note.

- `README.md`
  - Updated repository/archive status while preserving runtime/source-run MASM behavior phase as Phase 57.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57-CORR1:

- New MASM syntax.
- New instructions.
- Parser acceptance changes.
- VM instruction semantics changes.
- Memory-layout refactors.
- Memory-region merging.
- Section-capacity validation changes.
- Section-image validation changes.
- Declared-object validation changes.
- Uninitialized-read policy changes.
- Browser diagnostic setting changes.
- `.CONST` writability changes.
- `.code` access-denial behavior.
- Stack behavior.
- Control flow.
- Irvine32 routine expansion.
- Program Console input/output routines.
- Executable QWORD/SQWORD memory operations.
- Windows API behavior.
- PE loading.
- Object linking.
- Host include loading.
- Macro expansion.
- Runtime/source-run MASM behavior phase advancement beyond Phase 57.
- Phase 57A or later milestone work.

Future-owned work intentionally preserved:

- Future `.code` memory-access-denial phases should reuse the `region-boundary-crossing` protected-region diagnostic shape when cross-region accesses overlap `.code`.
- Future memory-reading instruction milestones must continue updating planned-read collection as they add new memory-reading opcodes.
- Phase 57A - README Landing Page Cleanup remains the next recommended milestone.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `region-boundary-crossing` is the correct structured diagnostic code for cross-region accesses that overlap a protected memory region.
- **Reason:** User testing showed that preserving `invalid-address` was technically functional but misleading. The failure is not merely that the start address is invalid; the requested final byte range crosses independent VM memory-region boundaries and overlaps protected `.CONST` storage.
- **Risk:** The code implementation temporarily led the earlier Phase 57-CORR1 documentation wording until the spec and guide were surgically updated.
- **How to change later:** A future diagnostic taxonomy milestone could split additional ordinary region/range failures into more specific codes, but that should be done explicitly with spec/guide updates and tests.

### Assumption 2

- **Assumption:** The new diagnostic should remain narrow and should not reclassify every invalid-address or invalid-region failure.
- **Reason:** Phase 57-CORR1 is corrective and diagnostic-specific, not a broad memory diagnostic taxonomy rewrite.
- **Risk:** Some non-`.CONST` cross-region failures still use older ordinary region/range wording.
- **How to change later:** A future diagnostic-quality phase can define a broader region/range diagnostic cleanup and migrate those cases deliberately.

### Assumption 3

- **Assumption:** Direct or wholly-contained `.CONST` writes should remain `permission-denied`.
- **Reason:** Those failures reach permission/read-only validation within one containing region and are not primarily cross-region failures.
- **Risk:** Users may see two different codes for `.CONST`-related failures.
- **How to change later:** Documentation now explains the distinction. A future UI/help enhancement could group these related failures visually without changing the structured codes.

### Assumption 4

- **Assumption:** `.CONST` cross-region reads should use `region-boundary-crossing` but must not imply `.CONST` is generally unreadable.
- **Reason:** A read that spans independent VM regions is invalid because one access cannot be stitched across regions. A wholly-contained `.CONST` read remains allowed.
- **Risk:** The phrase `protected memory region` could be misread without documentation guardrails.
- **How to change later:** The spec and guide now explicitly state that `.CONST` is protected against writes, not ordinary reads, and that cross-region reads fail because of region-boundary crossing.

### Assumption 5

- **Assumption:** The protected-region start address must be dynamic.
- **Reason:** The project supports or plans multiple layout modes, and hardcoded fixed-layout addresses would be stale or wrong outside the fixed educational layout.
- **Risk:** Current exact tests use fixed-layout addresses, so future layout-mode tests must ensure dynamic metadata remains exercised.
- **How to change later:** Add seeded/randomized layout fixture coverage when the relevant layout infrastructure is available for this diagnostic path.

### Assumption 6

- **Assumption:** Updating the spec and guide after the code change was acceptable in this session because the user explicitly requested surgical source-of-truth updates after manual verification.
- **Reason:** The implementation started from the original Phase 57-CORR1 scope but user testing identified a clearer diagnostic-code requirement, and the user requested code first, then canonical documentation updates.
- **Risk:** The temporary mismatch required a final documentation pass and gap check.
- **How to change later:** Future sessions should update source-of-truth text before or at the same time as diagnostic-code behavior changes when possible.

## 6. Relevant TODO-style notes reviewed

### Target-owned note

- **Location:** `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, Phase 57-CORR1 section and status/numbering text.
- **Note text or summary:** Phase 57-CORR1 is a non-renumbering corrective phase after Phase 57 and before Phase 57A; runtime/source-run MASM behavior phase remains Phase 57; do not renumber Phase 57A through Phase 57T, Phase 58, or later phases.
- **Classification:** target-owned.
- **Reason:** This directly constrains status documentation and phase metadata for this milestone.
- **Action for this milestone:** Resolved by preserving runtime/source-run phase metadata at Phase 57 and preserving later phase numbering.

### Future-owned note

- **Location:** `src/wasm/wasm_api.c`.
- **Note text or summary:** `TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.`
- **Classification:** future-owned.
- **Reason:** Phase 57-CORR1 does not add a new memory-reading opcode.
- **Action for this milestone:** Preserved unchanged.

### Future-owned note added during this milestone

- **Location:** `src/core/vm_memory.c`.
- **Note text or summary:** Future protected-region diagnostics should generalize the `.CONST` overlap helper for later `.code` memory-access-denial milestones, using active region metadata and dynamic `.code` base addresses.
- **Classification:** future-owned.
- **Reason:** `.code` access denial is not part of Phase 57-CORR1.
- **Action for this milestone:** Added narrowly and explicitly marked future-owned so it cannot be mistaken for current scope.

### Future-owned guide TODO added during documentation update

- **Location:** `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, Phase 57-CORR1 future-owned TODO for `.code` protected-region diagnostics.
- **Note text or summary:** Future `.code` access-denial phases should reuse the `region-boundary-crossing` diagnostic shape with dynamic `.code` base address metadata.
- **Classification:** future-owned.
- **Reason:** It gives future phases diagnostic guidance without implementing `.code` access denial now.
- **Action for this milestone:** Added as future-owned and explicitly says not to implement `.code` access denial during Phase 57-CORR1.

## 7. TODO-style note disposition

- **Target-owned TODO-style notes resolved:** Phase 57-CORR1 status/numbering constraint resolved. Runtime/source-run metadata remains Phase 57 and later phases were not renumbered.
- **Future-owned TODO-style notes intentionally preserved:** `src/wasm/wasm_api.c` future opcode planned-read TODO, `src/core/vm_memory.c` future `.code` protected-region diagnostic TODO, and the guide’s future `.code` protected-region TODO.
- **Stale or contradicted TODO-style notes corrected:** None found.
- **Unresolved TODO-related risks:** None identified. Future-owned TODOs are narrowly scoped and explicitly state that they do not authorize current implementation work.

## 8. Design summary

### Core memory layer

The memory layer now detects the specific situation where a checked memory access cannot be contained in one VM region and the requested byte range overlaps the active `.CONST` region. In that case it returns:

```text
VM_MEMORY_STATUS_REGION_BOUNDARY_CROSSING
```

The helper records `.CONST` overlap context in `VmMemoryDiagnostic`, including the dynamic `.CONST` base address and inclusive overlap range. The helper is intentionally local to `.CONST` for Phase 57-CORR1 but includes a future-owned TODO for later `.code` protected-region generalization.

### Wasm/source-run diagnostic formatting

The Wasm/source-run diagnostic formatter recognizes `VM_MEMORY_STATUS_REGION_BOUNDARY_CROSSING` and emits the exact message shape required by the finalized spec and guide. The message buffer was expanded to avoid truncating the more descriptive text.

### Status and phase metadata

Runtime/source-run phase metadata remains Phase 57. Repository/archive status is updated to Phase 57-CORR1 in current documentation. The final archive is named:

```text
Latest_repository_state_milestone_57-CORR1.zip
```

### Diagnostic-code scope

The implementation deliberately does not replace ordinary invalid-address diagnostics. Only cross-region/protected-`.CONST` overlap uses `region-boundary-crossing` in this milestone.

## 9. Files changed

Source and header files:

- `src/core/vm_memory.c`
- `src/core/vm_memory.h`
- `src/wasm/wasm_api.c`

Tests:

- `tests/core/test_data_section.c`
- `tests/core/test_vm_memory.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`

Test runner:

- `scripts/run_tests.py`

Documentation:

- `README.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`

Generated build/test artifacts were produced during testing under `build/tests`, but they are not source changes and were excluded from the final repository archive.

## 10. Tests added

### Core/unit tests

Added or updated memory tests to verify:

- invalid-address diagnostics remain structured;
- cross-region `.CONST` overlap records `.CONST` diagnostic metadata;
- the new `region-boundary-crossing` status name is available;
- dynamic `.CONST` base metadata is recorded.

### Source-run tests

Added Phase 57-CORR1 source-run coverage for:

- `phase57corr1-const-cross-region-write-overlap`;
- `phase57corr1-direct-const-write-permission`;
- `phase57corr1-const-cross-region-read`;
- `phase57corr1-non-const-cross-region-write`.

The source-run tests verify:

- `region-boundary-crossing` for cross-region `.CONST` write overlap;
- `region-boundary-crossing` for cross-region `.CONST` read overlap;
- `permission-denied` for direct `.CONST` write;
- `invalid-address` remains for unrelated non-`.CONST` cross-region failure;
- runtime/source-run phase metadata remains `57`;
- no memory-change row is emitted for failing accesses;
- no `execution-complete` message appears after fatal diagnostics.

### Rendered Simulator Messages tests

Added exact rendered-message tests for:

- cross-region `.CONST` write overlap;
- cross-region `.CONST` read overlap.

### Regression tests

Updated related expectations where previous tests expected `invalid-address` for the now-more-specific cross-region `.CONST` overlap path. Preserved regression coverage proving ordinary non-`.CONST` cross-region access is not reclassified.

## 11. Commands used to test

Focused test commands run during implementation and reviews:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Additional final gap-check commands run:

```bash
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --all
```

Skipped dependency check:

- Browser/Wasm rebuild smoke was skipped by the test runner because `emcc` is unavailable in this environment.

No subgroup or fixture-family reruns were required because focused groups and aggregate verification passed.

## 12. Pass/fail results

Focused groups:

```text
structure: PASS
native: PASS
source-run: PASS
web: PASS
diagnostics: PASS
protocol: PASS
static: PASS
```

Aggregate:

```text
python3 scripts/run_tests.py --all
```

Result:

```text
PASS
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

A combined shell invocation containing several focused commands plus aggregate timed out once after focused groups had already completed. The aggregate command was rerun separately and completed successfully. The final classification is therefore aggregate completed and passed, not aggregate timed out.

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification for dependency skip:

```text
group skipped because dependency was unavailable, such as emcc
```

No focused group failed. No focused group timed out and required subgroup or fixture reruns. The aggregate did not fail.

## 13. Manual/browser testing guidance and expected outputs

Website testing is available after rebuilding the Wasm artifact with Emscripten.

Windows CMD setup assumptions:

- Visual Studio Developer Command Prompt or equivalent C tooling available.
- Node.js available.
- Python available as `py`.
- Emscripten available only if doing browser/Wasm rebuild verification.

Browser rebuild and serve commands:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

### Manual Program 1 - Cross-region `.CONST` write overlap

```asm
.const
x BYTE 1

.code
main PROC
    mov eax, OFFSET x
    mov ebx, [eax]
    sub eax, 2
    mov DWORD PTR [eax], 0FFFFFFFFh
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] region-boundary-crossing line 9: Cross-region memory write at 005FFFFEh for 4 bytes. The memory address range 005FFFFEh..00600001h crosses/overlaps a protected memory region, .CONST, that starts at 00600000h. This is not allowed; program stopped before access.
```

Expected Program Console:

```text
(empty)
```

Expected final register values include:

```text
EAX = 005FFFFEh / unsigned 6291454
EBX = 00000001h / unsigned 1
```

Expected memory changes:

```text
No memory changes.
```

There should be no `execution-complete` message.

### Manual Program 2 - Direct `.CONST` write remains permission-denied

```asm
.const
x BYTE 1

.code
main PROC
    mov eax, OFFSET x
    mov DWORD PTR [eax], 0FFFFFFFFh
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] permission-denied line 7: Memory write at 00600000h for 4 bytes is not permitted in .const.
```

Expected Program Console:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

There should be no `execution-complete` message.

### Manual Program 3 - Cross-region `.CONST` read overlap

```asm
.const
x BYTE 1

.code
main PROC
    mov eax, OFFSET x
    sub eax, 2
    mov ebx, DWORD PTR [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] region-boundary-crossing line 8: Cross-region memory read at 005FFFFEh for 4 bytes. The memory address range 005FFFFEh..00600001h crosses/overlaps a protected memory region, .CONST, that starts at 00600000h. This is not allowed; program stopped before access.
```

Expected Program Console:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

There should be no `execution-complete` message.

### Windows CMD local tests

`program.asm` is not required for the local test-runner checks. The relevant MASM fixtures are embedded in the automated source-run and rendered-message tests.

Commands:

```cmd
py scripts\run_tests.py --source-run
py scripts\run_tests.py --diagnostics
py scripts\run_tests.py --all
```

Expected output snippets:

```text
[source-run] PASS
[diagnostics] PASS
All implemented milestone tests passed.
```

Acceptable if Emscripten is unavailable:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Regression signs:

- Program 1 reports `invalid-address` instead of `region-boundary-crossing`.
- Program 1 does not mention `.CONST` or the `.CONST` start address.
- Program 1 emits `execution-complete`.
- Program 1 commits a memory change.
- Program 2 stops reporting `permission-denied`.
- Program 3 reports `permission-denied` or generic `invalid-address` instead of `region-boundary-crossing`.
- A direct/wholly-contained `.CONST` read is rejected merely because `.CONST` is read-only.
- Source-run phase metadata advances beyond `57`.
- Any focused or aggregate command reports `FAIL`.

## 14. Compliance review summary

First compliance review found one coverage gap: ordinary non-`.CONST` cross-region write failure was not explicitly tested after the `.CONST` overlap change.

Fix applied:

- Added a source-run regression test proving non-`.CONST` cross-region write remains an ordinary `invalid-address` region/range failure and does not gain protected `.CONST` wording.

Tests rerun after first compliance review:

- `python3 scripts/run_tests.py --source-run`: PASS
- `python3 scripts/run_tests.py --native`: PASS
- `python3 scripts/run_tests.py --diagnostics`: PASS
- `python3 scripts/run_tests.py --web`: PASS
- `python3 scripts/run_tests.py --structure`: PASS
- `python3 scripts/run_tests.py --protocol`: PASS
- `python3 scripts/run_tests.py --static`: PASS
- `python3 scripts/run_tests.py --all`: PASS

Verdict after first compliance review:

```text
complete
```

## 15. Re-review summary

Second compliance review found one documentation clarity issue: the README opening sentence could be read as folding Phase 57-CORR1 into runtime MASM behavior. That conflicted with the required repository/runtime status split.

Fix applied:

- Reworded README to distinguish repository state from runtime/source-run MASM behavior metadata.

Tests rerun after second review:

- `python3 scripts/run_tests.py --static`: PASS
- `python3 scripts/run_tests.py --source-run`: PASS
- `python3 scripts/run_tests.py --diagnostics`: PASS
- `python3 scripts/run_tests.py --web`: PASS
- `python3 scripts/run_tests.py --all`: PASS

Final re-review verdicts:

- Scope verdict: complete.
- Documentation verdict: complete.
- Test coverage verdict: complete.
- TODO-style note verdict: complete.

## 16. User-test follow-up summary

The user manually tested the programs and reported that the program behavior worked as expected. The user then identified a diagnostic-quality issue: the earlier `invalid-address` code and wording were technically compliant but confusing because the fault was actually a region-boundary crossing that overlapped `.CONST`.

User-requested change:

- Use a more precise diagnostic code:

  ```text
  region-boundary-crossing
  ```

- Use message wording of the form:

  ```text
  Cross-region memory [write/read] at <address> for 4 bytes. The memory address range <start>..<end> crosses/overlaps a protected memory region, .CONST, that starts at <start address of the region>. This is not allowed; program stopped before access.
  ```

- Add future-owned TODOs for later `.code` memory-access-denial milestones to reuse the same protected-region diagnostic shape with `.code` and a dynamic `.code` base address.

Fixes applied after user-test follow-up:

- Added `VM_MEMORY_STATUS_REGION_BOUNDARY_CROSSING`.
- Added status name `region-boundary-crossing`.
- Updated source-run and rendered Simulator Messages to use the accepted wording.
- Added/updated tests for read and write cases.
- Added future-owned `.code` protected-region TODO in code and guide.
- Updated spec/guide after manual confirmation to make the new diagnostic code canonical.

User confirmed the updated diagnostic behavior worked perfectly.

## 17. Known limitations

- Emscripten `emcc` is unavailable in this environment, so browser/Wasm rebuild smoke testing was skipped locally.
- Website/browser verification requires rebuilding the Wasm artifact in an environment with Emscripten.
- Exact address values in manual examples are fixed-layout examples. The implementation uses dynamic metadata, and docs now require dynamic protected-region base addresses for other layout modes.
- The future `.code` protected-region diagnostic behavior is documented as future-owned guidance only. `.code` access denial was not implemented in this milestone.
- Broader ordinary invalid-address/invalid-region diagnostic taxonomy cleanup was not performed. Only cross-region/protected-`.CONST` overlap received the new diagnostic code.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57A - README Landing Page Cleanup
```

Phase 57A remains next because Phase 57-CORR1 was inserted after Phase 57 and before Phase 57A without renumbering Phase 57A through Phase 57T, Phase 58, or later phases.

## 19. Changed-files ZIP/package and archive produced

Changed-files ZIP/package artifacts produced during the milestone:

- `changed_files_m57_corr1.zip`
- `changed_files_m57_corr1_review.zip`
- `changed_files_m57_corr1_second_review.zip`
- `changed_files_m57_corr1_region_boundary.zip`
- `changed_files_m57_corr1_spec_guide_update.zip`

Final repository archive produced:

```text
Latest_repository_state_milestone_57-CORR1.zip
```

The final archive is the recommended repository handoff artifact for the next milestone.

## 20. Final milestone status

Phase 57-CORR1 is complete.

Final state:

- Implementation complete.
- Documentation updated and source-of-truth aligned.
- Tests added and passing.
- Manual testing completed by user.
- User-test follow-up applied and verified.
- Final archive produced.
- No target-owned TODO-style notes remain unresolved.
- Future-owned TODO-style notes are explicit and scoped.
