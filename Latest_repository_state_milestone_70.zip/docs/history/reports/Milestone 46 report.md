# Milestone 46 report - SHL and SAL

## 1. Milestone title and scope

Milestone 46 implements Phase 46 - SHL and SAL for the Online MASM32 Educational Simulator.

Scope implemented:

- Add executable runtime support for `shl` and `sal`.
- Treat `sal` as the same shift-left operation as `shl`, while preserving mnemonic identity in IR/opcode naming and diagnostics.
- Support register destinations at 8-bit, 16-bit, and 32-bit widths.
- Support unambiguous memory destinations through typed symbols, symbol offsets, explicit unsigned PTR forms, and explicit signed PTR aliases.
- Support immediate byte shift counts and `CL` as the only register shift-count operand.
- Apply MASM/x86-compatible count masking for 32-bit educational mode: `effective_count = raw_count & 31`.
- Preserve count-zero no-op behavior: if the effective count is zero, destination and modeled flags are unchanged and no undefined-shift warning is emitted.
- Implement default-mode undefined modeled-flag warnings for architecturally undefined SHL/SAL flag cases while allowing execution to complete.
- Implement strict undefined-shift validation through the test/API configuration path, where the same undefined modeled-flag condition becomes a runtime error before mutation.
- Add flag-specific diagnostic wording that states which modeled flags were updated, which flags are architecturally undefined, and which flags the simulator preserved deterministically.
- Preserve all prior milestone behavior.
- Update source-run and browser metadata to report phase 46.
- Add native C, parser, executor, source-run JSON, rendered Simulator Messages, protocol/static, documentation, manual-testing, compliance, and regression coverage.

The implementation stayed within the milestone boundary. No future shift-right, rotate, control-flow, stack, procedure, Irvine32, QWORD/SQWORD execution, or PF/AF behavior was implemented.

## 2. Source-of-truth files used

Canonical repository files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 45 report.md`

Repository archive used as the implementation base:

- `Latest_repository_state_milestone_45.zip`

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, phase tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.

External x86 behavior references used for the final behavior explanation:

- Felix Cloutier x86 reference page for `SAL/SAR/SHL/SHR`, which reflects Intel-style instruction semantics: `SAL` and `SHL` perform the same left-shift operation; count zero leaves flags unaffected; `OF` is defined only for 1-bit shifts; `CF` is undefined for SHL/SHR when count is greater than or equal to destination operand size.
- Oracle IA-32 Assembly Language Reference for the `sal`/`shl` synonym relationship.

These external references were used only to validate and explain the Phase 46 guide/spec behavior. The repository guide/spec remained the implementation authority.

## 3. Exact requirements implemented

Accepted syntax implemented:

```asm
shl reg, 1
shl reg, imm
shl reg, cl
shl mem, 1
shl mem, imm
shl mem, cl

sal reg, 1
sal reg, imm
sal reg, cl
sal mem, 1
sal mem, imm
sal mem, cl
```

Supported register destinations:

```text
reg8, reg16, reg32
```

Supported memory destinations:

```asm
shl BYTE PTR [eax], 1
shl WORD PTR [eax], 1
shl DWORD PTR [eax], 1
shl SBYTE PTR [eax], 1
shl SWORD PTR [eax], 1
shl SDWORD PTR [eax], 1
shl value, 1
shl values[4], 1
```

Equivalent `sal` forms are accepted.

Rejected syntax verified:

```asm
shl 1, al
shl eax, ebx
shl eax, cx
shl eax
shl eax, 1, 2
shl [eax], 1
shl QWORD PTR q, 1
shl SQWORD PTR q, 1
```

Equivalent `sal` invalid forms are also rejected.

Runtime semantics implemented:

- `sal` executes as the same left-shift operation as `shl`.
- Raw count source:
  - immediate byte count, or
  - low 8 bits of `ECX` when the count operand is `CL`.
- Effective count:

  ```text
  effective_count = raw_count & 31
  ```

- Effective count `0`:
  - destination unchanged;
  - `CF`, `ZF`, `SF`, and `OF` unchanged;
  - no undefined-shift warning.
- Effective count `1`:
  - destination shifted left by one bit;
  - low bit filled with zero;
  - `CF` receives the bit shifted out;
  - `ZF` and `SF` update from the result;
  - `OF = new_sign_bit XOR CF`.
- Effective count greater than `1` but less than destination width:
  - destination shifted left by effective count;
  - `CF` receives the last bit shifted out;
  - `ZF` and `SF` update from the result;
  - `OF` is architecturally undefined and is preserved deterministically by the simulator;
  - default mode emits `undefined-shift-flag` warning;
  - strict mode emits `undefined-shift-flag` runtime error before mutation.
- Effective count greater than or equal to destination width:
  - destination shifted left deterministically;
  - `ZF` and `SF` update from the result;
  - `CF` is architecturally undefined and is preserved deterministically by the simulator;
  - `OF` is architecturally undefined and is preserved deterministically by the simulator;
  - default mode emits `undefined-shift-flag` warning;
  - strict mode emits `undefined-shift-flag` runtime error before mutation.

Diagnostics implemented or verified:

- `undefined-shift-flag` warning in default mode.
- `undefined-shift-flag` runtime error in strict undefined-shift validation mode.
- `ambiguous-memory-width` for untyped memory destinations such as `shl [esi], 1`.
- `invalid-instruction-operands` for immediate destinations, wrong operand counts, and invalid count registers such as `EBX` or `CX`.
- Existing unsupported-runtime diagnostics for executable `QWORD PTR` and `SQWORD PTR` memory operations remain in force.
- Existing runtime memory diagnostics for invalid addresses and `.CONST` permission failures remain structured and rendered.
- Diagnostic source location data remains preserved: line, column, byte offset, and span length where applicable.

Improved warning wording implemented after manual user testing:

- Multi-bit shifts below operand width now say `CF`, `ZF`, and `SF` were updated, and `OF` was preserved because it is architecturally undefined.
- Shifts with effective count greater than or equal to destination width now say `ZF` and `SF` were updated, and `CF` and `OF` were preserved because they are architecturally undefined.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 46:

- `shr`
- `sar`
- `rol`
- `ror`
- `cmp`
- labels, `jmp`, conditional jumps, or `loop`
- `lea`
- `mul`, `imul`, `div`, or `idiv`
- `push`, `pop`, `call`, `ret`, `leave`, or stack behavior
- procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`
- Irvine32 routine bodies beyond the existing `exit` virtual terminator
- Program Console input/output routines
- scaled-index addressing
- executable QWORD/SQWORD memory operations
- PF/AF integration for shift instructions
- browser UI setting for strict undefined-shift validation
- Windows API, PE loading, object linking, host include loading, or macro behavior

Compile-time expression operator `SHL` remains separate from runtime instruction `shl`. Existing expression behavior was preserved.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `sal` should share the same executor helper as `shl`, but remain a separate IR opcode.
- **Reason:** The guide and x86 behavior define `SAL` as synonymous with `SHL`, while separate opcode identity keeps diagnostics, opcode-name helpers, tests, and future debugger display clear.
- **Risk:** Adds one additional opcode even though the behavior is shared.
- **How to change later:** A future IR normalization pass could lower both opcodes to a shared internal operation while preserving the original source mnemonic for diagnostics/debugger display.

### Assumption 2

- **Assumption:** Immediate shift counts should be accepted as byte-range values `0..255`.
- **Reason:** The guide describes an encoded immediate shift count and raw count as unsigned; x86 immediate shift counts are byte-sized in the relevant forms.
- **Risk:** If a future educational mode accepts broader constant expressions that evaluate outside this range, current validation will need to be widened or reclassified.
- **How to change later:** Route shift counts through the centralized constant-expression evaluator and then validate or truncate according to a later explicit instruction-encoding policy.

### Assumption 3

- **Assumption:** Strict undefined-shift validation should be exposed through the native/Wasm source-run options used by tests, not as a new browser UI setting in this milestone.
- **Reason:** Phase 46 requires strict-mode tests but does not require a user-facing settings UI.
- **Risk:** The test/API option may later need to be folded into a broader simulator-settings object.
- **How to change later:** Move the strict-shift flag into the eventual settings schema when UI settings are implemented.

### Assumption 4

- **Assumption:** PF and AF remain unmodeled and untouched in Phase 46.
- **Reason:** The project currently models only `CF`, `ZF`, `SF`, and `OF`; PF/AF shift integration is outside Phase 46 scope.
- **Risk:** Future PF/AF integration must revisit shift helpers and diagnostics.
- **How to change later:** Add PF/AF update behavior in the later PF/AF phase while keeping Phase 46 `CF/ZF/SF/OF` behavior stable.

### Assumption 5

- **Assumption:** For architecturally undefined modeled flags, the simulator should preserve previous flag values deterministically and warn by default.
- **Reason:** The guide requires deterministic educational behavior and warning-only execution in default mode.
- **Risk:** Users comparing against real hardware may observe different undefined flag values.
- **How to change later:** Add a documented alternate undefined-flag policy only if a future simulator-settings milestone explicitly introduces it.

## 6. Design summary

### IR changes

Two new opcodes were added:

```text
VM_IR_OPCODE_SHL
VM_IR_OPCODE_SAL
```

The opcode-name helper was updated so diagnostics, tests, and future debugging output can identify the opcodes as:

```text
shl
sal
```

### Parser changes

The parser recognizes `shl` and `sal` as binary destination-mutating shift instructions.

Parser behavior:

- Accepts register destinations.
- Accepts direct typed symbols and typed symbol offsets as memory destinations.
- Accepts explicit `BYTE PTR`, `WORD PTR`, and `DWORD PTR` memory forms.
- Accepts signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases by width.
- Accepts immediate byte shift counts.
- Accepts `CL` as the only register count operand.
- Rejects immediate destinations.
- Rejects wrong operand counts.
- Rejects count registers other than `CL`, including `CX`, `ECX`, and general registers such as `EBX`.
- Rejects untyped memory destinations such as `shl [eax], 1` with `ambiguous-memory-width`.
- Preserves existing QWORD/SQWORD executable memory-operation rejection.
- Emits static `.CONST` write diagnostics for direct `.CONST` destinations where existing static detection applies.

### Executor changes

The executor handles `SHL` and `SAL` through a shared left-shift read-modify-write path.

Execution algorithm:

1. Resolve and validate destination and shift-count operands.
2. Resolve raw count from immediate or `CL`.
3. Compute effective count as `raw_count & 31`.
4. If effective count is zero, return success without mutation.
5. In strict undefined-shift validation mode, detect undefined modeled-flag cases before mutation and emit a runtime error.
6. Read destination value.
7. Save pre-instruction CPU/flag state for rollback on failed writes.
8. Compute the shifted result at operand width.
9. Update or preserve modeled flags according to Phase 46 rules.
10. Write result back to register or memory destination.
11. If a memory write fails, restore CPU/flag state so no partial mutation is visible.

Memory behavior:

- All memory reads go through checked VM read helpers.
- All memory writes go through checked VM write helpers.
- `.CONST` permission checks remain enforced by final address range.
- Invalid reads occur before write-back.
- Failed writes do not create successful memory-change rows.

### Source-run and diagnostics changes

The source-run path emits default-mode `undefined-shift-flag` warnings before executing shift instructions that have architecturally undefined modeled flags.

Warning-only runs continue to execute and may end with both:

```text
[simulator-warning] undefined-shift-flag ...
[info] execution-complete: Execution completed successfully.
```

Strict undefined-shift validation instead returns a runtime error and does not execute the offending shift instruction.

### Documentation and metadata

Updated documentation and metadata to describe Phase 46 as the current implemented milestone and list `shl`/`sal` as supported runtime instructions.

## 7. Files changed

Final Phase 46 implementation, compliance, diagnostic-quality, and final gap-check work touched these files across the cumulative milestone work:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_exec.h
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
src/wasm/wasm_api.h
tests/core/diagnostic_json_producer.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

Final gap-check-only cleanup touched:

```text
tests/core/test_parser.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
```

## 8. Tests added

### Parser tests

Added or expanded coverage for:

- `shl al, 1`
- `shl ax, 1`
- `shl eax, 1`
- `shl eax, 0`
- `shl eax, 32`
- `shl eax, cl`
- `sal eax, 1`
- `sal eax, cl`
- `shl BYTE PTR [eax], 1`
- `shl WORD PTR [eax], 1`
- `shl DWORD PTR [eax], 1`
- `shl SBYTE PTR [eax], 1`
- `shl SWORD PTR [eax], 1`
- `shl SDWORD PTR [eax], 1`
- direct typed symbol destinations
- symbol-offset destinations
- case-insensitive mnemonic recognition
- immediate destination rejection
- wrong operand count rejection
- invalid count-register rejection
- ambiguous memory-width rejection
- QWORD/SQWORD executable memory-operation rejection
- direct `.CONST` write rejection through existing paths

### Executor tests

Added or expanded coverage for:

- `shl al, 1`: `80h -> 00h`, `CF=1`, `ZF=1`, `SF=0`, `OF=1`
- `shl ax, 1` edge behavior
- `shl eax, 1` sign/overflow behavior
- `shl eax, 2` defined result with undefined `OF` preservation
- `shl eax, 32` effective-count-zero no-op
- `shl al, 8` undefined `CF/OF` preservation with result-based `ZF/SF`
- `sal eax, 1` equivalence to `shl eax, 1`
- `shl eax, cl` using low 8 bits of `ECX`
- alias-width mutation for `AL` and `AX`
- byte, word, and dword memory read-modify-write success
- invalid memory read failure
- `.CONST` permission failure
- no partial mutation on failed memory writes
- strict undefined-shift validation rejecting before mutation

### Source-run JSON tests

Added or expanded coverage for:

- successful register acceptance program
- successful memory destination program
- `CL` count program
- count-zero no-op program
- default warning plus successful execution
- strict-mode runtime error without execution completion
- invalid immediate destination
- invalid count register
- wrong operand count
- ambiguous memory-width diagnostic
- direct `.CONST` assembly diagnostic
- computed `.CONST` runtime failure
- invalid memory destination runtime failure
- phase metadata reporting `46`
- warning text naming affected/preserved flags after diagnostic-quality fix

### Rendered Simulator Messages tests

Added or expanded exact rendered-message coverage for:

- successful execution line
- `ambiguous-memory-width` from `shl [esi], 1`
- `invalid-instruction-operands` from `shl eax, ebx`
- default `undefined-shift-flag` warning for `shl al, 8`
- default `undefined-shift-flag` warning for `sal eax, cl` with `CL = 2`
- strict-mode `undefined-shift-flag` runtime error
- QWORD/SQWORD unsupported executable memory operation path where existing diagnostics apply
- runtime invalid-address diagnostic
- `.CONST` runtime permission failure without successful memory-change rows

### Regression tests

Regression coverage confirms:

- Existing `not` behavior remains intact and preserves modeled flags.
- Existing `and`, `or`, and `xor` behavior remains intact.
- Existing `test` behavior remains read-only and flag-setting only.
- Existing `inc`/`dec` behavior remains intact and preserves `CF` while updating other modeled flags.
- Existing `neg`, `xchg`, `nop`, `adc`, `sbb`, and carry-control behavior remains intact.
- Existing compile-time expression `SHL` behavior remains separate from runtime instruction `shl`.
- Existing `.CONST`, object-bounds, uninitialized-read, and invalid-address validation paths remain intact.
- Existing Milestone 42 `exit` behavior remains intact.
- Program Console remains separate from Simulator Messages.
- `unsupported-shift-count` is not used for MASM-valid shift counts.

## 9. Commands used to test

Primary aggregate test command:

```sh
cd /mnt/data/repo_m46
python3 scripts/run_tests.py
```

Observed final result:

```text
All implemented milestone tests passed.
```

Wasm rebuild check:

```sh
cd /mnt/data/repo_m46
bash scripts/build_wasm.sh
```

Observed result in this container:

```text
scripts/build_wasm.sh: line 18: emcc: command not found
```

Interpretation:

- Native C and Node tests pass.
- This container cannot rebuild Wasm because Emscripten is not installed.
- Served website behavior requires a local Wasm rebuild in an Emscripten-enabled environment.

## 10. Pass/fail results

Final automated test status:

```text
PASS - native C tests
PASS - parser tests
PASS - executor tests through Milestone 46
PASS - source-run JSON tests through Phase 46
PASS - Node formatter/protocol tests
PASS - rendered Simulator Messages tests
PASS - milestone/static structure tests
PASS - aggregate test runner
SKIPPED/UNAVAILABLE - Wasm rebuild in this container because emcc is not installed
```

Manual user testing status:

```text
PASS - user-provided browser outputs matched the final Phase 46 behavior after the diagnostic-quality wording fix.
```

## 11. Manual/browser testing guidance and expected outputs

Website-testable: yes, after rebuilding Wasm locally with Emscripten.

Windows setup assumptions:

```cmd
emcc --version
py --version
node --version
```

Build and serve on Windows:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

Stop server:

```cmd
scripts\windows\stop_web.cmd
```

Local Windows test command:

```cmd
py scripts\run_tests.py
```

Expected:

```text
All implemented milestone tests passed.
```

Optional per-file local source check:

```cmd
build\tests\diagnostic_json_producer.exe program.asm
```

### Manual program 1 - count-one SHL, defined flags

```asm
.code
main PROC
    mov al, 80h
    shl al, 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    00000000h / 0
EFLAGS 00000841h / 2113
```

Expected flags:

```text
CF = 1
ZF = 1
SF = 0
OF = 1
```

Expected Memory Changes:

```text
No memory changes.
```

### Manual program 2 - SAL alias with CL count and warning

```asm
.code
main PROC
    mov ecx, 00000102h
    mov eax, 00000003h
    sal eax, cl
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 5, column 5, byte offset 66, span length 11: SAL count 2 has effective count 2 for a 32-bit destination. CF, ZF, and SF were updated from the result. OF is architecturally undefined because the effective count is greater than 1. The simulator preserved OF deterministically.
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    0000000Ch / 12
ECX    00000102h / 258
EFLAGS 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

### Manual program 3 - effective count zero from immediate 32

```asm
.code
main PROC
    stc
    mov eax, 12345678h
    shl eax, 32
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    12345678h / 305419896
EFLAGS 00000001h / 1
```

Expected flags:

```text
CF = 1
ZF = 0
SF = 0
OF = 0
```

Expected Memory Changes:

```text
No memory changes.
```

### Manual program 4 - writable memory read-modify-write

```asm
.data
value DWORD 40000000h
.code
main PROC
    mov esi, OFFSET value
    shl DWORD PTR [esi], 1
    mov eax, value
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    80000000h / 2147483648
ESI    00500000h / 5242880
EFLAGS 00000880h / 2176
```

Expected flags:

```text
CF = 0
ZF = 0
SF = 1
OF = 1
```

Expected Memory Changes:

```text
value: 40000000h / 1073741824 -> 80000000h / 2147483648
```

### Manual program 5 - ambiguous memory width diagnostic

```asm
.code
main PROC
    mov esi, 0
    shl [esi], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 4, column 9, byte offset 39, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Expected result:

```text
No execution.
No register state available.
No memory changes.
Program Console empty.
```

### Manual program 6 - invalid count register diagnostic

```asm
.code
main PROC
    shl eax, ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 3, column 14, byte offset 29, span length 3: SHL count must be an immediate byte count or CL.
```

Expected result:

```text
No execution.
No register state available.
No memory changes.
Program Console empty.
```

### Manual program 7 - undefined CF/OF warning for byte-width count equal to width

```asm
.code
main PROC
    mov al, 01h
    shl al, 8
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 4, column 5, byte offset 36, span length 9: SHL count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    00000000h / 0
EFLAGS 00000040h / 64
```

Expected flags:

```text
CF = 0
ZF = 1
SF = 0
OF = 0
```

Expected Memory Changes:

```text
No memory changes.
```

### Strict-mode local check

Use Manual program 7 as `program.asm` and run:

```cmd
set MASM32_DIAGNOSTIC_SHIFT_VALIDATION=strict
build\tests\diagnostic_json_producer.exe program.asm
set MASM32_DIAGNOSTIC_SHIFT_VALIDATION=
```

Expected JSON behavior:

```text
"ok":false
"status":"execution-error"
"instructionCount":1
"kind":"runtime-error"
"code":"undefined-shift-flag"
```

Expected strict-mode message for CRLF `program.asm`:

```text
[runtime-error] undefined-shift-flag line 4, column 5, byte offset 39, span length 9: SHL count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
```

## 12. Compliance review summary

First compliance review checked:

- scope control;
- completeness against Phase 46 requirements;
- C99-only core policy;
- Doxygen/file-header requirements;
- structured diagnostics and rendered messages;
- test coverage;
- documentation updates;
- line-ending/noisy-diff quality.

Issues found and fixed:

- Several edited files had been converted from the repository's CRLF line-ending style to LF, creating noisy full-file diffs.

Fixes applied:

- Restored CRLF line endings for changed files that previously used CRLF in the Milestone 45 base.
- Reran the full test suite.

Result:

```text
All implemented milestone tests passed.
```

Verdict:

```text
complete
```

## 13. Re-review summary

Second compliance review checked:

- Phase 46 guide/spec requirements again;
- changed code and docs;
- stale comments;
- rendered-message quality;
- accidental future-milestone behavior;
- default sample and supported syntax documentation.

Additional issues found and fixed:

- `docs/SUPPORTED_SYNTAX.md` had Phase 46 metadata notes but still omitted `shl` and `sal` from the executable-instruction list.
- `README.md` executable-instruction summary still stopped at `not`.
- `web/index.html` file-header/default sample text still demonstrated Milestone 45 `not` behavior while page metadata said Milestone 46.

Fixes applied:

- Added `shl` and `sal` to supported executable-instruction documentation.
- Added a `shl`/`sal` behavior paragraph.
- Updated README current-scope text.
- Updated browser shell file-header comment and default sample.

Result:

```text
All implemented milestone tests passed.
```

Verdict:

```text
complete
```

## 14. User-test follow-up summary

User manual testing found:

- Phase 46 behavior and outputs matched the implementation.
- The default sample and warning cases correctly emitted `undefined-shift-flag` warnings.
- Comparison against genuine MASM/Irvine32 `DumpRegs` showed flag differences in undefined-flag cases.

Diagnosis:

- The differences were expected where x86 defines flags as architecturally undefined.
- MASM assembles the instructions; the CPU determines runtime flag behavior.
- The simulator's deterministic policy preserves architecturally undefined modeled flags and warns by default.
- `shl eax, 32` is count-zero after count masking and should not affect flags. Differences in real `DumpRegs` were caused by pre-existing flags not fully initialized before `stc`.
- `shl al, 8` has undefined `CF` and `OF`; real hardware output should not be treated as portable expected behavior.

User then noted the warning wording was too vague.

Diagnostic-quality fix applied:

- Replaced generic wording with flag-specific wording.
- Multi-bit below-width shifts now say `CF`, `ZF`, and `SF` were updated and `OF` was preserved.
- Count-at-least-width shifts now say `ZF` and `SF` were updated and `CF`/`OF` were preserved.
- Kept diagnostic code stable as `undefined-shift-flag`.
- Updated exact rendered-message tests and source-run assertions.

User retested updated browser output:

- Default program warning matched new flag-specific wording.
- `sal eax, cl` with `CL=2` matched expected warning wording.
- `shl al, 8` matched expected warning wording.

Final gap check:

- Found stale NOT regression comments/assertion labels that said `Phase 46 NOT` even though NOT was a Milestone 45 feature being regression-tested under current Phase 46 metadata.
- Cleaned those test labels/comments.
- Reran the aggregate test suite.
- Result: all implemented milestone tests passed.

## 15. Known limitations

- This container cannot rebuild `web/dist` because Emscripten is not installed.
- Served website behavior requires a local Wasm rebuild in an Emscripten-enabled environment.
- Strict undefined-shift validation is available through the native/Wasm test/API configuration path but not through a browser settings UI.
- Undefined x86 flag behavior is deterministic in the simulator by policy; real hardware may display different values for undefined flags.
- PF and AF remain unmodeled.
- `shr`, `sar`, rotates, control flow, stack behavior, and broader Irvine32 routines remain future milestones.
- QWORD/SQWORD executable memory operations remain unsupported in MASM32 Educational Mode.

## 16. Next recommended milestone

Next recommended milestone:

```text
Phase 47 - SHR
```

Reason:

- Phase 46 implemented left shifts only.
- The guide sequence continues with the logical right-shift instruction.
- Future Phase 47 should reuse the Phase 46 shift-count compatibility policy, warning/strict validation structure, source-span diagnostic handling, and flag-specific undefined-modeled-flag wording while implementing SHR-specific result and flag behavior.

## 17. Changed-files ZIP/package produced

Changed-files packages produced during Milestone 46:

```text
/mnt/data/milestone46_changed_files.zip
/mnt/data/milestone46_compliance_review_changed_files.zip
/mnt/data/milestone46_second_review_changed_files.zip
/mnt/data/milestone46_diagnostic_quality_fix_changed_files.zip
/mnt/data/milestone46_final_gap_check_changed_files.zip
```

Package meanings:

- `milestone46_changed_files.zip`: initial Phase 46 implementation package.
- `milestone46_compliance_review_changed_files.zip`: package after first compliance review and line-ending cleanup.
- `milestone46_second_review_changed_files.zip`: package after second review documentation/sample fixes.
- `milestone46_diagnostic_quality_fix_changed_files.zip`: package after user-test diagnostic wording improvement.
- `milestone46_final_gap_check_changed_files.zip`: final cleanup package for stale test-label/comment fixes.

Recommended next repository archive name:

```text
Latest_repository_state_milestone_46.zip
```

This archive should be created from the final Milestone 46 repository state after applying all cumulative Phase 46 packages/fixes.
