# Milestone 55 report - Two- and Three-Operand IMUL Forms

## 1. Milestone title and scope

Milestone 55 implements **Phase 55 - Two- and Three-Operand IMUL Forms** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added executable runtime support for selected non-accumulator signed `imul` forms.
- Preserved all existing Phase 54 one-operand signed `imul` accumulator behavior.
- Supported 16-bit and 32-bit register destinations.
- Supported 16-bit and 32-bit register sources.
- Supported 16-bit and 32-bit memory sources where memory width is explicit or inferable through existing memory-width rules.
- Supported three-operand signed immediate forms with 16-bit and 32-bit destination widths.
- Validated three-operand immediates against the signed destination operand width.
- Stored only the low destination-width result into the destination register for Phase 55 forms.
- Preserved source registers and source memory.
- Routed memory-source reads through checked VM memory helpers and existing planned-read validation.
- Preserved deterministic `ZF` and `SF` values for Phase 55 `imul` forms.
- Updated `CF` and `OF` based on signed truncation/overflow.
- Preserved no-partial-mutation behavior for failed memory reads and strict uninitialized-read stops.
- Rejected Phase 55 non-goal forms with structured, source-located diagnostics.
- Updated source-run and browser metadata to report Phase 55.
- Updated documentation, status text, protocol tests, parser tests, executor tests, source-run tests, and rendered Simulator Messages tests.

The implementation stayed within the target milestone boundary. It did not add division, unsigned multiply changes, 8-bit explicit-destination `imul`, memory-destination `imul`, `imul reg, imm`, control flow, stack/procedure behavior, executable QWORD/SQWORD memory operations, scaled-index addressing, or broader Irvine32 behavior.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 54 report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_54.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 55 is the only target runtime milestone for this implementation session.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- All mandatory memory safety remains routed through checked VM memory helpers.
- User-visible diagnostics require structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

### 3.1 Accepted syntax implemented

Two-operand forms:

```asm
imul reg16, reg16
imul reg32, reg32
imul reg16, mem16
imul reg32, mem32
```

Three-operand forms:

```asm
imul reg16, reg16, imm
imul reg32, reg32, imm
imul reg16, mem16, imm
imul reg32, mem32, imm
```

Representative accepted forms include:

```asm
imul ax, bx
imul eax, ebx
imul ax, WORD PTR [esi]
imul eax, DWORD PTR [esi]
imul ax, bx, -5
imul eax, ebx, -5
imul ax, WORD PTR [esi], -5
imul eax, DWORD PTR [esi], -5
imul eax, factor
imul eax, factors[4]
imul eax, SDWORD PTR [esi]
```

Signed PTR aliases are accepted by width for memory sources where executable in MASM32 Educational Mode:

```asm
imul ax, SWORD PTR [esi]
imul eax, SDWORD PTR [esi]
```

Case-insensitive mnemonic matching remains preserved through the existing instruction policy:

```asm
IMUL eax, ebx
Imul eax, ebx, -5
imul eax, ebx
```

### 3.2 Rejected syntax implemented or preserved

Phase 55 intentionally rejects:

```asm
imul al, bl
imul mem, reg
imul reg, imm
imul reg, reg, reg
imul eax, ebx, ecx
imul eax, ebx, 5, 6
imul QWORD PTR q
imul SQWORD PTR q
```

One-operand `imul reg` remains accepted as the Phase 54 accumulator form. The rejection of `imul reg, imm` applies only to the two-operand immediate form.

Diagnostic behavior:

- `imul al, bl` reports `invalid-instruction-operands` because two-/three-operand IMUL destinations must be 16-bit or 32-bit registers.
- `imul DWORD PTR [esi], eax` reports `invalid-instruction-operands` because Phase 55 requires a register destination.
- `imul eax, 5` reports `invalid-instruction-operands` and explains that `imul reg, imm` is not supported in Phase 55.
- `imul eax, ebx, ecx` reports `invalid-instruction-operands` because the third operand must be an immediate constant expression.
- `imul eax, ebx, 5, 6` reports `invalid-instruction-operands` because Phase 55 forms take exactly three operands.
- Out-of-range immediates report `immediate-out-of-range` and point at the immediate expression.
- `imul QWORD PTR q` and `imul SQWORD PTR q` preserve the existing executable-64-bit memory-operation rejection with `unsupported-ptr-width`.

### 3.3 Runtime semantics implemented

For two-operand forms:

```text
dest = low_width_bits(signed(dest) * signed(source))
```

For three-operand forms:

```text
dest = low_width_bits(signed(source) * signed(immediate))
```

Rules:

- The destination is always a 16-bit or 32-bit register.
- The source is a register or memory operand of matching width.
- Three-operand immediates are interpreted at the signed destination width.
- Only the destination register is written.
- Source registers are not modified.
- Source memory is read but not written.
- Memory-source forms do not create memory-change rows.
- Memory-source reads route through checked VM memory helpers and existing planned-read validation.
- Failed memory reads stop execution before destination/flag mutation.
- Strict uninitialized-read mode stops before consuming uninitialized-origin bytes and before destination/flag mutation.

### 3.4 Flag behavior implemented

For 16-bit and 32-bit Phase 55 forms:

- If the full signed product is exactly representable as the sign extension of the low destination-width result:
  - `CF = 0`
  - `OF = 0`
- Otherwise:
  - `CF = 1`
  - `OF = 1`
- `ZF` is preserved deterministically.
- `SF` is preserved deterministically.
- Other x86 flags remain unmodeled.

Acceptance example:

```asm
.code
main PROC
    mov eax, 3
    mov ebx, 4
    imul eax, ebx
main ENDP
END main
```

Expected final behavior:

```text
[info] execution-complete: Execution completed successfully.
EAX = 0000000Ch / u: 12 / s: 12
EBX = 00000004h / u: 4 / s: 4
CF = 0
OF = 0
```

Signed immediate example:

```asm
.code
main PROC
    mov ebx, 4
    imul eax, ebx, -5
main ENDP
END main
```

Expected final behavior:

```text
EAX = FFFFFFECh / u: 4294967276 / s: -20
EBX = 00000004h / u: 4 / s: 4
CF = 0
OF = 0
```

Overflow example:

```asm
.code
main PROC
    mov eax, 2147483647
    mov ebx, 2
    imul eax, ebx
main ENDP
END main
```

Expected final behavior:

```text
EAX = FFFFFFFEh / u: 4294967294 / s: -2
EFLAGS = 00000801h / 2049
CF = 1
OF = 1
```

### 3.5 Immediate boundary behavior implemented

Accepted 32-bit boundaries:

```asm
imul eax, ebx, -2147483648
imul ecx, ebx, 2147483647
```

Accepted 16-bit boundaries:

```asm
imul ax, bx, -32768
imul cx, bx, 32767
```

Rejected out-of-range immediates:

```asm
imul eax, ebx, -2147483649
imul eax, ebx, 2147483648
imul ax, bx, -32769
imul ax, bx, 32768
```

Expected diagnostic code:

```text
immediate-out-of-range
```

### 3.6 Metadata and browser updates

Implemented metadata/status updates:

- Source-run JSON phase now reports `55`.
- Browser protocol readiness metadata now reports implemented phase `55`.
- Default sample/status text was updated to demonstrate Phase 55 `imul` behavior.
- Aggregate test output now reports Phase 55 executor/source-run coverage.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 55:

- `mul` changes.
- `div`.
- `idiv`.
- `imul reg, imm` two-operand immediate form.
- 8-bit explicit-destination `imul`, such as `imul al, bl`.
- Memory-destination `imul`.
- Register/register/register three-operand `imul`.
- Executable QWORD/SQWORD memory operations.
- Extended 32-bit / 64-bit register behavior.
- Scaled-index addressing.
- Labels, `jmp`, conditional jumps, `loop`, `SETcc`, or `CMOVcc`.
- Stack/procedure behavior, `push`, `pop`, `call`, `ret`, `leave`, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`.
- Irvine32 routine bodies beyond existing `exit` behavior.
- Program Console input/output routines.
- Macro expansion or real include loading.
- Windows API execution.
- PE loading, object linking, host filesystem behavior, or arbitrary JavaScript execution.
- New diagnostic policy families or browser settings.

Next planned instruction family is **Phase 56 - Unsigned DIV**.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 55 two-operand `imul` should reuse the existing `VM_IR_OPCODE_IMUL` when it has an explicit register destination.
- **Reason:** The mnemonic and signed multiply semantics are the same; the existing opcode could distinguish one-operand accumulator behavior from explicit-destination behavior by operand shape.
- **Risk:** The executor contains an opcode path with two related but distinct behaviors.
- **How to change later:** A later refactor can split one-operand and explicit-destination IMUL into separate internal helpers or opcodes while preserving public behavior and tests.

### Assumption 2

- **Assumption:** Phase 55 three-operand `imul` should use a new narrow IR opcode, `VM_IR_OPCODE_IMUL_IMMEDIATE`.
- **Reason:** The existing `VmIrInstruction` has two operand slots, and adding a third general operand would cause a broad IR rewrite outside the milestone. Storing the parsed signed immediate on the destination operand keeps the change targeted and reviewable.
- **Risk:** The immediate storage convention is specialized.
- **How to change later:** A future IR expansion can add a third operand field and migrate this opcode without changing source-visible semantics.

### Assumption 3

- **Assumption:** Signed PTR aliases such as `SWORD PTR` and `SDWORD PTR` should be accepted for Phase 55 memory sources by width.
- **Reason:** The stable memory-width policy maps signed PTR aliases to their unsigned widths, and Phase 54 one-operand signed `imul` already accepted signed PTR aliases.
- **Risk:** The Phase 55 guide examples use generic `mem16` and `mem32` rather than listing every accepted spelling.
- **How to change later:** If the guide is revised to narrow accepted spellings, parser validation can be narrowed while preserving width-resolution helpers.

### Assumption 4

- **Assumption:** `imul reg, imm` should remain rejected.
- **Reason:** The Phase 55 guide explicitly lists `imul reg, imm` under rejected syntax, even though real assemblers may support related forms.
- **Risk:** Users familiar with full x86/MASM may expect this form to execute.
- **How to change later:** Add it in a later guide-owned phase with explicit syntax, tests, and diagnostics.

### Assumption 5

- **Assumption:** Immediate range should be checked against signed operation width, not against machine-code encoding width.
- **Reason:** Phase 55 explicitly says not to expose `imm8` versus `imm16/imm32` encoding distinctions in user diagnostics.
- **Risk:** This abstracts away some real assembler encoding behavior.
- **How to change later:** A future machine-code-education phase could add optional encoding notes without changing execution semantics.

### Assumption 6

- **Assumption:** Browser/source-run metadata should advance to `55`, including correcting the stale browser protocol constant that still reported `53` before this milestone.
- **Reason:** Prior milestones update source-run and browser metadata, and the Prompt 2 repository verification found the stale constant as a non-blocking metadata inconsistency.
- **Risk:** Browser protocol/status files are touched even though the primary behavior is in parser/executor code.
- **How to change later:** A future metadata cleanup phase can centralize phase reporting to avoid duplicate constants.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and deferral references reviewed before and during implementation:

1. `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
   - Phase 54 wording said two- and three-operand `imul` forms were deferred to Phase 55.
   - Classification: target-owned.

2. `docs/SUPPORTED_SYNTAX.md`
   - Syntax reference said `imul` supported only the one-operand signed accumulator form and deferred two-/three-operand forms to Phase 55.
   - Classification: target-owned.

3. `README.md`
   - Current limitations/status text said two- and three-operand signed multiplication remained deferred.
   - Classification: target-owned.

4. `src/parser/parser.c`
   - Parser emitted a deferral diagnostic for two-/three-operand `imul` forms.
   - Classification: target-owned.

5. `tests/core/test_parser.c`
   - Parser tests expected accepted Phase 55 forms to fail with `unsupported-instruction-form`.
   - Classification: target-owned.

6. `tests/core/test_wasm_source_run.c`
   - Source-run tests expected `imul eax, ebx` and related forms to fail before Phase 55.
   - Classification: target-owned.

7. `tests/web/test_diagnostic_rendering.mjs`
   - Rendered diagnostic tests expected exact Phase 55 deferral wording for accepted forms.
   - Classification: target-owned.

8. `src/wasm/wasm_api.c`
   - TODO note says future memory-reading opcodes must be added to planned-read handling when implemented.
   - Classification before source inspection: unclear.
   - Final disposition: no longer a Phase 55 gap because `VM_IR_OPCODE_IMUL_IMMEDIATE` was added to the planned-read/access handling.

Additional broader TODO-style notes for future phases were reviewed and left untouched where they referred to later features such as QWORD/SQWORD execution, `div`, `idiv`, control flow, stack/procedure behavior, Irvine32 expansion, macros, WinAPI, PE loading, and linking.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

Resolved:

- Parser deferral behavior for accepted Phase 55 `imul` forms.
- Parser/source-run/rendered tests that expected accepted Phase 55 forms to fail.
- README and supported-syntax text that listed two-/three-operand signed multiplication as still deferred.
- Phase 55 syntax/status documentation.
- Planned-read handling for the new `VM_IR_OPCODE_IMUL_IMMEDIATE` opcode.

### Future-owned TODO-style notes intentionally preserved

Preserved:

- Future executable QWORD/SQWORD memory operation notes.
- Future `div` and `idiv` notes.
- Future control-flow notes.
- Future stack/procedure behavior notes.
- Future Irvine32 expansion notes.
- Future macro/WinAPI/PE/linker notes.
- General future memory-reading opcode integration TODO in `src/wasm/wasm_api.c`, now still valid for later opcodes.

### Stale or contradicted TODO-style notes corrected

Corrected:

- Stale Phase 55 deferral wording in README and supported syntax was removed during second review.
- No stale Phase 55 TODO-style notes remained after the final gap check.

### Unresolved TODO-related risks

No unresolved target-owned TODO-related risks remain.

Remaining TODO-style risks are future-scope only and are documented as deferred features, not Phase 55 requirements.

## 8. Design summary

### Parser design

The parser now distinguishes three IMUL families:

1. One-operand accumulator IMUL from Phase 54.
2. Two-operand explicit-destination IMUL from Phase 55.
3. Three-operand explicit-destination IMUL with signed immediate from Phase 55.

Validation rules:

- One operand keeps existing Phase 54 handling.
- Two operands require a 16-bit or 32-bit register destination and a same-width register or memory source.
- Three operands require a 16-bit or 32-bit register destination, a same-width register or memory source, and an immediate constant expression fitting the signed destination width.
- Memory destinations are rejected.
- 8-bit explicit-destination forms are rejected.
- `imul reg, imm` is rejected with an explicit Phase 55 diagnostic.
- Extra operands are rejected with source-located diagnostics.
- Immediate out-of-range diagnostics point at the immediate expression.

### IR design

Implemented IR behavior:

- `VM_IR_OPCODE_IMUL` continues to represent one-operand accumulator IMUL when there is no explicit destination.
- `VM_IR_OPCODE_IMUL` also represents two-operand explicit-destination IMUL when operand 0 is a register destination and operand 1 is the source.
- `VM_IR_OPCODE_IMUL_IMMEDIATE` represents three-operand explicit-destination IMUL.
- The three-operand immediate is stored as operand-width two's-complement bits on the destination operand's `immediate` field to avoid widening the global IR structure.
- Opcode-name helpers and tests were updated for the new opcode.

### Executor design

The executor now contains shared explicit-destination signed IMUL helpers that:

- read destination/source operands at the selected width;
- sign-interpret operands at the selected width;
- compute the signed product;
- store the low destination-width result into the destination register;
- set `CF`/`OF` based on signed truncation;
- preserve `ZF`/`SF` deterministically;
- snapshot/restore CPU state for failed memory-source reads or writeback failures;
- avoid memory-change rows for memory-source reads.

### Source-run/Wasm design

The Wasm/source-run planned-read path was updated so the new `VM_IR_OPCODE_IMUL_IMMEDIATE` receives the same memory-read validation behavior as existing memory-reading instructions.

This preserves:

- default uninitialized-read warnings;
- strict uninitialized-read stop-before-mutation behavior;
- section/object validation policy behavior;
- no memory-change rows for reads.

### Documentation and UI/status design

Documentation and metadata were updated to show Phase 55 as implemented. The default sample demonstrates Phase 55 IMUL behavior. The browser protocol phase constant was corrected to `55`.

## 9. Files changed

Changed files in the final gap-checked package:

```text
README.md
docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md
docs/SUPPORTED_SYNTAX.md
docs/TESTING_GUIDE.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

## 10. Tests added

### Native executor tests

Added/updated tests for:

- two-operand 32-bit register/register `imul`;
- three-operand signed-immediate `imul`;
- 16-bit alias destination writeback;
- memory-source reads without memory-change rows;
- overflow/truncation setting `CF`/`OF`;
- no-overflow clearing `CF`/`OF`;
- preservation of `ZF` and `SF`;
- invalid memory-source no-mutation behavior.

### Parser tests

Added/updated tests for accepted forms:

```asm
imul ax, bx
imul eax, ebx
imul ax, WORD PTR [esi]
imul eax, DWORD PTR [esi]
imul ax, bx, -5
imul eax, ebx, -5
imul ax, WORD PTR [esi], -5
imul eax, DWORD PTR [esi], -5
imul eax, factor
imul eax, factors[4]
imul eax, SDWORD PTR [esi]
```

Added/updated tests for rejected forms:

```asm
imul al, bl
imul BYTE PTR [esi], al
imul value, eax
imul eax, 5
imul eax, ebx, ecx
imul eax, ebx, 5, 6
imul
```

Parser tests also verify source location data for selected diagnostics.

### Source-run tests

Added/updated tests for:

- two-operand success;
- three-operand signed-immediate success;
- direct symbol memory source;
- symbol-offset memory source;
- explicit PTR memory source;
- `.CONST` memory source read behavior;
- memory-source no memory-change behavior;
- overflow and no-overflow flag behavior;
- 16-bit destination behavior;
- accepted 32-bit immediate boundaries;
- accepted 16-bit immediate boundaries;
- rejected out-of-range 32-bit and 16-bit immediates;
- rejected `imul reg, imm`;
- rejected memory destination;
- rejected extra operands;
- strict uninitialized-read stop-before-mutation behavior;
- Phase 55 metadata.

### Rendered Simulator Messages tests

Added/updated rendered-message coverage for:

- rejected `imul reg, imm`;
- immediate out-of-range diagnostics;
- still-invalid IMUL forms after Phase 55.

### Protocol/static tests

Updated tests for:

- browser protocol implemented phase `55`;
- metadata/status consistency;
- aggregate runner reporting through Milestone 55.

### Regression tests

Preserved and extended coverage for:

- Phase 54 one-operand IMUL behavior;
- unsigned `mul` behavior;
- QWORD/SQWORD executable memory rejection;
- signed PTR alias width handling;
- default uninitialized-read warnings;
- strict uninitialized-read stop-before-mutation behavior;
- Program Console and Simulator Messages separation.

## 11. Commands used to test

Primary aggregate test command:

```bash
cd /mnt/data/repo_m55_review
python3 scripts/run_tests.py
```

The aggregate command compiles native C tests with:

```text
cc -std=c99 -Wall -Wextra -Werror -pedantic
```

and runs Node-based web/protocol/formatter/rendered-diagnostic tests.

The command was run after implementation, after first compliance fixes, after second review fixes, after final gap-check fixes, and again while preparing this report.

## 12. Pass/fail results

Final observed result:

```text
All implemented milestone tests passed.
```

Relevant final output lines:

```text
Executor tests through Milestone 55 passed.
Source execution tests through Phase 55 IMUL coverage passed.
Milestone structure tests passed.
Phase 51 browser manual smoke after rebuilding Wasm: not run; emcc is unavailable in this environment.
All implemented milestone tests passed.
```

Environment limitation:

- `emcc` is unavailable in this environment, so a rebuilt Wasm/browser manual smoke test could not be run here.
- Browser testing is expected after rebuilding Wasm in an Emscripten-capable environment.

## 13. Manual/browser testing guidance and expected outputs

Phase 55 is website-testable after rebuilding the Wasm artifact with Emscripten.

### Browser setup

On Windows, from the project root in an Emscripten-capable environment:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the served website, paste each program into the editor, click **Run**, and compare Simulator Messages, register output, and memory changes.

### Manual Program 1 - two-operand register IMUL

```asm
.code
main PROC
    mov eax, 3
    mov ebx, 4
    imul eax, ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX    | 0000000Ch / u: 12         / s:  12
EBX    | 00000004h / u: 4          / s:  4
EFLAGS | 00000000h / 0
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `imul eax, ebx` is rejected.
- `EBX` changes.
- `EAX` is not `12`.
- `CF` or `OF` is set.

### Manual Program 2 - three-operand signed immediate

```asm
.code
main PROC
    mov ebx, 4
    imul eax, ebx, -5
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX    | FFFFFFECh / u: 4294967276 / s: -20
EBX    | 00000004h / u: 4          / s:  4
EFLAGS | 00000000h / 0
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- Negative immediate is rejected.
- `EAX` is not `FFFFFFECh`.
- `EBX` is modified.

### Manual Program 3 - signed memory source IMUL

```asm
.data
factor SDWORD -3
.code
main PROC
    mov eax, 7
    imul eax, factor
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX    | FFFFFFEBh / u: 4294967275 / s: -21
EFLAGS | 00000000h / 0
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `factor` is treated as unsigned.
- Memory-source `imul` writes to memory.
- Memory changes appear.

### Manual Program 4 - overflow/truncation flags

```asm
.code
main PROC
    mov eax, 2147483647
    mov ebx, 2
    imul eax, ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX    | FFFFFFFEh / u: 4294967294 / s: -2
EBX    | 00000002h / u: 2          / s:  2
EFLAGS | 00000801h / 2049
```

`00000801h` means `CF=1` and `OF=1`.

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `EFLAGS` remains `00000000h`.
- Only one of `CF`/`OF` is set.
- `EAX` is not the low 32-bit product.

### Manual Program 5 - immediate boundary acceptance

```asm
.code
main PROC
    mov ebx, 1
    imul eax, ebx, -2147483648
    imul ecx, ebx, 2147483647
    mov bx, 1
    imul dx, bx, -32768
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX    | 80000000h / u: 2147483648 / s: -2147483648
EBX    | 00000001h / u: 1          / s:  1
ECX    | 7FFFFFFFh / u: 2147483647 / s:  2147483647
EDX    | 00008000h / u: 32768      / s:  32768
  DX   |     8000h / u: 32768      / s: -32768
EFLAGS | 00000000h / 0
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- Signed boundary immediates are rejected.
- `DX` is not `8000h`.
- `CF` or `OF` is set for these boundary products.

### Manual Program 6 - default uninitialized-read warning still executes

```asm
.DATA?
factor SDWORD ?
.code
main PROC
    mov eax, 5
    imul eax, factor
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] uninitialized-read line 6: Memory read range 00500000h..00500003h reads 4 bytes from factor + 0; 4 of those bytes still originated from uninitialized storage.
[info] execution-complete: Execution completed successfully.
```

Expected key register:

```text
EAX    | 00000000h / u: 0          / s:  0
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- No warning appears in default settings.
- Execution stops in warning mode.
- `imul` writes to memory.

### Manual Program 7 - rejected `imul reg, imm`

```asm
.code
main PROC
    imul eax, 5
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 3, column 15, byte offset 30, span length 1: IMUL reg, imm is not supported in Phase 55; use a register or memory source, or the three-operand reg, r/m, imm form.
```

Expected registers:

```text
No register state available.
```

Expected memory changes:

```text
No memory changes.
```

Regression sign:

- `imul eax, 5` executes.

### Manual Program 8 - rejected 8-bit explicit-destination IMUL

```asm
.code
main PROC
    imul al, bl
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 3, column 10, byte offset 25, span length 2: IMUL two- and three-operand destinations must be 16-bit or 32-bit registers.
```

Expected registers:

```text
No register state available.
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `imul al, bl` executes.
- Diagnostic is vague or lacks source location.

### Manual Program 9 - rejected out-of-range immediate

```asm
.code
main PROC
    mov ebx, 1
    imul eax, ebx, 2147483648
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] immediate-out-of-range line 4, column 20, byte offset 50, span length 10: IMUL immediate value does not fit the signed destination operand width.
```

Expected registers:

```text
No register state available.
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- Program executes.
- Immediate is silently truncated.
- Diagnostic does not point at the immediate.

### Windows CMD local testing

From the project root:

```cmd
python scripts\run_tests.py
```

Expected final line:

```text
All implemented milestone tests passed.
```

For individual source testing, save a source file as `program.asm` in the project root and run:

```cmd
build\tests\diagnostic_json_producer.exe program.asm
```

For a successful Phase 55 source, expected JSON includes:

```json
"phase": 55
"ok": true
"status": "ok"
"message": "Execution completed successfully."
```

For an invalid `imul eax, 5` source, expected JSON includes:

```json
"phase": 55
"ok": false
"status": "parse-error"
"code": "invalid-instruction-operands"
"message": "IMUL reg, imm is not supported in Phase 55; use a register or memory source, or the three-operand reg, r/m, imm form."
"line": 3
"column": 15
"byteOffset": 30
"spanLength": 1
```

## 14. Compliance review summary

A first compliance review was performed after implementation.

Findings:

- The initial implementation covered out-of-range immediate rejection but did not explicitly test accepted immediate boundary values required by the guide.
- A parser comment/test expectation mismatch existed for how 16-bit negative immediates were represented internally.

Fixes applied:

- Added accepted 32-bit immediate-boundary source-run tests for `-2147483648` and `2147483647`.
- Added accepted 16-bit immediate-boundary source-run tests for `-32768` and `32767`.
- Added below-range 32-bit immediate rejection coverage.
- Updated parser immediate encoding so 16-bit immediates are stored as operand-width two's-complement bits.
- Updated parser IR expectations to match the corrected representation.

Result:

```text
All implemented milestone tests passed.
```

## 15. Re-review summary

A second compliance review and final gap check were performed.

Second review findings:

- `README.md` and `docs/SUPPORTED_SYNTAX.md` still had stale deferred-feature wording that listed two- and three-operand signed multiplication as deferred.

Second review fixes:

- Removed stale Phase 55 deferral wording from README and supported syntax.
- Re-scanned changed docs/source/tests for Phase 55 deferral wording.

Final gap-check findings:

- Extra-operand coverage for a three-operand Phase 55 form was missing.
- Source-run memory-destination rejection coverage was missing, although parser coverage existed.

Final gap-check fixes:

- Added parser coverage for `imul eax, ebx, 5, 6`.
- Added source-run coverage for `imul DWORD PTR [esi], eax` memory-destination rejection.
- Added source-run coverage for `imul eax, ebx, 5, 6` extra-operand rejection.

Final result:

```text
All implemented milestone tests passed.
```

Final verdict:

- Phase 55 requirements, acceptance criteria, diagnostics, docs, tests, and TODO disposition are covered.
- No accidental future milestone behavior was found.
- No stale TODO-style note was introduced.
- No target-owned TODO-style note remains unresolved.

## 16. User-test follow-up summary, if any

No user-test follow-up changes were requested after manual testing instructions.

Manual testing guidance was provided for:

- accepted two-operand register IMUL;
- accepted three-operand signed-immediate IMUL;
- accepted signed memory-source IMUL;
- overflow/truncation flag behavior;
- immediate boundary acceptance;
- default uninitialized-read warning behavior;
- rejected `imul reg, imm`;
- rejected 8-bit explicit-destination IMUL;
- rejected out-of-range immediate.

The browser portion requires rebuilding Wasm with Emscripten before testing on the served website.

## 17. Known limitations

Known limitations after Milestone 55:

- `imul reg, imm` remains unsupported by design for Phase 55.
- 8-bit explicit-destination `imul` remains unsupported.
- Memory-destination `imul` remains unsupported.
- Register/register/register three-operand `imul` remains unsupported.
- Executable QWORD/SQWORD memory operations remain deferred.
- `div` and `idiv` are not implemented.
- Control flow is not implemented.
- Stack/procedure behavior is not implemented.
- Irvine32 routine bodies beyond existing behavior are not implemented.
- Macro expansion and real include loading are not implemented.
- Windows API simulation, PE loading, and object linking are not implemented.
- Scaled-index addressing is not implemented.
- Wasm/browser manual smoke testing was not run in this environment because `emcc` is unavailable.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 56 - Unsigned DIV
```

Recommended implementation focus for Phase 56:

- Implement unsigned accumulator division only as specified by the guide.
- Preserve Phase 55 IMUL behavior.
- Add divide-by-zero and quotient-overflow diagnostics with structured and rendered-message tests.
- Continue to reject future signed division, control flow, stack/procedure, Irvine32 expansion, and QWORD/SQWORD execution unless Phase 56 explicitly requires otherwise.

## 19. Changed-files ZIP/package produced

Final changed-files package produced:

```text
/mnt/data/milestone55_final_gap_changed_files.zip
```

Package contents preserve repository structure and include the final gap-checked Phase 55 changes.

The package does not include generated build artifacts. Existing `web/dist` artifacts in the repository remain stale until rebuilt with Emscripten in a browser/Wasm environment.
