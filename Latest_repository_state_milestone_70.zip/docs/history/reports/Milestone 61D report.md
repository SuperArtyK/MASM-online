# Milestone 61D report - Source-Run Capacity Documentation and Diagnostic Hardening

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 61D - Source-Run Capacity Documentation and Diagnostic Hardening
```

Repository/archive milestone after this work:

```text
Phase 61D - Source-Run Capacity Documentation and Diagnostic Hardening
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 61 - Direct JMP Runtime Execution
```

Status interpretation:

The repository/archive milestone is newer than the runtime/source-run MASM behavior phase because Phase 61D is documentation, static-check, and regression-test hardening for parser/source-run capacity diagnostics. Phase 61D does not add MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser controls, browser layout, browser interaction behavior, new diagnostic codes, new diagnostic JSON fields, new rendered Simulator Messages categories, debugger stepping, breakpoint behavior, editor source navigation, current-instruction highlighting, CodeMirror gutter behavior, or branch-target editor highlighting.

Scope implemented:

- Documented parser/source-run capacity limits as distinct from runtime instruction-count limits.
- Hardened source-run regression coverage for representative fixed-capacity failures.
- Added rendered Simulator Messages coverage for a stable capacity diagnostic.
- Added static documentation/status checks for Phase 61D capacity-limit wording and status hygiene.
- Preserved Phase 62 as the next ordinary runtime instruction milestone.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_61D.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 61C report.md`
- `Project Audit and Milestones.txt`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_61C.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, status-surface hygiene, and broad product constraints.
- The implementation guide owns Phase 61D numbering, exact phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or implementation guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or implementation guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

## 3. Exact requirements implemented

### 3.1 Parser/source-run capacity documentation

Updated current documentation to describe parser/source-run capacity limits as fixed simulator limits rather than runtime execution limits.

The documentation now distinguishes at least these categories:

- lexer token capacity;
- parser diagnostic capacity;
- source text buffer capacity;
- lowered IR instruction capacity;
- data symbol capacity;
- code label capacity;
- data image capacity;
- source-run JSON/output capacity where applicable;
- runtime `instructionLimit`;
- memory-region capacity;
- Program Console output limits;
- Simulator Messages output limits;
- worker/browser hard failures.

This prevents capacity failures from being confused with Phase 59/61 runtime instruction-count watchdog behavior.

### 3.2 Repository/runtime status split

Updated repository/current-status documentation to advance repository/archive status to Phase 61D while preserving runtime/source-run MASM behavior at Phase 61.

Current status after this milestone:

```text
Repository/archive milestone:
Phase 61D - Source-Run Capacity Documentation and Diagnostic Hardening

Runtime/source-run MASM behavior phase:
Phase 61 - Direct JMP Runtime Execution
```

### 3.3 Source-run capacity regression tests

Added generated source-run tests for representative simulator-controlled capacity failures:

- token capacity exhaustion;
- source-text capacity exhaustion;
- code-label capacity exhaustion.

The tests assert that these failures remain structured source-run failures rather than generic worker failures or runtime instruction-count watchdog failures.

### 3.4 Rendered Simulator Messages regression coverage

Added a rendered Simulator Messages test for the stable `token-capacity-exceeded` diagnostic.

This verifies that capacity diagnostics appear through Simulator Messages, not Program Console, and remain user-readable.

### 3.5 Static documentation checks

Added static checks in `scripts/run_tests.py` to prove Phase 61D current-status and capacity documentation requirements remain present.

The checks cover:

- repository/archive Phase 61D status;
- runtime/source-run Phase 61 status;
- parser/source-run capacity documentation;
- distinction from runtime `instructionLimit`;
- preservation of Phase 62 as the next ordinary runtime instruction milestone;
- avoidance of broad arbitrary-large-program-support claims.

### 3.6 Compliance cleanup after first review

The first compliance review found and fixed documentation/comment hygiene issues:

- removed duplicated Phase 61C debugger-boundary wording from `docs/SUPPORTED_SYNTAX.md`;
- corrected capitalization in the parser/source-run capacity section;
- updated a stale static-check docstring in `scripts/run_tests.py` from Phase 61C to Phase 61D;
- updated a stale `tests/core/test_wasm_source_run.c` file header from Phase 61A to Phase 61D capacity hardening;
- updated the related static test expected text after documentation cleanup.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 61D:

- Phase 61E reserved-word symbol diagnostics.
- Phase 62 `cmp` register/immediate forms.
- Conditional jumps.
- `loop`, `loope`, `loopne`, `jcxz`, or `jecxz`.
- Indirect jumps.
- Register-target `jmp` execution.
- Memory-target `jmp` execution.
- Immediate-target `jmp` execution.
- Branch-distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Relative branch encoding or real x86 instruction encoding.
- Native x86 execution.
- Stack or procedure execution semantics.
- `call`, `ret`, `leave`, `push`, or `pop`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 callable routines beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Active-time watchdog behavior.
- Wall-clock execution limits.
- Monotonic-clock or fake-clock logic.
- Worker yielding/chunking for responsiveness.
- Stop-button responsiveness.
- Browser UI controls for execution time or capacity limits.
- Dynamic unbounded parser allocation.
- Broad parser/source-run capacity redesign.
- Streaming diagnostics.
- Source paging.
- Large-program support beyond the existing bounded simulator capacities.
- `OPTION NOKEYWORD`.
- General dynamic keyword-table mutation.
- Full MASM macro expansion.

Future work intentionally preserved:

- Phase 61E - Reserved Word Symbol Diagnostics.
- Phase 62 - CMP Register and Immediate Forms.
- Later conditional jump phases.
- Later `loop` phase.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- A possible later dedicated capacity-expansion phase if dynamic allocation, streaming, larger JSON output, source paging, or broad memory-management changes become desired.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 61D advances repository/archive milestone status but does not advance runtime/source-run MASM behavior metadata.
- **Reason:** Phase 61D added documentation, static checks, and regression tests. It did not add MASM syntax, runtime instruction behavior, parser behavior, executor behavior, Wasm API behavior, source-run JSON shape, browser controls, browser layout, browser interaction behavior, diagnostic codes, diagnostic JSON fields, or rendered Simulator Messages categories.
- **Risk:** Future readers may see repository/archive Phase 61D and think runtime/source-run metadata should also be Phase 61D.
- **How to change later:** Only update runtime/source-run metadata in a later phase that explicitly changes runtime-visible MASM/source behavior or explicitly requires metadata advancement.

### Assumption 2

- **Assumption:** Existing public capacity diagnostic codes should be preserved.
- **Reason:** The guide and spec require diagnostic hardening, not renaming stable public codes. Existing codes such as `token-capacity-exceeded`, `source-text-capacity-exceeded`, and `code-label-capacity-exceeded` were already structured and suitable for tests.
- **Risk:** Existing diagnostic names may not exactly match example names in the roadmap text.
- **How to change later:** Add compatibility aliases or rename codes only in a deliberate diagnostic compatibility phase with migration tests.

### Assumption 3

- **Assumption:** Generated source-run fixtures are preferable to committing large hand-written capacity fixtures.
- **Reason:** Capacity tests need large or boundary-oriented inputs. Generated fixtures keep the repository maintainable and reduce stale line/column risks.
- **Risk:** Generated fixtures can hide source shape unless fixture builders are simple and deterministic.
- **How to change later:** Move a fixture to an external named `.asm` file if a future phase needs explicit hand-audited source text.

### Assumption 4

- **Assumption:** Instruction/IR capacity is not source-run-reachable before token capacity with the current source-run limits.
- **Reason:** Generated source-run programs hit token capacity before they can reach the lower instruction-capacity limit through normal source-run parsing.
- **Risk:** Instruction-capacity source-run behavior could remain less directly exercised than token/source-text/label capacity.
- **How to change later:** Add a lower-level parser/lowering fixture or test-specific capacity override in a future capacity-test infrastructure phase if direct source-run reachability becomes required.

### Assumption 5

- **Assumption:** JSON-capacity behavior should remain documented but not forced through an oversized fixture in Phase 61D.
- **Reason:** Phase 61D explicitly forbids broad capacity redesign and oversized kitchen-sink fixtures. Forcing JSON output exhaustion safely would likely require new test infrastructure or capacity controls.
- **Risk:** JSON-capacity behavior remains less exhaustively tested than representative parser/source-run capacities.
- **How to change later:** Add a future JSON-output-capacity or capacity-expansion phase with explicit test knobs and bounded fixture generation.

### Assumption 6

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this environment.
- **Reason:** `emcc` is unavailable on PATH in the assistant/container environment, and Phase 61D did not require rebuilt Wasm artifacts to validate documentation/static/source-run tests.
- **Risk:** Local served artifacts may be stale if a developer expects rebuilt Wasm after applying changes.
- **How to change later:** Run the Windows Emscripten build script in an environment where `emcc` is configured.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning, implementation, compliance review, second review, manual-test preparation, and final gap check:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61D - Source-Run Capacity Documentation and Diagnostic Hardening
- Note text or summary:
  Phase 61D owns source-run/parser capacity documentation and targeted diagnostic hardening.
- Classification:
  target-owned
- Reason:
  This is the selected TARGET_MILESTONE scope.
- Action for this milestone:
  Implemented through documentation updates, source-run regression tests, rendered Simulator Messages coverage, and static checks.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61D scope and non-goals
- Note text or summary:
  Large-program support requiring dynamic allocation, chunked parsing, larger JSON, streaming diagnostics, source paging, or broad memory-management changes must be split into a later capacity-expansion phase.
- Classification:
  target-owned
- Reason:
  This directly constrains Phase 61D implementation.
- Action for this milestone:
  Preserved as a boundary. No broad capacity redesign was implemented.
```

```text
- Location:
  docs/FULL_IMPLEMENTATION_SPEC.md, parser/source-run capacity behavior section
- Note text or summary:
  Parser/source-run capacity failures must be distinguished from runtime instruction-count watchdog failures and should produce structured diagnostics where simulator-controlled.
- Classification:
  target-owned
- Reason:
  This is the stable behavior contract for Phase 61D.
- Action for this milestone:
  Implemented through documentation and regression tests distinguishing capacity failures from runtime `instructionLimit`.
```

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
- Classification:
  irrelevant-to-target
- Reason:
  Phase 61D is not an instruction milestone and does not add memory-reading opcodes.
- Action for this milestone:
  Left unchanged.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61E - Reserved Word Symbol Diagnostics
- Note text or summary:
  Reserved-word user-symbol diagnostics are scheduled after Phase 61D.
- Classification:
  future-owned
- Reason:
  Phase 61E is not the selected target milestone.
- Action for this milestone:
  Left deferred. No reserved-word diagnostics were implemented.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md and docs/SUPPORTED_SYNTAX.md, deferred branch/control-flow/debugger notes
- Note text or summary:
  Conditional jumps, loop forms, stack/procedure behavior, debugger/editor behavior, and active-time watchdog behavior remain future work.
- Classification:
  future-owned
- Reason:
  Phase 61D is capacity documentation/diagnostic hardening only.
- Action for this milestone:
  Preserved as future work.
```

```text
- Location:
  docs/FULL_IMPLEMENTATION_SPEC.md and docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, OPTION NOKEYWORD notes
- Note text or summary:
  OPTION NOKEYWORD remains unsupported until a later explicit keyword-control phase.
- Classification:
  future-owned
- Reason:
  Phase 61D does not own reserved-word disabling or dynamic keyword-table mutation.
- Action for this milestone:
  Left unsupported.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 61D parser/source-run capacity documentation was implemented.
- Phase 61D capacity-diagnostic regression tests were added.
- Phase 61D static checks were added.
- The parser/source-run capacity versus runtime `instructionLimit` distinction was documented and tested.
- The no-broad-capacity-redesign boundary was preserved.

### Future-owned TODO-style notes intentionally preserved

- Phase 61E reserved-word symbol diagnostics.
- Phase 62 `cmp`.
- Conditional jumps.
- `loop` forms.
- Indirect jumps and additional branch forms.
- Stack/procedure/call/return behavior.
- Debugger/editor/source-map behavior.
- Active-time watchdogs.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- Future memory-reading opcode TODO in `src/wasm/wasm_api.c`.

### Stale or contradicted TODO-style notes corrected

- None found.

The first compliance pass corrected stale non-TODO comments and duplicated documentation wording, but no stale TODO-style note required correction.

### Unresolved TODO-related risks

- None specific to Phase 61D.

## 8. Design summary

Phase 61D was implemented as a minimal documentation, static-check, and test-hardening milestone.

Primary design choices:

1. **Do not rewrite parser/VM capacity internals.** Existing capacity diagnostics were already structured. The milestone hardened coverage and documentation instead of performing broad allocation or JSON-output redesign.

2. **Use generated tests for capacity boundaries.** Generated source avoids large committed fixtures while still covering real source-run paths.

3. **Keep runtime/source-run behavior phase at Phase 61.** Phase 61D did not add runtime-visible MASM behavior.

4. **Preserve capacity categories.** Parser/source-run capacity failures remain distinct from runtime instruction-count watchdog failures, memory-region capacity failures, Program Console output limits, Simulator Messages output limits, and browser/worker infrastructure failures.

5. **Prefer static checks for documentation guarantees.** Since Phase 61D includes documentation/status obligations, `scripts/run_tests.py --static` now verifies required status and wording fragments.

6. **No future feature implementation.** Reserved-word diagnostics, `cmp`, conditional jumps, `loop`, stack/procedure behavior, debugger/editor behavior, active-time watchdogs, and `OPTION NOKEYWORD` remain future work.

## 9. Files changed

Changed files in the final Phase 61D state:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `scripts/run_tests.py`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`

No C runtime/core/parser/executor/memory implementation files were changed.

No browser UI behavior files were changed.

No Wasm API behavior was changed.

## 10. Tests added

Added or strengthened tests/checks:

- `test_phase61d_token_capacity_diagnostic_source_run_program`
- `test_phase61d_source_text_capacity_diagnostic_source_run_program`
- `test_phase61d_code_label_capacity_diagnostic_source_run_program`
- `Phase 61D renders token capacity diagnostic exactly`
- `assert_phase61d_capacity_documented`

Coverage added:

- token-capacity source-run diagnostic path;
- source-text-capacity source-run diagnostic path;
- code-label-capacity source-run diagnostic path;
- exact rendered Simulator Messages output for token-capacity failure;
- static documentation/status coverage for Phase 61D capacity distinctions.

Existing related coverage preserved:

- data-capacity source-run coverage;
- Phase 59/61 instruction-count watchdog coverage;
- Phase 61 direct-JMP behavior;
- Phase 61C debugger/editor boundary wording;
- full focused test-group coverage.

## 11. Commands used to test

### Pre-implementation repository verification

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate timed out in assistant/container environment
```

Focused commands run after aggregate timeout:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate timed out in assistant/container environment, focused groups passed
group skipped because dependency was unavailable, such as emcc
```

### Implementation verification

Focused commands run:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
```

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate timed out in assistant/container environment
```

Classification:

```text
aggregate timed out with focused groups passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### First compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate completed and passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Second compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate timed out in assistant/container environment
```

Classification:

```text
aggregate timed out with focused groups passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Final gap-check verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
```

Result:

```text
All focused groups passed.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate timed out in assistant/container environment
```

Classification:

```text
aggregate timed out with focused groups passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

## 12. Pass/fail result distinction

Observed result categories during the milestone:

- **aggregate completed and passed:** observed during first compliance review.
- **aggregate timed out but focused groups passed:** observed during pre-implementation verification, implementation verification, second review, and final gap check.
- **aggregate failed:** not observed.
- **focused group failed:** not observed.
- **focused group timed out and was rerun by subgroup/fixture:** not observed.
- **group skipped because a dependency was unavailable:** browser/Wasm rebuild smoke skipped because `emcc` was unavailable in the assistant/container environment.

Final confidence result:

```text
All focused test groups passed. Aggregate completion was inconsistent in the assistant/container environment due to timeout behavior, but one compliance pass completed aggregate successfully, and every final focused group passed.
```

## 13. Manual/browser testing guidance and expected outputs

Phase 61D is not meaningfully testable through a small manual MASM program on the served website. The milestone hardens generated capacity tests, documentation, and static checks. `program.asm` is not applicable.

### Website testing

Website-testable:

```text
no
```

Reason:

```text
Phase 61D does not add new MASM syntax or runtime behavior. The relevant cases are generated capacity/boundary tests.
```

### Windows CMD local testing

Required setup assumptions:

- Windows CMD or Visual Studio Developer Command Prompt.
- Python available as `py -3`.
- Node.js available as `node` for web/formatter tests.
- A C compiler available through Visual Studio tooling for native/source-run tests.
- Emscripten is not required for Phase 61D verification.

Recommended commands from the project root:

```cmd
py -3 scripts\run_tests.py --source-run
py -3 scripts\run_tests.py --web
py -3 scripts\run_tests.py --static
```

Expected output snippets:

```text
[source-run] PASS - source-run integration binary passed independently
Selected test groups passed.
```

```text
[web] PASS - browser-side Node module tests passed
Selected test groups passed.
```

```text
[static] PASS - runner/documentation consistency checks passed
Selected test groups passed.
```

Optional broad check:

```cmd
py -3 scripts\run_tests.py --all
```

Expected output snippets if it completes locally:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
All implemented milestone tests passed.
```

Acceptable dependency skip if Emscripten is not configured:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Regression signs:

- `[source-run] FAIL`
- `[web] FAIL`
- `[static] FAIL`
- missing coverage for `token-capacity-exceeded`, `source-text-capacity-exceeded`, or `code-label-capacity-exceeded`;
- docs collapsing parser/source-run capacity limits into runtime `instructionLimit`;
- generic worker failure replacing simulator-controlled capacity diagnostics;
- docs claiming arbitrary large-program support.

## 14. Compliance review summary

First compliance review found minor documentation/comment hygiene issues and fixed them:

- duplicated Phase 61C debugger-boundary wording in `docs/SUPPORTED_SYNTAX.md`;
- lowercase `parser/source-run` sentence start;
- stale Phase 61C wording in a static-check docstring;
- stale Phase 61A wording in `tests/core/test_wasm_source_run.c` file header;
- static expected-text adjustment after cleanup.

First compliance review result:

```text
complete
```

Files changed during first compliance review:

- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `tests/core/test_wasm_source_run.c`

Package produced:

```text
milestone_61D_first_compliance_check.zip
```

## 15. Re-review summary

Second compliance review found no additional issues.

Checks performed:

- re-read target guide section and relevant spec capacity/status sections;
- compared implementation against Phase 61D tasks and acceptance criteria;
- inspected changed files for stale comments and hidden assumptions;
- re-scanned TODO-style notes in changed files and nearby modules;
- reviewed tests for quality and meaningful coverage;
- verified rendered message test coverage;
- verified docs do not promise future behavior;
- reran focused groups and attempted aggregate.

Second review result:

```text
complete; no additional fixes applied
```

No second compliance ZIP was produced because no project files changed during the second compliance pass.

## 16. User-test follow-up summary

Manual testing instructions were provided for local-only verification.

The user did not report discrepancies from Prompt 7. Prompt 8 was skipped and the process continued directly to the final gap check.

## 17. Known limitations

- Phase 61D does not expand large-program support.
- Phase 61D does not introduce dynamic parser allocation, streaming diagnostics, source paging, larger JSON buffers, or broad capacity redesign.
- Instruction/IR capacity is not directly source-run-reachable with current token capacity; representative source-run capacity tests cover token, source-text, and code-label paths.
- JSON capacity is documented as bounded behavior but was not forced through an oversized fixture in this phase.
- Browser/Wasm artifacts were not rebuilt in the assistant/container environment because `emcc` was unavailable.
- Served-site testing requires applying the changed files and rebuilding Wasm locally only if a developer wants refreshed served artifacts; Phase 61D itself does not change runtime/Wasm behavior.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 61E - Reserved Word Symbol Diagnostics
```

Phase 61E should remain narrowly scoped to reserved-word user-symbol diagnostics. It should not implement Phase 62 `cmp`, conditional jumps, `loop`, stack/procedure behavior, debugger/editor behavior, active-time watchdogs, or `OPTION NOKEYWORD`.

## 19. Changed-files ZIP/package produced

Packages produced during the milestone:

- `changed_files_61D.zip`
- `milestone_61D_first_compliance_check.zip`

No second-compliance ZIP was produced because no files changed in the second compliance pass.

No final-compliance ZIP was produced because no files changed in the final gap-check pass.

Latest repository/archive recommendation:

```text
Latest_repository_state_milestone_61D.zip
```
