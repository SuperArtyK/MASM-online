# Milestone 68 report

## 1. Milestone title and scope

**Milestone:** Phase 68 - Call Target Classification and Procedure Entry Metadata

**Scope:** Phase 68 adds parser/source metadata that classifies future `CALL`/`INVOKE` targets without making `CALL`, `INVOKE`, `RET`, stack behavior, procedure frames, or Irvine32 dispatch executable. The milestone is a metadata and diagnostics phase. It prepares later execution phases by separating procedure-entry labels from ordinary executable labels and by exposing a documented classifier API that can distinguish supported, deferred, unsupported, malformed, and unknown targets.

The implementation preserves the Online MASM32 Educational Simulator product boundary:

- Static browser app.
- C99 MASM-like parser plus internal VM compiled to WebAssembly with Emscripten.
- JS/TS browser UI.
- Educational MASM32/Irvine32-style console simulator.
- Not a full MASM compiler.
- Not a full x86 emulator.
- Not a Windows emulator.
- Not a PE loader/linker.
- Not a WinAPI simulator.

## 2. Source-of-truth files used

The implementation and reviews used the active canonical source-of-truth pair:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Additional project status, syntax, and history files used:

- `docs/SUPPORTED_SYNTAX.md`
- `docs/history/reports/Milestone 67A report.md`
- `README.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `web/index.html`

The requested `docs/history/PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_67A.md` was not present in the 67A archive. Older audit/handoff reports were present but were not treated as replacements for the canonical spec and guide.

## 3. Exact requirements implemented

Phase 68 requirements implemented:

1. Added or confirmed procedure-entry metadata distinct from ordinary executable code labels.
2. Preserved declaration source location for accepted procedures.
3. Added documented parser-facing target-classification helpers for future `CALL` and `INVOKE` phases:
   - `vm_parser_classify_call_target_name`
   - `vm_parser_classify_call_target_token`
   - `vm_parser_call_target_class_name`
4. Added `VmCallTargetClass` classifications for:
   - malformed target expressions;
   - user procedure entries;
   - ordinary executable code labels;
   - currently supported virtual Irvine32 intrinsic/terminator names;
   - known Irvine32 routines planned for later;
   - known Irvine32 routines explicitly unsupported in v1;
   - explicit external/API/linker/import-library/non-goal target names;
   - data symbols;
   - numeric equates;
   - local symbols as a reserved future metadata class;
   - reserved words;
   - unknown symbols.
5. Reused the central virtual Irvine32 registry for Irvine32 target classification rather than adding an independent call-target table.
6. Preserved case policy:
   - mnemonics, directives, registers, aliases, virtual include names, Irvine32 names, and reserved built-ins remain case-insensitive;
   - user procedure, label, data, and equate names continue to follow the active user-symbol `OPTION CASEMAP` policy.
7. Preserved and expanded duplicate/collision validation for procedure names, labels, data symbols, and numeric equates under existing namespace rules.
8. Rejected procedure names that collide with reserved words, including mnemonics, directives, registers, operators, data types, `PTR` names, virtual include names, and recognized Irvine32 names.
9. Added structured diagnostics for malformed or invalid procedure names where required, including `invalid-procedure-name`.
10. Added the Phase 68 classifier diagnostic namespace support for `unsupported-call-target`, without emitting executable `CALL` behavior in normal source parsing.
11. Preserved existing `CALL` and `INVOKE` unsupported/deferred behavior.
12. Preserved Phase 67A selected-entry runtime boundary behavior.
13. Published accepted numeric equate metadata with `VmNumericEquate` so the classifier can distinguish numeric equates from unknown symbols.
14. Updated status surfaces to Phase 68:
   - README
   - supported syntax reference
   - milestone history
   - build/development guide
   - browser `index.html`
   - protocol constants
   - Wasm/source-run metadata.
15. Updated the browser default program to demonstrate procedure/equate metadata without using executable `CALL`.

## 4. Explicit non-goals and future work not implemented

The following future behavior remains intentionally unimplemented:

- Executable `CALL`.
- `RET`, root `RET`, `RET imm16`, and `LEAVE`.
- Stack runtime initialization and `ESP` startup contract. This belongs to Phase 68A.
- Source-level `PUSH`/`POP` and stack mutation.
- Procedure frame behavior.
- Call-depth tracking.
- `PROC USES`, `LOCAL`, `PROTO`, `INVOKE`, `ADDR`, arguments, calling conventions, or frame metadata beyond the Phase 68 classifier needs.
- Irvine32 callable routine dispatch beyond previously completed behavior.
- Windows API execution.
- PE loading, object files, linking, import libraries, or host filesystem access.
- Browser/Wasm generated artifact rebuild in this assistant environment, because `emcc` was unavailable.

## 5. Assumptions used

- **Assumption:** Phase 68 classifier exposure should be parser-facing and test-facing, not source-level executable `CALL` syntax.
  - **Reason:** The guide defines Phase 68 as parser metadata and target classification. Executable direct `CALL` is assigned to Phase 69.
  - **Risk:** If a future interpretation expects typed `CALL` lines to produce target-specific classifier diagnostics in Phase 68, the parser API-only exposure may be viewed as narrower than desired.
  - **How to change later:** A later phase can route parsed `CALL` operands through the classifier while still deciding whether the resulting diagnostic is unsupported, deferred, or executable.

- **Assumption:** Existing Phase 67A procedure-range metadata can remain the basis for procedure-entry classification.
  - **Reason:** Phase 67A already records procedure names, source locations, spans, body boundaries, and procedure-entry labels.
  - **Risk:** Future phases may need richer procedure metadata for parameters, locals, frames, or calling conventions.
  - **How to change later:** Extend the procedure metadata structures in the future owning phase without changing the Phase 68 classifier contract for basic target identity.

- **Assumption:** Existing diagnostic codes can be reused where their semantics match, and new codes should be added only where required.
  - **Reason:** The guide allows retaining existing specific codes where they correctly describe the error, and minimal diagnostic changes reduce churn.
  - **Risk:** Later UI or test expectations may prefer more specific codes for individual classifier paths.
  - **How to change later:** Add narrowly scoped diagnostic codes in the future phase that exposes those paths to users.

- **Assumption:** The missing Phase 67A audit/handoff report is not blocking.
  - **Reason:** The canonical spec/guide, supported syntax doc, and 67A milestone report were available and sufficient for source-of-truth verification.
  - **Risk:** A navigation-only warning from the missing handoff report could have been missed.
  - **How to change later:** If the 67A handoff report becomes available, compare it against the Phase 68 implementation before archiving the final repository state.

## 6. Relevant TODO-style notes reviewed

The repository was searched case-insensitively for TODO-style notes using terms including:

- `TODO`
- `FIXME`
- `HACK`
- `TEMP`
- `DEFERRED`
- `future milestone`
- `not yet implemented`
- `later phase`
- `follow-up`

Relevant notes reviewed:

- **Location:** `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, Phase 68 section
  - **Summary:** Phase 68 owns call-target classification and procedure-entry metadata but must not implement executable `CALL`, `INVOKE`, `RET`, stack mutation, Irvine dispatch, or frames.
  - **Classification:** target-owned.
  - **Disposition:** Implemented as the milestone acceptance checklist.

- **Location:** `docs/FULL_IMPLEMENTATION_SPEC.md`, direct `CALL` target-classification stable behavior
  - **Summary:** Classifier must distinguish procedures, labels, data symbols, equates, Irvine32 target categories, external/non-goal names, reserved words, malformed targets, and unknown names.
  - **Classification:** target-owned.
  - **Disposition:** Implemented through parser classifier APIs and tests.

- **Location:** `src/parser/parser.c`, previous comment/path near bare Irvine32 symbol handling
  - **Summary:** Existing wording said call-target classification was deferred until executable `CALL` exists.
  - **Classification:** target-owned/stale once Phase 68 is implemented.
  - **Disposition:** Corrected as part of the implementation so it no longer contradicts the Phase 68 boundary.

- **Location:** `docs/SUPPORTED_SYNTAX.md`, procedure/stack/Irvine32 status notes
  - **Summary:** `CALL`, `RET`, `INVOKE`, stack behavior, and broader Irvine32 routine calls remain deferred.
  - **Classification:** future-owned.
  - **Disposition:** Preserved and clarified to describe current Phase 68 behavior without promising future execution.

- **Location:** `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, Phase 68A and Phase 69 sections
  - **Summary:** Phase 68A owns stack runtime initialization and `ESP`; Phase 69 owns executable direct `CALL procedureName`.
  - **Classification:** future-owned.
  - **Disposition:** Preserved; no future behavior implemented.

- **Location:** `src/wasm/wasm_api.c`, future memory-reading opcode TODO
  - **Summary:** Future memory-reading opcodes should be added to planned-read validation when those opcodes are implemented.
  - **Classification:** future-owned.
  - **Disposition:** Preserved unchanged.

## 7. TODO-style note disposition

- **Target-owned TODO-style notes resolved:**
  - Phase 68 guide/spec classifier requirements implemented.
  - Parser comment/path that previously deferred call-target classification until executable `CALL` was corrected.

- **Future-owned TODO-style notes intentionally preserved:**
  - Stack initialization and `ESP` startup: Phase 68A.
  - Executable direct `CALL`: Phase 69.
  - `RET`, frames, `PUSH`, `POP`, `INVOKE`, `ADDR`, `LOCAL`, `PROC USES`, calling conventions, Irvine32 routine dispatch: later phases.
  - Future memory-reading opcode TODO in `src/wasm/wasm_api.c`.

- **Stale or contradicted TODO-style notes corrected:**
  - No stale TODO-style notes remain for Phase 68.
  - Stale non-TODO test/comment wording found during compliance passes was corrected.

- **Unresolved TODO-related risks:**
  - None identified for Phase 68.

## 8. Design summary

Phase 68 was implemented as a parser metadata and classifier layer.

The parser now exposes accepted numeric equate metadata through `VmNumericEquate`, allowing future parser/executor code and tests to distinguish numeric equates from unknown identifiers. Procedure entries remain represented separately from ordinary executable labels through existing Phase 67A metadata. The new classifier helpers layer over existing parser data and the central Irvine32 registry, returning a stable enum value and display name for future phases.

The classifier intentionally does not make source `CALL` executable. Ordinary source parsing still rejects unsupported `CALL` and `INVOKE` as before. This keeps the Phase 68 boundary intact while giving later phases a stable way to ask what kind of target name they are seeing.

Diagnostics preserve the project requirement for structured source locations: line, column, byte offset, and span length. Rendered Simulator Messages coverage was added for user-visible procedure-name diagnostics.

Status surfaces were advanced to Phase 68, including the browser shell and protocol metadata. The generated browser Wasm artifact remains stale until rebuilt locally with Emscripten.

## 9. Files changed

Implementation changed or updated these files:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

Compliance passes additionally corrected wording and test-harness issues in:

- `tests/core/test_parser.c`
- `scripts/run_tests.py`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`

## 10. Tests added

Tests added or expanded include:

- Parser/classifier success tests for:
  - user procedure entries;
  - ordinary code labels;
  - data symbols;
  - numeric equates;
  - supported Irvine32 virtual intrinsics/terminators;
  - planned Irvine32 routines;
  - unsupported Irvine32 routines;
  - external/MASM object non-goal names;
  - reserved words;
  - unknown symbols;
  - malformed empty/numeric targets;
  - register-token reserved classification;
  - classifier display-name stability.

- CASEMAP tests for:
  - duplicate default-case procedure detection;
  - distinct exact-case procedures under `OPTION CASEMAP:NONE`;
  - Irvine32 names remaining case-insensitive under `CASEMAP:NONE`.

- Procedure-name diagnostic tests for:
  - Irvine32 routine names as procedure names;
  - instruction, register, directive, operator, condition-operator, data-type, `PTR`, and virtual include names as reserved procedure names;
  - malformed numeric procedure names;
  - data/procedure and equate/procedure collisions.

- Rendered Simulator Messages tests for:
  - duplicate procedure diagnostics;
  - reserved Irvine32 procedure-name diagnostics;
  - malformed procedure-name diagnostics.

- Regression tests for:
  - Phase 67A selected-entry runtime boundaries;
  - existing unsupported `CALL` and `INVOKE` behavior;
  - protocol and phase metadata updates;
  - current status surfaces and harness documentation.

## 11. Commands used to test

Focused commands run during implementation and reviews:

```text
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command run:

```text
/usr/bin/timeout 300s python3 scripts/run_tests.py --all
```

No documented subgroup or fixture-family fallback was required after the final pass because all focused groups passed and the final aggregate completed.

Skipped dependency check:

- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

## 12. Pass/fail results

Final test results:

- `python3 scripts/run_tests.py --structure`: PASS.
- `python3 scripts/run_tests.py --native`: PASS.
- `python3 scripts/run_tests.py --source-run`: PASS.
- `python3 scripts/run_tests.py --web`: PASS.
- `python3 scripts/run_tests.py --diagnostics`: PASS.
- `python3 scripts/run_tests.py --protocol`: PASS.
- `python3 scripts/run_tests.py --static`: PASS.
- `/usr/bin/timeout 300s python3 scripts/run_tests.py --all`: aggregate completed and passed in the final run.
- Browser/Wasm rebuild smoke: SKIP because `emcc` was unavailable.

Earlier in the session, aggregate attempts timed out in the assistant/container environment while focused groups passed. The final aggregate run completed and passed.

## 13. Manual/browser testing guidance and expected outputs

Phase 68 is partially website-testable after rebuilding `web/dist` with Emscripten and partially local-test-only through parser/classifier tests.

### Browser setup on Windows

```cmd
where emcc
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open:

```text
http://localhost:8000
```

If `emcc` is unavailable, browser runtime testing should be skipped. Local tests still apply.

### Browser program 1: default Phase 68 success behavior

```asm
COUNT = 4
.data
value DWORD 7
.code
helper PROC
    mov ecx, 111      ; recorded as procedure metadata only
helper ENDP

main PROC
entryLabel:
    mov eax, value    ; END main still starts here
    cmp eax, 7
    je selectedPath
    mov ebx, 999
selectedPath:
    mov ebx, COUNT    ; numeric equate metadata is also tracked
main ENDP             ; normal fallthrough completes here
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected key final registers:

```text
EAX    | 00000007h / u: 7 / s: 7
EBX    | 00000004h / u: 4 / s: 4
ECX    | 00000000h / u: 0 / s: 0
ESP    | 00000000h / u: 0 / s: 0
EFLAGS | 00000040h / 64
ZF     | 1
```

Expected Program Console: empty.

Expected Memory Changes: none.

Regression signs:

- `ECX` becomes `111`, meaning the helper procedure ran incorrectly.
- `ESP` changes, meaning Phase 68A stack behavior leaked into Phase 68.
- Browser phase/status text remains at Phase 67A.

### Browser program 2: duplicate procedure diagnostic

```asm
.code
Helper PROC
Helper ENDP
helper PROC
helper ENDP
END Helper
```

Expected Simulator Messages:

```text
[assembly-error] duplicate-label line 4, column 1, byte offset 30, span length 6: procedure-entry label `helper` conflicts with `Helper` because user-defined symbols are case-insensitive under the active CASEMAP policy; first defined at line 2, column 1.
```

Expected behavior: no successful execution message and no Program Console output.

### Browser program 3: Irvine32 reserved procedure name diagnostic

```asm
.code
WriteString PROC
WriteString ENDP
END WriteString
```

Expected Simulator Messages:

```text
[assembly-error] reserved-word-symbol line 2, column 1, byte offset 6, span length 11: 'WriteString' is a reserved MASM Irvine32 registry name and cannot be used as a procedure name.
```

Expected behavior: no successful execution message and no Program Console output.

### Browser program 4: malformed procedure name diagnostic

```asm
.code
123 PROC
END
```

Expected Simulator Messages:

```text
[assembly-error] invalid-procedure-name line 2, column 1, byte offset 6, span length 3: Procedure name must be an identifier before PROC.
```

Expected behavior: no successful execution message and no Program Console output.

### Browser program 5: `CALL` still unsupported

```asm
.code
helper PROC
    mov eax, 99
helper ENDP
main PROC
    call helper
    mov ebx, 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-instruction line 6, column 5, byte offset 60, span length 4: CALL is not supported yet.
```

Expected behavior: no successful execution message and no Program Console output.

Regression signs:

- The program executes.
- `EAX` becomes `99`.
- `EBX` becomes `1`.
- Any stack or call behavior appears.

### Windows CMD local testing

From the project root:

```cmd
py scripts\run_tests.py --native
py scripts\run_tests.py --source-run
py scripts\run_tests.py --diagnostics
py scripts\run_tests.py --web
py scripts\run_tests.py --protocol
py scripts\run_tests.py --static
```

Expected snippets:

```text
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[web] PASS - browser-side Node module tests passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Selected test groups passed.
```

`program.asm` is not required for local classifier API tests; those are covered by `--native`.

## 14. Compliance review summary

First compliance review findings and fixes:

- Corrected one stale copied Doxygen/test comment that referenced Phase 58 before a Phase 68 classifier test.
- Added explicit procedure/data-symbol collision coverage.
- Added explicit procedure/numeric-equate collision coverage.
- Expanded reserved procedure-name coverage for directives, operators, condition operators, and virtual include names.
- Reran focused groups. All passed. Aggregate still timed out in that pass.

## 15. Re-review summary

Second compliance review findings and fixes:

- Renamed a static test-harness helper from stale Phase 67 wording to Phase 68 wording.
- Corrected a stale parser-test expectation message that said Windows/API routine diagnostics applied until call classification exists.
- Reran all focused groups. All passed. Aggregate completed and passed in that review.

Final gap check findings and fixes:

- Corrected stale assertion/reason text in source-run and rendered-diagnostics tests that still described current runtime metadata as Phase 67A while expecting Phase 68 metadata.
- Confirmed generated `web/dist/masm32_sim_core.wasm` still contains Phase 67A strings because `emcc` is unavailable here. This is a generated artifact issue, not a source implementation issue.
- Reran source-run, diagnostics, static, and aggregate tests. All passed; `emcc` rebuild smoke skipped.

## 16. User-test follow-up summary

Prompt 8 was conditional and was not run. The user reported that everything appeared to pass and proceeded directly to the final gap check. No user-test discrepancies were provided, and no Prompt 8 fixes were required.

## 17. Known limitations

- Generated browser Wasm artifact remains stale until rebuilt locally with Emscripten.
- `CALL`, `RET`, `INVOKE`, stack mutation, `PUSH`/`POP`, procedure frames, root procedure termination, and Irvine32 callable dispatch remain future work.
- Windows API, PE loading, linking, import libraries, object files, and host filesystem access remain non-goals.
- The missing Phase 67A audit/handoff report was not available in the archive and was not used.

## 18. Next recommended milestone

**Phase 68A - Stack Runtime Initialization and ESP Startup Contract.**

Phase 68A should initialize and document stack runtime state and the `ESP` startup contract without implementing executable `CALL` unless the Phase 68A guide explicitly says otherwise.

## 19. Changed-files ZIP/package produced

Packages produced during the milestone:

- `milestone_68_implementation.zip`
- `milestone_68_first_compliance_check.zip`
- `milestone_68_second_compliance_check.zip`
- `milestone_68_final_compliance_check.zip`

Recommended final repository archive name after applying all packages and rebuilding generated Wasm locally:

```text
Latest_repository_state_milestone_68.zip
```

A full latest repository archive was not produced in this assistant environment because the generated browser Wasm artifact could not be rebuilt without `emcc`.
