# Milestone 70 report

## 1. Milestone title and scope

**Target milestone:** Phase 70 - RET Execution and Return Address Validation.

**Latest completed milestone at session start:** Phase 69C - Wasm Output-Contract Compatibility and Test Runner Decomposition.

**Scope implemented:** Phase 70 adds plain near `RET` execution to the Online MASM32 Educational Simulator. The milestone connects the Phase 69 direct `CALL` pseudo-EIP return-token push to a checked stack read and validated return transfer. It also updates parser support, runtime diagnostics, source-run metadata, browser-visible status, default browser sample code, documentation, static checks, and tests.

Phase 70 implements only no-operand near `RET`:

```asm
ret
RET
```

It does not implement root procedure termination, `RET imm16`, `RETF`, `LEAVE`, stack frames, source-level `PUSH` or `POP`, Irvine32 callable routine dispatch, calling conventions, host callbacks, WinAPI behavior, PE loading, linking, or native x86 execution.

## 2. Source-of-truth files used

Canonical product/specification files read and used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`

Supporting current-status/history files read and used:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/history/HISTORY_README.md`
- `docs/history/reports/Milestone 69C report.md`

Archive used at session start:

- `Latest_repository_state_milestone_69C.zip`

Audit/handoff note:

- `docs/history/PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_69C.md` was requested by the handoff prompt but was not present in the archive.
- Older audit/handoff reports existed only for earlier milestones and were treated as historical navigation material, not as replacements for the active spec/guide pair.

## 3. Exact requirements implemented

Implemented parser requirements:

- Accepted plain no-operand `ret` and `RET`.
- Rejected future or unsupported forms, including:
  - `ret 4`
  - `ret eax`
  - `ret WORD PTR [esp]`
  - `retf`
- Lowered accepted plain `RET` to an executable VM opcode.
- Preserved parser source location data for accepted and rejected `RET` forms.

Implemented VM/runtime requirements:

- Added executable VM `RET` opcode support.
- Implemented `RET` as a simulator control-transfer instruction that consumes a 32-bit pseudo-EIP return token from DWORD `[ESP]`.
- Routed the implicit `[ESP]` return-token read through central checked-memory read validation.
- Added planned-read participation for the implicit `RET` stack read.
- Preserved required diagnostic precedence:
  - invalid/unreadable stack ranges fail through existing central checked-memory diagnostics;
  - optional educational planned-read diagnostics are not emitted for ranges that fail mandatory readable-range validation;
  - fatal optional policies stop before token consumption and control-flow validation.
- Preserved no-partial-mutation semantics on all failed `RET` paths:
  - no instruction-pointer change;
  - no `ESP` mutation;
  - no flag or flag-validity mutation;
  - no memory mutation;
  - no Program Console output change;
  - no public `memoryChanges` row;
  - no `execution-complete` status.
- Validated successfully read tokens as executable pseudo-EIP return targets.
- Rejected invalid readable tokens through a new `invalid-return-address` runtime status.
- Rejected root-return sentinel behavior before Phase 71.
- On successful `RET`:
  - incremented `ESP` by 4 only after all validation succeeded;
  - transferred control to the mapped instruction;
  - displayed `EIP` according to the existing Phase 68B pseudo-EIP model;
  - preserved flags and flag-validity metadata.

Implemented CALL/RET boundary requirements found during review:

- Added parser-owned CALL return-target metadata so Phase 70 distinguishes a real executable same-procedure successor from a terminal `CALL` with no executable successor.
- Ensured terminal `CALL` followed physically by a helper procedure does not accidentally return into the helper body.
- Ensured terminal `CALL` before Phase 71 produces `invalid-return-address` after the helper `RET`, rather than synthetic success.

Implemented source-run/browser/protocol/status requirements:

- Advanced runtime/source-run behavior metadata to Phase 70.
- Preserved the Phase 69C source-run output contract identifier where appropriate: `phase-69c-source-run-output-contract-v1`.
- Added rendered Simulator Messages support for `invalid-return-address`.
- Updated browser-visible status text to:

```text
Milestone 70: RET execution and return address validation.
```

- Updated default browser editor program to include `INCLUDE Irvine32.inc` so `exit` is legal.
- Updated default browser sample to exercise successful CALL/RET behavior.
- Updated static checks so stale Phase 69/69C current-status wording cannot silently return in active docs, browser status, or relevant tests.

## 4. Explicit non-goals and future work not implemented

The following remain intentionally unimplemented:

- root `RET` success;
- successful terminal helper-procedure return when no executable instruction follows the `CALL`;
- non-entry procedure fallthrough diagnostics;
- call-depth diagnostics;
- active-call-frame validation;
- `RET imm16` / caller-cleanup return;
- `RETF` / far returns;
- `LEAVE`;
- source-level `PUSH` and `POP`;
- procedure frames;
- `PROC USES`;
- `LOCAL`;
- `PROTO`;
- `INVOKE`;
- `ADDR`;
- Irvine32 callable routine dispatch beyond the already implemented virtual `exit` terminator behavior;
- external/API/WinAPI calls;
- PE loading;
- object-file linking;
- import-library behavior;
- host callbacks;
- native x86 execution;
- public UI visualization of implicit CALL/RET stack-token accesses as `memoryChanges` rows.

Phase 71 remains responsible for root procedure termination semantics and non-entry procedure fallthrough diagnostics.

## 5. Assumptions used

- **Assumption:** `invalid-return-address` should be a distinct runtime status rather than reusing `invalid-branch-target` or `invalid-call-target`.
  **Reason:** The implementation guide explicitly names `invalid-return-address` for successfully read tokens that fail Phase 70 return-target validation.
  **Risk:** Adding a status requires synchronized changes across C status names, JSON/source-run output, rendered messages, protocol tests, and documentation.
  **How to change later:** A later diagnostic cleanup phase can consolidate or rename return diagnostics by updating the diagnostic registry, source-run JSON tests, rendered-message tests, docs, and static checks together.

- **Assumption:** `sourceRunOutputContract` should remain `phase-69c-source-run-output-contract-v1` because Phase 70 changes runtime behavior, not the Phase 69C output-order/schema contract.
  **Reason:** Phase 69C explicitly separated output-contract compatibility from runtime/source-run behavior phase metadata.
  **Risk:** If a later phase changes JSON schema or output ordering, retaining the old contract would hide a compatibility change.
  **How to change later:** Bump the output-contract identifier in the Wasm API, browser protocol, protocol tests, docs, and static checks in the same phase that changes the output contract.

- **Assumption:** Planned-read policy coverage for implicit `RET` stack reads can use internal/native fixtures for metadata states that cannot yet be constructed by accepted source syntax.
  **Reason:** Phase 70 does not implement source-level `PUSH`, `POP`, stack-frame metadata, local stack objects, or general stack-writing syntax.
  **Risk:** Some policy interactions are less visible through browser-only manual tests until later stack syntax exists.
  **How to change later:** Add higher-level source-run fixtures when later phases define source-level stack writes or stack-object metadata.

- **Assumption:** Terminal `CALL` with no executable same-procedure successor should encode an invalid return target before Phase 71 instead of inventing a synthetic return location.
  **Reason:** The Phase 70 guide says the executable successor after `CALL` must be an actual executable lowered instruction, not `ENDP`, a procedure boundary, a following procedure body, or a synthetic terminal marker.
  **Risk:** Users familiar with real MASM may expect a root `RET` or terminal helper return to succeed because real programs often have startup/runtime caller context.
  **How to change later:** Phase 71 can define root procedure termination semantics and non-entry fallthrough diagnostics without weakening Phase 70 return-token validation.

- **Assumption:** The shorter browser status string is permitted when repository milestone and runtime behavior phase are both 70.
  **Reason:** No documentation prohibited the shorter form; split repository/runtime wording is only necessary when the two differ, as in Phase 69C repository status with Phase 69 runtime behavior.
  **Risk:** Future documentation-only milestones may again require split wording.
  **How to change later:** Static checks can be adjusted in the future milestone that introduces a new repository/runtime split.

## 6. Relevant TODO-style notes reviewed

Target-relevant TODO-style/status notes reviewed before and during implementation:

- `README.md` notes that plain `RET` remained deferred.
- `README.md` deferred/future list including plain `ret` plus `leave`, `ret imm16`, root `ret`, non-entry fallthrough diagnostics, and frame-related features.
- `docs/SUPPORTED_SYNTAX.md` status notes describing plain `RET`, root `RET`, non-entry fallthrough diagnostics, stack instructions, frames, arguments, calling conventions, and Irvine32 dispatch as deferred.
- `docs/SUPPORTED_SYNTAX.md` future stack/procedure list including plain `ret`.
- `docs/SUPPORTED_SYNTAX.md` text stating source-level stack instructions, procedure frames, and `RET` stack mutation remained deferred.
- `docs/SUPPORTED_SYNTAX.md` central status note saying `RET` was not implemented in Phase 69 and Phase 70 owned plain `RET`.
- `web/index.html` status/sample text saying runtime behavior was Phase 69 and code after `CALL` was not reached until `RET` existed in a later phase.
- `src/wasm/wasm_api.c` future memory-reading opcode planned-read note.
- Existing parser notes around deferred CALL distance/type overrides, memory/register targets, Irvine32 routine executable behavior, and Irvine32 CALL dispatch.

## 7. TODO-style note disposition

Target-owned TODO-style notes resolved:

- Plain near `RET` is no longer documented as deferred in active status/syntax/browser surfaces.
- Browser default sample no longer says code after `CALL` is unreachable until a later phase.
- Browser default sample now includes `INCLUDE Irvine32.inc` so `exit` is legal.
- Phase 70 implicit `RET` planned-read integration was implemented in the source-run/Wasm planned-read path.
- Static checks now protect Phase 70 status wording and the default browser sample include requirement.

Future-owned TODO-style notes intentionally preserved:

- `RET imm16`.
- `RETF`.
- `LEAVE`.
- Root `RET` success.
- Terminal procedure-return success.
- Non-entry procedure fallthrough diagnostics.
- Call-depth diagnostics.
- Active-call-frame validation.
- Source-level `PUSH` and `POP`.
- Stack frames and stack-object metadata.
- `PROC USES`, `LOCAL`, `PROTO`, `INVOKE`, and `ADDR`.
- Irvine32 callable routine dispatch beyond the virtual `exit` terminator.
- Unsupported/non-goal external/API/WinAPI/native/PE/linker behavior.

Stale or contradicted TODO-style notes corrected:

- No stale TODO-style notes remained after review.
- Stale non-TODO wording was corrected in active docs and tests, including references that still implied Phase 69 or Phase 69C was the current runtime/source-of-truth revision after Phase 70.

Unresolved TODO-related risks:

- None identified for Phase 70.

## 8. Design summary

Phase 70 completes the narrow CALL/RET loop required for ordinary helper returns while preserving simulator boundaries.

`CALL` continues to write a simulator pseudo-EIP return token internally through the Phase 69 checked stack-write path. During Phase 70 review, CALL lowering/execution was tightened so parser-owned metadata identifies the valid same-procedure executable successor when one exists. If the source successor is not an executable lowered instruction, the return token is invalid rather than a synthetic terminal marker or the first instruction of a following procedure.

`RET` is implemented as an executable VM instruction that:

1. captures original `ESP`;
2. creates a planned read for DWORD `[ESP]`;
3. validates mandatory memory readability through central checked-memory helpers;
4. applies optional planned-read policy with required fatal/warn/off behavior;
5. reads the 32-bit token only after fatal validation paths pass;
6. validates the token as an executable pseudo-EIP target;
7. increments `ESP` by 4 only after token validation succeeds;
8. transfers control to the mapped instruction;
9. preserves flags and flag-validity metadata.

The return-token read is internal VM state. It is checked and policy-visible, but it does not create public source-run JSON `memoryChanges` rows or browser memory-change display rows.

The browser/source-run surfaces now report runtime behavior phase 70 while preserving the separate Phase 69C output-contract identifier. This keeps runtime behavior advancement distinct from output-contract compatibility.

## 9. Files changed

Implementation pass changed:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_ir.c`
- `src/core/vm_ir.h`
- `src/parser/parser.c`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

First compliance pass additionally changed or refined:

- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `tests/web/test_diagnostic_rendering.mjs`

Second compliance pass additionally changed or refined:

- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`

Feedback-suggestion pass additionally changed or refined:

- `web/index.html`
- `scripts/run_tests.py`

Final gap-check pass additionally changed or refined:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `scripts/run_tests.py`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`

Report creation pass added:

- `docs/history/reports/Milestone 70 report.md`

## 10. Tests added

Parser tests added/updated:

- Plain `ret` accepted.
- Uppercase `RET` accepted.
- Accepted `RET` lowers to the new VM opcode.
- `ret 4` rejected as a future `RET imm16` form.
- `ret eax` rejected.
- `ret WORD PTR [esp]` rejected.
- `retf` rejected as a future/non-goal far return.
- Terminal `CALL` return-target metadata does not treat a following helper procedure as a valid return successor.

Native executor tests added/updated:

- Successful CALL/RET returns to the instruction after `CALL`.
- `RET` increments `ESP` only after successful token validation.
- `RET` preserves flags and flag-validity metadata.
- Invalid readable return token produces `invalid-return-address` without branching or mutating state.
- Empty-stack/root `RET` fails through central checked-memory diagnostics.
- Planned-read and strict validation paths prevent token consumption where required.

Source-run tests added/updated:

- Phase 70 acceptance program completes with CALL writing a pseudo-EIP token, RET returning to the post-CALL instruction, and `exit` terminating.
- Final registers show successful data transfer after return.
- Public `memoryChanges` remains empty for implicit CALL/RET stack-token accesses.
- Invalid readable return tokens emit `invalid-return-address`.
- Root `RET` with empty stack emits checked-memory `invalid-address`.
- Terminal `CALL` followed by helper `RET` remains invalid before Phase 71.
- Metadata advances runtime/source-run behavior phase to 70 while preserving Phase 69C output contract.

Web/protocol/rendering/static tests added/updated:

- Rendered `invalid-return-address` message is exact and user-visible.
- Rendered checked-memory failure for root/empty-stack `RET` is exact.
- Protocol constants reflect Phase 70 runtime metadata.
- Browser status text reflects Phase 70.
- Browser default editor program includes `INCLUDE Irvine32.inc`.
- Browser default editor program exercises successful CALL/RET.
- Static checks guard against stale Phase 69-current wording and stale default-program text.
- Static checks preserve future-owned boundaries for root `RET`, `RET imm16`, `RETF`, stack instructions, frames, and Irvine32 callable dispatch.

## 11. Commands used to test

Aggregate commands run during the milestone:

```sh
python3 scripts/run_tests.py --all
```

Focused group commands run during the milestone:

```sh
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Additional manually rerun focused commands during final/user follow-up:

```sh
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
```

Skipped dependency check:

- Browser/Wasm rebuild smoke was skipped in this assistant/container environment because `emcc` was unavailable.
- This skip affects rebuilding checked-in Wasm/browser artifacts only. Native/source-run/Node/protocol/static tests were still runnable.

No separate fixture-family subgroup command was required after final focused groups passed. One chained focused command timed out during a second review before later groups ran; the remaining focused groups were rerun individually and passed.

## 12. Pass/fail results

Implementation pass:

- `--structure`: PASS.
- `--native`: PASS.
- `--source-run`: PASS.
- `--web`: PASS.
- `--diagnostics`: PASS.
- `--protocol`: PASS.
- `--static`: PASS.
- `--all`: aggregate completed and passed all implemented groups.
- Browser/Wasm rebuild smoke: SKIP because `emcc` was unavailable.

First compliance pass:

- Initial `--static`: failed while adjusting documentation/static expectations.
- Final `--static`: PASS.
- `--structure`: PASS.
- `--native`: PASS.
- `--source-run`: PASS.
- `--web`: PASS.
- `--diagnostics`: PASS.
- `--protocol`: PASS.
- `--static`: PASS.
- `--all`: aggregate completed and passed all implemented groups.
- Browser/Wasm rebuild smoke: SKIP because `emcc` was unavailable.

Second compliance pass:

- One chained focused command timed out after the web group before diagnostics/protocol/static ran.
- `--structure`: PASS.
- `--native`: PASS.
- `--source-run`: PASS.
- `--web`: PASS.
- `--diagnostics`: PASS after separate rerun.
- `--protocol`: PASS after separate rerun.
- `--static`: PASS after separate rerun.
- `--all`: aggregate completed and passed all implemented groups.
- Browser/Wasm rebuild smoke: SKIP because `emcc` was unavailable.

Feedback-suggestion pass:

- `--static`: PASS.
- `--web`: PASS.
- `--source-run`: PASS.
- `--all`: aggregate completed and passed all implemented groups.
- Browser/Wasm rebuild smoke: SKIP because `emcc` was unavailable.

User-test follow-up:

- No implementation fix was needed.
- `--source-run`: PASS.
- `--diagnostics`: PASS.

Final gap-check pass:

- `--static`: PASS.
- `--source-run`: PASS.
- `--diagnostics`: PASS.
- `--structure`: PASS.
- `--native`: PASS.
- `--web`: PASS.
- `--protocol`: PASS.
- `--all`: timed out in the assistant/container environment after final documentation/test-description cleanup.
- Classification for final state: aggregate timed out but focused groups passed.
- Browser/Wasm rebuild smoke remains skipped because `emcc` is unavailable.

Overall result classification:

- Aggregate completed and passed during implementation and review passes before final cleanup.
- After the final cleanup, aggregate timed out in the assistant/container environment, but all relevant focused groups passed.
- No focused group remained failing.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Website-testable: yes, after rebuilding the Wasm artifact with Emscripten.

Emscripten requirement:

- `emcc` is required to rebuild the browser Wasm artifact because Phase 70 changes C core behavior.
- If `emcc` is unavailable, browser/Wasm rebuild verification is expected to be skipped.

Windows CMD setup:

```bat
cd /d C:\path\to\repo
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

Expected browser status text:

```text
Milestone 70: RET execution and return address validation.
```

### Manual Program 1: successful CALL/RET return

```asm
INCLUDE Irvine32.inc
.stack 4096
.data
value DWORD 7
.code
main PROC
    call Helper       ; Writes pseudo-EIP return token at ESP - 4
    mov eax, ebx      ; Runs after Helper returns with RET
    exit
main ENDP

Helper PROC
    mov ebx, value
    ret               ; Reads token at ESP and returns to mov eax, ebx
Helper ENDP
END main
```

Expected messages include:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX = 00000007h
EBX = 00000007h
ESP = 00900000h
EIP = 00401008h
EFLAGS = 00000000h
```

Expected Program Console:

```text
<empty>
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `assembly-error` on `exit`.
- Missing `execution-complete`.
- `EAX` or `EBX` not equal to `00000007h`.
- `ESP` left at `008FFFFCh`.
- A public memory-change row appears for implicit CALL/RET stack-token access.

### Manual Program 2: terminal CALL remains invalid before Phase 71

```asm
INCLUDE Irvine32.inc
.code
main PROC
    call Helper
main ENDP

Helper PROC
    mov eax, 1
    ret
Helper ENDP
END main
```

Expected runtime error:

```text
[runtime-error] invalid-return-address line 9, column 5, byte offset 95, span length 3: RET read a return token that does not map to an executable pseudo-EIP instruction target. Execution stopped before changing ESP or transferring control.
```

Expected key registers:

```text
EAX = 00000001h
ESP = 008FFFFCh
EIP = 00401008h
```

Regression signs:

- Program completes successfully.
- `RET` silently terminates root execution.
- `ESP` returns to `00900000h`.
- Execution falls into another procedure as if procedure boundaries did not matter.

### Manual Program 3: root RET still fails through checked memory

```asm
INCLUDE Irvine32.inc
.code
main PROC
    ret
main ENDP
END main
```

Expected runtime error:

```text
[runtime-error] invalid-address line 4, column 5, byte offset 41, span length 3: Invalid memory read at 00900000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

Expected key registers:

```text
EAX = 00000000h
EBX = 00000000h
ESP = 00900000h
EIP = 00401000h
EFLAGS = 00000000h
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- Root `RET` completes successfully before Phase 71.
- Diagnostic is not `invalid-address`.
- `ESP` changes.
- `execution-complete` appears.

### Manual Program 4: RET imm16 remains rejected

```asm
INCLUDE Irvine32.inc
.code
main PROC
    ret 4
main ENDP
END main
```

Expected assembly error:

```text
[assembly-error] unsupported-instruction-form line 4, column 9, byte offset 45, span length 1: RET imm16, register, and memory operand forms are deferred; Phase 70 implements only plain near RET with no operands.
```

Expected register state:

```text
No register state available.
```

Expected Memory Changes:

```text
No memory changes.
```

### Windows CMD local tests

`program.asm` is not required for the standard local test suite.

Recommended commands:

```bat
set CC=clang
py -3 scripts\run_tests.py --source-run
py -3 scripts\run_tests.py --diagnostics
py -3 scripts\run_tests.py --web
py -3 scripts\run_tests.py --protocol
py -3 scripts\run_tests.py --static
py -3 scripts\run_tests.py --all
```

Expected focused snippets:

```text
[source-run] PASS - source-run integration binary passed independently
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[web] PASS - browser-side Node module tests passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Selected test groups passed.
```

Expected full-suite snippets when the aggregate completes:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
All implemented milestone tests passed.
```

If `emcc` is unavailable, this is expected and not a failure:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

## 14. Compliance review summary

First compliance review found and fixed documentation/status issues:

- `docs/BUILDING_AND_DEVELOPMENT.md` still had stale wording saying Phase 69 remained the latest completed runtime/source-run behavior phase.
- `docs/MILESTONE_HISTORY.md` had ambiguous current-status wording around Phase 69B.
- `docs/SUPPORTED_SYNTAX.md` used broad deferred “CALL/RET behavior” wording that could confuse implemented plain `RET` with future CALL/RET features.
- `tests/web/test_diagnostic_rendering.mjs` had a stale fixture name implying `RET` was unsupported.
- Static checks did not yet guard against stale Phase 69-current wording.

Fixes:

- Reworded active status docs to identify Phase 70 as current runtime/source-run behavior.
- Clarified that remaining deferred CALL/RET behavior belongs to later phases.
- Renamed stale rendered-diagnostic fixture language.
- Added static-check protection.
- Reran focused groups and aggregate; implemented groups passed, with browser/Wasm rebuild smoke skipped due to unavailable `emcc`.

## 15. Re-review summary

Second compliance review found a real Phase 70 boundary issue:

- Runtime `CALL` still computed a return token from the next physical lowered instruction when parser-owned return-target metadata was absent.
- A terminal `CALL` followed physically by a helper procedure could therefore let `RET` return into the helper body, which Phase 70 explicitly forbids.
- Source-run selected-entry boundary handling could also treat `CALL` reaching the selected entry `ENDP` like ordinary fallthrough.

Fixes:

- Added parser-owned CALL return-target metadata.
- Distinguished real same-procedure executable successors from terminal non-executable successors.
- Made terminal `CALL` produce an invalid return target before Phase 71.
- Updated CALL execution to use parser metadata when present, with fallback behavior preserved for hand-authored native fixtures.
- Updated source-run boundary handling so `CALL` and `RET` are not mistaken for ordinary selected-entry fallthrough.
- Added parser and source-run regression tests for terminal `CALL` followed by helper `RET`.
- Reran focused groups and aggregate; implemented groups passed, with browser/Wasm rebuild smoke skipped due to unavailable `emcc`.

Final gap check found stale wording only:

- Active spec/test phrasing still used “current Phase 69” or “after Phase 69C” wording.
- Those non-runtime strings were corrected and protected by static checks.
- Final focused groups passed; final aggregate timed out in this assistant/container environment.

## 16. User-test follow-up summary

User manual feedback asked why Program 2 produced `invalid-return-address` even though a similar real MASM program can run, and why root `RET` in `main` fails with an `invalid-address` read at `00900000h`.

Diagnosis:

- Program 2 behavior is expected for Phase 70.
- The default successful program has an executable instruction after `CALL`; the helper `RET` can return to that instruction.
- Program 2 has no executable instruction after `CALL` inside `main`; `main ENDP` is not an executable return target, and Phase 70 must not invent one.
- Real MASM may run under startup/runtime code that calls `main`; this simulator does not currently model CRT/Irvine startup caller frames or synthetic root return tokens.
- Root `RET` from `main` reads from the empty modeled stack at `ESP = 00900000h`, so central checked-memory validation correctly emits `invalid-address`.
- Root procedure termination semantics are already planned for Phase 71.

Fixes applied from user-test follow-up:

- None. The behavior matched Phase 70 scope.

Tests rerun:

- `python3 scripts/run_tests.py --source-run`: PASS.
- `python3 scripts/run_tests.py --diagnostics`: PASS.

## 17. Known limitations

- `emcc` is unavailable in the assistant/container environment, so checked-in Wasm artifacts were not rebuilt here.
- Served website verification of Phase 70 runtime behavior requires rebuilding the Wasm artifact in an Emscripten-enabled environment.
- Root `RET` success remains future work for Phase 71.
- Terminal helper procedure return success remains future work for Phase 71.
- Non-entry procedure fallthrough diagnostics remain future work for Phase 71.
- Call-depth/active-call-frame validation remains future work.
- `RET imm16`, `RETF`, `LEAVE`, source-level stack instructions, frames, and Irvine32 callable routine dispatch remain unimplemented by design.
- Some planned-read policy metadata cases are covered by native/internal fixtures because current source syntax cannot yet construct arbitrary stack metadata states without future stack-writing features.

## 18. Next recommended milestone

Next recommended milestone:

- Phase 71 - Root Procedure Termination Semantics.

Suggested latest repository-state archive name after applying all Phase 70 changes and this report:

```text
Latest_repository_state_milestone_70.zip
```

## 19. Changed-files ZIP/package produced

Milestone implementation/review packages produced during the session:

- `milestone_70_implementation.zip`
- `milestone_70_first_compliance_check.zip`
- `milestone_70_second_compliance_check.zip`
- `milestone_70_feedback_suggestions.zip`
- `milestone_70_final_compliance_check.zip`

This report package:

- `milestone_70_report.zip`

The report package contains only:

- `docs/history/reports/Milestone 70 report.md`
