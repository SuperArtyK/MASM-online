# Milestone 57R report - Unsupported INVOKE, ADDR, and External Routine Diagnostics

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57R - Unsupported INVOKE, ADDR, and External Routine Diagnostics
```

Repository/archive milestone after this work:

```text
Phase 57R - Unsupported INVOKE, ADDR, and External Routine Diagnostics
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 57R - Unsupported INVOKE, ADDR, and External Routine Diagnostics
```

Scope implemented:

- Added narrow, diagnostic-only recognition for common unsupported `INVOKE` lines.
- Added structured parser/source-run diagnostics for unsupported `INVOKE` syntax.
- Added structured diagnostics for `ADDR` operands inside unsupported `INVOKE` lines.
- Added targeted external-routine diagnostics for the Phase 57R examples:
  - `StdOut` as an external MASM32 runtime-style routine.
  - `crt_printf` as a C runtime formatted-output routine.
  - `ExitProcess` as WinAPI/external process-termination behavior.
- Preserved parser recovery across multiple unsupported `INVOKE` lines.
- Suppressed noisy token-level cascades from already-classified unsupported `INVOKE` lines.
- Preserved the separation between Program Console and Simulator Messages.
- Preserved the existing virtual Irvine32 `exit` terminator behavior.
- Updated repository/archive and runtime/source-run status surfaces to Phase 57R.

Representative source forms now receive stable diagnostics:

```asm
invoke StdOut, addr titleMsg
invoke crt_printf, addr numberFmt, counter
invoke ExitProcess, 0
```

These forms are not executable. They are recognized only to produce stable, user-friendly diagnostics before execution begins.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status and verification files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57Q report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_57Q.zip
```

Repository archive recommended after implementation:

```text
Latest_repository_state_milestone_57R.zip
```

A full latest repository archive was not produced during this session. Changed-files packages were produced and are listed in Section 19.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, status-surface hygiene, and stable browser/source-run behavior expectations.
- The incremental implementation guide owns phase numbering, target milestone scope, per-phase tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only. They do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

## 3. Exact requirements implemented

### 3.1 Unsupported `INVOKE` line recognition

Phase 57R adds targeted handling for unsupported `INVOKE` lines. The parser now recognizes `INVOKE` in the unsupported line-recovery path and emits a stable primary diagnostic for unsupported invocation syntax instead of relying on the older generic unsupported-feature message.

The required example forms are covered:

```asm
invoke StdOut, addr titleMsg
invoke crt_printf, addr numberFmt, counter
invoke ExitProcess, 0
```

This recognition is diagnostic-only. It does not lower arguments, push parameters, set up calling conventions, call procedures, execute routines, or synthesize external symbols.

### 3.2 `ADDR` diagnostics inside unsupported `INVOKE` lines

The implementation recognizes `ADDR` operands in unsupported `INVOKE` lines and emits the `unsupported-addr` diagnostic.

The diagnostic explains that `ADDR` depends on later `INVOKE`, procedure-argument lowering, and calling-convention support. It is intentionally separate from ordinary symbol lookup so unsupported invocation examples do not degrade into misleading `unknown-symbol` cascades.

### 3.3 External routine classification

The implementation adds targeted diagnostics for the Phase 57R routine examples:

```text
unsupported-masm32-runtime-routine
unsupported-crt-routine
unsupported-winapi-execution
```

Classification implemented:

- `StdOut` receives `unsupported-masm32-runtime-routine`.
- `crt_printf` receives `unsupported-crt-routine`.
- `ExitProcess` receives `unsupported-winapi-execution`.

`unsupported-external-routine` code-name support was also added as a generic diagnostic-code name for stable taxonomy coverage, but Phase 57R behavior remains narrow and does not broaden external-routine execution support.

### 3.4 `ExitProcess` is not virtual Irvine32 `exit`

The implementation reuses or aligns with the existing Irvine32/Windows API classification path for `ExitProcess`, while preserving the distinction between:

```asm
invoke ExitProcess, 0
```

and:

```asm
exit
```

`invoke ExitProcess, 0` is WinAPI/external process behavior and is rejected. The supported virtual Irvine32 `exit` terminator remains available when `INCLUDE Irvine32.inc` is active.

A compliance-review fix narrowed the WinAPI-specific diagnostic branch to `ExitProcess` so Phase 57R does not accidentally introduce broader WinAPI routine classification for names outside the target examples.

### 3.5 Multi-diagnostic recovery and cascade suppression

A source file containing several unsupported `INVOKE` lines can now produce useful diagnostics for each line when safe.

The implementation avoids cascades such as reporting every routine name, argument name, or `ADDR` target as unrelated syntax errors or unknown symbols after the line has already been classified as unsupported invocation syntax.

### 3.6 Execution refusal and stream separation

Source containing Phase 57R unsupported invocation diagnostics refuses execution before runtime begins.

Required behavior implemented:

- No `execution-complete` message after unsupported invocation assembly diagnostics.
- No Program Console output for these failures.
- No register or memory mutation from subsequent `.code` instructions.
- No procedure metadata, call metadata, external routine metadata, import metadata, or linker metadata is created.

### 3.7 Existing behavior preserved

The following existing behavior was preserved:

- `INCLUDE Irvine32.inc` remains a supported virtual include.
- Virtual Irvine32 `exit` remains accepted and executable when `INCLUDE Irvine32.inc` is active.
- Phase 57P host/path-like `INCLUDE` diagnostics remain unchanged.
- Phase 57Q `INCLUDELIB` diagnostics remain unchanged.
- Existing unsupported diagnostics for later procedure, stack, macro, high-level-flow, and linkage features remain deferred.
- Program Console and Simulator Messages remain separate streams.

### 3.8 Status surfaces updated

Because Phase 57R changes source-visible parser and diagnostic behavior, both project status values advanced:

```text
Repository/archive milestone:
Phase 57R - Unsupported INVOKE, ADDR, and External Routine Diagnostics

Runtime/source-run MASM behavior phase:
Phase 57R - Unsupported INVOKE, ADDR, and External Routine Diagnostics
```

Updated status surfaces include:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- source-run/Wasm status metadata
- browser static status text
- worker/protocol metadata
- protocol/static tests

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57R:

- Executable `INVOKE` behavior.
- `ADDR` expression semantics.
- Procedure call lowering.
- Argument pushing.
- Calling-convention setup.
- `CALL`, `RET`, `LEAVE`, stack frames, or stack instruction behavior.
- Procedure parameter metadata.
- `USES`, `PROTO`, `LOCAL`, or procedure body expansion.
- `StdOut` execution.
- `crt_printf` execution.
- `ExitProcess` execution.
- Windows API execution.
- CRT execution.
- MASM32 runtime library execution.
- PE loading.
- Import resolution.
- Object-file linking.
- External routine execution.
- Host filesystem or library loading.
- Macro expansion.
- New virtual include behavior.
- High-level-flow diagnostics from Phase 57S.
- Debugger behavior.
- Broader Irvine32 routine bodies beyond existing virtual `exit` behavior.

Future work intentionally preserved:

- Phase 57S - Unsupported High-Level Flow Diagnostics.
- Later procedure, stack, call/return, and calling-convention milestones.
- Later Irvine32 routine milestones.
- Later macro/high-level-flow milestones.
- Later external-symbol, linkage, or routine classification refinement if the canonical guide adds it.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Use distinct Phase 57R diagnostic codes for recognized concepts rather than only one generic unsupported-invoke diagnostic.
- **Reason:** The guide recommended distinct codes, and prior Phase 57P/57Q diagnostics already used specific taxonomy for include/linker boundary diagnostics.
- **Risk:** More parser enum, diagnostic-code mapping, JSON, rendered-message, documentation, and static-test updates are required.
- **How to change later:** A future diagnostic-cleanup phase can consolidate codes if exact rendered messages still prove all required concept distinctions.

### Assumption 2

- **Assumption:** Classify `StdOut` narrowly as an external MASM32 runtime-style routine, not as an Irvine32 routine.
- **Reason:** The Phase 57R guide names `StdOut` separately from the virtual Irvine32 `exit` behavior and frames it as external MASM32 runtime-style behavior.
- **Risk:** If a later MASM32 runtime compatibility table is introduced, this classification may need to move to that central table.
- **How to change later:** Introduce a MASM32 runtime classification table or extend the virtual symbol registry with a clearly mapped MASM32-runtime category.

### Assumption 3

- **Assumption:** Classify `crt_printf` narrowly as a C runtime formatted-output routine without adding broad CRT symbol support.
- **Reason:** The target guide specifically names `crt_printf`; broad CRT recognition is not required for Phase 57R.
- **Risk:** Other CRT names may still receive generic unsupported invocation diagnostics.
- **How to change later:** Add a limited CRT classification table in a future diagnostic-refinement phase if the guide requires broader CRT recognition.

### Assumption 4

- **Assumption:** Keep `INVOKE` handling line-oriented and diagnostic-only.
- **Reason:** The guide explicitly allows line-oriented recognition and states that full argument parsing is not required.
- **Risk:** Unusual `INVOKE` forms may receive only the primary unsupported invocation diagnostic or fewer secondary diagnostics.
- **How to change later:** Later procedure/INVOKE phases can replace line-oriented recovery with real parsing, argument lowering, and procedure/calling-convention semantics.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can be reported as skipped when `emcc` is unavailable in the assistant/container environment.
- **Reason:** Emscripten is not installed in this environment.
- **Risk:** Served browser artifacts can remain stale until rebuilt locally or in CI.
- **How to change later:** Rebuild with Emscripten locally or in CI and run the manual browser verification programs in Section 13.

## 6. Relevant TODO-style notes reviewed

Target-owned TODO-style notes and TODO-style evidence reviewed:

- Phase 57R requirements in `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` for unsupported `INVOKE`, `ADDR`, and external routine diagnostics.
- Existing generic unsupported parser path in `src/parser/parser.c` that emitted `Unsupported feature: INVOKE is not supported yet; use CALL when available.`
- Existing parser tests in `tests/core/test_parser.c` that expected generic `INVOKE` unsupported-feature recovery.
- Existing source-run tests in `tests/core/test_wasm_source_run.c` that expected generic `INVOKE` unsupported-feature behavior.
- Existing rendered Simulator Messages tests in `tests/web/test_diagnostic_rendering.mjs` that expected generic `INVOKE` wording.
- Existing supported-syntax documentation that listed `INVOKE` among unsupported/recovered constructs.
- Existing Irvine32 helper/registry notes that required preserving central virtual Irvine32/Windows API classification behavior.

Future-owned TODO-style notes reviewed and intentionally not implemented:

- Future memory-reading opcode TODO in `src/wasm/wasm_api.c`.
- Procedure, stack, call/return, calling convention, and debugger work.
- Broader Irvine32 routine bodies beyond existing virtual `exit`.
- MASM32 runtime execution.
- CRT routine execution.
- WinAPI execution.
- External symbol/linkage behavior.
- Macro expansion.
- Phase 57S high-level-flow diagnostics.

Broad TODO-style categories reviewed and excluded as irrelevant to Phase 57R:

- Future debugger/editor/share/URL work.
- Future stack and heap runtime behavior.
- Future QWORD/SQWORD execution.
- Future scaled-index memory operands.
- Historical milestone-report wording and generated artifacts.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 57R unsupported `INVOKE`, `ADDR`, and external routine diagnostics implemented and tested.
- Existing generic `INVOKE ... not supported yet` parser path replaced by Phase 57R-specific diagnostic handling.
- Existing parser/source-run/rendered-message expectations updated from generic `INVOKE` behavior to Phase 57R-specific behavior.
- Supported-syntax and current-status documentation updated to Phase 57R.

### Future-owned TODO-style notes intentionally preserved

- Future memory-reading opcode TODO remains future-owned.
- Later procedure, stack, call/return, calling-convention, macro, high-level-flow, Irvine32 routine, CRT/MASM32 runtime, WinAPI, PE/import/linker, debugger, and external execution work remains deferred.

### Stale or contradicted TODO-style notes corrected

- No stale target-related TODO-style notes required correction.
- The compliance review did correct an implementation scope issue where a WinAPI/external registry classification branch was initially broader than Phase 57R should own.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 57R was implemented as a focused diagnostics-quality milestone.

Primary design choices:

1. **Keep `INVOKE` non-executable.** The parser recognizes `INVOKE` only to emit stable diagnostics. It does not create calls, procedure metadata, argument metadata, stack effects, or runtime entries.

2. **Use line-oriented recovery.** The implementation classifies unsupported `INVOKE` lines without full argument parsing. This keeps the change small and matches the guide's explicit allowance.

3. **Emit concept-specific diagnostics.** Phase 57R examples can emit separate diagnostics for unsupported `INVOKE`, unsupported `ADDR`, and the relevant external routine category.

4. **Preserve source locations.** Diagnostics preserve source line, column, byte offset, and span length for the relevant keyword or routine token.

5. **Avoid cascades.** Already-classified unsupported invocation lines do not trigger unrelated token or unknown-symbol cascades for every argument.

6. **Reuse existing external classification where applicable.** `ExitProcess` classification aligns with the existing Irvine32/Windows API registry behavior, while the final compliance fix prevents that path from accidentally broadening Phase 57R beyond the named target example.

7. **Preserve virtual Irvine32 `exit`.** `invoke ExitProcess, 0` is rejected as WinAPI/external process behavior, but bare `exit` after `INCLUDE Irvine32.inc` remains supported.

8. **Advance runtime/source-run metadata.** Phase 57R changes source-visible parser/diagnostic behavior, so repository/archive and runtime/source-run phase metadata both advance to Phase 57R.

## 9. Files changed

Files changed across implementation, compliance review, second review, and final status updates:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

### Parser tests

Added or updated coverage for:

- `invoke StdOut, addr titleMsg` producing `unsupported-invoke`, `unsupported-addr`, and `unsupported-masm32-runtime-routine`.
- `invoke crt_printf, addr numberFmt, counter` producing `unsupported-invoke`, `unsupported-addr`, and `unsupported-crt-routine`.
- `invoke ExitProcess, 0` producing `unsupported-invoke` and `unsupported-winapi-execution`.
- Multiple `INVOKE` lines producing stable diagnostics in source order.
- Source-location and span preservation for `INVOKE`, `ADDR`, and routine tokens.
- Diagnostic code-name mapping for new Phase 57R diagnostic codes, including `unsupported-external-routine`.
- No-cascade behavior for unsupported invocation lines.
- Regression proving a non-target Windows/API registry routine such as `MsgBox` does not receive the `ExitProcess`-specific diagnostic in Phase 57R.

### Source-run tests

Added or updated coverage for:

- Source-run JSON exposing Phase 57R diagnostic codes.
- Source-run JSON preserving line, column, byte offset, and span length.
- Unsupported `INVOKE` diagnostics preventing execution.
- No `execution-complete` message after unsupported invocation assembly diagnostics.
- No Program Console output after unsupported invocation assembly diagnostics.
- No register mutation from later instructions after unsupported invocation diagnostics.
- No `unknown-symbol` cascade for `ADDR` operands or invocation arguments in the tested patterns.
- Virtual Irvine32 `exit` regression behavior remaining unchanged.

### Rendered Simulator Messages tests

Added exact rendered-message tests for:

- Unsupported `INVOKE` syntax.
- Unsupported `ADDR` operands.
- Unsupported MASM32 runtime-style `StdOut`.
- Unsupported CRT-style `crt_printf`.
- Unsupported WinAPI/external `ExitProcess`.
- Multi-diagnostic invocation fixtures with stable ordering.

### Protocol/static/status tests

Updated tests for:

- Repository/archive milestone Phase 57R.
- Runtime/source-run MASM behavior phase Phase 57R.
- Browser status text Phase 57R.
- Worker/protocol metadata Phase 57R.
- Supported-syntax/status documentation Phase 57R.
- Milestone history Phase 57R.
- README/status wording.
- Static checks preserving legacy Phase 57P/57Q wording references where intentionally historical or regression-related.

## 11. Commands used to test

### Aggregate commands

Aggregate command run during implementation:

```bash
cd /mnt/data/repo_57Q_verify
python3 scripts/run_tests.py --all
```

Observed result during implementation:

```text
All implemented milestone tests passed.
```

Aggregate command run during compliance review and second review:

```bash
python3 scripts/run_tests.py --all
```

Observed result during those review passes:

```text
Timed out in the assistant/container environment before a final aggregate success line.
```

This was treated as an assistant/container timeout, not as a project failure, and focused groups were rerun.

Aggregate command run during final gap check:

```bash
python3 scripts/run_tests.py --all
```

Observed final gap-check result:

```text
All implemented milestone tests passed.
```

### Focused group commands

The following focused groups were run after implementation and during reviews:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused results:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Subgroup or fixture-family commands

No subgroup or individual fixture-family reruns were required.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is a dependency skip, not a test failure. Served browser testing requires rebuilding Wasm in an environment with Emscripten.

## 12. Pass/fail results

Final result classification:

```text
aggregate completed and passed
group skipped because a dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

Detailed classification:

- Final aggregate command completed and returned final success status during implementation/final gap verification.
- Focused groups completed and passed:
  - `--structure`
  - `--native`
  - `--source-run`
  - `--web`
  - `--diagnostics`
  - `--protocol`
  - `--static`
- During compliance review and second review, aggregate attempts timed out in the assistant/container environment; focused groups passed afterward. Those timeouts were not claimed as aggregate passes.
- No focused group failed.
- No focused group required subgroup reruns.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Phase 57R is browser-testable after rebuilding the Wasm artifact. Because the milestone changes C parser/source-run behavior, the served website must use a rebuilt `web/dist/masm32_sim_core.wasm`. If the browser serves the old Phase 57Q artifact, old generic `INVOKE` behavior may still appear.

### Browser setup on Windows

From the project root in Windows CMD:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the served page and paste the following programs.

### Program 1 - MASM32 runtime-style `StdOut` plus `ADDR`

```asm
.data
titleMsg BYTE "Hello", 0

.code
main PROC
    invoke StdOut, addr titleMsg
    mov eax, 42
main ENDP
END main
```

Expected Simulator Messages exactly:

```text
[unsupported-feature] unsupported-invoke line 6, column 5, byte offset 52, span length 6: INVOKE syntax is not implemented in MASM32 Educational Mode; the simulator does not lower procedure arguments, set up calling conventions, or call routines.
[unsupported-feature] unsupported-addr line 6, column 20, byte offset 67, span length 4: ADDR operands are not implemented; ADDR depends on INVOKE/procedure argument lowering and future calling-convention support.
[unsupported-feature] unsupported-masm32-runtime-routine line 6, column 12, byte offset 59, span length 6: StdOut is an external MASM32 runtime-style routine. MASM32 Educational Mode does not link MASM32 runtime libraries or execute external routines.
```

Expected Program Console:

```text
(empty)
```

Expected behavior:

- No `execution-complete` message.
- `mov eax, 42` must not execute.

### Program 2 - CRT-style `crt_printf` plus `ADDR`

```asm
.data
numberFmt BYTE "%d", 0
counter DWORD 7

.code
main PROC
    invoke crt_printf, addr numberFmt, counter
    mov eax, 42
main ENDP
END main
```

Expected Simulator Messages exactly:

```text
[unsupported-feature] unsupported-invoke line 7, column 5, byte offset 66, span length 6: INVOKE syntax is not implemented in MASM32 Educational Mode; the simulator does not lower procedure arguments, set up calling conventions, or call routines.
[unsupported-feature] unsupported-addr line 7, column 24, byte offset 85, span length 4: ADDR operands are not implemented; ADDR depends on INVOKE/procedure argument lowering and future calling-convention support.
[unsupported-feature] unsupported-crt-routine line 7, column 12, byte offset 73, span length 10: crt_printf is a C runtime formatted-output routine. MASM32 Educational Mode does not link or execute CRT routines.
```

Expected Program Console:

```text
(empty)
```

Expected behavior:

- No `execution-complete` message.
- `mov eax, 42` must not execute.

### Program 3 - WinAPI `ExitProcess`, not Irvine32 `exit`

```asm
INCLUDE Irvine32.inc

.code
main PROC
    invoke ExitProcess, 0
    exit
main ENDP
END main
```

Expected Simulator Messages exactly:

```text
[unsupported-feature] unsupported-invoke line 5, column 5, byte offset 42, span length 6: INVOKE syntax is not implemented in MASM32 Educational Mode; the simulator does not lower procedure arguments, set up calling conventions, or call routines.
[unsupported-feature] unsupported-winapi-execution line 5, column 12, byte offset 49, span length 11: ExitProcess is WinAPI/external process termination behavior. MASM32 Educational Mode does not execute Windows API calls; this is not the virtual Irvine32 exit terminator.
```

Expected Program Console:

```text
(empty)
```

Expected behavior:

- No `execution-complete` message.
- The later `exit` instruction must not run because assembly diagnostics prevent execution.

### Program 4 - Regression: virtual Irvine32 `exit` still works

```asm
INCLUDE Irvine32.inc

.code
main PROC
    mov eax, 1
    exit
    mov eax, 2
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected final register:

```text
EAX = 00000001h / u: 1 / s: 1
```

`EAX` must not become `2`.

### Local Windows CMD verification

`program.asm` is not applicable for local test-suite verification because the checked-in fixtures cover these diagnostics directly.

From the project root:

```cmd
py -3 scripts\run_tests.py --source-run
py -3 scripts\run_tests.py --diagnostics
py -3 scripts\run_tests.py --web
py -3 scripts\run_tests.py --protocol
py -3 scripts\run_tests.py --static
```

Expected output snippets:

```text
[source-run] PASS - source-run integration binary passed independently
Selected test groups passed.
```

```text
[diagnostics] PASS - native diagnostic producer and rendered messages passed
Selected test groups passed.
```

```text
[web] PASS - browser-side Node module tests passed
Selected test groups passed.
```

```text
[protocol] PASS - protocol tests passed independently
Selected test groups passed.
```

```text
[static] PASS - runner/documentation consistency checks passed
Selected test groups passed.
```

Regression signs:

- `INVOKE` produces only the old generic message `Unsupported feature: INVOKE is not supported yet`.
- `ADDR` is reported as `unknown-symbol` instead of `unsupported-addr`.
- `StdOut` or `crt_printf` produces Program Console output.
- `invoke ExitProcess, 0` is treated like Irvine32 `exit`.
- Any unsupported `INVOKE` program shows `execution-complete`.
- `mov eax, 42` executes after an unsupported `INVOKE`.
- The virtual `exit` regression program leaves `EAX = 2`.
- Browser status still says Phase 57Q after rebuilding Wasm and serving the updated site.

## 14. Compliance review summary

A first compliance review checked scope control, completeness, code quality, diagnostics, tests, documentation, TODO-style notes, and test results.

Issue found:

- The initial Phase 57R WinAPI/external classification branch used an `ExitProcess`-specific message for any Irvine32-registry symbol classified as Windows/API/external. That risked accidental broader future behavior and misleading diagnostics for names outside the Phase 57R target examples.

Fix applied:

- Narrowed the Phase 57R WinAPI diagnostic branch to `ExitProcess` only.
- Kept registry-based classification in the check so `ExitProcess` still uses the existing Irvine32/Windows API taxonomy.
- Added a parser regression proving a non-target registry external routine such as `MsgBox` does not receive the `ExitProcess`-specific diagnostic in Phase 57R.

Compliance review verdict:

```text
complete
```

## 15. Re-review summary

A second compliance review re-read the target guide section, relevant spec sections, changed files, nearby TODO-style notes, diagnostics, tests, and docs.

Additional issue found:

- Minor test gap: `VM_PARSER_DIAGNOSTIC_UNSUPPORTED_EXTERNAL_ROUTINE` had code-name plumbing but lacked a direct parser code-name regression assertion.

Fix applied:

- Added a parser test assertion for `unsupported-external-routine` diagnostic code-name stability.

Second review verdicts:

- Final scope verdict: complete.
- Final documentation verdict: complete.
- Final test coverage verdict: complete.
- Final TODO-style note verdict: complete.

## 16. User-test follow-up summary

Prompt 8 was conditional and was not provided because there were no user-reported discrepancies after the manual testing instructions. No user-test triage fixes were required.

## 17. Known limitations

- The served browser website requires a rebuilt Wasm artifact before Phase 57R parser/source-run behavior appears in `web/dist`.
- `emcc` was unavailable in the assistant/container environment, so Browser/Wasm rebuild smoke was skipped.
- A full latest repository archive named `Latest_repository_state_milestone_57R.zip` was not produced in this session.
- `INVOKE`, `ADDR`, external routines, calls, stack setup, calling conventions, MASM32 runtime routines, CRT routines, and WinAPI execution remain unimplemented by design.
- The external-routine classification is intentionally narrow for Phase 57R. Broader routine taxonomies should be added only if a future canonical phase requires them.

## 18. Next recommended milestone

Next canonical milestone:

```text
Phase 57S - Unsupported High-Level Flow Diagnostics
```

Phase 57S should focus on unsupported high-level flow constructs such as `.IF`, `.WHILE`, `.REPEAT`, `.BREAK`, and `.CONTINUE` diagnostics if the current implementation guide still lists that as the next phase.

Do not implement stack/procedure/call/external-routine behavior merely because Phase 57R now diagnoses unsupported invocations.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the session:

- `milestone_57R_changed_files.zip`
- `milestone_57R_compliance_review_changed_files.zip`
- `milestone_57R_second_review_changed_files.zip`

Latest changed-files package:

```text
milestone_57R_second_review_changed_files.zip
```

A full latest repository archive was not produced. Recommended full-archive name after packaging the complete repository state:

```text
Latest_repository_state_milestone_57R.zip
```
