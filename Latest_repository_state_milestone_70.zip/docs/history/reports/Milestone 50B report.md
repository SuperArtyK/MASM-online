# Milestone 50B report - Undefined Flag Use Diagnostics for Flag Consumers

## 1. Milestone title and scope

Milestone 50B implements **Phase 50B - Undefined Flag Use Diagnostics for Flag Consumers** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added a shared C99 flag-consumption diagnostic mechanism for instructions that read modeled flags whose deterministic values are currently marked architecturally invalid by Phase 50A metadata.
- Added an undefined-flag-use policy with three modes:
  - `off`
  - `warn`
  - `error`
- Added the structured diagnostic code:

```text
undefined-flag-use
```

- Integrated the Phase 50B helper into already-implemented flag consumers in the current repository state:
  - `adc`, which reads `CF`;
  - `sbb`, which reads `CF`;
  - `cmc`, which reads and toggles `CF`.
- Preserved existing deterministic EFLAGS bit behavior and existing producer warnings.
- Preserved existing default browser/source-run behavior by keeping the undefined-flag-use policy off unless explicitly enabled through the local diagnostic/test API path.
- Added exact rendered Simulator Messages tests for both warning and runtime-error forms.
- Added native executor and source-run regression coverage for success, warning, error, metadata, and no-partial-mutation cases.

The implementation stayed within the milestone boundary. It did not add new syntax, new flag consumers, conditional jumps, `cmp`, `loop`, `SETcc`, `CMOVcc`, browser settings, or any future instruction/control-flow behavior.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 50A report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_50A.zip
```

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.
- Phase 50B is the only target milestone for this implementation session.

## 3. Exact requirements implemented

Phase 50B required a shared helper conceptually equivalent to:

```text
check_flag_consumption(required_flags, consumer_instruction, policy)
```

Implemented C API behavior:

- Added `VmUndefinedFlagUsePolicy` with these values:
  - off: do not diagnose invalid flag consumption;
  - warn: emit a warning at the consumer and continue;
  - error: emit a runtime error at the consumer and stop before consumer mutation.
- Added a shared helper for checking a set of consumed flags before an instruction reads them.
- The helper inspects Phase 50A flag-validity metadata.
- The helper collects invalid consumed modeled flags.
- The helper emits at most one `undefined-flag-use` diagnostic per consumer check.
- The helper includes producer metadata when available:
  - producer mnemonic;
  - producer diagnostic code;
  - producer line;
  - producer source-span metadata where available.
- The helper preserves flag validity metadata after warnings.
- Error mode returns before the consumer instruction mutates registers, memory, flags, Program Console output, or memory-change rows.

Implemented policy behavior:

```text
off:
  Consumers use deterministic preserved flag values.
  No undefined-flag-use diagnostic is emitted.

warn:
  A simulator-warning undefined-flag-use diagnostic is emitted at the consumer.
  Execution continues with the deterministic preserved flag value.

error:
  A runtime-error undefined-flag-use diagnostic is emitted at the consumer.
  Execution stops before the consumer uses the undefined flag.
```

Implemented source-run/test API behavior:

- Added source-run option support for setting the undefined-flag-use policy.
- Added local diagnostic producer support for the environment variable:

```text
MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=off
MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=warn
MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=error
```

Implemented diagnostics:

- Warning message form:

```text
ADC reads CF, but CF is architecturally undefined from SHL at line 5. The simulator preserved the flag deterministically; this flag-dependent behavior is not portable.
```

- Runtime-error message form:

```text
ADC reads CF, but CF is architecturally undefined from SHL at line 5. Execution stopped before using the undefined flag.
```

- Structured diagnostic fields include:
  - `code: undefined-flag-use`;
  - diagnostic kind (`simulator-warning` or `runtime-error`);
  - consumer line;
  - consumer column;
  - consumer byte offset;
  - consumer span length;
  - `consumedFlags`;
  - `producerMnemonic`;
  - `producerCode`;
  - `producerLine`.

Acceptance criteria implemented:

- A shared flag-consumption validity helper exists.
- `undefined-flag-use` diagnostics exist and are rendered.
- `warn` and `error` consumer policies are testable.
- `undefined_flag_use_policy` affects only consumer diagnostics.
- Existing producer warnings remain under their existing instruction-phase policy.
- Browser default behavior is not changed.
- Error mode stops at the consumer, not at the producer.
- Warning mode continues using deterministic preserved flag values.
- No new flag-consuming instruction was implemented merely to test this phase.
- Producer instructions remain MASM-compatible and executable.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 50B:

- labels;
- direct jumps;
- conditional jumps;
- `cmp`;
- `loop`;
- `SETcc`;
- `CMOVcc`;
- any new flag-consuming instruction;
- browser UI controls or settings for undefined-flag-use policy;
- changing the default browser/source-run behavior;
- new producer-warning policy;
- producer-side rotate strict errors;
- PF, AF, or DF metadata;
- carry rotates;
- stack/procedure behavior;
- Irvine32 routine expansion beyond existing behavior;
- executable QWORD/SQWORD memory operations;
- scaled-index addressing;
- Windows API simulation;
- PE loading;
- object linking;
- macro expansion;
- host filesystem behavior.

Future conditional jump and other flag-consuming phases must call the Phase 50B helper before evaluating their conditions. Phase 50B did not implement those future consumers.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Existing `adc`, `sbb`, and `cmc` are valid Phase 50B integration targets because they consume `CF`.
- **Reason:** The guide requires integration into already-implemented flag consumers, if any exist. `adc` and `sbb` use `CF` as an arithmetic input, and `cmc` reads `CF` before complementing it.
- **Risk:** The guide's examples emphasize conditional jumps, so carry arithmetic could be missed by future readers if not documented.
- **How to change later:** Keep the helper generic and continue adding consumers explicitly as future phases introduce instructions that read flags.

### Assumption 2

- **Assumption:** Default `undefined_flag_use_policy` should remain `off`.
- **Reason:** The guide says browser default behavior should remain compatible with earlier behavior unless a later settings/UI phase changes it.
- **Risk:** Website users cannot trigger `undefined-flag-use` diagnostics until a future UI/settings milestone exposes the policy.
- **How to change later:** Add a browser settings control in a later UI/settings phase and route that setting into the same policy field.

### Assumption 3

- **Assumption:** Warning mode should not clear invalid flag metadata.
- **Reason:** The helper contract says warning emission alone must not clear validity metadata.
- **Risk:** A later consumer can warn again for the same invalid flag until an instruction architecturally defines that flag.
- **How to change later:** Add a separate diagnostic de-duplication policy only if a future diagnostics milestone explicitly requires it.

### Assumption 4

- **Assumption:** In warning mode, a consumer that continues may subsequently define flags normally.
- **Reason:** Warning mode explicitly continues execution using the deterministic preserved value, after which normal instruction semantics apply.
- **Risk:** For instructions such as `adc` and `sbb`, the consumed flag may influence arithmetic before the instruction writes new flag values.
- **How to change later:** Add instruction-specific sequencing documentation if a future audit wants a more formal read-before-write model for every flag-consuming instruction.

### Assumption 5

- **Assumption:** Byte offsets in manual testing should not be treated as fixed across manually-created files.
- **Reason:** Byte offsets vary with LF vs CRLF line endings and leading/trailing whitespace, while line, column, span length, diagnostic code, and semantic output remain stable.
- **Risk:** Manual testers may see different byte offsets from examples.
- **How to change later:** Document manual expected outputs in terms of semantic JSON fields and line/column/span checks, leaving exact byte offsets to automated fixtures.

## 6. Design summary

### CPU/diagnostic design

Phase 50A added per-modeled-flag validity metadata. Phase 50B uses that metadata at consumption time instead of changing producer behavior.

The new helper follows this model:

1. Receive the consumer mnemonic, source location, consumed flag set, active policy, and diagnostics sink.
2. Inspect validity metadata for each consumed flag.
3. If all consumed flags are valid, return success.
4. If some consumed flags are invalid and policy is `off`, return success without diagnostics.
5. If policy is `warn`, emit `undefined-flag-use` and return success.
6. If policy is `error`, emit `undefined-flag-use` and return a runtime-error result before consumer mutation.

### Executor integration

The executor calls the helper before already-implemented `CF` consumers:

- `adc` calls the helper before reading `CF` and before mutating its destination.
- `sbb` calls the helper before reading `CF` and before mutating its destination.
- `cmc` calls the helper before reading/toggling `CF`.

This preserves the no-partial-mutation guarantee in error mode.

### Source-run/API integration

The source-run options now carry the undefined-flag-use policy. Existing normal/default calls continue using `off`, so browser behavior remains unchanged. The native diagnostic JSON producer can set the policy from `MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE` for local/manual tests.

### Rendering integration

The web diagnostic formatter renders the new structured fields in normal Simulator Messages text. Exact warning and runtime-error rendered output is tested through the Node diagnostic rendering harness.

## 7. Files changed

Final Phase 50B changed files:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_cpu.c
src/core/vm_cpu.h
src/core/vm_exec.c
src/core/vm_exec.h
src/wasm/wasm_api.c
src/wasm/wasm_api.h
tests/core/diagnostic_json_producer.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
```

Changed-files packages produced:

```text
/mnt/data/milestone50B_changed_files.zip
/mnt/data/milestone50B_compliance_review_changed_files.zip
/mnt/data/milestone50B_second_review_changed_files.zip
```

The latest package is:

```text
/mnt/data/milestone50B_second_review_changed_files.zip
```

## 8. Tests added

### Native/helper/executor tests

Added coverage for:

- consuming valid flags;
- invalid consumed flag with policy `off`;
- invalid consumed flag with policy `warn`;
- invalid consumed flag with policy `error`;
- multiple invalid consumed flags in one diagnostic;
- warning mode preserving validity metadata;
- error mode preserving flag values and validity metadata;
- `adc` integration;
- `sbb` integration;
- `cmc` integration;
- no mutation when error occurs before a flag consumer.

### Source-run tests

Added coverage for:

- default/off behavior remains compatible with Milestone 50A and earlier;
- `warn` mode emits `undefined-flag-use` and still completes;
- `error` mode emits `undefined-flag-use` and stops before register mutation;
- `error` mode stops before `cmc` toggles `CF`;
- `error` mode stops before memory-destination mutation;
- error mode does not create memory-change rows;
- no `execution-complete` message is emitted after a runtime error.

### Rendered Simulator Messages tests

Added exact rendered-message coverage for:

- `undefined-flag-use` simulator-warning;
- `undefined-flag-use` runtime-error.

### Static/structure tests

Updated milestone structure checks to assert Phase 50B artifacts and to ensure the new helper, diagnostics, options, and tests remain present.

## 9. Commands used to test

Repository verification before implementation:

```bash
cd /mnt/data/repo_verify_50A
python3 scripts/run_tests.py
```

Main implementation test command:

```bash
cd /mnt/data/repo_50B_impl
python3 scripts/run_tests.py
```

First compliance review test command:

```bash
cd /mnt/data/repo_50B_impl
python3 scripts/run_tests.py
```

Second compliance review test command:

```bash
cd /mnt/data/repo_50B_second_review
python3 scripts/run_tests.py
```

Final relevant regression commands:

```bash
cd /mnt/data/repo_50B_second_review
python3 - <<'PY'
import scripts.run_tests as rt
rt.run_structure_tests()
print('structure checks passed')
PY
```

```bash
cd /mnt/data/repo_50B_second_review
./build/tests/test_vm_exec
./build/tests/test_wasm_source_run
MASM32_DIAGNOSTIC_JSON_PRODUCER=$PWD/build/tests/diagnostic_json_producer node tests/web/test_diagnostic_rendering.mjs
```

Manual diagnostic producer commands used/recommended:

```cmd
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=off
build\tests\diagnostic_json_producer.exe program.asm
```

```cmd
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=warn
build\tests\diagnostic_json_producer.exe program.asm
```

```cmd
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=error
build\tests\diagnostic_json_producer.exe program.asm
```

## 10. Pass/fail results

Repository verification result before implementation:

```text
All implemented milestone tests passed.
```

Implementation result:

```text
All implemented milestone tests passed.
```

First compliance review result:

```text
All implemented milestone tests passed.
```

Second compliance review result:

```text
All implemented milestone tests passed.
```

Final relevant test results:

```text
structure checks passed
Executor tests through Milestone 50B passed.
Source execution tests through Phase 50B regression coverage passed.
PASS renders undefined flag-use warning exactly
PASS renders undefined flag-use runtime error exactly
```

A complete aggregate pass in the finalized tree also ended with:

```text
All implemented milestone tests passed.
```

Manual user-test follow-up results:

- `warn` policy produced `undefined-flag-use` and completed successfully.
- `error` policy for `adc ebx, 0` stopped before register mutation.
- `error` policy for `adc value, 0` stopped before memory mutation and produced no memory-change row.

## 11. Manual/browser testing guidance and expected outputs

### Browser testing

The Phase 50B warn/error policy is not selectable on the served website yet. Browser testing is limited to default/off regression behavior.

Program:

```asm
.code
main PROC
    stc
    mov al, 1
    shl al, 8
    mov ebx, 0
    adc ebx, 0
main ENDP
END main
```

Expected default website behavior:

- `undefined-shift-flag` producer warning appears.
- No `undefined-flag-use` warning appears by default.
- Execution completes successfully.
- `EBX = 00000001h / 1`.
- Program Console remains empty.
- No memory-change rows are emitted.

Regression signs:

- Website emits `undefined-flag-use` by default.
- Website blocks `adc ebx, 0` by default.
- `EBX` is not `00000001h / 1`.
- Existing `undefined-shift-flag` warning disappears.

### Windows CMD local testing

Required setup:

- Visual Studio Developer Command Prompt, or another CMD environment with the native C compiler used by `scripts/run_tests.py`.
- Node.js on `PATH` for web/formatter tests.
- Emscripten is not required for native/local Phase 50B tests.

Build/run tests:

```cmd
py scripts\run_tests.py
```

Expected final output:

```text
All implemented milestone tests passed.
```

#### Manual Program 1 - off/default policy

`program.asm`:

```asm
.code
main PROC
    stc
    mov al, 1
    shl al, 8
    mov ebx, 0
    adc ebx, 0
main ENDP
END main
```

Command:

```cmd
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=off
build\tests\diagnostic_json_producer.exe program.asm
```

Expected:

- `"ok":true`
- `"status":"ok"`
- `"instructionCount":5`
- `EBX = 00000001h / 1`
- no `undefined-flag-use` diagnostic
- `undefined-shift-flag` producer warning still present
- `execution-complete` present

#### Manual Program 2 - warn policy

Use the same `program.asm`.

Command:

```cmd
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=warn
build\tests\diagnostic_json_producer.exe program.asm
```

Expected:

- `"ok":true`
- `"status":"ok"`
- `"instructionCount":5`
- `EBX = 00000001h / 1`
- `undefined-shift-flag` warning present
- `undefined-flag-use` warning present
- `execution-complete` present
- `undefined-flag-use` contains:
  - `"consumedFlags":["CF"]`
  - `"producerMnemonic":"SHL"`
  - `"producerCode":"undefined-shift-flag"`
  - `"producerLine":5`

#### Manual Program 3 - error policy before register mutation

Use the same `program.asm`.

Command:

```cmd
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=error
build\tests\diagnostic_json_producer.exe program.asm
```

Expected:

- `"ok":false`
- `"status":"execution-error"`
- `"instructionCount":4`
- `EBX = 00000000h / 0`
- `EFLAGS = 00000041h / 65`
- no memory changes
- no `execution-complete`
- one runtime-error `undefined-flag-use` diagnostic at `adc ebx, 0`

#### Manual Program 4 - error policy before memory mutation

`program.asm`:

```asm
.data
value DWORD 5
.code
main PROC
    stc
    mov al, 1
    shl al, 8
    adc value, 0
main ENDP
END main
```

Command:

```cmd
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=error
build\tests\diagnostic_json_producer.exe program.asm
```

Expected:

- `"ok":false`
- `"status":"execution-error"`
- `"instructionCount":3`
- `"memoryChanges":[]`
- no `execution-complete`
- one runtime-error `undefined-flag-use` diagnostic at `adc value, 0`

Manual note:

- Exact `byteOffset` values may differ between LF and CRLF line endings. Manual tests should treat line, column, span length, diagnostic code, registers, memory changes, and status as authoritative.

## 12. Compliance review summary

First compliance review found and fixed:

- stale `src/core/vm_exec.h` header wording that omitted later rotate support;
- stale `tests/core/test_wasm_source_run.c` header wording saying Phase 50 instead of Milestone 50B;
- missing direct source-run coverage for `sbb` as an integrated `CF` consumer.

Fixes applied:

- updated stale file-header wording;
- added `test_phase50b_undefined_flag_use_sbb_warn_policy_source_run`;
- reran aggregate tests successfully.

Review verdict:

```text
complete
```

## 13. Re-review summary

Second compliance review found and fixed:

- a coverage gap where error-mode source-run tests proved no register mutation but did not directly prove no memory-destination mutation or memory-change-row suppression.

Fix applied:

- added `test_phase50b_undefined_flag_use_memory_destination_error_source_run`.

The new test verifies:

- `adc value, 0` stops before consuming invalid `CF` in error mode;
- memory is not mutated;
- no memory-change rows are emitted;
- no `execution-complete` message is emitted.

Second review verdict:

```text
complete
```

## 14. User-test follow-up summary

Initial user manual tests showed `warn` and `error` behaving like `off`. Diagnosis:

- The behavior matched a stale build artifact or environment-variable issue, not the finalized implementation.
- The current 50B tree reproduced correct `warn` and `error` behavior.
- The likely causes were either not rebuilding `diagnostic_json_producer.exe` after applying 50B changes or setting the environment variable in PowerShell using CMD syntax.

Clarifications provided:

- In CMD:

```cmd
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=warn
```

- In PowerShell:

```powershell
$env:MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE = "warn"
```

After cleaning artifacts and rebuilding, the user reran the manual tests:

- `warn` mode matched expected behavior: `undefined-flag-use` warning appeared and execution completed.
- `error` mode before register mutation matched expected behavior: execution stopped before `adc ebx, 0`, `EBX` stayed zero, and no `execution-complete` was emitted.
- `error` mode before memory mutation matched expected behavior: execution stopped before `adc value, 0`, no memory-change rows were emitted, and no `execution-complete` was emitted.

No code changes were required during user-test triage.

## 15. Known limitations

- The normal served website does not expose an undefined-flag-use policy setting.
- Default browser behavior remains unchanged: `undefined-flag-use` is off unless a later UI/settings milestone exposes it.
- The JSON `phase` value remains numeric `50`, consistent with the existing metadata path and the precedent from Phase 50A internal infrastructure.
- The implementation covers already-implemented flag consumers only: `adc`, `sbb`, and `cmc`.
- Future conditional jumps and other future flag consumers still need to call the helper when implemented.
- Emscripten was not installed in the execution environment used for this session, so a fresh Wasm/browser rebuild was not performed here.
- Exact byte offsets in manual tests may vary depending on file line endings and whitespace.

## 16. Next recommended milestone

The next canonical guide phase is:

```text
Phase 51 - Post-30 Memory, Diagnostic, Irvine, and Instruction Integration Smoke Harness
```

Recommended next repository/archive name:

```text
Latest_repository_state_milestone_50B.zip
```

## 17. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

```text
/mnt/data/milestone50B_changed_files.zip
/mnt/data/milestone50B_compliance_review_changed_files.zip
/mnt/data/milestone50B_second_review_changed_files.zip
```

Latest recommended changed-files package:

```text
/mnt/data/milestone50B_second_review_changed_files.zip
```

The package preserves repository structure and contains the final reviewed changed files for Milestone 50B.
