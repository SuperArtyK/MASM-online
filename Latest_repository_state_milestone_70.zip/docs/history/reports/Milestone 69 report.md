# Milestone 69 report - Direct CALL to User Procedures

## 1. Milestone title and scope

**Target milestone:** Phase 69 - Direct CALL to User Procedures  
**Latest completed baseline:** Phase 68B - EIP Pseudo-Code Address Display and Source-Operand Restrictions  
**Recommended next repository archive after applying this milestone:** `Latest_repository_state_milestone_69.zip`

Phase 69 implements direct near `CALL` execution to user-defined `PROC` entries in the Online MASM32 Educational Simulator. The feature is intentionally narrow: it accepts and executes source such as `call Helper` only when `Helper` resolves to a user procedure entry. It does not implement `RET`, Irvine32 routine dispatch, source-level stack instructions, procedure frames, calling conventions, or external/API calls.

The milestone adds parser/lowering support, VM IR support, executor behavior, source-run integration, diagnostics, rendered-message coverage, documentation updates, web status/default sample updates, and static checks so the active repository state reflects Phase 69.

## 2. Source-of-truth files used

The active canonical source-of-truth pair was confirmed as:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Additional active documentation and history used during implementation and review:

- `docs/SUPPORTED_SYNTAX.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/history/reports/Milestone 68B report.md`
- `README.md`
- `web/index.html`

The expected but unavailable 68B-specific audit/handoff report was:

- `docs/history/PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_68B.md`

Only older audit reports were present:

- `docs/history/PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `docs/history/PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`

The latest repository archive inspected at the start of the session was:

- `/mnt/data/Latest_repository_state_milestone_68B.zip`

## 3. Exact requirements implemented

Phase 69 requirements implemented:

1. **Direct user-procedure CALL parsing and lowering**
   - `call Helper` is accepted when `Helper` resolves to a user-defined `PROC` entry.
   - Accepted direct user-procedure calls lower to executable IR instead of broad unsupported-instruction diagnostics.
   - CALL fixups are kept separate from branch fixups so user procedure entries can be accepted while labels, data symbols, equates, externals, and Irvine32 names remain rejected.

2. **CASEMAP-aware user procedure resolution**
   - Default / `OPTION CASEMAP:ALL` behavior resolves procedure targets case-insensitively.
   - `OPTION CASEMAP:NONE` requires exact-case user procedure lookup from that directive forward.
   - The implementation does not use CASEMAP to turn reserved words, external names, or Irvine32 names into user procedure entries.

3. **CALL-specific VM IR support**
   - Added `VM_IR_OPCODE_CALL`.
   - CALL target metadata reuses the existing direct target style where appropriate, while retaining distinct opcode identity for execution and diagnostics.

4. **Runtime CALL behavior**
   - The executor resolves the lowered target to a valid procedure-entry instruction target.
   - The return token is computed as the Phase 68B pseudo-EIP of the executable lowered instruction immediately after the CALL.
   - The stack destination is computed as `ESP - 4`.
   - The implicit return-token write is routed through central checked VM memory helpers.
   - On success, the VM writes the return token, updates `ESP`, records the stack memory change, transfers instruction pointer control to the procedure entry, and displays `EIP` as the target procedure pseudo-code address.
   - Modeled flags and flag-validity metadata are preserved.

5. **No-partial-mutation failure behavior**
   - A failed CALL stack write does not partially commit the CALL.
   - On failure, the externally visible instruction pointer, `ESP`, memory, memory-change rows, Program Console, flags, and completion state remain unmodified by the failed CALL.
   - Invalid stack destinations use the central checked-memory diagnostic path.

6. **Source-run and Wasm API integration**
   - Source-run metadata now reports Phase 69.
   - CALL runtime errors surface through structured source-run diagnostics.
   - Planned-write validation recognizes CALL's internal stack write.
   - Valid CALL stack writes are not rejected solely because strict declared-object validation is enabled and the stack address is outside declared `.data`, `.DATA?`, or `.CONST` objects.

7. **Diagnostics and rendered messages**
   - Invalid CALL target diagnostics are structured and target-token scoped.
   - Ordinary labels, data symbols, numeric equates, register targets, memory/indirect targets, `OFFSET` targets, Irvine32 routines, external/API names, and unknown targets remain rejected with precise messages.
   - Runtime stack-write failures preserve line, column, byte offset, and span length.
   - Rendered Simulator Messages tests cover user-visible diagnostics.

8. **Documentation and web status**
   - `README.md`, `docs/SUPPORTED_SYNTAX.md`, `docs/BUILDING_AND_DEVELOPMENT.md`, `docs/MILESTONE_HISTORY.md`, and `docs/FULL_IMPLEMENTATION_SPEC.md` were updated where active current-state wording would otherwise imply that all CALL behavior remains deferred.
   - `web/index.html` was updated to show Phase 69 status and a direct CALL default editor sample.
   - `web/src/protocol.js` was updated for Phase 69 protocol metadata.
   - Static checks were updated to enforce corrected Phase 69 wording and avoid reintroducing long/stale current-state blocks.

## 4. Explicit non-goals and future work not implemented

The following remain intentionally deferred:

- `RET` execution.
- Root `RET` behavior.
- Return-address validation beyond the direct CALL return-token write.
- `RET imm16`.
- `LEAVE`.
- Source-level `PUSH` and `POP`.
- Procedure frames, stack-frame metadata, and local stack objects.
- `PROC USES`.
- `LOCAL`.
- `PROTO`.
- `INVOKE`.
- `ADDR`.
- Irvine32 routine dispatch for calls such as `call WriteString`.
- Windows/API/external routine execution such as `call ExitProcess`.
- Indirect CALL forms, including register, memory, pointer, far, expression, and `OFFSET` CALL targets.
- Call-depth limits, recursion diagnostics, call traces, and debugger call-stack UI.
- A new `stack-overflow` diagnostic.
- Treating pseudo-EIP values as code memory, data memory addresses, source offsets, PE RVAs, linker addresses, or native addresses.
- Any full x86 emulator, full MASM compiler, Windows emulator, PE loader/linker, or WinAPI simulator behavior.

## 5. Assumptions used

- **Assumption:** CALL target metadata can reuse the existing direct branch-target operand representation while preserving a distinct `VM_IR_OPCODE_CALL` opcode.  
  **Reason:** Phase 69 needs only a direct lowered instruction target and does not yet need call-frame metadata.  
  **Risk:** Future phases may need procedure identity, active frame data, or call trace metadata that cannot be represented by a raw target alone.  
  **How to change later:** Add CALL-specific metadata fields or an auxiliary procedure-index mapping in the owning future phase.

- **Assumption:** The normal CALL return token is `pseudo_eip(call_instruction_index + 1)`.  
  **Reason:** The guide specifies the Phase 68B pseudo-EIP model and requires the return token to represent the executable lowered instruction immediately after CALL.  
  **Risk:** A terminal CALL edge case may need different behavior once RET/root termination is implemented.  
  **How to change later:** Define terminal/root return-token handling in the Phase 70+ RET work without changing ordinary CALL behavior.

- **Assumption:** Runtime malformed CALL metadata should report a CALL-specific invalid target status.  
  **Reason:** Parser diagnostics distinguish invalid CALL targets from invalid branch targets, and a CALL-specific runtime failure is clearer.  
  **Risk:** Consumers expecting only branch-target failures might need protocol compatibility if they introspect runtime error codes.  
  **How to change later:** Add documented aliases or compatibility mapping if future protocol requirements call for it.

- **Assumption:** Strict declared-object validation must not reject CALL's internal stack write merely because stack memory is outside declared data objects.  
  **Reason:** The stack is a valid VM memory region and the guide explicitly requires CALL's implicit stack write to be accepted when region/permission checks pass.  
  **Risk:** Future stack-object teaching features may want stricter stack-specific validation.  
  **How to change later:** Add stack-region declared-object or frame-object metadata in a future stack/frame milestone.

- **Assumption:** Phase 69 should not add temporary RET/root termination behavior to make CALL programs complete more naturally.  
  **Reason:** RET is explicitly Phase 70. Adding temporary RET behavior would blur phase ownership and create future cleanup risk.  
  **Risk:** Manual examples must avoid implying full procedure call/return support.  
  **How to change later:** Implement RET properly in Phase 70 with explicit return-address validation and tests.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and deferred-status wording reviewed during planning and compliance passes included:

- Active README/status wording that described procedure entries as future CALL/INVOKE metadata.
- Active supported-syntax wording that listed `call` broadly as future or deferred.
- Active browser status/default-code wording that grouped CALL with RET and source stack features as deferred.
- Existing test expectations that all CALL forms produced broad unsupported-CALL diagnostics.
- `src/wasm/wasm_api.c` future-instruction TODO for memory-reading opcodes.
- Active future/deferred notes for RET, source-level PUSH/POP, frames, LOCAL, USES, PROTO, INVOKE, ADDR, Irvine32 routine dispatch, and unsupported CALL forms.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Broad active “CALL deferred” README/status text was corrected.
- Broad active supported-syntax “CALL future” wording was corrected to distinguish implemented direct user-procedure CALL from unsupported CALL forms.
- Browser status/default-code wording was corrected to show Phase 69 behavior.
- Existing broad unsupported-CALL test expectations were replaced or split so direct user-procedure CALL succeeds while invalid CALL target classes remain rejected.
- Source/test comments that described CALL target classification as future-only were corrected.

### Future-owned TODO-style notes intentionally preserved

- RET and root RET.
- Source-level PUSH/POP.
- Procedure frames and stack locals.
- LOCAL, USES, PROTO, INVOKE, ADDR.
- Irvine32 routine dispatch.
- External/API routine execution.
- Unsupported indirect, memory, far, expression, and OFFSET CALL forms.
- Future memory-reading-opcode TODO in `src/wasm/wasm_api.c`.

### Stale or contradicted TODO-style notes corrected

- Corrected stale wording that direct CALL was still completely future behavior.
- Corrected stale Phase 68/68B assertion descriptions after Phase 69 metadata was implemented.
- Corrected stale next-milestone title from `Phase 70 - RET from User Procedures` to `Phase 70 - RET Execution and Return Address Validation`.
- Corrected historical Phase 68 wording in `docs/MILESTONE_HISTORY.md` so it now says Phase 68 metadata is used by Phase 69 direct CALL and may also support future INVOKE work.

### Unresolved TODO-related risks

None blocking for Phase 69. Remaining TODO/deferred notes are future-owned and intentionally preserved.

## 8. Design summary

The implementation adds direct CALL as a first-class VM IR opcode rather than treating it as an unsupported source instruction. Parser/lowering uses the existing procedure metadata and call-target classifier lineage from Phase 68, but narrows Phase 69 acceptance to user `PROC` entries only. Ordinary labels, data symbols, equates, external/API symbols, Irvine32 routine names, unknown names, and indirect forms remain invalid or deferred.

At execution time, CALL performs an internal checked write of a pseudo-EIP return token to `ESP - 4`, then transfers control to the procedure entry. The stack write is modeled as VM memory, not as source-level PUSH. The executor uses no-partial-mutation behavior for failed stack writes: validation and write failure leave externally visible state unchanged except for the emitted runtime diagnostic.

The implementation preserves the Phase 68B pseudo-EIP boundary. CALL return tokens are simulator pseudo-code addresses, not native addresses, source locations, linker addresses, PE RVAs, or source-readable data-memory values.

Documentation and web status were deliberately tightened during compliance passes to avoid long “current state” ledgers. Current-status sections now summarize Phase 69 briefly and point detailed syntax behavior to the appropriate docs.

## 9. Files changed

C core and parser/runtime integration:

- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_ir.c`
- `src/core/vm_ir.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`

Tests:

- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`

Web/UI protocol and page:

- `web/index.html`
- `web/src/protocol.js`

Docs and test runner/static checks:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`

## 10. Tests added

Parser and lowering tests:

- Accepted direct user-procedure CALL.
- Default CASEMAP / CASEMAP:ALL direct CALL resolution.
- CASEMAP:NONE exact-case resolution and mismatch rejection.
- Rejection of ordinary labels, data symbols, equates, unknown identifiers, external/API targets, Irvine32 routine names, register targets, memory/indirect targets, and OFFSET targets.

Executor tests:

- Successful CALL stack write and transfer to user procedure.
- CALL return token equals the pseudo-EIP of the next executable instruction.
- CALL preserves flags and flag-validity metadata.
- Failed CALL stack write rolls back instruction pointer, ESP, memory, memory changes, flags, Program Console, and completion state.
- Malformed CALL metadata reports invalid CALL target behavior.

Source-run and policy tests:

- Successful direct CALL behavior without requiring RET.
- Failed CALL stack write via invalid `ESP` value.
- Irvine32 routine CALL remains deferred.
- Strict declared-object validation does not reject a valid CALL stack write outside declared data objects.

Web/rendering/protocol tests:

- Rendered Simulator Messages for invalid direct CALL target diagnostics.
- Rendered Simulator Messages for CALL checked stack-write failure.
- Protocol metadata reports Phase 69.
- Static documentation checks enforce concise Phase 69 current-status wording and correct next-milestone wording.

## 11. Commands used to test

Focused commands run during implementation and compliance:

```text
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command run:

```text
python3 scripts/run_tests.py --all
```

Final aggregate command from the final gap check:

```text
timeout 300 python3 scripts/run_tests.py --all
```

No documented subgroup or fixture-family reruns were required after the final gap check because the focused groups and aggregate command completed successfully.

Skipped dependency check:

- Browser/Wasm rebuild smoke was skipped because `emcc` is unavailable in the assistant/container environment.

## 12. Pass/fail results

Final focused group results:

- `--structure`: PASS
- `--native`: PASS
- `--source-run`: PASS
- `--web`: PASS
- `--diagnostics`: PASS
- `--protocol`: PASS
- `--static`: PASS

Final aggregate result:

- `python3 scripts/run_tests.py --all`: PASS
- Classification: aggregate completed and passed.

Dependency skip:

- Browser/Wasm rebuild smoke: skipped because `emcc` is unavailable.
- Classification: group/dependency skipped because dependency was unavailable.

Earlier compliance passes had aggregate timeout behavior in the assistant/container environment while focused groups passed; those were not claimed as aggregate success. The final gap check did complete aggregate execution successfully.

## 13. Manual/browser testing guidance and expected outputs

Website testing is valid after rebuilding Wasm with Emscripten. From Windows CMD:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000/web/index.html
```

Stop the server after testing:

```cmd
scripts\windows\stop_web.cmd
```

If `build_wasm.cmd` reports `ERROR: emcc was not found.`, served-website runtime testing is not valid yet. Local tests remain valid.

### Manual Program 1 - Direct CALL success

```asm
.stack 4096
.data
value DWORD 7
.code
main PROC
    call Helper       ; Writes pseudo-EIP return token at ESP - 4
    mov eax, value    ; Not reached until RET exists in a later phase
main ENDP

Helper PROC
    mov ebx, value
Helper ENDP
END main
```

Expected behavior:

- Run status: success.
- Program Console: empty.
- Memory changes: empty in the website output.
- `EAX = 00000000h`
- `EBX = 00000007h`
- `ESP = 008FFFFCh`
- `EIP = 00401008h`
- `EFLAGS = 00000000h`
- Simulator Messages include the `.stack` metadata notice, startup-state notice, and `Execution completed successfully.`

Regression signs:

- `CALL is not supported yet` appears.
- `EBX` remains zero.
- `EAX` becomes 7.
- `ESP` remains `00900000h`.
- RET-like behavior appears.

### Manual Program 2 - CALL stack-write failure rollback

```asm
.code
main PROC
    mov esp, 0
    call Helper
    mov eax, 1
main ENDP

Helper PROC
    mov ebx, 2
Helper ENDP
END main
```

Expected behavior:

- Run status: execution error.
- Program Console: empty.
- Memory changes: empty.
- `EAX = 00000000h`
- `EBX = 00000000h`
- `ESP = 00000000h`
- `EIP = 00401004h`
- Runtime diagnostic:

```text
[runtime-error] invalid-address line 4, column 5, byte offset 35, span length 11: Invalid memory write at FFFFFFFCh for 4 bytes. The address is outside the simulator's configured memory regions.
```

Regression signs:

- `ESP = FFFFFFFCh`.
- `EBX = 00000002h`.
- `EAX = 00000001h`.
- Any memory-change row appears.
- Execution completes successfully.

### Manual Program 3 - Ordinary label rejected as CALL target

```asm
.code
main PROC
LabelOnly:
    call LabelOnly
main ENDP
END main
```

Expected diagnostic:

```text
[assembly-error] invalid-call-target line 4, column 10, byte offset 36, span length 9: CALL target cannot be an ordinary code label. Phase 69 direct CALL accepts only user procedure entries.
```

Regression signs:

- The program executes.
- The label is treated like a jump target.
- The diagnostic says all CALL is unsupported.
- The diagnostic span does not point at `LabelOnly`.

### Manual Program 4 - Irvine32 routine CALL remains deferred

```asm
INCLUDE Irvine32.inc
.code
main PROC
    call WriteString
main ENDP
END main
```

Expected diagnostic:

```text
[unsupported-feature] unsupported-irvine32-routine line 4, column 10, byte offset 46, span length 11: Recognized Irvine32 routine or virtual terminator, but CALL dispatch for Irvine32 routine names is deferred to a later Irvine32 routine-dispatch phase.
```

Regression signs:

- `call WriteString` executes.
- Program Console prints output.
- Diagnostic says direct user-procedure CALL failed.
- Diagnostic says all CALL is unsupported.

### Windows CMD local testing

```cmd
set CC=clang
python scripts\run_tests.py --source-run
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --web
python scripts\run_tests.py --static
```

Expected snippets:

```text
[source-run] PASS - source-run integration binary passed independently
Selected test groups passed.
```

```text
[diagnostics] PASS - native diagnostic producer and rendered messages passed
Selected test groups passed.
```

```text
[web] PASS
Selected test groups passed.
```

```text
[static] PASS
Selected test groups passed.
```

## 14. Compliance review summary

First compliance review found and fixed stale wording and one test coverage gap:

- Corrected stale `src/core/vm_exec.h` wording that still described CALL stack mutation as future work.
- Corrected stale active supported-syntax wording that said direct CALL/internal CALL writes were future behavior.
- Corrected stale default-code/comment wording in `web/index.html`.
- Updated stale Phase 68/68B test-description text.
- Added source-run regression coverage proving strict declared-object validation does not reject valid CALL stack writes.

Tests rerun after first compliance review:

- `--structure`: PASS
- `--native`: PASS
- `--source-run`: PASS
- `--web`: PASS
- `--diagnostics`: PASS
- `--protocol`: PASS
- `--static`: PASS

## 15. Re-review summary

Second compliance review found and fixed additional stale wording:

- Removed direct `call procedureName` from future-only syntax lists.
- Updated spec current-status examples that still described CALL execution as future work.
- Updated procedure-entry metadata wording to acknowledge Phase 69 direct CALL.
- Updated parser/test comments that described CALL target classification as future-only.
- Renamed a stale Phase 68B metadata test function to Phase 69 wording.

Third compliance review focused on stale documentation and overlong current-state messages:

- Shortened `README.md` current-status section.
- Shortened the top of `docs/SUPPORTED_SYNTAX.md`.
- Corrected `INCLUDE Irvine32.inc` wording from broad “does not implement call” to “does not implement Irvine32 routine calls.”
- Clarified full-spec entry-boundary wording.
- Shortened the browser landing paragraph.
- Updated static checks to enforce the concise status wording.

Final gap check found and fixed:

- Stale next-milestone title in active docs/static checks.
- Stale Phase 68 history wording that described direct CALL target metadata as purely future-facing.

Final result:

- No missing Phase 69 runtime implementation, diagnostics, test coverage, documentation, or web-facing behavior remained.
- No accidental future milestone behavior was found.

## 16. User-test follow-up summary

Manual testing instructions were provided in Prompt 7. The user reported that everything appeared to pass and proceeded directly to the final gap check. No discrepancy triage or Prompt 8 fixes were required.

## 17. Known limitations

- `RET` is not implemented.
- Direct CALL can transfer into a helper procedure, but full call/return procedure flow belongs to Phase 70.
- Irvine32 routine calls remain deferred.
- External/API calls remain unsupported.
- Source-level PUSH/POP, frames, LOCAL, USES, PROTO, INVOKE, and ADDR remain deferred.
- Unsupported indirect/far/memory/register/expression CALL forms remain rejected.
- `web/dist` Wasm artifacts were not rebuilt in the assistant/container environment because `emcc` is unavailable.
- Served-website runtime testing requires rebuilding Wasm locally with Emscripten after applying the changed files.

## 18. Next recommended milestone

**Phase 70 - RET Execution and Return Address Validation**

Recommended full repository archive name after applying Phase 69:

```text
Latest_repository_state_milestone_69.zip
```

## 19. Changed-files ZIP/packages produced

The following changed-files packages were produced during the milestone session:

- `milestone_69_implementation.zip`
- `milestone_69_first_compliance_check.zip`
- `milestone_69_second_compliance_check.zip`
- `milestone_69_third_compliance_check.zip`
- `milestone_69_final_compliance_check.zip`

The final compliance package contains the last documentation/static-check corrections from the final gap check. The full latest repository archive was recommended but not produced as part of this report step.
