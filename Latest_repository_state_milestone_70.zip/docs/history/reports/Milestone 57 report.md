# Milestone 57 report - Signed IDIV

## 1. Milestone title and scope

Milestone 57 implements **Phase 57 - Signed IDIV** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added executable runtime support for one-operand signed `idiv`.
- Supported 8-bit, 16-bit, and 32-bit register divisor operands.
- Supported 8-bit, 16-bit, and 32-bit memory divisor operands where the memory width is explicit or inferable through existing memory-width rules.
- Supported memory divisors through typed symbols, typed symbol offsets, unsigned `BYTE PTR` / `WORD PTR` / `DWORD PTR` forms, and signed `SBYTE PTR` / `SWORD PTR` / `SDWORD PTR` aliases by width.
- Implemented x86-style implicit signed dividend/result behavior for MASM32 Educational Mode:
  - `idiv r/m8`: signed `AX / r/m8 -> AL` quotient and `AH` remainder.
  - `idiv r/m16`: signed `DX:AX / r/m16 -> AX` quotient and `DX` remainder.
  - `idiv r/m32`: signed `EDX:EAX / r/m32 -> EAX` quotient and `EDX` remainder.
- Implemented signed division quotient truncation toward zero.
- Implemented signed remainder behavior where the remainder has the same sign as the dividend.
- Added signed `IDIV` coverage for structured runtime diagnostics:
  - `divide-by-zero`;
  - `quotient-overflow`.
- Preserved no-partial-mutation guarantees for divide-by-zero, quotient overflow, invalid memory reads, strict planned-read validation, strict allocated-object validation, strict section-image validation, and strict uninitialized-read validation.
- Preserved modeled flags and flag-validity metadata for successful and failed `idiv` execution.
- Routed memory divisor reads through checked VM memory helpers and existing planned-read validation.
- Ensured memory divisor reads do not create memory-change rows.
- Updated runtime/source-run/browser metadata to report Phase 57.
- Updated documentation, browser status text, default sample, parser tests, executor tests, source-run tests, rendered Simulator Messages tests, protocol tests, static checks, and aggregate test reporting.

The implementation stayed within the target milestone boundary. No unsigned `div` semantic change, QWORD/SQWORD execution, control flow, stack/procedure behavior, scaled-index addressing, carry rotates, broader Irvine32 behavior, macro behavior, WinAPI behavior, PE loading, linker behavior, or host include behavior was implemented.

Repository/archive milestone:

```text
Phase 57 - Signed IDIV
```

Runtime/source-run MASM behavior phase:

```text
Phase 57 - Signed IDIV
```

Status interpretation:

Phase 57 is a runtime-visible MASM behavior milestone. Unlike Phase 56A and Phase 56B maintenance/wording work, this milestone intentionally advances runtime/source-run MASM behavior metadata from Phase 56 - Unsigned DIV to Phase 57 - Signed IDIV.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 56B report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_56B.zip
```

Final repository archive produced after completion:

```text
Latest_repository_state_milestone_57.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 57 is the only target runtime milestone for this implementation session.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- All mandatory memory safety remains routed through checked memory helpers.
- User-visible diagnostics have structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, WinAPI simulator, host include loader, or macro assembler.

## 3. Exact requirements implemented

### 3.1 Accepted syntax

Accepted one-operand signed IDIV forms:

```asm
idiv reg8
idiv reg16
idiv reg32
idiv BYTE PTR [reg32]
idiv WORD PTR [reg32]
idiv DWORD PTR [reg32]
idiv symbol
idiv symbol[offset]
```

Representative accepted register forms:

```asm
idiv bl
idiv bx
idiv ebx
```

Representative accepted memory forms:

```asm
idiv BYTE PTR [esi]
idiv WORD PTR [esi]
idiv DWORD PTR [esi]
idiv divisor
idiv divisors[4]
```

Signed PTR aliases are accepted by executable width:

```asm
idiv SBYTE PTR [esi]
idiv SWORD PTR [esi]
idiv SDWORD PTR [esi]
```

Case-insensitive instruction matching remains preserved through the existing instruction policy:

```asm
IDIV ebx
Idiv ebx
idiv ebx
```

### 3.2 Rejected syntax preserved or added

Rejected forms include:

```asm
idiv 5
idiv eax, ebx
idiv [eax]
idiv QWORD PTR q
idiv SQWORD PTR q
idiv
idiv eax, ebx, ecx
```

Diagnostic behavior:

- `idiv 5` reports `invalid-instruction-operands`.
- `idiv eax, ebx` reports `invalid-instruction-operands`.
- `idiv` with no operand reports `invalid-instruction-operands`.
- `idiv eax, ebx, ecx` reports `invalid-instruction-operands`.
- `idiv [eax]` reports `ambiguous-memory-width` because the memory access width is not inferable.
- `idiv QWORD PTR q` and `idiv SQWORD PTR q` preserve the existing executable-64-bit memory-operation rejection with `unsupported-ptr-width`.

### 3.3 Runtime semantics

For 8-bit divisor operands:

```text
signed AX / signed source8 -> AL quotient, AH remainder
```

For 16-bit divisor operands:

```text
signed DX:AX / signed source16 -> AX quotient, DX remainder
```

For 32-bit divisor operands:

```text
signed EDX:EAX / signed source32 -> EAX quotient, EDX remainder
```

Rules:

- Division is signed.
- Source operands are sign-interpreted at their resolved operand width.
- The dividend is the required implicit accumulator pair for the divisor width.
- The quotient must fit in the signed result register width:
  - `AL`: -128 through 127;
  - `AX`: -32768 through 32767;
  - `EAX`: -2147483648 through 2147483647.
- Quotient calculation truncates toward zero.
- The remainder has the same sign as the dividend.
- If the divisor is zero, execution stops with `divide-by-zero` before writing quotient or remainder registers.
- If the quotient does not fit in the destination register, execution stops with `quotient-overflow` before writing quotient or remainder registers.

### 3.4 Flag behavior

For successful `idiv` execution:

- `CF` is preserved.
- `ZF` is preserved.
- `SF` is preserved.
- `OF` is preserved.
- Phase 50A flag-validity metadata is preserved.
- No `undefined-modeled-flag` or `undefined-shift-flag` producer diagnostic is emitted by `idiv`.

For failed `idiv` execution:

- Modeled flag bits remain unchanged.
- Phase 50A flag-validity metadata remains unchanged.
- Result registers remain unchanged.
- Program Console output remains unchanged.
- Memory-change rows remain unchanged.

### 3.5 Memory behavior

- Register-source `idiv` does not access simulated memory.
- Memory-source `idiv` reads the divisor through checked VM memory helpers.
- Memory-source `idiv` does not write memory.
- Memory-source `idiv` does not create memory-change rows.
- `.CONST` memory divisors are accepted because `idiv` reads them and does not write them.
- Invalid memory reads fail before division.
- Strict planned-read validation fails before division.
- Strict uninitialized-read validation fails before divisor consumption.
- Section-capacity, section-image, and declared-object planned-read policies apply to memory-source `idiv` when enabled.
- Mandatory Level 1 region validation and `.CONST` protection precedence remain unchanged.

### 3.6 Runtime/source-run metadata

Updated runtime/source-run metadata from Phase 56 to Phase 57 where the target milestone explicitly owns runtime behavior metadata:

- source-run JSON phase fields;
- worker/protocol phase expectations;
- browser runtime-status text;
- default browser sample;
- current-status documentation and supported syntax wording;
- test assertions that describe runtime/source-run behavior metadata.

### 3.7 Acceptance behavior

Representative acceptance program:

```asm
.code
main PROC
    mov eax, -100
    cdq
    mov ebx, 7
    idiv ebx
main ENDP
END main
```

Expected result:

```text
EAX = FFFFFFF2h / u: 4294967282 / s: -14
EDX = FFFFFFFEh / u: 4294967294 / s: -2
EBX = 00000007h / u: 7 / s: 7
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console output:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

Representative divide-by-zero diagnostic:

```text
[runtime-error] divide-by-zero ... IDIV divisor operand EBX evaluated to zero. Division by zero is not allowed. Execution stopped before updating the quotient register EAX and remainder register EDX.
```

Representative quotient-overflow diagnostic:

```text
[runtime-error] quotient-overflow ... IDIV quotient is too large to fit in quotient register EAX. Execution stopped before updating the quotient register EAX and remainder register EDX.
```

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 57:

- No changes to unsigned `div` semantics beyond regression protection.
- No new `mul` or `imul` behavior.
- No `cmp`.
- No labels, `jmp`, conditional jumps, or `loop`.
- No `lea` changes.
- No `push`, `pop`, `call`, `ret`, `leave`, or stack behavior.
- No procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`.
- No Irvine32 routine bodies beyond the existing `exit` virtual terminator.
- No Program Console input/output routines.
- No scaled-index addressing.
- No executable QWORD/SQWORD memory operations in MASM32 Educational Mode.
- No carry rotates.
- No Windows API, PE loading, object linking, host include loading, or macro expansion.
- No Extended 32-bit Mode activation.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Existing Phase 56 `div` parser, executor, source-run diagnostic formatting, and planned-read integration were the safest implementation template for Phase 57.
- **Reason:** `div` has the same one-operand implicit-accumulator structure, memory divisor shape, divide-by-zero and quotient-overflow diagnostic family, and no-memory-write behavior.
- **Risk:** Unsigned arithmetic or unsigned overflow checks could be accidentally copied into signed `idiv`.
- **How to change later:** Keep signed and unsigned arithmetic paths explicit. If a future refactor shares helper code, retain width-specific signed and unsigned tests for every operand width.

### Assumption 2

- **Assumption:** `idiv` should be represented as a dedicated IR opcode.
- **Reason:** The guide treats `div` and `idiv` as separate milestones with distinct signedness semantics. A dedicated opcode keeps diagnostics, opcode names, parser tests, and future debugger display unambiguous.
- **Risk:** Adds one opcode that must be included in opcode enumeration, planned-read collection, parser lowering, executor dispatch, diagnostics, and tests.
- **How to change later:** A future internal refactor could share signed/unsigned division helper infrastructure while preserving separate public IR opcode identity.

### Assumption 3

- **Assumption:** Existing `divide-by-zero` and `quotient-overflow` diagnostic codes should be reused for `idiv`.
- **Reason:** The guide explicitly requires those codes and states not to use `division-overflow`.
- **Risk:** Message wording must clearly distinguish `IDIV` from `DIV` while using the same stable diagnostic codes.
- **How to change later:** A future diagnostic-policy phase could add extra diagnostic fields or wording, but should preserve stable codes unless an intentional migration is specified.

### Assumption 4

- **Assumption:** No new user-visible flag-validity UI is needed to prove Phase 50A metadata preservation.
- **Reason:** The project already has native/test-only inspection paths for flag metadata. Phase 57 does not require exposing a new UI surface.
- **Risk:** Metadata preservation is validated by tests rather than manual browser output.
- **How to change later:** A future debugger/status milestone can expose flag-validity metadata in the browser with separate product, protocol, and rendering tests.

### Assumption 5

- **Assumption:** Browser website testing requires a rebuilt Wasm artifact.
- **Reason:** Phase 57 changes C core behavior and Wasm/source-run metadata. The static web page must load an updated Wasm build to exercise `idiv` in the browser.
- **Risk:** If a user serves stale Wasm, the website may still reject `idiv` or report Phase 56.
- **How to change later:** Future build tooling could include a stronger stale-Wasm version check or automated release packaging step.

## 6. Relevant TODO-style notes reviewed

### Target-owned TODO-style notes

- Location:
  ```text
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md:9028
  ```
- Note text or summary:
  ```text
  If the codebase contains a TODO or comment that says future memory-capable opcodes must update planned-read or planned-access collection, Phase 57 owns resolving that TODO for idiv.
  ```
- Classification:
  ```text
  target-owned
  ```
- Reason:
  Phase 57 adds a memory-capable source-only opcode. The guide explicitly makes planned-read integration a Phase 57 responsibility.
- Action for this milestone:
  Resolved by adding `idiv` to planned memory-read and planned access collection, including strict uninitialized-read, declared-object, and section-image validation coverage.

- Location:
  ```text
  src/wasm/wasm_api.c
  ```
- Note text or summary:
  ```text
  TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
  ```
- Classification:
  ```text
  target-owned for IDIV; future-owned for later memory-reading opcodes
  ```
- Reason:
  The note applied directly to `idiv` for Phase 57 while remaining relevant to later memory-reading opcodes.
- Action for this milestone:
  Resolved for `idiv` by adding `VM_IR_OPCODE_IDIV` to the relevant planned-read/planned-access paths. The general future-facing note remains accurate for future opcodes.

- Location:
  ```text
  docs/SUPPORTED_SYNTAX.md
  ```
- Note text or summary:
  Signed `idiv` was listed as still deferred.
- Classification:
  ```text
  target-owned
  ```
- Reason:
  Phase 57 implements signed `idiv`, so the deferred wording would become stale.
- Action for this milestone:
  Updated supported syntax documentation to list `idiv` as supported and remove it from the deferred runtime-instruction list.

- Location:
  ```text
  README.md current-status text
  ```
- Note text or summary:
  Runtime/source-run behavior was listed through Phase 56 - Unsigned DIV, with signed division not yet added.
- Classification:
  ```text
  target-owned
  ```
- Reason:
  Phase 57 is runtime-visible and advances runtime/source-run MASM behavior metadata.
- Action for this milestone:
  Updated README status text to Phase 57 - Signed IDIV.

- Location:
  ```text
  source-run metadata and protocol/status tests
  ```
- Note text or summary:
  Metadata and tests expected Phase 56 runtime behavior.
- Classification:
  ```text
  target-owned
  ```
- Reason:
  Phase 57 intentionally advances runtime/source-run phase metadata.
- Action for this milestone:
  Updated source-run metadata and protocol/status tests to Phase 57.

### Future-owned TODO-style notes

Future-owned TODO-style notes and deferred systems intentionally preserved:

- Future memory-reading opcodes beyond `idiv` still need planned-read integration when those opcodes are implemented.
- Executable QWORD/SQWORD memory operations remain deferred to Extended 32-bit Mode.
- Stack, control flow, procedure behavior, Irvine32 routine expansion, scaled-index addressing, carry rotates, macros, WinAPI, PE/linker, and host include behavior remain deferred.

### Stale or contradicted TODO-style notes

No stale source TODO-style notes were found.

A stale non-TODO file-level comment in `tests/core/test_wasm_source_run.c` was corrected during the second compliance review. It had described the test file as covering “Phase 57 unsigned DIV”; it now correctly describes Phase 57 signed IDIV.

### Unclear TODO-style notes

None remained unclear after source inspection.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Planned-read/planned-access integration was completed for `idiv` memory divisors.
- Supported syntax/current-status documentation was updated for Phase 57.
- README current-status wording was updated for Phase 57.
- Source-run/runtime metadata and related tests were updated for Phase 57.

### Future-owned TODO-style notes intentionally preserved

- Generic future memory-reading opcode planned-read reminder in `src/wasm/wasm_api.c` remains accurate for later opcodes.
- Future stack, control-flow, procedure, Irvine32, QWORD/SQWORD execution, scaled-index, macro, WinAPI, PE/linker, and host include work remains outside Phase 57.

### Stale or contradicted TODO-style notes corrected

- No stale or contradicted source TODO-style notes required correction.
- One stale non-TODO comment was corrected in second review.

### Unresolved TODO-related risks

No unresolved TODO-related risks remain for Phase 57.

## 8. Design summary

### IR and parser design

`idiv` was added as a dedicated IR opcode rather than a mode of `div`. This keeps opcode identity explicit for parser tests, executor dispatch, diagnostics, future debugger output, and opcode-name helpers.

The parser accepts exactly one divisor operand. The divisor can be a register or an unambiguous memory source at 8-bit, 16-bit, or 32-bit width. It rejects immediates, missing operands, extra operands, ambiguous memory width, and executable 64-bit memory widths using existing structured diagnostic families.

### Executor design

The executor implements signed division separately from unsigned `div`:

- It sign-interprets the implicit dividend at the required paired-accumulator width.
- It sign-interprets the divisor at the operand width.
- It checks divisor zero before division.
- It computes quotient and remainder with C99-safe helper logic that avoids committing state until all checks succeed.
- It verifies quotient range before writing result registers.
- It writes quotient and remainder only after validation succeeds.

The implementation preserves the no-partial-mutation policy by restoring or avoiding mutation for all runtime failure paths.

### Memory and validation design

Memory-source `idiv` routes divisor reads through the same checked memory helper and planned-read validation paths used by other memory-reading instructions. The Phase 57 target-owned planned-read TODO was resolved by adding the new opcode to planned-read/planned-access collection.

Strict validation paths stop before division. Warning paths continue according to existing diagnostic policy. Memory divisor reads do not create memory-change rows.

### Diagnostic design

Phase 57 reuses stable diagnostic codes:

- `divide-by-zero`
- `quotient-overflow`
- `ambiguous-memory-width`
- `invalid-instruction-operands`
- `unsupported-ptr-width`

Rendered messages name `IDIV`, identify the divisor operand where available, identify the quotient and remainder registers that would have been updated, and state that execution stopped before mutation. Diagnostics preserve source line, column, byte offset, and span length through existing infrastructure.

### Documentation/status design

Because Phase 57 adds runtime-visible MASM behavior, status surfaces were advanced to Phase 57:

- README current status;
- supported syntax current status;
- browser status text;
- default browser sample;
- source-run/protocol metadata;
- tests that assert runtime phase behavior.

## 9. Files changed

Changed files in the final Phase 57 package:

```text
README.md
docs/SUPPORTED_SYNTAX.md
docs/TESTING_GUIDE.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_exec.h
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

Packages produced:

```text
milestone57_changed_files.zip
milestone57_compliance_changed_files.zip
milestone57_second_review_changed_files.zip
milestone57_final_gap_changed_files.zip
Latest_repository_state_milestone_57.zip
```

Recommended package/archive to keep:

```text
milestone57_final_gap_changed_files.zip
Latest_repository_state_milestone_57.zip
```

## 10. Tests added

### Parser tests

Added parser coverage for accepted `idiv` forms:

- `idiv reg8`
- `idiv reg16`
- `idiv reg32`
- `idiv BYTE PTR [reg32]`
- `idiv WORD PTR [reg32]`
- `idiv DWORD PTR [reg32]`
- `idiv SBYTE PTR [reg32]`
- `idiv SWORD PTR [reg32]`
- `idiv SDWORD PTR [reg32]`
- `idiv symbol`
- `idiv symbol[offset]`
- `.CONST` divisor source

Added parser rejection coverage for:

- `idiv 5`
- `idiv eax, ebx`
- `idiv` with no operand
- `idiv eax, ebx, ecx`
- `idiv [eax]`
- `idiv QWORD PTR q`
- `idiv SQWORD PTR q`

### Native executor tests

Added native executor coverage for:

- 8-bit signed `idiv` success.
- 16-bit signed `idiv` success.
- 32-bit signed `idiv` success.
- Quotient truncation toward zero.
- Remainder sign matching the dividend.
- Negative dividend with positive divisor.
- Positive dividend with negative divisor.
- Negative dividend with negative divisor.
- 32-bit signed `EDX:EAX` dividend use.
- Divide-by-zero no-partial-mutation behavior.
- Quotient-overflow no-partial-mutation behavior.
- Successful flag bit preservation.
- Failed flag bit preservation.
- Successful and failed flag-validity metadata preservation.

### Source-run tests

Added source-run coverage for:

- Successful register-source signed `idiv`.
- Successful memory-source signed `idiv`.
- `.CONST` divisor source.
- Signed PTR alias divisor source.
- Divide-by-zero diagnostics.
- Quotient-overflow diagnostics.
- Ambiguous memory-width diagnostic.
- Strict uninitialized-read planned validation.
- Strict declared-object planned validation.
- Strict section-image planned validation added during compliance review.
- Memory divisor reads producing no memory-change rows.
- Phase 57 metadata.

### Rendered Simulator Messages tests

Added exact rendered-message coverage for:

- `IDIV` divide-by-zero.
- `IDIV` quotient-overflow.
- `IDIV` uninitialized-read warning plus fatal divide-by-zero composition.
- `IDIV` section-image strict planned-read diagnostic added during compliance review.
- Parser diagnostics affected by `idiv` status transition.

### Protocol/static tests

Updated protocol/static coverage for:

- Phase 57 runtime/source-run metadata.
- Browser status text.
- Supported syntax status.
- Stable diagnostic wording audit.
- Test-runner reporting inventory.

## 11. Commands used to test

### Aggregate command

```bash
python3 scripts/run_tests.py --all
```

This completed and passed after implementation and after both compliance review rounds.

### Focused group commands

The following focused groups were run after implementation:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

The following focused groups were rerun during compliance review and final review:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
```

### Subgroup or fixture-family commands

No subgroup or fixture-family reruns were required. Focused groups and aggregate command completed in the assistant/container environment.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because Emscripten/`emcc` was unavailable in the environment.

Observed acceptable skip line:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

## 12. Pass/fail results

### Aggregate completed and passed

Final aggregate result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS

Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

Additional dependency classification:

```text
group skipped because dependency was unavailable, such as emcc
```

This skip applies only to browser/Wasm rebuild smoke and does not indicate failure of the native, source-run, web, diagnostics, protocol, or static test groups.

### Focused group results

Focused group results:

```text
--structure: PASS
--native: PASS
--source-run: PASS
--web: PASS
--diagnostics: PASS
--protocol: PASS
--static: PASS
```

No focused group failed.

No focused group timed out.

No aggregate timeout occurred.

No aggregate failure occurred.

## 13. Manual/browser testing guidance and expected outputs

### Browser testing setup

Phase 57 is browser-testable after rebuilding the Wasm artifact with Emscripten.

Windows CMD setup:

```bat
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

If `emcc` is unavailable, browser/Wasm testing is expected to be skipped. Use local test-suite commands instead.

### Browser program 1 - default signed IDIV success

Paste or use the default Phase 57 sample:

```asm
.code
main PROC
    mov eax, -100
    cdq
    mov ebx, 7
    idiv ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected Memory Changes:

```text
No memory changes.
```

Expected important final registers:

```text
EAX    | FFFFFFF2h / u: 4294967282 / s: -14
EDX    | FFFFFFFEh / u: 4294967294 / s: -2
EBX    | 00000007h / u: 7          / s:  7
EFLAGS | 00000000h / 0
```

### Browser program 2 - memory divisor and signed remainder

```asm
.data
factor SDWORD -7

.code
main PROC
    mov eax, 100
    cdq
    idiv factor
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected Memory Changes:

```text
No memory changes.
```

Expected important final registers:

```text
EAX    | FFFFFFF2h / u: 4294967282 / s: -14
EDX    | 00000002h / u: 2          / s:  2
```

### Browser program 3 - divide by zero

```asm
.code
main PROC
    mov eax, 100
    cdq
    mov ebx, 0
    idiv ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] divide-by-zero line 6, column 5, byte offset 60, span length 8: IDIV divisor operand EBX evaluated to zero. Division by zero is not allowed. Execution stopped before updating the quotient register EAX and remainder register EDX.
```

Expected important final registers:

```text
EAX    | 00000064h / u: 100        / s:  100
EDX    | 00000000h / u: 0          / s:  0
EBX    | 00000000h / u: 0          / s:  0
```

Expected absence:

```text
No execution-complete message.
No memory changes.
No Program Console output.
```

### Browser program 4 - signed quotient overflow

```asm
.code
main PROC
    mov eax, 80000000h
    cdq
    mov ebx, -1
    idiv ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] quotient-overflow line 6, column 5, byte offset 67, span length 8: IDIV quotient is too large to fit in quotient register EAX. Execution stopped before updating the quotient register EAX and remainder register EDX.
```

Expected important final registers:

```text
EAX    | 80000000h / u: 2147483648 / s: -2147483648
EDX    | FFFFFFFFh / u: 4294967295 / s: -1
EBX    | FFFFFFFFh / u: 4294967295 / s: -1
```

Expected absence:

```text
No execution-complete message.
No memory changes.
No Program Console output.
```

### Browser program 5 - ambiguous memory width rejection

```asm
.code
main PROC
    mov esi, 00500000h
    idiv [esi]
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 4, column 10, byte offset 48, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Expected result:

```text
No register state available.
No memory changes.
No Program Console output.
```

### Windows CMD local testing

Full local verification:

```bat
python scripts\run_tests.py --all
```

Expected output snippets:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
All implemented milestone tests passed.
```

If Emscripten is unavailable, this is acceptable:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Focused Phase 57-relevant tests:

```bat
python scripts\run_tests.py --native
python scripts\run_tests.py --source-run
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --protocol
python scripts\run_tests.py --static
```

Expected output snippets:

```text
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

Optional raw JSON local test using `program.asm`:

Create `program.asm` at project root:

```asm
.code
main PROC
    mov eax, -100
    cdq
    mov ebx, 7
    idiv ebx
main ENDP
END main
```

Run:

```bat
python scripts\run_tests.py --diagnostics
build\tests\diagnostic_json_producer.exe program.asm > result.json
type result.json
```

Expected JSON fragments:

```text
"phase":57
"ok":true
"status":"ok"
"instructionCount":4
"EAX":{"hex":"FFFFFFF2h","unsigned":4294967282}
"EDX":{"hex":"FFFFFFFEh","unsigned":4294967294}
"memoryChanges":[]
"code":"execution-complete"
```

Regression signs:

- `idiv` is rejected as unsupported.
- `idiv` behaves like unsigned `div`.
- quotient/remainder signs are wrong.
- divide-by-zero or overflow mutates `EAX`/`EDX`.
- memory divisor reads create memory-change rows.
- diagnostics use milestone-relative wording.
- source-run/browser metadata still reports Phase 56.
- website still rejects `idiv` after rebuild, which usually indicates stale Wasm.

## 14. Compliance review summary

First compliance review found one coverage gap:

- The implementation had planned-read integration, but there was no Phase 57 `idiv`-specific strict section-image planned-read regression test.
- Exact rendered Simulator Messages coverage for that path was also missing.

Fixes applied:

- Added a Phase 57 source-run test proving `idiv DWORD PTR [esi]` participates in strict section-image planned-read validation before divisor consumption or quotient/remainder mutation.
- Added exact rendered Simulator Messages coverage for the same `idiv` section-image strict planned-read diagnostic.
- Verified the diagnostic is a read access, stops before `idiv` executes, preserves `EAX`, does not emit `divide-by-zero`, and does not emit `execution-complete`.

Tests rerun after first compliance review:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Result:

```text
All selected focused groups passed.
Aggregate completed and passed.
Browser/Wasm rebuild smoke skipped because emcc was unavailable.
```

Verdict after first compliance review:

```text
complete
```

## 15. Re-review summary

Second compliance review found one stale non-TODO comment:

- `tests/core/test_wasm_source_run.c` file-level comment described the test file as covering “Phase 57 unsigned DIV.”

Fix applied:

- Corrected the file-level comment to describe tests through Phase 57 signed IDIV.

Tests rerun after second review:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Result:

```text
All selected focused groups passed.
Aggregate completed and passed.
Browser/Wasm rebuild smoke skipped because emcc was unavailable.
```

Final re-review verdict:

```text
complete
```

## 16. User-test follow-up summary

Prompt 8 user-test triage was not run because no user-reported discrepancies were provided after the manual testing instructions.

No user-test follow-up fixes were applied.

## 17. Known limitations

- Browser/Wasm rebuild smoke was skipped in the assistant/container environment because Emscripten/`emcc` was unavailable.
- Browser testing requires rebuilding the Wasm artifact in an environment with Emscripten.
- If the website still rejects `idiv` after implementation, the most likely cause is a stale Wasm artifact.
- Executable QWORD/SQWORD memory operations remain unsupported in MASM32 Educational Mode.
- Stack behavior, control flow, procedure behavior, Irvine32 routine expansion, Program Console input/output routines, scaled-index addressing, carry rotates, macros, WinAPI, PE/linker, and host include behavior remain future work.
- `idiv` preserves modeled flags deterministically and preserves Phase 50A validity metadata; it does not expose any new flag-validity UI.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 58 - Code Label Table and Label Diagnostics
```

Expected scope for the next phase should be determined from the canonical `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` before implementation begins. Phase 58 should not be implemented as part of Phase 57.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

```text
milestone57_changed_files.zip
milestone57_compliance_changed_files.zip
milestone57_second_review_changed_files.zip
milestone57_final_gap_changed_files.zip
```

Final recommended changed-files package:

```text
milestone57_final_gap_changed_files.zip
```

Latest repository archive produced:

```text
Latest_repository_state_milestone_57.zip
```

The final archive name follows the required naming pattern:

```text
Latest_repository_state_milestone_<TARGET_MILESTONE>.zip
```

with:

```text
TARGET_MILESTONE = 57
```
