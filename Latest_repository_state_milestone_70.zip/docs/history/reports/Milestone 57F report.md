# Milestone 57F report - Seeded Random Register and Flag Startup Mode

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57F - Seeded Random Register and Flag Startup Mode
```

Repository/archive milestone:

```text
Phase 57F - Seeded Random Register and Flag Startup Mode
```

Runtime/source-run MASM behavior phase:

```text
Phase 57F - Seeded Random Register and Flag Startup Mode
```

Status interpretation:

Phase 57F is a runtime/source-run behavior milestone because it adds a new runtime initialization setting that changes source-run execution results when non-default settings are selected. It intentionally advances runtime/source-run metadata from Phase 57 - Signed IDIV to Phase 57F while preserving Phase 57 as the latest MASM instruction/syntax behavior phase.

Scope implemented:

- Added an opt-in deterministic seeded-random startup mode for general-purpose registers and modeled flags.
- Added a separate startup setting axis:

  ```text
  startup_register_flag_mode = zero | seeded-random
  ```

- Added a shared unsigned 32-bit startup seed setting:

  ```text
  startup_state_seed = <u32>
  ```

- Preserved default zero startup behavior for registers and modeled flags.
- Preserved deterministic zero-filled visible bytes for `.DATA?`, `?`, and `DUP(?)` storage.
- Preserved uninitialized-origin metadata used by code-quality diagnostics.
- Preserved initialized `.data` and `.CONST` bytes.
- Preserved Program Console behavior; startup notices remain Simulator Messages only.
- Added mode-specific startup-state notice wording for default zero startup and seeded register/flag startup.
- Added structured/rendered setting diagnostics for invalid startup setting values.
- Added worker/protocol/source-run plumbing for the new startup settings.
- Updated documentation, status surfaces, tests, browser landing text, static checks, and manual testing guidance for Phase 57F.
- Completed user-test follow-up for a Windows-specific seed parsing bug in the local diagnostic JSON producer.

The implementation stayed within the Phase 57F boundary. It did not implement memory randomization, uninitialized-storage visible-byte randomization, `.CONST ?` support, parser syntax changes, instruction semantic changes, browser UI controls, stack behavior, control flow, or future Irvine32 behavior.

## 2. Source-of-truth files used

Canonical repository files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57E report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_57E.zip
```

Changed-files packages produced during the milestone:

```text
milestone_57F_changed_files.zip
milestone_57F_compliance_review_changed_files.zip
milestone_57F_second_review_changed_files.zip
milestone_57F_user_followup_changed_files.zip
```

No full latest repository archive was produced during this milestone-report step. The recommended full archive name after accepting and applying the latest changed-files package is:

```text
Latest_repository_state_milestone_57F.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, and current-status surface hygiene.
- The implementation guide owns phase numbering, phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 57F is the only target milestone for this implementation session.
- TODO-style notes are implementation-risk evidence only and do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- User-visible diagnostics have structured tests and exact rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, WinAPI simulator, host include loader, or macro assembler.

## 3. Exact requirements implemented

### 3.1 Startup register/flag mode setting

Implemented a startup register/flag mode setting with these values:

```text
zero
seeded-random
```

Behavior:

- `zero`: preserve the existing deterministic startup behavior. General-purpose registers and modeled flags start at zero.
- `seeded-random`: initialize general-purpose registers and modeled flags from a deterministic pseudo-random sequence derived from `startup_state_seed`.

The setting is intentionally separate from future uninitialized-storage visible-byte randomization. This resolves the Phase 57F guide note that register/flag startup randomization must not become a catch-all startup mode.

### 3.2 Startup seed setting

Implemented an unsigned 32-bit startup seed:

```text
startup_state_seed = <u32>
```

Accepted range:

```text
0 through 4294967295
```

The same seed, source, settings, and input produce the same startup register and flag values.

A user-test follow-up corrected the local diagnostic JSON producer's environment parser so out-of-range values such as `4294967296` are rejected consistently on Windows/MSVC as well as on platforms where `unsigned long` is wider.

### 3.3 Deterministic register startup

Seeded mode initializes these general-purpose registers:

```text
EAX
EBX
ECX
EDX
ESI
EDI
EBP
ESP
```

`EIP` remains zero. It is execution metadata, not a general-purpose register.

Register aliases continue to reflect the canonical randomized register storage. No separate alias randomization was added.

### 3.4 Deterministic modeled-flag startup

Seeded mode initializes currently modeled flags:

```text
CF
ZF
SF
OF
```

Flag validity metadata remains valid after startup initialization. Unmodeled EFLAGS bits remain clear.

### 3.5 Memory preservation

Phase 57F intentionally does not randomize memory. The following behavior remains unchanged:

- initialized `.data` bytes are unchanged;
- initialized `.CONST` bytes are unchanged;
- `.DATA?`, `?`, and `DUP(?)` visible bytes remain deterministic zero-filled;
- uninitialized-origin metadata remains preserved;
- no memory-change row is emitted merely because startup randomization is enabled.

### 3.6 Startup notices

The existing `startup-state-notice` diagnostic family is reused.

Default zero-startup notice:

```text
The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
```

Seeded register/flag startup notice:

```text
The simulator started general-purpose registers and modeled flags from the configured deterministic seed. Uninitialized storage bytes remain zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
```

The notice is emitted through Simulator Messages only. It does not write to Program Console.

### 3.7 Invalid setting diagnostics

Implemented structured/rendered setting diagnostics for invalid startup settings.

Invalid setting paths covered include:

- invalid `startup_register_flag_mode` values;
- invalid `startup_state_seed` values;
- out-of-range unsigned seed values in the diagnostic JSON producer environment path.

The user-test follow-up added regression coverage for rejecting `4294967296` as an invalid `u32` seed.

### 3.8 Source-run, protocol, and status metadata

Updated source-run/protocol status metadata to report:

```text
phase: 57
phaseSuffix: F
phaseName: Phase 57F - Seeded Random Register and Flag Startup Mode
```

This avoids treating Phase 57F as a new instruction milestone while still accurately reporting the runtime/source-run behavior phase.

### 3.9 Browser visibility

Updated browser landing/current-status text to Phase 57F. No browser UI controls were added for startup randomization. Seeded startup is testable through source-run, diagnostic producer, and worker/protocol settings paths.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57F:

- Phase 57G - Seeded Random Uninitialized Storage Mode.
- Uninitialized-storage visible-byte randomization.
- `.DATA?`, `?`, or `DUP(?)` random visible bytes.
- `.CONST ?` or `.CONST DUP(?)` acceptance.
- Phase 57J `.CONST` uninitialized-storage policy controls.
- Browser UI controls for startup randomization.
- Parser or MASM syntax changes.
- New instructions or instruction semantic changes.
- Memory layout changes.
- Stack execution behavior.
- Procedure behavior.
- Control flow.
- Irvine32 routine expansion.
- Host-derived randomness, true randomness, wall-clock randomness, process-state randomness, or browser-global nondeterminism.
- `.code` memory-access-denial policy changes.
- Future display-phase behavior such as Phase 57H startup provenance display.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 57F randomizes only MASM32 general-purpose registers: `EAX`, `EBX`, `ECX`, `EDX`, `ESI`, `EDI`, `EBP`, and `ESP`; it does not randomize `EIP`.
- **Reason:** The guide says general-purpose registers and modeled flags. `EIP` is execution/control metadata, not a general-purpose register.
- **Risk:** If a future interpretation expects all displayed registers to be randomized, `EIP` will appear excluded.
- **How to change later:** Add a separate reviewed requirement to include or configure `EIP` startup behavior.

### Assumption 2

- **Assumption:** Only modeled flags `CF`, `ZF`, `SF`, and `OF` are randomized.
- **Reason:** The current flag model and validity metadata only model these flags.
- **Risk:** Future flags such as `PF`, `AF`, or `DF` will not be affected until implemented.
- **How to change later:** Extend the startup helper when additional flags become current modeled behavior.

### Assumption 3

- **Assumption:** Startup randomization must run after `vm_load_program`.
- **Reason:** Program load resets CPU state; applying startup randomization before load would be overwritten.
- **Risk:** If future loader order changes, the startup hook location may require adjustment.
- **How to change later:** Keep startup policy application centralized at the final post-load, pre-execution point.

### Assumption 4

- **Assumption:** The deterministic pseudo-random algorithm is an internal implementation detail, while same-seed repeatability is the externally important behavior.
- **Reason:** The guide requires deterministic seeded behavior, not a specific public PRNG sequence.
- **Risk:** Tests that lock exact seeded values could require fixture updates if the internal algorithm changes intentionally.
- **How to change later:** Treat exact values as regression fixtures for current implementation; update intentionally only with a documented compatibility decision.

### Assumption 5

- **Assumption:** The existing `startup-state-notice` diagnostic family should cover both zero-startup and seeded register/flag startup notices.
- **Reason:** Phase 57E introduced startup-state notices, and Phase 57F asks for a mode-specific startup notice rather than a new diagnostic family.
- **Risk:** Later phases might want separate toggles for different startup notices.
- **How to change later:** Add a separate diagnostic-policy family only if a later guide phase explicitly requires independent configuration.

### Assumption 6

- **Assumption:** The protocol should retain numeric `phase: 57` and add/use suffix/title fields for suffixed runtime behavior phases.
- **Reason:** Existing protocol and tests compare numeric phase values; using a suffix preserves compatibility while accurately representing Phase 57F.
- **Risk:** Consumers that only inspect the numeric phase may not distinguish Phase 57 from 57F.
- **How to change later:** Normalize phase metadata into a structured object such as `{phaseNumber, phaseSuffix, phaseTitle}` in a future protocol cleanup.

## 6. Relevant TODO-style notes reviewed

### Target-owned notes

- `docs/SUPPORTED_SYNTAX.md` current-state note that startup randomization was not implemented.
  - Classification: target-owned.
  - Disposition: resolved by updating current-status behavior to reflect Phase 57F.

- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` Phase 57F note requiring register/flag startup randomization to remain its own setting axis.
  - Classification: target-owned.
  - Disposition: resolved by adding `startup_register_flag_mode` as a separate axis from future memory randomization.

### Future-owned notes

- Phase 57G note for `uninitialized_storage_visible_byte_mode`.
  - Classification: future-owned.
  - Disposition: preserved. Phase 57F does not randomize memory.

- `src/core/vm_diagnostic_policy.c` future diagnostic-family guidance.
  - Classification: future-owned.
  - Disposition: preserved. No new diagnostic family was needed; the existing startup-state notice family was reused.

- `src/wasm/wasm_api.c` future planned-read collection note for memory-reading opcodes.
  - Classification: future-owned.
  - Disposition: preserved. Phase 57F does not add memory-reading opcodes.

- `src/core/vm_memory.c` future protected-region and `.code` diagnostic note.
  - Classification: future-owned.
  - Disposition: preserved. Phase 57F does not change `.code` memory access policy.

- Phase 57H display/provenance note.
  - Classification: future-owned.
  - Disposition: preserved. Phase 57F does not add startup provenance display.

### Stale or contradicted notes

None identified as remaining after implementation, compliance review, second review, user follow-up, and final gap check.

### Unclear notes

None remained unclear for Phase 57F after source inspection and review.

## 7. TODO-style note disposition

- **Target-owned TODO-style notes resolved:** yes. The current-state startup-randomization note was updated, and the separate register/flag startup setting axis was implemented.
- **Future-owned TODO-style notes intentionally preserved:** yes. Phase 57G, future registry, memory planned-read, `.code` protection, and Phase 57H notes remain deferred and scoped to future work.
- **Stale or contradicted TODO-style notes corrected:** no stale TODO-style notes remained after review.
- **Unresolved TODO-related risks:** none identified for Phase 57F.
- **New TODO-style notes added:** none.

## 8. Design summary

### Core startup helper

A deterministic startup helper was added around the CPU startup path. It supports:

- zero startup mode;
- seeded-random startup mode;
- deterministic `u32` seed input;
- preservation of `EIP`;
- preservation of unmodeled EFLAGS bits;
- valid modeled-flag metadata after startup initialization.

The implementation uses a deterministic C99-compatible pseudo-random/mixing sequence instead of `rand()`, host entropy, process state, wall-clock time, or browser randomness.

### Source-run application point

Startup settings are applied after program load and before execution, because program load resets CPU state.

This ensures seeded mode affects actual initial execution state and is not overwritten by loader reset behavior.

### Settings/protocol path

The new startup settings are exposed through local/source-run/worker/protocol paths rather than visible browser controls.

This matches Phase 57F scope: backend/source-run configuration behavior, not UI controls.

### Diagnostic behavior

The existing startup-state notice family is mode-aware:

- zero startup receives the Phase 57E-style zero-state notice;
- seeded register/flag startup receives a deterministic-seed notice;
- notices remain non-fatal and Simulator Messages only.

Invalid startup settings produce structured/renderable setting diagnostics. The user-follow-up fix ensures out-of-range seed parsing is reliable on Windows/MSVC.

### Current-status metadata

Phase metadata now represents Phase 57F as a suffixed runtime/source-run phase while keeping the numeric phase at `57` for compatibility.

The documentation distinguishes:

- instruction/MASM syntax support: through Phase 57 - Signed IDIV;
- runtime/source-run behavior status: Phase 57F - Seeded Random Register and Flag Startup Mode.

## 9. Files changed

Files changed across implementation, compliance review, second review, and user follow-up:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/build_wasm.sh`
- `scripts/run_tests.py`
- `scripts/windows/build_wasm.cmd`
- `src/core/vm_cpu.c`
- `src/core/vm_cpu.h`
- `src/wasm/wasm_api.c`
- `src/wasm/wasm_api.h`
- `tests/core/diagnostic_json_producer.c`
- `tests/core/test_vm_cpu.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_formatters.mjs`
- `tests/web/test_protocol.mjs`
- `tests/web/test_settings.mjs`
- `web/index.html`
- `web/src/protocol.js`
- `web/src/settings.js`
- `web/src/worker.js`

## 10. Tests added

### Native C tests

Added native CPU/startup tests for:

- default zero startup;
- deterministic seeded startup;
- same seed repeatability;
- different seed difference;
- `EIP` preservation;
- unmodeled EFLAGS bit preservation;
- modeled flag validity preservation;
- register alias consistency after seeded startup;
- NULL/defensive helper behavior where applicable.

### Source-run tests

Added source-run coverage for:

- Phase 57F phase metadata;
- default zero mode;
- `startup_state_seed` having no randomizing effect when mode is `zero`;
- deterministic seeded startup with seed `123`;
- different seeds producing different startup state;
- seeded startup notice;
- invalid startup mode;
- memory preservation;
- uninitialized-origin preservation;
- no memory-change rows from startup randomization.

### Diagnostic JSON producer tests

Added environment/configuration support and tests for:

- startup mode selection;
- seed selection;
- invalid startup setting behavior;
- invalid seed overflow behavior after user follow-up.

### Rendered Simulator Messages tests

Added exact rendered-message coverage for:

- seeded startup notice;
- invalid startup setting UI error path;
- invalid out-of-range startup seed in the diagnostic JSON producer path.

### Web/protocol/settings tests

Added or updated tests for:

- startup setting normalization;
- valid startup mode/seed propagation;
- invalid startup setting diagnostics;
- stale Wasm/export detection when non-default startup settings require Phase 57F-capable exports;
- Phase 57F protocol metadata.

### Static/status tests

Added or updated static checks for:

- Phase 57F documentation and status surfaces;
- browser landing page Phase 57F text;
- build-script export coverage;
- no stale Phase 57E/57B current-status references in touched surfaces.

## 11. Commands used to test

### Aggregate command

The aggregate command was run multiple times during implementation/review:

```bash
python3 scripts/run_tests.py --all
```

Observed result in the assistant/container environment:

```text
Timed out before returning a final aggregate result.
```

No aggregate-pass claim is made.

### Focused group commands

Focused groups run after implementation and during compliance/final checks:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

All focused groups passed.

### User-follow-up focused commands

After the invalid-seed fix, relevant focused groups were rerun:

```bash
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --structure
```

All rerun focused groups passed.

One combined multi-command invocation timed out after completing `--native`; the affected groups were rerun individually and passed.

### Subgroup or fixture-family commands

No dedicated subgroup/fixture-family rerun was required beyond rerunning the focused groups individually after the combined invocation timed out.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

Classification:

```text
group skipped because dependency was unavailable, such as emcc
```

## 12. Pass/fail results

Result classification:

```text
aggregate timed out but focused groups passed
```

Detailed results:

- `python3 scripts/run_tests.py --structure`: PASS.
- `python3 scripts/run_tests.py --native`: PASS.
- `python3 scripts/run_tests.py --source-run`: PASS.
- `python3 scripts/run_tests.py --web`: PASS.
- `python3 scripts/run_tests.py --diagnostics`: PASS.
- `python3 scripts/run_tests.py --protocol`: PASS.
- `python3 scripts/run_tests.py --static`: PASS.
- `python3 scripts/run_tests.py --all`: timed out in the assistant/container environment before final aggregate completion.
- Browser/Wasm rebuild smoke: skipped because `emcc` is unavailable.

No focused group failed after fixes.

## 13. Manual/browser testing guidance and expected outputs

### Browser testing

Website-testable default behavior: yes, after rebuilding Wasm.

Seeded startup mode: not through visible UI controls. Phase 57F intentionally exposes seeded mode through local source-run/protocol/test settings, not a browser settings panel.

Windows CMD setup:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Emscripten is required for a true browser/Wasm Phase 57F backend rebuild. If `emcc` is unavailable, browser backend verification should be skipped.

Default browser sample:

```asm
.code
main PROC
    mov eax, -100
    cdq
    mov ebx, 7
    idiv ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected primary final registers:

```text
EAX    | FFFFFFF2h / u: 4294967282 / s: -14
EBX    | 00000007h / u: 7          / s:  7
ECX    | 00000000h / u: 0          / s:  0
EDX    | FFFFFFFEh / u: 4294967294 / s: -2
ESI    | 00000000h / u: 0          / s:  0
EDI    | 00000000h / u: 0          / s:  0
EBP    | 00000000h / u: 0          / s:  0
ESP    | 00000000h / u: 0          / s:  0
EIP    | 00000000h / u: 0          / s:  0
EFLAGS | 00000000h / 0
```

Expected Program Console: empty.

Expected memory changes:

```text
No memory changes.
```

### Local Windows CMD testing

Create `program.asm` at the project root:

```cmd
> program.asm (
  echo .code
  echo main PROC
  echo main ENDP
  echo END main
)
```

Default zero startup command:

```cmd
set MASM32_DIAGNOSTIC_STARTUP_REGISTER_FLAG_MODE=zero
set MASM32_DIAGNOSTIC_STARTUP_STATE_SEED=123
set MASM32_DIAGNOSTIC_STARTUP_STATE_NOTICE=warn
build\tests\diagnostic_json_producer.exe program.asm
```

Expected result: JSON with all general-purpose registers, `EIP`, and `EFLAGS` equal to zero, Phase 57F metadata, empty memory changes, startup notice, and execution-complete info.

Seeded startup command:

```cmd
set MASM32_DIAGNOSTIC_STARTUP_REGISTER_FLAG_MODE=seeded-random
set MASM32_DIAGNOSTIC_STARTUP_STATE_SEED=123
set MASM32_DIAGNOSTIC_STARTUP_STATE_NOTICE=warn
build\tests\diagnostic_json_producer.exe program.asm
```

Expected seeded register/flag values for seed `123`:

```text
EAX = 585DB8F1h / 1482537201
EBX = A330287Dh / 2737842301
ECX = 9EFEDA41h / 2667502145
EDX = BD42EF61h / 3175280481
ESI = C6891116h / 3330871574
EDI = 27B01DAFh / 665853359
EBP = 8060C439h / 2153825337
ESP = AABB1AA4h / 2864388772
EIP = 00000000h / 0
EFLAGS = 00000040h / 64
```

Expected seeded startup notice:

```text
The simulator started general-purpose registers and modeled flags from the configured deterministic seed. Uninitialized storage bytes remain zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
```

Different seed command:

```cmd
set MASM32_DIAGNOSTIC_STARTUP_REGISTER_FLAG_MODE=seeded-random
set MASM32_DIAGNOSTIC_STARTUP_STATE_SEED=124
set MASM32_DIAGNOSTIC_STARTUP_STATE_NOTICE=warn
build\tests\diagnostic_json_producer.exe program.asm
```

Expected behavior: at least one general-purpose register or modeled flag differs from seed `123`; `EIP` remains zero; memory changes remain empty.

Invalid seed command after user-follow-up fix:

```cmd
set MASM32_DIAGNOSTIC_STARTUP_REGISTER_FLAG_MODE=seeded-random
set MASM32_DIAGNOSTIC_STARTUP_STATE_SEED=4294967296
build\tests\diagnostic_json_producer.exe program.asm
```

Expected output:

```text
diagnostic_json_producer: invalid unsigned environment value
```

Expected process behavior: nonzero exit, no source-run JSON emitted.

Regression signs:

- `phaseSuffix` missing or not `F`.
- `phaseName` not Phase 57F.
- zero mode produces nonzero register or flag values.
- `startup_state_seed` changes values while mode is `zero`.
- seed `123` no longer matches deterministic expected values without an intentional documented algorithm change.
- repeating the same seed changes output.
- `EIP` is randomized.
- memory changes appear for startup-only fixtures.
- startup notices appear in Program Console.
- out-of-range seed `4294967296` is accepted.
- browser shows stale-Wasm/export errors after successful rebuild.

## 14. Compliance review summary

The first compliance review checked scope, completeness, code quality, diagnostics, tests, documentation, and TODO-style note disposition.

Issues found:

- `docs/SUPPORTED_SYNTAX.md` still had a current-status sentence implying runtime MASM behavior was through Phase 57 rather than Phase 57F.
- `web/src/settings.js` and `tests/web/test_settings.mjs` comments still described settings as Phase 53E-only even though they now also include Phase 57F startup settings.
- Exact formatter coverage existed for earlier UI setting errors but not for the new `invalid-startup-setting` path.

Fixes applied:

- Clarified supported-syntax status so instruction support remains through Phase 57 while runtime/source-run behavior status is Phase 57F.
- Updated comments for settings code/tests to mention Phase 57F startup settings.
- Added exact rendered-message assertion coverage for `invalid-startup-setting`.

Focused tests rerun and passed. Aggregate timed out in the assistant/container environment.

Compliance verdict: complete after fixes.

## 15. Re-review summary

The second review re-read the Phase 57F guide/spec requirements, inspected changed files, checked stale comments/docs, re-scanned TODO-style notes in changed files and nearby modules, checked diagnostic wording, and reran focused tests.

Additional issues found:

- `docs/BUILDING_AND_DEVELOPMENT.md` still had stale Phase 57B/Phase 57 served-site wording.
- `web/index.html` still advertised the browser shell as Milestone 57 and did not reflect Phase 57F runtime status.
- `docs/FULL_IMPLEMENTATION_SPEC.md` and `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` top source-of-truth notes still named Phase 57E as the latest reviewed revision.
- `docs/FULL_IMPLEMENTATION_SPEC.md` still described randomized startup modes as purely future behavior.
- `.CONST ?` current-state wording still used through Phase 57 instead of through Phase 57F.
- One Phase 57E source-run test assertion description still implied Phase 57E owned current runtime/source-run metadata.

Fixes applied:

- Updated source-of-truth notes to Phase 57F.
- Updated startup-state specification wording to identify Phase 57F register/flag startup randomization while keeping memory randomization excluded.
- Updated `.CONST ?` current-state wording through Phase 57F.
- Updated build/dev browser-smoke guidance.
- Updated browser landing text and file comment to Phase 57F.
- Updated stale source-run test assertion description.
- Added static checks for Phase 57F browser landing text.

Focused tests rerun and passed. Aggregate timed out in the assistant/container environment.

Re-review verdict: complete after fixes.

## 16. User-test follow-up summary

The user ran manual/local checks from the Prompt 7 instructions.

Observed results:

- Default zero startup matched expected output.
- Seeded register/flag startup with seed `123` matched expected output.
- Different seed startup changed state as expected and preserved `EIP = 0` and `memoryChanges = []`.
- Invalid seed rejection did not match: seed `4294967296` was accepted and execution completed successfully.

Diagnosis:

- Implementation bug in the local diagnostic JSON producer's environment seed parser.
- Root cause: use of `strtoul`; on Windows/MSVC, `unsigned long` is 32-bit, so overflow handling did not reliably reject values above `UINT32_MAX`.

Fix applied:

- Changed the diagnostic JSON producer's unsigned environment parser to use `strtoull`.
- Added explicit `errno == ERANGE` handling.
- Added explicit `value > 0xFFFFFFFFULL` range check.

Regression test added:

- Diagnostic-rendering harness test that invokes the native diagnostic JSON producer with `MASM32_DIAGNOSTIC_STARTUP_STATE_SEED=4294967296` and verifies:
  - nonzero exit;
  - empty stdout;
  - stderr exactly `diagnostic_json_producer: invalid unsigned environment value`.

Focused tests rerun and passed.

User-test follow-up verdict: fixed within Phase 57F scope.

## 17. Known limitations

- The aggregate test command did not complete in the assistant/container environment. Focused groups passed individually, so the correct classification is aggregate timed out but focused groups passed.
- Browser/Wasm rebuild smoke was skipped because `emcc` is unavailable in the assistant/container environment.
- No visible browser UI controls were added for seeded startup. This is intentional Phase 57F scope.
- Seeded startup mode is primarily exercised through local source-run, diagnostic JSON producer, and worker/protocol paths until a later UI phase exposes controls.
- Exact deterministic seeded values are current regression fixtures. Same-seed repeatability is the stable behavioral requirement.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57G - Seeded Random Uninitialized Storage Mode
```

Expected Phase 57G ownership:

- Add opt-in deterministic seeded visible-byte randomization for uninitialized storage.
- Preserve uninitialized-origin metadata.
- Keep it separate from Phase 57F `startup_register_flag_mode`.
- Do not retroactively merge memory randomization into Phase 57F behavior.

## 19. Changed-files ZIP/package produced

Changed-files packages produced:

- `milestone_57F_changed_files.zip`
- `milestone_57F_compliance_review_changed_files.zip`
- `milestone_57F_second_review_changed_files.zip`
- `milestone_57F_user_followup_changed_files.zip`

Latest changed-files package:

```text
milestone_57F_user_followup_changed_files.zip
```

Recommended application order if applying all packages sequentially:

1. `milestone_57F_changed_files.zip`
2. `milestone_57F_compliance_review_changed_files.zip`
3. `milestone_57F_second_review_changed_files.zip`
4. `milestone_57F_user_followup_changed_files.zip`

Recommended final full repository archive name after accepting the milestone:

```text
Latest_repository_state_milestone_57F.zip
```

No full latest repository archive was produced during this report step.
