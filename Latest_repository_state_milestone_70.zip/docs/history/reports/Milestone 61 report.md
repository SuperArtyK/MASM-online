# Milestone 61 report - Direct JMP Runtime Execution

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 61 - Direct JMP Runtime Execution
```

Repository/archive milestone after this work:

```text
Phase 61 - Direct JMP Runtime Execution
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 61 - Direct JMP Runtime Execution
```

Scope implemented:

- Executed already-lowered direct `jmp label` instructions by transferring to the resolved VM instruction index.
- Counted a committed direct `jmp` as one executed VM instruction.
- Consumed Phase 60 branch-target IR metadata at runtime instead of reclassifying source-level labels during execution.
- Preserved modeled flags and Phase 50A flag-validity metadata across direct `jmp` execution.
- Produced no memory-change row for direct `jmp` execution.
- Preserved Program Console output separation from Simulator Messages.
- Preserved source-run instruction-accounting fields introduced by Phase 59:
  - `instructionLimit`;
  - `executedInstructionCount`;
  - `attemptedNextInstructionIndex`;
  - `currentInstructionIndex`.
- Replaced the Phase 60 `branch-runtime-deferred` outcome for valid direct `jmp label` source programs with actual branch transfer.
- Preserved parser/lowering target classification from Phase 60 for accepted and rejected direct-JMP target classes.
- Added malformed direct-branch metadata runtime protection with `invalid-branch-target` and no partial mutation.
- Updated current-status documentation and protocol/status surfaces to Phase 61.
- Updated the browser default example so it demonstrates successful direct JMP runtime execution.
- After user-test follow-up, restored MASM-compatible behavior for reserved instruction-mnemonic targets such as `jmp loop`: current scope rejects `loop` as an instruction mnemonic target unless a future `OPTION NOKEYWORD` phase explicitly changes keyword handling.

Scope intentionally not implemented:

- Conditional jumps.
- `cmp`.
- `loop` instruction semantics.
- Indirect jumps.
- Register-target, memory-target, or immediate-target `jmp` execution.
- `SHORT`, `NEAR PTR`, or `FAR PTR` branch-distance/type overrides.
- `call`, `ret`, `leave`, stack mutation, stack frames, arguments, or procedure invocation semantics.
- Irvine32 routine calls beyond already-existing virtual `exit` terminator behavior.
- Debugger stepping, breakpoints, source navigation, editor marker navigation, or UI label navigation.
- `OPTION NOKEYWORD` or general reserved-word symbol diagnostics. A future user-local spec phase is expected to own reserved-word symbol diagnostics; this milestone preserves the current rule that reserved instruction mnemonics are not valid direct-JMP targets by default.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_61.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 60 report.md`
- `Project Audit and Milestones.txt`, user-provided follow-up planning note for future `OPTION NOKEYWORD` placeholder guidance

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_60.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, current-status surface hygiene, and broad product constraints.
- The implementation guide owns Phase 61 numbering, exact phase scope, tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

External MASM behavior reference used during user-test follow-up:

- Microsoft Learn documents `OPTION NOKEYWORD` as a MASM `OPTION` directive value.
- MASM reserved-word documentation explains that recognition of reserved words can be disabled through `OPTION NOKEYWORD`, after which the word can be used as a user-defined symbol if it is otherwise a valid identifier.
- Therefore, because this project does not implement `OPTION NOKEYWORD` in Phase 61, reserved instruction mnemonics such as `loop` remain reserved by default in the simulator's current MASM compliance scope.

## 3. Exact requirements implemented

### 3.1 Direct JMP runtime transfer

Implemented execution for already-lowered direct branch instructions produced by Phase 60.

A valid direct `jmp label` now transfers to the resolved target VM instruction index instead of returning `branch-runtime-deferred`.

Example supported behavior:

```asm
.code
main PROC
    mov eax, 1
    jmp done
    mov ebx, 2
done:
    mov ecx, 3
main ENDP
END main
```

Expected behavior:

- `EAX = 1`.
- `EBX` remains unchanged/zero because the fall-through instruction is skipped.
- `ECX = 3`.
- `execution-complete` is emitted.
- `branch-runtime-deferred` is not emitted.

### 3.2 Phase 60 metadata consumption

Implemented runtime consumption of the branch-target operand/metadata added in Phase 60.

Runtime branch execution does not reclassify source-level labels. Target classification remains parser/lowering work from Phase 60.

### 3.3 Executed-instruction accounting

Implemented Phase 61 accounting rules:

- A committed direct `jmp` counts as one executed instruction.
- `executedInstructionCount` includes executed direct `jmp` instructions.
- `attemptedNextInstructionIndex` remains `null` on successful completion.
- `attemptedNextInstructionIndex` is set when the instruction-count watchdog blocks a later attempted instruction.
- `currentInstructionIndex` reflects the last committed instruction index.

### 3.4 Watchdog behavior

Backward direct jumps are executable and may loop until the Phase 59 instruction-count watchdog stops the program.

For a backward loop with a low instruction limit, the expected failure remains:

```text
instruction-limit-exceeded
```

The watchdog stops before executing the attempted instruction that would exceed the limit.

### 3.5 No memory behavior

Direct `jmp` has no memory read or write in Phase 61.

Therefore:

- No memory planned-read or planned-write collection was added.
- No memory-change row is created by `jmp`.
- The future memory-reading opcode TODO in `src/wasm/wasm_api.c` remains future-owned and unchanged.

### 3.6 Flag preservation

Direct `jmp` does not consume or modify modeled flags.

Preserved state includes:

- `CF`;
- `ZF`;
- `SF`;
- `OF`;
- Phase 50A flag-validity metadata.

### 3.7 Procedure-entry target behavior

Direct `jmp procedureName` continues to be accepted only when Phase 60 target classification resolved the procedure entry to a first executable instruction.

This remains a direct branch only. It does not imply:

- `CALL`;
- `RET`;
- stack mutation;
- argument passing;
- `USES` behavior;
- `LOCAL` behavior;
- procedure frame setup;
- calling conventions.

### 3.8 Runtime malformed-target diagnostics

Added malformed branch-target metadata protection.

Malformed or out-of-range direct-branch metadata reports:

```text
invalid-branch-target
```

The error path preserves no-partial-mutation behavior:

- instruction pointer is unchanged;
- instruction count is unchanged for the failed instruction;
- registers are unchanged;
- modeled flags are unchanged;
- Phase 50A flag-validity metadata is unchanged;
- memory is unchanged;
- Program Console output is unchanged;
- no memory-change row is created.

### 3.9 Valid direct JMP no longer emits Phase 60 deferred diagnostic

For valid direct `jmp label`, Phase 61 removes the transitional Phase 60 behavior:

```text
branch-runtime-deferred
```

That diagnostic remains in the codebase as a stable status enum/message path for possible future accepted-but-deferred branch forms, but valid direct JMP no longer uses it.

### 3.10 Reserved instruction-mnemonic direct-JMP targets

During user-test follow-up, the simulator was briefly made too permissive for a label named `loop`. That permissive behavior was corrected.

Current Phase 61 behavior:

```asm
.code
main PROC
loop:
    inc eax
    jmp loop
main ENDP
END main
```

The simulator rejects `jmp loop` as an instruction-mnemonic target in current scope.

Rationale:

- Real MASM treats instruction mnemonics such as `LOOP` as reserved words by default.
- `OPTION NOKEYWORD` is the MASM mechanism for disabling recognition of reserved words.
- This project does not implement `OPTION NOKEYWORD` yet.
- The user indicated a new future spec phase exists locally for Reserved Word Symbol Diagnostics; Phase 61 does not implement that future phase.

Recommended portable infinite-loop test label:

```asm
.code
main PROC
again:
    inc eax
    jmp again
main ENDP
END main
```

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 61:

- Conditional jumps, including `je`, `jne`, `jg`, `jl`, and related branch families.
- `cmp`.
- `loop` instruction semantics.
- Indirect branch execution.
- Register-target direct/indirect jumps.
- Memory-target direct/indirect jumps.
- Immediate-target jumps.
- Branch-distance/type override support: `SHORT`, `NEAR PTR`, `FAR PTR`.
- Relative branch encoding or real x86 instruction encoding.
- Native x86 execution.
- Stack or procedure execution semantics.
- `call`, `ret`, `leave`, `push`, `pop`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 routine calls.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Debugger stepping, breakpoints, current-instruction highlighting, editor source navigation, or label-click navigation.
- Browser UI controls for instruction limits.
- `OPTION NOKEYWORD`.
- Full reserved-word symbol declaration diagnostics.
- General dynamic keyword-table mutation.
- Full MASM macro expansion.

Future work intentionally preserved:

- Phase 62 - CMP Register and Immediate Forms.
- Later conditional jump phases.
- Later `loop` phase.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Later execution-control UI/settings phases if the guide requires them.
- Future reserved-word symbol diagnostics phase supplied by the user locally.
- Future `OPTION NOKEYWORD` keyword-control compatibility phase or placeholder when the canonical guide includes it.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 61 advances both repository/archive milestone and runtime/source-run MASM behavior phase.
- **Reason:** Phase 61 changes runtime-visible MASM/source behavior by making valid direct `jmp label` executable. It also changes source-run JSON outcomes, Simulator Messages behavior, status metadata, and current syntax/status documentation.
- **Risk:** Any unupdated status surface could still claim runtime branch transfer is deferred to Phase 61.
- **How to change later:** If a reviewed guide revision later separates repository and runtime metadata for this phase, apply the repository/runtime split block from the spec and update only explicitly owned surfaces. The current guide interpretation supports advancing both values to Phase 61.

### Assumption 2

- **Assumption:** Runtime branch execution should consume Phase 60 branch-target metadata rather than reclassifying source labels.
- **Reason:** Phase 60 explicitly lowered direct branch target metadata so Phase 61 could execute already-lowered targets.
- **Risk:** If future branch families need richer runtime metadata, the current representation may need extension.
- **How to change later:** Add documented branch metadata helpers in the owning future branch phase without reclassifying normal source labels during execution.

### Assumption 3

- **Assumption:** `branch-runtime-deferred` should be removed for valid direct `jmp label` rather than retained as a warning.
- **Reason:** Phase 61 owns actual instruction-pointer transfer for direct JMP runtime execution.
- **Risk:** Existing Phase 60 tests expecting the deferred diagnostic for valid direct JMP needed careful updating so invalid target diagnostics were not weakened.
- **How to change later:** Reserve `branch-runtime-deferred` only for future accepted-but-still-deferred branch forms explicitly documented by a later phase.

### Assumption 4

- **Assumption:** Malformed branch metadata is primarily a native executor/IR test path.
- **Reason:** Normal parser/source-run paths should not generate malformed direct-branch metadata after Phase 60 validation succeeds.
- **Risk:** User-visible malformed-IR runtime diagnostics are less directly testable through ordinary MASM source.
- **How to change later:** If a future public API accepts external IR, stale debug sessions, serialized execution state, or reloadable partially compiled state, add source-run/protocol-level rendered diagnostic tests for malformed branch metadata.

### Assumption 5

- **Assumption:** Direct JMP does not require planned-read/planned-write collection updates.
- **Reason:** Phase 61 direct JMP performs no simulated memory access.
- **Risk:** Future indirect branch phases may have memory operands and must not copy this exemption blindly.
- **How to change later:** Future memory-capable branch features must apply the standing memory-capable feature rule and update planned-access collection before mutation.

### Assumption 6

- **Assumption:** Website manual verification requires a fresh Emscripten/Wasm rebuild after C changes.
- **Reason:** Phase 61 changes C executor/source-run behavior. Stale `web/dist` artifacts may still show the previous Phase 60 behavior.
- **Risk:** A user may run old served artifacts and still see `branch-runtime-deferred` for valid direct JMP.
- **How to change later:** Rebuild with `scripts\windows\build_wasm.cmd` in an Emscripten-enabled environment before browser testing.

### Assumption 7

- **Assumption:** Reserved instruction mnemonics such as `loop` remain unavailable as direct-JMP targets in current scope.
- **Reason:** MASM reserves instruction mnemonics by default and uses `OPTION NOKEYWORD` to disable reserved-word recognition. Phase 61 does not implement `OPTION NOKEYWORD` or the user's future Reserved Word Symbol Diagnostics phase.
- **Risk:** The simulator still accepts `loop:` syntactically as a code label declaration in some parser paths, while later target use is rejected as an instruction-mnemonic target. This is a known current limitation until the future reserved-word symbol diagnostics phase rejects the declaration itself.
- **How to change later:** Implement the future Reserved Word Symbol Diagnostics phase so reserved-word declarations are rejected at declaration time with a clear diagnostic. Later, if the canonical guide adds `OPTION NOKEYWORD`, implement its source-order keyword-control rules in that future phase.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning, implementation, compliance review, user-test follow-up, and final gap check:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61 - Direct JMP Runtime Execution
- Note text or summary:
  Phase 61 must execute already-lowered direct branch instructions by branching to the target VM instruction index, consuming Phase 60 metadata, counting `jmp` as one executed instruction, preserving modeled flags, producing no memory-change row, respecting watchdogs, and reporting invalid branch metadata without partial mutation.
- Classification:
  target-owned
- Reason:
  This is the canonical target milestone scope.
- Action for this milestone:
  Implemented and tested.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md and Milestone 60 report, Phase 60 deferred runtime boundary
- Note text or summary:
  Phase 60 accepted and lowered direct `jmp label`, but runtime branch execution remained deferred to Phase 61. Reaching a lowered valid `jmp` emitted `branch-runtime-deferred`.
- Classification:
  target-owned
- Reason:
  Phase 61 directly supersedes this temporary runtime boundary for valid direct JMP.
- Action for this milestone:
  Replaced for valid direct JMP with actual instruction-pointer transfer. Preserved rejected-target diagnostics.
```

```text
- Location:
  README.md, docs/SUPPORTED_SYNTAX.md, docs/BUILDING_AND_DEVELOPMENT.md, docs/MILESTONE_HISTORY.md
- Note text or summary:
  Runtime branch transfer was described as deferred to Phase 61.
- Classification:
  target-owned
- Reason:
  These current-status notes became stale once Phase 61 runtime branch transfer was implemented.
- Action for this milestone:
  Updated current-status wording to describe implemented direct JMP runtime execution and to preserve future scope for conditional/indirect/loop/procedure/debugger features.
```

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  Future memory-reading opcodes should be added to planned-access collection when implemented.
- Classification:
  future-owned
- Reason:
  Direct JMP is not a memory-reading instruction and does not perform memory access.
- Action for this milestone:
  Left in place.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md and docs/MILESTONE_HISTORY.md future-control-flow notes
- Note text or summary:
  Conditional jumps, `loop`, indirect branches, register/memory jumps, distance overrides, call/ret, stack/procedure execution, debugger stepping, breakpoints, and UI navigation remain future work.
- Classification:
  future-owned
- Reason:
  Phase 61 implements only already-lowered direct JMP runtime execution.
- Action for this milestone:
  Preserved and clarified where necessary.
```

```text
- Location:
  User-test follow-up discussion and Project Audit and Milestones.txt
- Note text or summary:
  Reserved instruction mnemonics such as `loop` should remain reserved by default; `OPTION NOKEYWORD` belongs to future keyword-control compatibility work and should not be implemented early.
- Classification:
  future-owned for `OPTION NOKEYWORD`; target-owned for correcting the Phase 61 user-test regression.
- Reason:
  The Phase 61 follow-up briefly allowed a `loop` label to override the instruction mnemonic for direct JMP. That was inconsistent with the current MASM compliance scope.
- Action for this milestone:
  Corrected direct-JMP target handling/test expectations so `jmp loop` remains rejected as an instruction mnemonic target. Did not implement the future reserved-word declaration diagnostic or `OPTION NOKEYWORD` behavior.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 61 direct JMP runtime execution was implemented.
- Phase 60 `branch-runtime-deferred` behavior was removed for valid direct `jmp label`.
- Phase 59 instruction-count accounting was preserved for executed direct JMP and instruction-limit failures.
- Direct JMP flag preservation was implemented and tested.
- Direct JMP no-memory-change behavior was implemented and tested.
- Malformed branch-target metadata diagnostics were implemented and tested.
- Current-status surfaces were updated to Phase 61.
- Manual/browser testing guidance was updated for Phase 61.
- The user-test regression around `loop` reserved-word behavior was corrected within current Phase 61 scope.

### Future-owned TODO-style notes intentionally preserved

- Future memory-reading opcode planned-access TODO in `src/wasm/wasm_api.c`.
- Conditional jumps.
- `cmp`.
- `loop` instruction semantics.
- Indirect branches.
- Register/memory/immediate jump targets.
- Branch-distance/type overrides.
- `call`, `ret`, stack behavior, procedure frames, and procedure invocation.
- Debugger stepping, breakpoints, editor/source navigation, and UI label navigation.
- Irvine32 callable routines beyond the virtual `exit` terminator.
- Reserved-word declaration diagnostics.
- `OPTION NOKEYWORD` keyword-control compatibility.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style notes were found.

Stale non-TODO wording/comments corrected:

- Parser comments that still described direct JMP runtime execution as deferred after Phase 61.
- Source-run test header that mislabeled Phase 61 as parsing/lowering instead of runtime execution.
- Supported-syntax wording that described all control flow as deferred after direct JMP runtime execution became current behavior.
- Rendered-message fixture names that still used `phase60` for Phase 61 direct-JMP target diagnostics.
- `docs/MILESTONE_HISTORY.md` concise ledger ordering after Phase 61 follow-up.

### Unresolved TODO-related risks

- None for Phase 61.
- Known future risk: until the future reserved-word symbol diagnostics phase is implemented, reserved-word labels such as `loop:` may still be accepted syntactically in a declaration position and later rejected when used as a branch target. This is reported as a known limitation, not unresolved Phase 61 work.

## 8. Design summary

Phase 61 was implemented as a narrow runtime execution milestone for the direct branch metadata added by Phase 60.

Primary design choices:

1. **Reuse Phase 60 lowering metadata.** The executor consumes resolved branch-target metadata already stored in IR. It does not repeat parser-level symbol classification during runtime.

2. **Make valid direct JMP a committed instruction.** A valid `jmp` now transfers instruction pointer control and counts as one executed instruction.

3. **Preserve the no-memory nature of direct JMP.** Direct JMP does not use memory helpers because it performs no simulated memory access, and it creates no memory-change rows.

4. **Preserve modeled flags.** Direct JMP does not consume or mutate `CF`, `ZF`, `SF`, `OF`, or flag-validity metadata.

5. **Keep procedure-entry JMP as direct branch only.** Procedure-entry labels are jump targets only. They do not imply procedure invocation, stack behavior, or calling conventions.

6. **Retain Phase 60 rejected-target classification.** Data symbols, equates, Irvine32 symbols, unknown targets, registers, memory targets, immediates, instruction names, directive names, external/WinAPI names, no-executable labels, and distance/type overrides remain rejected by parser/lowering.

7. **Add runtime metadata defense.** Malformed branch metadata reports `invalid-branch-target` with no partial mutation, mainly for native executor/IR resilience.

8. **Preserve instruction watchdog semantics.** Backward direct JMP is executable and can reach `instruction-limit-exceeded` deterministically.

9. **Keep reserved-word behavior MASM-compatible in current scope.** The simulator does not implement `OPTION NOKEYWORD`; instruction mnemonic direct-JMP targets such as `loop` remain rejected.

10. **Advance runtime/source-run phase metadata.** Because Phase 61 changes runtime-visible source behavior, repository/archive milestone and runtime/source-run MASM behavior phase both advance to Phase 61.

## 9. Files changed

Files changed across implementation, compliance passes, user-test follow-up, reserved-word correction, and final gap check:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_ir.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`
- `web/src/worker.js`

No C++ core files were introduced. Core implementation remains C99.

## 10. Tests added

### Native executor tests

Added or extended tests for:

- Direct JMP forward branch transfer.
- Direct JMP counts as one executed instruction.
- Direct JMP preserves modeled flags.
- Direct JMP preserves Phase 50A flag-validity metadata.
- Direct JMP creates no memory-change row.
- Malformed branch-target metadata reports `invalid-branch-target`.
- Malformed branch-target metadata failure preserves no-partial-mutation behavior.

### Source-run tests

Added or extended tests for:

- Valid forward direct JMP skips fall-through instructions and completes successfully.
- Valid direct JMP as the first executable instruction.
- Valid direct JMP to the immediately following instruction.
- Valid direct JMP to a procedure-entry target as direct branch only.
- Backward direct JMP reaches instruction-limit diagnostics deterministically.
- Instruction-limit precedence before fetching a later JMP.
- Valid direct JMP no longer emits `branch-runtime-deferred`.
- `jmp exit` remains invalid as a direct branch target.
- `exit` virtual terminator behavior remains separate and valid where already implemented.
- Reserved instruction mnemonic target regression: `jmp loop` remains rejected as an instruction mnemonic target in current scope.

### Rendered Simulator Messages tests

Added or updated exact rendered-message coverage for:

- Direct JMP success path.
- Rejected direct-JMP target diagnostics inherited from Phase 60.
- Instruction-mnemonic target diagnostic after reserved-word follow-up.
- Absence of `branch-runtime-deferred` for valid direct JMP.

### Protocol/status/static tests

Added or updated tests for:

- Phase 61 repository/runtime status metadata.
- Worker/protocol Phase 61 status strings.
- Browser-visible status text.
- Default website example direct JMP runtime behavior.
- Documentation/status consistency.
- Concise milestone-history ordering after final gap check.

### Regression tests

Preserved or updated regressions for:

- Phase 58 label/procedure-entry metadata.
- Phase 59 instruction-count accounting.
- Phase 60 direct branch target classification.
- Rejected data/equate/Irvine/unknown/register/memory/immediate/distance/directive/instruction/external targets.
- Future-owned conditional/control-flow features remaining unsupported.
- Program Console and Simulator Messages separation.
- No accidental memory planned-access changes.

## 11. Commands used to test

### Pre-change verification from Prompt 2

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed; group skipped because dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

### Implementation focused tests

Focused commands run after implementation:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Results:

```text
--structure: PASS
--native: PASS
--source-run: PASS
--web: PASS
--diagnostics: PASS
--protocol: PASS
--static: PASS
```

Classification:

```text
focused groups passed
```

### Implementation aggregate test

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate completed and passed; group skipped because dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

### First compliance review tests

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result summary:

- An initial chained focused command timed out after `--web` in the assistant/container environment.
- That timeout was treated as an assistant/container command timeout, not a project failure.
- Remaining focused groups were rerun individually and passed.

Aggregate command:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
focused command timed out in assistant/container environment and was rerun by focused groups; aggregate completed and passed; dependency skipped: emcc unavailable
```

### Second compliance review tests

Commands rerun:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Result summary:

- `--source-run`: PASS
- `--web`: PASS
- `--diagnostics`: PASS
- `--static`: PASS
- A chained command including `--all` timed out after focused groups completed.
- `--all` was rerun separately and passed.

Aggregate result:

```text
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
focused groups passed; aggregate rerun separately and completed and passed; dependency skipped: emcc unavailable
```

### User-test follow-up tests

Commands rerun after the first user-test follow-up fix:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Result:

```text
--source-run: PASS
--web: PASS
--diagnostics: PASS
--static: PASS
--all: PASS
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate completed and passed; dependency skipped: emcc unavailable
```

### Reserved-word follow-up correction tests

Commands rerun after correcting the too-permissive `loop` follow-up behavior:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Result:

```text
--source-run: PASS
--web: PASS
--diagnostics: PASS
--static: PASS
--all: PASS
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate completed and passed; dependency skipped: emcc unavailable
```

### Final gap-check tests

Commands rerun:

```bash
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --all
```

Results:

```text
--static: PASS
--source-run: PASS
--web: PASS
--diagnostics: PASS
--protocol: PASS
--all: PASS
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate completed and passed; focused groups passed; group skipped because dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

No focused group failed. No real aggregate failure occurred. No subgroup or fixture-family reruns were needed for a failing project test.

## 12. Pass/fail result distinction

Observed result categories during the milestone:

- **Aggregate completed and passed:** yes, repeatedly. Final aggregate result was `All implemented milestone tests passed.`
- **Aggregate timed out but focused groups passed:** no final aggregate timeout remained. Some chained assistant/container commands timed out, but aggregate was rerun separately and completed successfully.
- **Aggregate failed:** no.
- **Focused group failed:** no.
- **Focused group timed out and was rerun by subgroup/fixture:** no project focused group failure required fixture-family reruns. Chained command timeout was rerun with individual focused commands.
- **Group skipped because a dependency was unavailable:** yes. Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in this environment.

## 13. Manual/browser testing guidance and expected outputs

Phase 61 is website-testable after a fresh Emscripten/Wasm rebuild.

Required browser setup on Windows:

```cmd
where emcc
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Then open:

```text
http://localhost:8000
```

If `emcc` is unavailable, skip browser rebuild and use local source-run tests instead. This skip is not a Phase 61 failure.

### Browser/manual Program A - forward direct JMP

```asm
.code
main PROC
    mov eax, 1
    jmp done
    mov ebx, 2
done:
    mov ecx, 3
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
<blank>
```

Expected key registers:

```text
EAX = 00000001h
EBX = 00000000h
ECX = 00000003h
EFLAGS = 00000000h
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `branch-runtime-deferred` appears.
- `EBX` becomes `00000002h`.
- `ECX` remains `00000000h`.
- `execution-complete` is missing.

### Browser/manual Program B - procedure-entry target as direct branch only

```asm
.code
main PROC
    mov eax, 1
    jmp targetProc
    mov ebx, 2
main ENDP

targetProc PROC
    mov ecx, 3
    mov edx, 4
targetProc ENDP
END main
```

Expected key registers:

```text
EAX = 00000001h
EBX = 00000000h
ECX = 00000003h
EDX = 00000004h
EFLAGS = 00000000h
```

Expected messages:

```text
startup-state-notice
execution-complete
```

Regression signs:

- `EBX = 00000002h`.
- Stack/procedure/calling-convention behavior appears.
- `branch-runtime-deferred` appears.

### Browser/manual Program C - invalid `jmp exit` remains rejected

```asm
INCLUDE Irvine32.inc
.code
main PROC
    jmp exit
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-branch-target line 4, column 9, byte offset 45, span length 4: JMP target cannot be an Irvine32 virtual routine, virtual terminator, Windows/API name, or external symbol. Direct JMP accepts only code labels.
```

Expected Program Console:

```text
<blank>
```

Regression signs:

- Program executes.
- `jmp exit` is accepted.
- The diagnostic becomes generic or milestone-relative.

### Browser/manual Program D - reserved mnemonic target remains rejected in current scope

```asm
.code
main PROC

mov eax, 0

loop:
inc eax
jmp loop

main ENDP
END main
```

Expected result in current Phase 61 scope:

```text
[assembly-error] invalid-branch-target ... JMP target cannot be an instruction mnemonic. Use a code label with an executable target instruction.
```

The exact line/column/byte offset may differ if blank lines or indentation are changed.

Regression signs:

- Program executes and reaches instruction limit.
- The simulator treats `loop` as a valid label despite `OPTION NOKEYWORD` being unsupported.

Recommended portable infinite-loop test:

```asm
.code
main PROC
again:
    inc eax
    jmp again
main ENDP
END main
```

With a low instruction limit, expected runtime diagnostic:

```text
instruction-limit-exceeded
```

## 14. Compliance review summary

First compliance review found and fixed:

- Stale Phase 60 wording in `src/parser/parser.c` that said direct JMP runtime branch execution was still deferred.
- Stale Phase 60 wording in `src/parser/parser.h` that said branch transfer/execution remained deferred until Phase 61.
- `tests/core/test_wasm_source_run.c` file header incorrectly described Phase 61 as direct JMP parsing and target lowering.
- `docs/SUPPORTED_SYNTAX.md` still said all control flow was deferred, which was no longer accurate after direct JMP runtime execution.

First compliance review verdict:

```text
complete
```

## 15. Re-review summary

Second compliance review found and fixed:

- Rendered-message fixture names in `tests/web/test_diagnostic_rendering.mjs` still used `phase60...` for direct-JMP target diagnostics now asserted under Phase 61.
- A planned Phase 61 edge case was missing explicit coverage: `jmp` to the immediately following executable instruction.

Second compliance review added:

- Source-run regression for `jmp` to the immediately following instruction.
- Renamed stale rendered-message fixture names from `phase60...` to `phase61...` where appropriate.

Second compliance review verdict:

```text
complete
```

Final gap check found and fixed:

- `docs/MILESTONE_HISTORY.md` recent concise ledger entries were out of sequence after Phase 61/reserved-word follow-up.

Final gap-check verdict:

```text
complete
```

## 16. User-test follow-up summary

The user reported that all provided manual tests appeared to pass.

The user then tested an exploratory infinite loop using a label named `loop`:

```asm
.code
main PROC

mov eax, 0

loop:
inc eax
jmp loop

main ENDP
END main
```

Observed result before discussion:

```text
[assembly-error] invalid-branch-target ... JMP target cannot be an instruction mnemonic. Use a code label with an executable target instruction.
```

Initial follow-up diagnosis:

- Real MASM treats `loop` as a reserved instruction mnemonic by default.
- The user's `ml.exe` test produced MASM compiler errors for `loop:` and `jmp loop`.
- The proper portable simulator test for instruction-limit behavior should use a non-keyword label such as `again:`.

An initial fix briefly made `loop:` work in the simulator by allowing a declared code label to override the instruction mnemonic. The user then correctly questioned the discrepancy with real MASM behavior.

Final follow-up correction:

- Reverted the too-permissive behavior.
- Preserved current MASM compliance scope: `loop` remains an instruction mnemonic/reserved target in Phase 61.
- Did not implement `OPTION NOKEYWORD`.
- Did not implement full reserved-word declaration diagnostics.
- Updated tests so the `loop:` exploratory program expects `invalid-branch-target`, not `instruction-limit-exceeded`.

Known limitation recorded:

- The future reserved-word symbol diagnostics phase should reject reserved-word labels at declaration time, producing a clearer error before later `jmp loop` use.

## 17. Known limitations

- Browser/Wasm artifacts were not rebuilt in the assistant/container environment because `emcc` was unavailable.
- Served website verification requires a fresh Emscripten/Wasm rebuild before testing Phase 61 behavior in the browser.
- `branch-runtime-deferred` remains in the enum/message path for possible future accepted-but-deferred branch forms, but valid direct `jmp label` does not use it.
- Reserved instruction mnemonics such as `loop` remain rejected as direct-JMP targets. Full reserved-word declaration diagnostics are future work.
- `OPTION NOKEYWORD` is unsupported and remains future work.
- Conditional jumps, `cmp`, `loop`, indirect jumps, register/memory jump targets, distance overrides, `call`, `ret`, stack/procedure behavior, Irvine32 calls, debugger stepping, breakpoints, and editor/source navigation remain future work.
- Phase 61 does not add browser UI controls for instruction-limit settings.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 62 - CMP Register and Immediate Forms
```

Expected next archive name after acceptance:

```text
Latest_repository_state_milestone_62.zip
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced during this milestone:

- `phase61_changed_files.zip`
- `milestone_61_first_compliance_check.zip`
- `milestone_61_second_compliance_check.zip`
- `milestone_61_user_followup_fix.zip`
- `milestone_61_reserved_word_followup_fix.zip`
- `milestone_61_final_compliance_check.zip`

Final compliance package:

```text
milestone_61_final_compliance_check.zip
```

Recommended repository/archive package for the accepted complete milestone state:

```text
Latest_repository_state_milestone_61.zip
```

This report does not itself create the full repository archive. It recommends that the accepted repository state be archived under that name.
