# Milestone 61E report - Reserved Word Symbol Diagnostics

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 61E - Reserved Word Symbol Diagnostics
```

Repository/archive milestone after this work:

```text
Phase 61E - Reserved Word Symbol Diagnostics
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 61E - Reserved Word Symbol Diagnostics
```

Scope implemented:

- Added parser/source-run diagnostics for user-defined symbol declarations that use simulator-recognized MASM reserved words.
- Rejected reserved-word declarations for data symbols, numeric equates, code labels, and procedure names.
- Added structured diagnostic code `reserved-word-symbol`.
- Preserved source line, column, byte offset, and span length for the declaration token where available.
- Kept reserved-word matching case-insensitive and independent from `OPTION CASEMAP`.
- Preserved `OPTION NOKEYWORD` as unsupported.
- Preserved Phase 61 direct-JMP runtime behavior, Phase 61D capacity diagnostics, and all future-feature boundaries.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_61E.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 61D report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_61D.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, status-surface hygiene, and broad product constraints.
- The implementation guide owns Phase 61E numbering, exact phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or implementation guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or implementation guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

## 3. Exact requirements implemented

### 3.1 Reserved-word declaration diagnostics

Implemented `reserved-word-symbol` diagnostics for declarations that attempt to use a simulator-recognized MASM reserved word as a user-defined symbol.

Declaration categories covered:

- data symbols;
- numeric equates;
- code labels;
- procedure names.

Examples now rejected:

```asm
.code
main PROC
loop:
main ENDP
END main
```

```asm
.data
mov DWORD 1
eax DWORD 1
DWORD DWORD 1
OFFSET DWORD 1
```

```asm
add EQU 2
```

```asm
.code
loop PROC
loop ENDP
END loop
```

### 3.2 Case-insensitive reserved-word matching

Reserved-word matching is case-insensitive. For example, `loop:`, `LOOP:`, and `Loop:` are all rejected because `LOOP` is a recognized reserved instruction mnemonic.

### 3.3 CASEMAP separation

`OPTION CASEMAP` continues to control lookup for accepted user-defined symbols only. It does not make reserved words available as declarations.

Implemented regression coverage proving this remains rejected:

```asm
OPTION CASEMAP:NONE
.code
main PROC
LOOP:
main ENDP
END main
```

### 3.4 OPTION NOKEYWORD remains unsupported

`OPTION NOKEYWORD` remains unsupported and does not enable reserved-word identifiers.

Implemented rendered-message coverage for:

```asm
OPTION NOKEYWORD:<LOOP>
.code
main PROC
loop:
main ENDP
END main
```

Expected behavior remains:

- `unsupported-option` for `OPTION NOKEYWORD`;
- `reserved-word-symbol` for `loop:`;
- no execution.

### 3.5 Irvine32 registry boundary

Irvine32 routine and terminator reserved-name classification uses the existing Phase 41 virtual Irvine32 registry/classification path. The implementation does not hardcode a second independent Irvine32 name list in the parser.

### 3.6 Rejected declarations are not inserted

Rejected reserved-word declarations are not inserted into the relevant user-symbol tables. Follow-on references may still produce ordinary parser recovery diagnostics, but the primary declaration-site diagnostic is `reserved-word-symbol`.

### 3.7 Runtime/source-run metadata advancement

Because Phase 61E changes source acceptance/rejection behavior, current runtime/source-run metadata now reports:

```json
{
  "phase": 61,
  "phaseSuffix": "E",
  "phaseName": "Phase 61E - Reserved Word Symbol Diagnostics"
}
```

Current-status documentation was updated so repository/archive milestone and runtime/source-run MASM behavior phase both identify Phase 61E.

### 3.8 Preservation of prior behavior

Preserved:

- Phase 61 direct `jmp label` runtime execution for valid labels.
- Phase 59 instruction-count watchdog behavior for executable direct-JMP loops.
- Phase 61B instruction-count watchdog boundary.
- Phase 61C debugger/editor non-goal boundary.
- Phase 61D parser/source-run capacity diagnostic distinctions.
- Existing Program Console versus Simulator Messages separation.
- Existing source-location preservation for diagnostics.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 61E:

- Full MASM reserved-word table import.
- `OPTION NOKEYWORD` behavior or dynamic keyword-table mutation.
- Phase 62 `cmp` register/immediate forms.
- Conditional jumps.
- `loop`, `loope`, `loopne`, `jcxz`, or `jecxz` runtime behavior.
- Indirect jumps.
- Register-target, memory-target, or immediate-target `jmp` execution.
- Branch-distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Relative branch encoding or real x86 instruction encoding.
- Native x86 execution.
- Stack or procedure execution semantics.
- `call`, `ret`, `leave`, `push`, or `pop`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 callable routines beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Active-time watchdog behavior.
- Wall-clock execution limits.
- Worker yielding/chunking for responsiveness.
- Browser UI controls for execution time or capacity limits.
- Macro expansion.
- Debugger stepping, breakpoints, breakpoint binding, editor source navigation, current-instruction highlighting, CodeMirror gutter behavior, or branch-target editor highlighting.

Future work intentionally preserved:

- Phase 62 - CMP Register and Immediate Forms.
- Later conditional jump phases.
- Later `loop` phase.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- Future memory-reading opcode planned-access work noted in `src/wasm/wasm_api.c`.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Reserved-word checking should occur before inserting any user-defined symbol into data-symbol, equate, code-label, or procedure-name tables.
- **Reason:** The guide requires rejected reserved-word declarations not to be inserted.
- **Risk:** Existing parser recovery may still emit secondary diagnostics after the primary declaration diagnostic.
- **How to change later:** Add more targeted cascade suppression in a future diagnostics-quality phase if implementation shows noisy duplicate follow-ons.

### Assumption 2

- **Assumption:** Existing parser-recognized words are the reserved-word source for Phase 61E, not the complete MASM reserved-word table.
- **Reason:** The guide explicitly forbids importing or fully reproducing the complete MASM reserved-word table in this phase.
- **Risk:** Some real MASM reserved words not yet known to the simulator may remain usable as symbols.
- **How to change later:** Future phases that add recognized keywords must update the reserved-word classifier at the same time.

### Assumption 3

- **Assumption:** Runtime/source-run metadata must advance from Phase 61 to Phase 61E.
- **Reason:** Phase 61E changes runtime/source-run source acceptance/rejection behavior.
- **Risk:** Existing tests and status text that asserted Phase 61 metadata needed careful updates.
- **How to change later:** Only change phase metadata again when a later phase changes runtime/source-run MASM behavior or explicitly owns metadata advancement.

### Assumption 4

- **Assumption:** `OPTION NOKEYWORD` behavior remains rejected through existing unsupported-option handling.
- **Reason:** The spec and guide both defer keyword disabling to a later explicit phase.
- **Risk:** Tests combining `OPTION NOKEYWORD` with `loop:` may produce both `unsupported-option` and `reserved-word-symbol` diagnostics depending on parser recovery.
- **How to change later:** A future `OPTION NOKEYWORD` phase must define source-order behavior, keyword restoration, CASEMAP interaction, and exact diagnostics.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in this environment.
- **Risk:** Locally served browser artifacts may remain stale until a developer rebuilds Wasm with Emscripten configured.
- **How to change later:** Run the Windows Emscripten build script in an environment where `emcc` is available.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning, implementation, compliance review, second review, manual-test preparation, and final gap check:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61E - Reserved Word Symbol Diagnostics
- Note text or summary:
  Reserved-word user-symbol diagnostics are the selected milestone scope.
- Classification:
  target-owned
- Reason:
  This is the selected TARGET_MILESTONE.
- Action for this milestone:
  Implemented reserved-word declaration rejection and tests.
```

```text
- Location:
  docs/FULL_IMPLEMENTATION_SPEC.md, Section 8.1.3A Reserved Words and User-Defined Symbols
- Note text or summary:
  MASM reserved words are not valid user-defined symbols by default. OPTION CASEMAP does not make reserved words available.
- Classification:
  target-owned
- Reason:
  This is the stable behavior contract implemented by Phase 61E.
- Action for this milestone:
  Implemented and documented.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61E Irvine32 registry boundary
- Note text or summary:
  Irvine32 routine and terminator reserved-name checks must use the centralized Phase 41 registry or a documented wrapper.
- Classification:
  target-owned
- Reason:
  Directly constrains Phase 61E implementation design.
- Action for this milestone:
  Implemented by routing Irvine32 name classification through the existing registry path.
```

```text
- Location:
  docs/FULL_IMPLEMENTATION_SPEC.md and docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, OPTION NOKEYWORD notes
- Note text or summary:
  OPTION NOKEYWORD remains unsupported until a later explicit keyword-control phase.
- Classification:
  future-owned
- Reason:
  Phase 61E must not implement keyword disabling or dynamic keyword-table mutation.
- Action for this milestone:
  Preserved unsupported behavior and added/maintained regression coverage.
```

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
- Classification:
  future-owned
- Reason:
  Phase 61E is not a memory-reading instruction milestone.
- Action for this milestone:
  Left unchanged.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 61E reserved-word symbol diagnostics were implemented.
- Reserved-word behavior from the specification was implemented for current relevant declaration categories.
- The Irvine32 registry boundary was preserved.
- Required diagnostics and rendered-message coverage were added.

### Future-owned TODO-style notes intentionally preserved

- `OPTION NOKEYWORD` keyword-control compatibility.
- Future memory-reading opcode planned-access TODO in `src/wasm/wasm_api.c`.
- Phase 62 `cmp`.
- Conditional jumps.
- `loop` runtime behavior.
- Stack/procedure behavior.
- Debugger/editor/source-map behavior.
- Active-time watchdog behavior.
- Macro/linker/WinAPI behavior.

### Stale or contradicted TODO-style notes corrected

- None found.

The compliance and second-review passes corrected stale non-TODO wording in tests, but no stale TODO-style note required correction.

### Unresolved TODO-related risks

- None specific to Phase 61E.

## 8. Design summary

Phase 61E was implemented as a focused parser/source-run diagnostics milestone.

Primary design choices:

1. **Parser-local reserved-word classifier for current simulator-recognized words.** The implementation uses the simulator's current keyword surface instead of importing the complete MASM reserved-word table.

2. **Early declaration rejection.** Reserved-word checks run before insertion into data-symbol, equate, code-label, or procedure-name tables, ensuring rejected reserved names are not available for later lookup or execution.

3. **Source-location preserving diagnostics.** The diagnostic points at the declaration name token where possible and preserves line, column, byte offset, and span length.

4. **CASEMAP separation.** The existing user-symbol case policy remains limited to accepted user-defined symbols. Reserved-word matching is independent and case-insensitive.

5. **Centralized Irvine32 registry usage.** Irvine32 reserved-name classification uses the existing registry/classification mechanism rather than a second parser-only list.

6. **Runtime metadata advancement.** Because the source acceptance/rejection behavior changed, runtime/source-run metadata and protocol/status tests were updated to Phase 61E.

7. **No future feature creep.** The phase did not add `OPTION NOKEYWORD`, `cmp`, conditional jumps, `loop` runtime behavior, stack/procedure semantics, debugger/editor behavior, active-time watchdogs, macros, linker behavior, or WinAPI behavior.

## 9. Files changed

Changed files in the final Phase 61E state:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `scripts/run_tests.py`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `web/src/protocol.js`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`

## 10. Tests added

Added or strengthened tests/checks:

- Parser diagnostic tests for reserved instruction labels.
- Parser diagnostic tests for mixed-case reserved labels.
- Parser diagnostic tests for `OPTION CASEMAP:NONE` plus reserved labels.
- Parser diagnostic tests for reserved data symbols.
- Parser diagnostic tests for reserved register names and aliases where relevant.
- Parser diagnostic tests for reserved data type names.
- Parser diagnostic tests for reserved operator names.
- Parser diagnostic tests for reserved numeric equates.
- Parser diagnostic tests for reserved procedure names.
- Parser diagnostic tests for Irvine32 registry names.
- Parser success regression tests for nearby non-reserved names.
- Source-run JSON tests proving `loop:` now fails with `reserved-word-symbol` before execution.
- Source-run metadata tests for Phase 61E.
- Rendered Simulator Messages tests for:
  - reserved code label;
  - reserved data symbol;
  - `OPTION CASEMAP:NONE` reserved label;
  - reserved numeric equate;
  - reserved procedure name;
  - `OPTION NOKEYWORD:<LOOP>` remaining unsupported while `loop:` remains reserved.
- Protocol/status tests updated for Phase 61E.
- Static documentation/status checks updated for Phase 61E.
- Regression fixture cleanup where older tests used now-reserved names such as `loop`, `ch`, or `short` as ordinary symbols.

Coverage added:

- Declaration-site reserved-word diagnostics.
- Case-insensitive reserved-word matching.
- CASEMAP separation.
- OPTION NOKEYWORD deferral.
- Source-run parse-failure behavior.
- Rendered Simulator Messages quality.
- Phase metadata/status consistency.
- Valid non-reserved label behavior.
- Direct-JMP and instruction-count watchdog preservation for valid labels.

## 11. Commands used to test

### Pre-implementation repository verification

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate completed and passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Implementation verification

Focused commands run:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate completed and passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### First compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate completed and passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Second compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --static
```

Result:

```text
Focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate completed and passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Final gap-check verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
```

Result:

```text
Focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate completed and passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

No subgroup or fixture-family reruns were required because focused groups and aggregate completed successfully.

## 12. Pass/fail result classification

Final classification:

```text
aggregate completed and passed
group skipped because dependency was unavailable, such as emcc
```

No aggregate timeout occurred during final verification.

No focused group failed.

No focused group timed out.

No subgroup or fixture-family reruns were needed.

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

This is an environment dependency skip, not a test failure.

## 13. Manual/browser testing guidance and expected outputs

Phase 61E is website-testable after rebuilding Wasm artifacts with Emscripten. It is also testable through local native/source-run/diagnostic tests without Emscripten.

### Browser setup on Windows CMD

```bat
cd path\to\project
call C:\_CPP_TOOLS\emsdk\emsdk_env.bat
where emcc
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

`where emcc` should print an `emcc` path. If it does not, browser testing may use stale Wasm artifacts.

### Browser test 1: reserved code label

```asm
.code
main PROC
loop:
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] reserved-word-symbol line 3, column 1, byte offset 16, span length 4: 'loop' is a reserved MASM instruction mnemonic and cannot be used as a code label.
```

Expected Program Console:

```text
(empty)
```

Expected behavior:

```text
No execution-complete message.
No instruction-limit-exceeded message.
No branch-runtime-deferred message.
```

### Browser test 2: reserved data symbol

```asm
.data
mov DWORD 1
.code
main PROC
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] reserved-word-symbol line 2, column 1, byte offset 6, span length 3: 'mov' is a reserved MASM instruction mnemonic and cannot be used as a data symbol.
```

Expected Program Console:

```text
(empty)
```

### Browser test 3: CASEMAP does not allow reserved labels

```asm
OPTION CASEMAP:NONE
.code
main PROC
LOOP:
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] reserved-word-symbol line 4, column 1, byte offset 36, span length 4: 'LOOP' is a reserved MASM instruction mnemonic and cannot be used as a code label.
```

Expected Program Console:

```text
(empty)
```

### Browser test 4: OPTION NOKEYWORD remains unsupported

```asm
OPTION NOKEYWORD:<LOOP>
.code
main PROC
loop:
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-option line 1, column 1, byte offset 0, span length 6: Unsupported OPTION form. Supported CASEMAP values: ALL, NONE. Recognized but unsupported: NOTPUBLIC.
[assembly-error] reserved-word-symbol line 4, column 1, byte offset 40, span length 4: 'loop' is a reserved MASM instruction mnemonic and cannot be used as a code label.
```

Expected Program Console:

```text
(empty)
```

### Browser test 5: valid non-reserved labels still work

```asm
.code
main PROC
    mov eax, 41
again:
    inc eax
    jmp done
done:
    nop
main ENDP
END main
```

Expected Simulator Messages include:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected final register:

```text
EAX = 0000002Ah / 42
```

### Windows CMD local testing

From the project root:

```bat
py scripts\run_tests.py --source-run
py scripts\run_tests.py --diagnostics
py scripts\run_tests.py --protocol
py scripts\run_tests.py --static
```

Expected output snippets:

```text
[source-run] PASS - source-run integration binary passed independently
Selected test groups passed.
```

```text
[diagnostics] PASS - native diagnostic producer and rendered messages passed
Selected test groups passed.
```

```text
[protocol] PASS - protocol tests passed independently
Selected test groups passed.
```

```text
[static] PASS - runner/documentation consistency checks passed
Selected test groups passed.
```

Optional aggregate:

```bat
py scripts\run_tests.py --all
```

Expected output:

```text
All implemented milestone tests passed.
```

If `emcc` is not configured, this skip is acceptable:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Regression signs

Treat any of these as a regression:

- `loop:`, `LOOP:`, or `Loop:` is accepted as a label.
- `mov DWORD 1`, `eax DWORD 1`, `DWORD DWORD 1`, or `OFFSET EQU 4` is accepted as a user symbol.
- `OPTION CASEMAP:NONE` makes reserved words available as labels or data symbols.
- `OPTION NOKEYWORD:<LOOP>` enables `loop:` instead of remaining unsupported.
- Reserved-word diagnostics lack line, column, byte offset, or span length.
- Reserved-word diagnostics appear in Program Console instead of Simulator Messages.
- Valid non-reserved labels such as `again:` and `done:` are rejected.
- Browser status still reports Phase 61 or Phase 61D after rebuilding Wasm.

## 14. Compliance review summary

First compliance review found two gaps:

1. Rendered Simulator Messages coverage existed for reserved labels, reserved data symbols, and CASEMAP interaction, but exact rendered tests were missing for reserved equate/procedure-name diagnostics and `OPTION NOKEYWORD` remaining unsupported with a reserved label.
2. Some source-run assertion descriptions still used stale “runtime Phase 61 metadata” wording after Phase 61E metadata advancement.

Fixes applied:

- Added exact rendered Simulator Messages tests for:
  - reserved numeric equate;
  - reserved procedure name;
  - `OPTION NOKEYWORD:<LOOP>` remaining unsupported while `loop:` remains rejected.
- Updated stale source-run assertion descriptions to refer to Phase 61E metadata.

Review result:

```text
complete
```

## 15. Re-review summary

Second compliance review found only minor stale wording in `tests/core/test_wasm_source_run.c` comments/assertion labels:

- one metadata comment still referred to Phase 61 rather than Phase 61E;
- assertion labels referred to “loop label source” for a fixture that tests the unsupported future `LOOP` instruction;
- a few assertion descriptions said “numeric Phase 61 metadata” where “numeric Phase 61E metadata” was clearer.

Fixes applied:

- Updated comments/assertion labels only.
- No implementation behavior changed.
- No documentation behavior changed.
- No future milestone behavior added.

Review result:

```text
complete
```

## 16. User-test follow-up summary

The user reported no discrepancies after Prompt 7 manual testing guidance. Prompt 8 was skipped as allowed by the workflow, and the session proceeded directly to Prompt 9 final gap check.

Final gap check found no missing Phase 61E work.

## 17. Known limitations

- Browser/Wasm rebuild smoke was skipped in the assistant/container environment because `emcc` is unavailable.
- The served website requires a Wasm rebuild in an Emscripten-configured environment before Phase 61E behavior is visible there.
- Phase 61E covers simulator-recognized reserved words only. It does not import the complete MASM reserved-word table.
- `OPTION NOKEYWORD` remains unsupported.
- Future instruction/control-flow/debugger/watchdog/procedure features remain outside this milestone.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 62 - CMP Register and Immediate Forms
```

Phase 62 should begin from the accepted Phase 61E repository archive:

```text
Latest_repository_state_milestone_61E.zip
```

## 19. Changed-files ZIP/package produced

Changed-files and compliance packages produced during this milestone:

- `phase61e_changed_files.zip`
- `milestone_61E_first_compliance_check.zip`
- `milestone_61E_second_compliance_check.zip`

No final compliance ZIP was produced because the final gap check did not change project files.

No latest full repository archive was created during this report step. Recommended archive name for the accepted full repository state:

```text
Latest_repository_state_milestone_61E.zip
```
