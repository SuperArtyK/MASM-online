# Milestone 58 report - Code Label Table and Label Diagnostics

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 58 - Code Label Table and Label Diagnostics
```

Repository/archive milestone after this work:

```text
Phase 58 - Code Label Table and Label Diagnostics
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 58 - Code Label Table and Label Diagnostics
```

Scope implemented:

- Added parser-owned code label metadata for ordinary `name:` labels.
- Added parser-owned procedure-entry label metadata for `name PROC` declarations.
- Added label target classification metadata for executable-instruction targets, procedure-entry targets, and no-executable-target labels.
- Added duplicate and conflict diagnostics for code labels and procedure-entry labels against current user-symbol categories.
- Preserved user-symbol `OPTION CASEMAP` policy for code labels and procedure names.
- Preserved straight-line execution semantics. Labels do not emit executable IR instructions, do not mutate runtime state, and do not enable branches.
- Advanced repository/archive and runtime/source-run current-status surfaces to Phase 58.
- Added native, source-run, rendered diagnostic, protocol, and static/status coverage for the new behavior.

Scope intentionally not implemented:

- Branch parsing or branch execution.
- Direct `jmp`, conditional jumps, `loop`, `call`, `ret`, stack behavior, procedure invocation, debugger stepping, breakpoints, and UI click-to-label behavior.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status and verification files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57T report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_57T.zip
```

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_58.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, and current-status surface hygiene.
- The incremental implementation guide owns phase numbering, target milestone scope, per-phase tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the spec/guide.
- TODO-style notes are implementation-risk evidence only. They do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

## 3. Exact requirements implemented

### 3.1 Ordinary code label acceptance

Implemented acceptance and metadata recording for ordinary code labels such as:

```asm
start:
loop_top:
```

Accepted code labels are recorded in a bounded parser-owned label table. They preserve source spelling and source location metadata.

### 3.2 Procedure-entry label metadata

Implemented metadata recording for procedure declarations as procedure-entry labels:

```asm
main PROC
main ENDP
```

Procedure-entry labels are distinct in metadata classification but participate in the same current user-defined symbol namespace conflict checks as ordinary labels.

### 3.3 Label target classification metadata

Implemented target classification metadata for accepted labels:

- executable-instruction target;
- procedure-entry target;
- no-executable-target.

The metadata is internal parser/source metadata for Phase 58. No new public label-table JSON API was added.

### 3.4 Multiple labels before one instruction

Implemented multiple pending labels before a single executable instruction. Consecutive labels point to the same following executable IR instruction and do not create additional executable instructions.

Example accepted behavior:

```asm
.code
main PROC
first:
second:
    mov eax, 1
main ENDP
END main
```

`first` and `second` both target the `mov` instruction. The `mov` executes once.

### 3.5 No-executable-target labels

Implemented no-executable-target metadata for labels that appear before non-executable boundaries, such as `ENDP`, `END`, or the end of a code region.

Such labels are accepted as metadata only and are not silently mapped to `ENDP`, `END`, program termination, or a later unrelated procedure.

### 3.6 CASEMAP policy for labels

Implemented label/procedure-name insertion and lookup under the current user-defined symbol CASEMAP policy:

- Default behavior is equivalent to `OPTION CASEMAP:ALL`, so labels differing only by ASCII case conflict.
- `OPTION CASEMAP:ALL` keeps case-insensitive user-symbol behavior.
- `OPTION CASEMAP:NONE` allows exact-case-distinct labels such as `Start:` and `start:`.
- Instruction mnemonics, directives, registers, virtual include names, and recognized Irvine32 names remain case-insensitive and are not affected by label CASEMAP behavior.

### 3.7 Duplicate and conflict diagnostics

Added structured diagnostics for:

- duplicate ordinary labels;
- ordinary label versus procedure-entry label conflicts;
- procedure-entry label versus ordinary label conflicts;
- label conflicts with existing data symbols;
- label conflicts with existing numeric equates;
- folded-case conflicts under default/`CASEMAP:ALL`;
- exact-spelling conflicts under `CASEMAP:NONE`.

Diagnostics preserve:

- current declaration line;
- current declaration column;
- current byte offset;
- current source span length;
- prior-definition line/column information when available;
- conflicting symbol category where applicable.

### 3.8 Rendered Simulator Messages coverage

Added exact rendered Simulator Messages tests for new Phase 58 user-visible diagnostics, including duplicate labels and label/symbol conflict diagnostics.

### 3.9 Source-run behavior coverage

Added source-run tests proving valid labels preserve straight-line behavior and do not:

- emit executable IR instructions by themselves;
- mutate registers, flags, memory, or console output;
- create memory-change rows;
- enable branch execution.

### 3.10 Current-status updates

Updated current-status surfaces to Phase 58 where appropriate, including repository/archive and runtime/source-run MASM behavior metadata. Public-facing status text was later condensed during user-test follow-up so it reports the current milestone without accumulating long past-milestone accomplishment notes.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 58:

- Direct `jmp` parsing, lowering, or execution.
- Conditional jumps.
- `loop` execution.
- Branch target operand resolution for executable branch instructions.
- Instruction-pointer mutation.
- Control-flow runtime behavior.
- Instruction-count watchdog behavior from Phase 59.
- Direct jump behavior from later branch phases.
- `call`, `ret`, `leave`, stack frames, `USES`, `LOCAL`, `PROTO`, `INVOKE`, `ADDR`, procedure invocation, procedure argument lowering, or calling conventions.
- Irvine32 routine implementation beyond already-existing virtual `exit` behavior.
- High-level `.IF`, `.ELSE`, `.ENDIF`, `.WHILE`, `.REPEAT`, `.BREAK`, or `.CONTINUE` lowering.
- Macro expansion.
- Linker, PE-loader, WinAPI, host include-file, or host filesystem behavior.
- Debugger stepping, breakpoints, source maps, source navigation, or UI click-to-label behavior.
- Public label-table JSON/debugger API.

Future work intentionally preserved:

- Phase 59 - Control-Flow Instruction Limit.
- Later direct branch parsing and runtime branch execution phases.
- Later conditional jump, signed/unsigned relational jump, and `loop` phases.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Later Irvine32 routine phases.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Label metadata should remain parser/internal metadata in Phase 58 rather than becoming a new public source-run JSON API.
- **Reason:** The guide requires metadata and tests, but does not require public JSON enum names unless a tested API exposes labels. Keeping the metadata internal avoids premature debugger/source-map API design.
- **Risk:** Later debugger/source-navigation phases will need a public or protocol-visible label representation.
- **How to change later:** A later debugger/source-map phase can deliberately expose label metadata with a documented JSON shape, protocol tests, UI tests, and migration notes.

### Assumption 2

- **Assumption:** Numeric equates are part of the currently implemented user-symbol universe and should participate in Phase 58 conflict checks.
- **Reason:** The current repository includes numeric-equate support, and the Phase 58 requirements call for conflicts against numeric equates when that category is implemented.
- **Risk:** Equate conflict integration could have required broader symbol-table changes if the category had been isolated.
- **How to change later:** If later phases split namespaces, update the shared symbol policy and tests deliberately rather than making labels special-case exceptions.

### Assumption 3

- **Assumption:** Reusing stable symbol-conflict concepts with label-specific rendered wording is preferable to inventing overly broad future branch diagnostics.
- **Reason:** Phase 58 is about declarations and metadata, not branch target use. Diagnostics should describe duplicate/conflicting declarations rather than future branch behavior.
- **Risk:** Future branch phases may need additional diagnostics for unresolved, non-executable, or wrong-kind branch targets.
- **How to change later:** Add target-use diagnostics in the owning branch milestone while preserving Phase 58 declaration diagnostics.

### Assumption 4

- **Assumption:** Repository/archive and runtime/source-run MASM behavior metadata should both advance to Phase 58.
- **Reason:** Phase 58 changes accepted source/parser behavior. It is not documentation-only or test-runner-only work.
- **Risk:** Some status surfaces had accumulated verbose prior milestone notes and needed cleanup after advancement.
- **How to change later:** Continue using the repository/archive versus runtime/source-run distinction. For maintenance-only phases, advance only repository/archive status unless the guide explicitly says otherwise.

### Assumption 5

- **Assumption:** `jmp`, `loop`, `call`, and `ret` should remain on the existing unsupported-instruction path for Phase 58.
- **Reason:** Later control-flow/procedure phases own those features. Phase 58 only records label declarations.
- **Risk:** Users may expect labels to imply `jmp label` now works.
- **How to change later:** Implement branch parsing/execution only in the relevant later phases and update documentation/tests then.

## 6. Relevant TODO-style notes reviewed

Target-owned TODO-style evidence reviewed:

- Phase 58 guide requirements for ordinary code-label metadata.
- Phase 58 guide requirements for procedure-entry label metadata.
- Phase 58 guide requirements for executable/procedure-entry/no-executable target classification.
- Phase 58 guide requirements for duplicate/conflict diagnostics.
- Phase 58 guide requirements for CASEMAP label behavior.
- Phase 58 guide requirements for source-run and rendered diagnostic tests.
- Full-spec user-defined symbol CASEMAP policy.
- Full-spec duplicate-name policy across data symbols, labels, procedures, and equates.

Future-owned TODO-style notes reviewed and intentionally not implemented:

- Future memory-reading opcode planned-access TODO in `src/wasm/wasm_api.c`.
- CALL/Irvine32 callable behavior comments in parser code.
- Direct branch parsing/lowering and runtime branch execution notes.
- Conditional jump, `loop`, stack/procedure, debugger, and UI label-navigation roadmap notes.

Broad TODO-style categories reviewed and excluded as irrelevant to Phase 58:

- Future debugger/editor/share/URL work.
- Future stack and heap runtime behavior.
- Future Irvine32 routine bodies.
- Future macro compatibility.
- Future QWORD/SQWORD execution.
- Test fixture strings that intentionally mention unsupported future constructs.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 58 label metadata requirements were implemented.
- Phase 58 procedure-entry metadata requirements were implemented.
- Phase 58 duplicate/conflict diagnostics were implemented and rendered-message tested.
- Phase 58 CASEMAP label behavior was implemented and tested.
- Phase 58 source-run behavior and non-goal regressions were implemented and tested.
- Phase 58 documentation/status updates were completed.

### Future-owned TODO-style notes intentionally preserved

- Future memory-reading opcode planned-access TODO remains future-owned.
- CALL/Irvine32 callable behavior remains future-owned.
- Direct branch parsing/lowering and runtime branch execution remain future-owned.
- Conditional jumps, `loop`, stack/procedure behavior, debugger stepping, breakpoints, and UI label navigation remain future-owned.

### Stale or contradicted TODO-style notes corrected

- No stale or contradicted TODO-style notes were found.
- One stale static-check helper name and stale test/header wording were corrected during compliance and final gap checks, but these were not TODO-style notes.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 58 was implemented as parser/source metadata and diagnostics work.

Primary design choices:

1. **Reuse existing parser label recognition.** The parser already consumed label-prefix syntax in some paths. Phase 58 extended that path to record metadata instead of discarding labels.

2. **Keep labels out of executable IR.** Labels are source metadata only. They do not increase instruction count, do not mutate runtime state, and do not enable branch behavior.

3. **Use a bounded parser-owned label table.** Parser configuration/result structures now carry a caller-owned label table, preserving deterministic bounded C99 behavior.

4. **Resolve pending labels at executable-instruction emission.** Labels pending before an executable instruction receive executable-target metadata. Labels before `ENDP`, `END`, or equivalent non-executable boundaries are finalized as no-executable-target labels.

5. **Record `PROC` names as procedure-entry labels.** Procedure declarations become metadata targets but do not add callable procedure behavior.

6. **Apply the shared user-symbol policy.** Labels and procedure names use the same CASEMAP and conflict policy as other current user-defined symbols.

7. **Keep future target-use diagnostics out of scope.** Phase 58 does not validate branch operands because branch instructions remain unsupported.

8. **Keep public copy concise.** During user-test follow-up, verbose milestone accomplishment text in README/docs/index status surfaces was condensed to concise current Phase 58 wording.

## 9. Files changed

Files changed across implementation, compliance review, re-review, user-test follow-up, and final gap check:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_object_map.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

No C++ core files were introduced. Core implementation remains C99.

## 10. Tests added

### Native parser/metadata tests

Added or updated native tests for:

- ordinary code label metadata;
- procedure-entry label metadata;
- executable-instruction targets;
- procedure-entry targets;
- no-executable-target labels;
- multiple labels before one instruction;
- labels before `ENDP`/`END`;
- adjacent procedures;
- procedure bodies containing non-executable metadata only;
- label source line, column, byte offset, and span metadata;
- label conflict behavior against labels, procedure-entry labels, data symbols, and numeric equates;
- CASEMAP-sensitive and CASEMAP-insensitive label behavior.

### Source-run tests

Added or updated source-run tests for:

- valid labels preserving straight-line execution;
- multiple labels not creating extra execution;
- no Program Console output from labels;
- no memory-change rows from labels alone;
- duplicate labels refusing execution;
- conflicting labels refusing execution;
- `jmp label` remaining unsupported;
- `loop label` remaining unsupported.

### Rendered Simulator Messages tests

Added exact rendered-message tests for:

- duplicate label diagnostic;
- folded duplicate label under default/`CASEMAP:ALL`;
- data-symbol/code-label conflict diagnostic;
- procedure-entry followed by conflicting ordinary label;
- ordinary label followed by conflicting procedure-entry label.

### Protocol/static/status tests

Updated tests for:

- Phase 58 repository/archive status;
- Phase 58 runtime/source-run MASM behavior status;
- concise public-facing status copy;
- protocol/status metadata consistency;
- supported syntax and documentation status surfaces.

### Regression tests

Added or preserved regression tests for:

- current unsupported `jmp` behavior;
- current unsupported `loop` behavior;
- current unsupported CALL/procedure behavior through existing fixtures;
- existing source-run behavior without labels;
- existing diagnostic rendering harness behavior;
- CASEMAP behavior for non-label user symbols and syntax recognition.

## 11. Commands used to test

### Aggregate command

Aggregate command run after implementation and review passes:

```bash
python3 scripts/run_tests.py --all
```

Observed final result:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Focused group commands

Focused groups run during implementation and compliance review:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused results across final passing runs:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### User-test follow-up focused commands

After public-facing copy cleanup:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --static
```

Observed result:

```text
[structure] PASS - repository structure and metadata checks passed
[web] PASS - browser-side Node module tests passed
[static] PASS - runner/documentation consistency checks passed
```

### Final gap-check commands

Final gap-check commands:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Observed result:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[static] PASS - runner/documentation consistency checks passed
All implemented milestone tests passed.
```

### Subgroup or fixture-family commands

No documented subgroup or individual fixture-family reruns were required after final fixes. Focused groups were sufficient.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is a dependency skip, not a test failure. Served browser testing with freshly rebuilt Wasm requires Emscripten locally or in CI.

## 12. Pass/fail results

Final result classification:

```text
aggregate completed and passed
group skipped because a dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

Detailed classification:

- Aggregate command completed and returned final success status.
- Focused groups completed and passed:
  - `--structure`
  - `--native`
  - `--source-run`
  - `--web`
  - `--diagnostics`
  - `--protocol`
  - `--static`
- One chained command containing all focused groups plus aggregate timed out before the aggregate could complete during review. This was not treated as a project failure. The aggregate was rerun alone and completed successfully.
- No focused group failed.
- No focused group timeout remained unresolved.
- No subgroup or fixture-family rerun was required.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Phase 58 is website-testable after rebuilding the Wasm artifact with Emscripten, because Phase 58 changes the C parser/source-run path. Without a fresh Wasm rebuild, served-browser behavior may still reflect an older artifact.

### Browser setup on Windows

From the project root in an Emscripten-enabled Windows CMD environment:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the served URL, paste the programs below, and click **Run**.

If `emcc` is unavailable, use the local test-suite commands instead.

### Program 1 - valid labels, multiple labels, no-target label

```asm
.code
main PROC
start:
    mov eax, 1
middle:
again:
    mov ebx, 2
done:
main ENDP
END main
```

Expected Simulator Messages with default startup notice enabled:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

Expected key final registers:

```text
EAX = 00000001h / u: 1 / s: 1
EBX = 00000002h / u: 2 / s: 2
```

Regression signs:

- Any assembly diagnostic for valid labels.
- Labels appearing to execute as instructions.
- `EAX` or `EBX` values differ.
- Program Console output appears.

### Program 2 - duplicate label diagnostic

```asm
.code
main PROC
start:
    mov eax, 1
start:
    mov ebx, 2
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] duplicate-label line 5, column 1, byte offset 38, span length 5: Duplicate code label `start`; first defined at line 3, column 1.
```

Expected behavior:

- Program Console is empty.
- No `execution-complete` message appears.
- Execution does not begin.

Regression signs:

- Program executes.
- Duplicate label is silently accepted.
- Diagnostic lacks source location or prior-definition details.

### Program 3 - code label conflicts with data symbol

```asm
.data
value DWORD 7
.code
main PROC
value:
    mov eax, value
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] label-symbol-conflict line 5, column 1, byte offset 36, span length 5: code label `value` conflicts with existing data symbol `value` defined at line 2, column 1.
```

Expected behavior:

- Program Console is empty.
- No `execution-complete` message appears.
- Execution does not begin.

Regression signs:

- Program executes.
- Label and data symbol are allowed to share the same effective name.
- Diagnostic lacks prior-definition location.

### Program 4 - CASEMAP:NONE allows exact-case-distinct labels

```asm
OPTION CASEMAP:NONE
.code
main PROC
Start:
    mov eax, 10
start:
    mov ebx, 20
main ENDP
END main
```

Expected Simulator Messages with default startup notice enabled:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected key final registers:

```text
EAX = 0000000Ah / u: 10 / s: 10
EBX = 00000014h / u: 20 / s: 20
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `Start:` and `start:` conflict under `OPTION CASEMAP:NONE`.
- Instructions or directives become case-sensitive.
- Register values differ.

### Program 5 - future branch behavior remains unsupported

```asm
.code
main PROC
start:
    mov eax, 1
    jmp start
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-instruction line 5, column 5, byte offset 42, span length 3: Unsupported instruction. This mnemonic has no executable behavior in MASM32 Educational Mode; use an implemented instruction listed in docs/SUPPORTED_SYNTAX.md.
```

Expected behavior:

- No `execution-complete` message appears.
- No branch executes.
- Program Console remains empty.

Regression signs:

- `jmp` executes.
- `jmp` is parsed as a Phase 58 feature.

### Program 6 - `loop` remains unsupported

```asm
.code
main PROC
start:
    mov ecx, 1
    loop start
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-instruction line 5, column 5, byte offset 42, span length 4: Unsupported instruction. This mnemonic has no executable behavior in MASM32 Educational Mode; use an implemented instruction listed in docs/SUPPORTED_SYNTAX.md.
```

Expected behavior:

- No `execution-complete` message appears.
- No `loop` execution occurs.
- Program Console remains empty.

Regression signs:

- `loop` executes.
- `ECX` is mutated by `loop`.
- Program completes successfully.

### Local Windows CMD test commands

From the project root:

```cmd
python scripts\run_tests.py --source-run
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --web
```

Expected output snippets:

```text
[source-run] PASS - source-run integration binary passed independently
Selected test groups passed.
```

```text
[diagnostics] PASS - native diagnostic producer and rendered messages passed
Selected test groups passed.
```

```text
[web] PASS - browser-side Node module tests passed
Selected test groups passed.
```

Optional broader check:

```cmd
python scripts\run_tests.py --all
```

Expected output snippet:

```text
All implemented milestone tests passed.
```

Acceptable dependency skip when Emscripten is not installed:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

## 14. Compliance review summary

First compliance review found and fixed:

- Missing exact rendered Simulator Messages coverage for folded CASEMAP duplicate labels.
- Missing rendered coverage for one procedure-entry/ordinary-label conflict order.
- Missing parser byte-offset assertions for label metadata.
- Missing parser edge coverage for a procedure containing accepted non-executable metadata only.
- Missing source-run non-goal regression proving `loop` remained unsupported.
- One stale test assertion message that incorrectly described unsuffixed Phase 58 as `Phase 58S`.
- A function-contract mismatch in `vm_parser_add_code_label`, where duplicate/conflict paths returned true despite recording diagnostics.

Files changed during first compliance review:

- `src/parser/parser.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/core/test_data_section.c`
- `tests/web/test_diagnostic_rendering.mjs`

Tests rerun during first compliance review:

- `python3 scripts/run_tests.py --native`
- `python3 scripts/run_tests.py --source-run`
- `python3 scripts/run_tests.py --web`
- `python3 scripts/run_tests.py --diagnostics`
- `python3 scripts/run_tests.py --protocol`
- `python3 scripts/run_tests.py --structure`
- `python3 scripts/run_tests.py --static`
- `python3 scripts/run_tests.py --all`

All completed and passed, with Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

First compliance verdict: complete.

## 15. Re-review summary

Second compliance review found and fixed:

- Stale Phase 57S/57T wording in two test file headers.
- Stale current-status paragraph in `docs/BUILDING_AND_DEVELOPMENT.md`.
- Parser source/header file comments that did not yet mention Phase 58 code-label metadata.

No behavior changes were made during the second review.

Tests rerun during second review:

- `python3 scripts/run_tests.py --structure`
- `python3 scripts/run_tests.py --native`
- `python3 scripts/run_tests.py --source-run`
- `python3 scripts/run_tests.py --web`
- `python3 scripts/run_tests.py --diagnostics`
- `python3 scripts/run_tests.py --protocol`
- `python3 scripts/run_tests.py --static`
- `python3 scripts/run_tests.py --all`

All completed and passed, with Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

Second review verdict: complete.

Final gap check found and fixed:

- A stale internal helper name in `scripts/run_tests.py` containing `phase57t`.
- `src/parser/parser.h` public parser API documentation did not explicitly mention that Phase 58 label metadata is parser/source metadata only and does not enable branch execution.
- A stray local manual-test helper artifact `run_masm_fixture.mjs` was removed from the working tree. It was not part of changed-files packages.

Tests rerun during final gap check:

- `python3 scripts/run_tests.py --structure`
- `python3 scripts/run_tests.py --native`
- `python3 scripts/run_tests.py --static`
- `python3 scripts/run_tests.py --all`

All completed and passed, with Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

Final gap-check verdict: complete.

## 16. User-test follow-up summary

User reported:

```text
everything appears to pass
```

No Phase 58 behavior bug was identified.

User also reported public-facing documentation concerns: several documentation files and `web/index.html` had accumulated verbose milestone accomplishment text from prior phases.

Follow-up diagnosis:

- No implementation bug.
- Documentation/public-facing copy issue.

Fixes applied during user-test follow-up:

- Condensed current-status text in:
  - `README.md`
  - `docs/BUILDING_AND_DEVELOPMENT.md`
  - `docs/MILESTONE_HISTORY.md`
  - `docs/SUPPORTED_SYNTAX.md`
  - `web/index.html`
- Simplified canonical source-of-truth notes in:
  - `docs/FULL_IMPLEMENTATION_SPEC.md`
  - `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- Updated static documentation checks in `scripts/run_tests.py` to guard concise Phase 58 public-facing status text.

Tests rerun after user-test follow-up:

- `python3 scripts/run_tests.py --structure`
- `python3 scripts/run_tests.py --web`
- `python3 scripts/run_tests.py --static`

All completed and passed.

## 17. Known limitations

- Browser/Wasm rebuild smoke was skipped in the assistant/container environment because `emcc` was unavailable.
- Served browser verification requires rebuilding the Wasm artifact in an Emscripten environment.
- Phase 58 label metadata is internal parser/source metadata. It is not yet exposed as a public debugger/source-map JSON API.
- Labels do not enable branch execution. `jmp`, conditional jumps, `loop`, `call`, and `ret` remain unsupported future work.
- No stack/procedure invocation semantics were added.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 59 - Control-Flow Instruction Limit
```

Phase 59 should be treated as the next canonical phase after accepting Phase 58. It must not be skipped.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during this milestone:

- `milestone_58_changed_files.zip`
- `milestone_58_first_compliance_check.zip`
- `milestone_58_second_compliance_check.zip`
- `milestone_58_user_test_followup.zip`
- `milestone_58_final_compliance_check.zip`

Recommended repository archive after applying all accepted changed-file packages:

```text
Latest_repository_state_milestone_58.zip
```

A full latest repository archive was not produced during this session. The user should apply the changed-files packages, verify locally, then package the complete repository state as `Latest_repository_state_milestone_58.zip`.
