# Milestone 53C report - Default Teaching Diagnostics for Existing Warning Modes

## 1. Milestone title and scope

Milestone 53C implements **Phase 53C - Default Teaching Diagnostics for Existing Warning Modes** for the Online MASM32 Educational Simulator.

This milestone changes the default user-facing diagnostic profile for two existing diagnostic systems:

- uninitialized-origin memory reads;
- undefined modeled-flag consumption by existing flag consumers.

Scope implemented:

- Changed omitted/default browser and source-run behavior so uninitialized-origin reads emit non-fatal `uninitialized-read` Simulator Messages warnings.
- Changed omitted/default browser and source-run behavior so existing undefined modeled-flag consumers emit non-fatal `undefined-flag-use` Simulator Messages warnings.
- Preserved deterministic execution: default warning mode continues using deterministic zero-filled uninitialized-origin bytes and deterministic preserved flag values.
- Preserved explicit opt-out behavior for both diagnostic families.
- Preserved explicit strict/error behavior for both diagnostic families.
- Preserved Phase 53B section-capacity and section-image validation as opt-in only.
- Preserved allocated-object validation as opt-in only.
- Preserved Program Console and Simulator Messages separation.
- Added structured source-run tests and exact rendered Simulator Messages tests.
- Added documentation and status updates for current Phase 53C behavior.
- Fixed a user-discovered follow-up bug where indirect/cast memory reads that partially overlap tracked uninitialized-origin bytes were not counted if the full read extended past the tracked data-image mask.

The implementation stayed within the target milestone boundary. It did not add new MASM syntax, new runtime instructions, new diagnostic codes, new browser settings UI, provenance/taint tracking, compatibility no-op notices, or future Phase 53D behavior.

## 2. Source-of-truth files used

Canonical repository files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 53B report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_53B.zip
```

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 53C is the only target milestone for this implementation session.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- User-visible diagnostics require structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

### 3.1 Default uninitialized-read warning policy

Before Phase 53C, uninitialized-read diagnostics existed but were opt-in through local/test configuration. Phase 53C changes omitted/default browser and source-run behavior to use warning mode.

Implemented default behavior:

```text
uninitialized_read_policy = warn
```

Behavior:

- Reads from `.DATA?`, `?`, and `DUP(?)` storage still return deterministic zero-filled bytes unless the program has overwritten those bytes.
- Default user-facing source-run emits `uninitialized-read` as a `simulator-warning` when a read consumes bytes that still carry uninitialized-origin metadata.
- Warning mode continues execution.
- The diagnostic is emitted through Simulator Messages, not Program Console.
- Execution completion is still reported when no fatal diagnostic occurs.
- The warning message explains the final read byte range and how many bytes still originated from uninitialized storage.

Example default behavior:

```asm
.DATA?
x DWORD ?
.code
main PROC
    mov eax, x
main ENDP
END main
```

Expected rendered Simulator Messages:

```text
[simulator-warning] uninitialized-read line 5: Memory read range 00500000h..00500003h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
[info] execution-complete: Execution completed successfully.
```

### 3.2 Explicit uninitialized-read opt-out preserved

Implemented explicit opt-out behavior:

- `MASM32_SIM_WASM_MEMORY_VALIDATION_REGION_ONLY` preserves silent deterministic zero-filled reads.
- The diagnostic JSON producer also accepts:
  - `MASM32_DIAGNOSTIC_MEMORY_VALIDATION=off`
  - `MASM32_DIAGNOSTIC_MEMORY_VALIDATION=region-only`

Explicit opt-out suppresses only the uninitialized-read teaching warning. It does not disable mandatory VM memory safety, `.CONST` protection, invalid-region errors, unaligned-access warnings, or unrelated diagnostics.

### 3.3 Explicit uninitialized-read strict behavior preserved

Existing strict behavior was preserved:

- `MASM32_SIM_WASM_MEMORY_VALIDATION_UNINITIALIZED_READ_STRICT` still emits `uninitialized-read` as a runtime error.
- Strict mode stops before consuming the uninitialized-origin bytes.
- No execution-complete message is emitted after the fatal diagnostic.

### 3.4 Default undefined-flag-use warning policy

Before Phase 53C, undefined flag-use diagnostics existed through Phase 50B but were opt-in. Phase 53C changes omitted/default browser and source-run behavior to use warning mode.

Implemented default behavior:

```text
undefined_flag_use_policy = warn
```

Behavior:

- Existing flag consumers check Phase 50A flag-validity metadata before reading modeled flags.
- If a consumer reads a modeled flag whose current deterministic bit is architecturally invalid, default source-run emits `undefined-flag-use` as a `simulator-warning`.
- Warning mode continues execution using the deterministic preserved flag value.
- Producer warnings such as `undefined-shift-flag` and `undefined-modeled-flag` remain unchanged.
- Diagnostics include producer metadata when available.

Example default behavior:

```asm
.code
main PROC
    stc
    mov al, 1
    shl al, 8
    mov ebx, 0
    adc ebx, 0
main ENDP
END main
```

Expected rendered Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 5, column 5, byte offset 42, span length 9: SHL count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
[simulator-warning] undefined-flag-use line 7, column 5, byte offset 71, span length 10: ADC reads CF, but CF is architecturally undefined from SHL at line 5. The simulator preserved the flag deterministically; this flag-dependent behavior is not portable.
[info] execution-complete: Execution completed successfully.
```

### 3.5 Explicit undefined-flag-use opt-out preserved

Implemented explicit opt-out behavior:

- `MASM32_SIM_WASM_UNDEFINED_FLAG_USE_OFF` preserves previous silent consumer behavior.
- `MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=off` suppresses consumer-side `undefined-flag-use` diagnostics in the local diagnostic JSON producer.

Producer warnings remain active unless controlled by their own policy. For example, opting out of undefined-flag-use does not suppress `undefined-shift-flag` producer diagnostics.

### 3.6 Explicit undefined-flag-use error behavior preserved

Existing error behavior was preserved:

- `MASM32_SIM_WASM_UNDEFINED_FLAG_USE_ERROR` emits `undefined-flag-use` as a runtime error.
- Error mode stops before the consumer mutates registers, memory, flags, Program Console output, or memory-change rows.
- No execution-complete message is emitted after the fatal diagnostic.

### 3.7 Section/object validation defaults preserved

Phase 53C did not change Phase 53B or earlier memory-boundary validation defaults.

Preserved defaults:

- Section-capacity validation: off.
- Section-image validation: off.
- Allocated-object validation: off.
- Mandatory Level 1 region/permission/.CONST validation remains always enforced.
- Unaligned-access warnings remain independent.

A second-review fix ensured that explicitly selecting section validation in the diagnostic JSON producer does not accidentally suppress Phase 53C's omitted/default uninitialized-read warning policy.

### 3.8 Indirect overlapping uninitialized-read follow-up fix

A user-test follow-up found that this program emitted only an unaligned read warning and missed the uninitialized-origin warning:

```asm
.DATA?
x DWORD ?
.code
main PROC
    mov eax, OFFSET x
    mov ebx, DWORD PTR [eax+1]
main ENDP
END main
```

Root cause:

- The uninitialized-read counter returned zero if the final read extended beyond the tracked data-image mask, instead of counting the overlapping tracked bytes inside the `.DATA?` object.

Implemented correction:

- The counter now counts the tracked overlap inside the uninitialized-origin mask.
- It no longer drops the entire read merely because the full final byte range extends past the tracked mask.

Expected rendered Simulator Messages after the fix:

```text
[simulator-warning] uninitialized-read line 6, column 24, byte offset 78, span length 7: Memory read range 00500001h..00500004h reads 4 bytes from x + 1; 3 of those bytes still originated from uninitialized storage.
[simulator-warning] unaligned-memory-access line 6: Unaligned DWORD memory access at 00500001h.
[info] execution-complete: Execution completed successfully.
```

This was treated as a Phase 53C follow-up bug because uninitialized-origin metadata is byte-range metadata and should be checked after final effective address calculation for indirect reads, matching the existing `.CONST` final-address protection principle.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 53C:

- No new MASM syntax.
- No new runtime instructions.
- No Phase 54 signed `imul` behavior.
- No division behavior.
- No new diagnostic codes.
- No compatibility no-op or limited-behavior notices; these remain Phase 53D work.
- No browser settings UI for diagnostic policies.
- No object-bound default warnings.
- No section-capacity or section-image default warnings.
- No provenance or taint tracking beyond existing uninitialized-origin byte metadata.
- No broad warning preset system.
- No Program Console changes.
- No changes to hard runtime memory errors.
- No changes to `.CONST` protection semantics.
- No labels, jumps, conditional jumps, `loop`, `SETcc`, or `CMOVcc`.
- No stack, procedure, `call`, `ret`, `leave`, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR` behavior.
- No Irvine32 routine expansion beyond existing behavior.
- No macro expansion.
- No Windows API simulation, PE loading, object linking, or host filesystem behavior.

## 5. Assumptions used

### Assumption 1

- **Assumption:** The correct implementation point is the user-facing source-run/Wasm default path, not the low-level VM executor.
- **Reason:** Phase 53C changes policy defaults for already-existing warning modes. The executor and memory systems already had the underlying diagnostic mechanisms.
- **Risk:** Some lower-level executor tests or internal API callers may still need explicit policy selection when they want teaching-default behavior.
- **How to change later:** A later settings/profile phase can introduce explicit named diagnostic profiles if internal and browser defaults need a more unified policy object.

### Assumption 2

- **Assumption:** Explicit APIs that select region-only memory validation should preserve pre-53C silent uninitialized-read behavior.
- **Reason:** The guide requires explicit `off` behavior to remain available.
- **Risk:** The existing memory-validation enum combines several policies, so callers must know which enum value represents the opt-out.
- **How to change later:** A future API cleanup phase can separate mandatory memory validation, uninitialized-read policy, object validation, and section validation into independent fields.

### Assumption 3

- **Assumption:** `MASM32_DIAGNOSTIC_MEMORY_VALIDATION=off` and `region-only` should be accepted by the diagnostic JSON producer as explicit uninitialized-read opt-out aliases.
- **Reason:** This gives local/manual testing a clear way to preserve old silent behavior after the default changes.
- **Risk:** Multiple spelling aliases can slightly increase documentation/test surface area.
- **How to change later:** A future diagnostic settings UI/API phase can consolidate names while keeping backward-compatible environment aliases for tests.

### Assumption 4

- **Assumption:** The numeric source-run metadata phase should remain `53` rather than trying to encode `53C` in existing numeric fields.
- **Reason:** Prior suffix milestones such as 50A, 50B, and 52A did not force string suffixes into the existing numeric phase metadata path.
- **Risk:** The browser numeric phase metadata cannot distinguish 53, 53A, 53B, and 53C by number alone.
- **How to change later:** Add an explicit milestone string field in a future protocol/status milestone if the UI needs exact suffix display in structured metadata.

### Assumption 5

- **Assumption:** Historical documentation should be qualified rather than rewritten as if earlier phases always had 53C defaults.
- **Reason:** Milestone 40 and Milestone 50B genuinely introduced opt-in diagnostics first; Phase 53C changes default behavior later.
- **Risk:** Too much historical wording can still confuse readers if not paired with current-status notes.
- **How to change later:** Continue using current-status summaries near the top of README and supported syntax, while preserving milestone chronology in detailed history.

### Assumption 6

- **Assumption:** The indirect overlapping uninitialized-read fix belongs to Phase 53C as a follow-up, even though underlying uninitialized-origin tracking began earlier.
- **Reason:** Phase 53C makes the warning default and the user-discovered gap directly affected default teaching diagnostics.
- **Risk:** The fix touches shared uninitialized-read counting behavior, so older opt-in tests also observe the corrected count.
- **How to change later:** If a later provenance phase adds richer object/range descriptions, keep byte-overlap counting as the baseline and layer richer messages on top.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and note-like status statements reviewed during planning, implementation, compliance review, second review, and final gap check:

```text
- Location:
  README.md, Milestone 40 status bullet
- Note text or summary:
  Default browser/source-run uninitialized-read behavior remained warning-free and deterministic zero-filled.
- Classification:
  target-owned
- Reason:
  Phase 53C changes omitted/default uninitialized-read policy from off to warn.
- Action:
  Updated/qualified to describe Phase 53C default warning behavior and explicit opt-out behavior.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md, Milestone 40 memory validation wording
- Note text or summary:
  Default browser/source-run behavior remained region-only and warning-free; UI settings and provenance diagnostics remained deferred.
- Classification:
  target-owned for default uninitialized-read wording; future-owned for UI/provenance wording.
- Reason:
  Phase 53C changes uninitialized-read defaults only. It does not add UI settings or provenance diagnostics.
- Action:
  Updated the current default behavior while preserving future UI/provenance deferral.
```

```text
- Location:
  README.md, Milestone 50B undefined flag-use diagnostics bullet
- Note text or summary:
  Default browser/source-run behavior kept undefined-flag-use consumer policy off.
- Classification:
  target-owned
- Reason:
  Phase 53C changes omitted/default undefined-flag-use policy from off to warn.
- Action:
  Updated/qualified to describe Phase 53C default warning behavior and explicit off behavior.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md, Milestone 50B status text
- Note text or summary:
  Milestone 50B added opt-in consumer diagnostics without default browser behavior changes.
- Classification:
  target-owned for current-status clarification; historical wording remains true for 50B.
- Reason:
  Phase 53C later changes the default policy.
- Action:
  Qualified with Phase 53C current behavior so readers do not infer default remains off.
```

```text
- Location:
  docs/FULL_IMPLEMENTATION_SPEC.md, uninitialized `?` declaration wording
- Note text or summary:
  Reads from `?` storage did not warn by default unless explicit warning/strict mode was enabled.
- Classification:
  stale-or-contradicted after Phase 53C
- Reason:
  Phase 53C changes omitted/default source-run behavior to warning mode.
- Action:
  Corrected during compliance/final gap review.
```

```text
- Location:
  src/wasm/wasm_api.c, future opcode memory-read TODO
- Note text or summary:
  Add each future memory-reading opcode here when that opcode is implemented.
- Classification:
  future-owned
- Reason:
  Phase 53C adds no new instruction or memory-reading opcode.
- Action:
  Left unchanged.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, future UI/settings references
- Note text or summary:
  Future UI settings should expose uninitialized-read and undefined-flag-use settings with defaults matching Phase 53C.
- Classification:
  future-owned
- Reason:
  Phase 53C changes backend/default source-run behavior but does not add browser settings UI.
- Action:
  Left deferred.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

Resolved or qualified:

- README default-off uninitialized-read wording.
- README default-off undefined-flag-use wording.
- Supported-syntax default-off historical wording for uninitialized-read and undefined-flag-use behavior.
- Full-spec stale uninitialized-read default wording for `?` storage and the default teaching diagnostic profile.
- Stale test function name that still described undefined-flag-use default as off.

### Future-owned TODO-style notes intentionally preserved

Preserved:

- Future memory-reading opcode TODO in `src/wasm/wasm_api.c`.
- Future browser diagnostic settings UI work.
- Future compatibility no-op and limited-behavior notices owned by Phase 53D.
- Future macro/procedure/control-flow/stack/Irvine32 expansion work.
- Deferred feature lists for signed multiplication, division, labels/jumps, macros, Windows API simulation, PE loading, object linking, host filesystem behavior, and related future milestones.

### Stale or contradicted TODO-style notes corrected

Corrected:

- Full spec statement that `?` reads did not warn by default.
- Spec wording that accidentally bundled future Phase 53D notices into Phase 53C defaults.
- Supported syntax wording that could be read as saying default-off behavior remained current after 53C.
- Stale test function name for explicit undefined-flag-use opt-out.

### Unresolved TODO-related risks

None identified for Phase 53C.

## 8. Design summary

The implementation is intentionally narrow.

### Policy-boundary design

The default policy change is centralized at the source-run/Wasm-facing policy boundary rather than in instruction execution. This keeps existing executor semantics stable and avoids changing low-level VM behavior outside the selected policy.

Default browser/source-run policies now select:

```text
uninitialized-read: warn
undefined-flag-use: warn
```

Explicit local/test configuration can still select:

```text
uninitialized-read: off / warn / strict
undefined-flag-use: off / warn / error
```

### Diagnostic JSON producer design

The native diagnostic JSON producer was updated so omitted policy fields use Phase 53C teaching defaults. Explicit environment variables continue to override the defaults.

A second-review fix ensures that selecting section validation through environment variables does not accidentally force memory validation back to silent region-only mode. This keeps policy dimensions independent enough for current test needs without adding a future settings UI.

### Uninitialized-read overlap design

The user-follow-up fix changed uninitialized-origin counting to count overlapping tracked bytes inside the final read range. The read no longer has to be fully contained inside the tracked data-image mask to diagnose a valid overlap.

This matches the intended byte-range nature of uninitialized-origin metadata and keeps behavior consistent with final-effective-address checks used by `.CONST` protection.

### Documentation design

Documentation now distinguishes:

- historical opt-in introduction of uninitialized-read and undefined-flag-use diagnostics in earlier milestones;
- current Phase 53C default warning behavior;
- explicit off/strict/error policy behavior;
- future Phase 53D compatibility notice behavior.

## 9. Files changed

Final changed files:

```text
README.md
docs/FULL_IMPLEMENTATION_SPEC.md
docs/SUPPORTED_SYNTAX.md
docs/TESTING_GUIDE.md
scripts/run_tests.py
src/wasm/wasm_api.c
src/wasm/wasm_api.h
tests/core/diagnostic_json_producer.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
web/index.html
```

No parser files were changed. No core instruction executor semantics were changed except for the uninitialized-read counting behavior in the Wasm/source-run diagnostic path.

## 10. Tests added

### Native/source-run tests

Added or updated tests in `tests/core/test_wasm_source_run.c` covering:

- default uninitialized-read warning continues execution;
- explicit uninitialized-read opt-out preserves old silent behavior;
- default uninitialized-read warning for a Phase 53-style memory source;
- default undefined-flag-use warning continues execution;
- explicit undefined-flag-use opt-out preserves old silent consumer behavior;
- explicit undefined-flag-use error behavior still stops before consumer mutation;
- default uninitialized-read warning remains active when section validation policy is explicitly selected;
- indirect overlapping `.DATA?` read through `DWORD PTR [eax+1]` emits uninitialized-read before unaligned-access warning.

### Diagnostic producer tests

Updated `tests/core/diagnostic_json_producer.c` behavior and its exercised paths to support:

- omitted/default Phase 53C warning behavior;
- explicit `off` / `region-only` uninitialized-read opt-out aliases;
- policy-combination regression where section validation is explicit but uninitialized-read policy is omitted.

### Rendered Simulator Messages tests

Added or updated tests in `tests/web/test_diagnostic_rendering.mjs` covering exact rendered messages for:

- default `uninitialized-read` warning plus execution completion;
- default `undefined-flag-use` warning plus execution completion;
- default uninitialized-read warning when only section validation is explicit;
- indirect overlapping uninitialized-read warning followed by unaligned-access warning;
- preservation of strict/error rendered behavior.

### Aggregate/static checks

Updated `scripts/run_tests.py` to require Phase 53C test coverage markers and current documentation/status text.

## 11. Commands used to test

Main aggregate command:

```sh
python3 scripts/run_tests.py
```

The aggregate runner compiled and ran the native C99 tests, built the diagnostic JSON producer, and ran the Node web tests.

Representative internal commands run by the aggregate runner include native C99 builds such as:

```sh
cc -std=c99 -Wall -Wextra -Werror -pedantic -Isrc/core -Isrc/parser tests/core/test_wasm_source_run.c src/core/masm32_sim_api.c src/core/vm_cpu.c src/core/vm_memory.c src/core/vm_layout.c src/core/vm_ir.c src/core/vm_exec.c src/parser/lexer.c src/parser/parser.c src/parser/symbols.c src/parser/object_map.c src/wasm/wasm_api.c -o build/tests/test_wasm_source_run
```

and Node tests such as:

```sh
node tests/web/test_protocol.mjs
node tests/web/test_formatters.mjs
node tests/web/test_diagnostic_rendering.mjs
```

Manual spot-check programs were also verified through `build/tests/diagnostic_json_producer` during manual-test preparation.

## 12. Pass/fail results

Final test result:

```text
All implemented milestone tests passed.
```

The aggregate test run passed after implementation, first compliance review fixes, second compliance review fixes, the user-test follow-up fix, and the final gap-check cleanup.

Environment limitation:

- `emcc` was not available in this environment, so a Wasm rebuild and manual browser smoke test could not be run here.
- Native/Node tests passed.
- Website behavior is testable after rebuilding Wasm in an Emscripten-capable environment.

## 13. Manual/browser testing guidance and expected outputs

### Setup

For browser testing, rebuild Wasm first in an Emscripten-capable environment:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000/web/
```

The default page-load program does not exhaustively test Phase 53C. Use the programs below.

### Browser/local program 1 - default uninitialized-read warning

Program:

```asm
.DATA?
x DWORD ?
.code
main PROC
    mov eax, x
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] uninitialized-read line 5: Memory read range 00500000h..00500003h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Expected final state:

```text
EAX = 00000000h / u: 0 / s: 0
Memory Changes: none
```

Regression signs:

- Missing `uninitialized-read` warning.
- Warning appears in Program Console.
- Warning is treated as a runtime error by default.
- Execution-complete is missing.
- `EAX` is not zero.

### Browser/local program 2 - default undefined-flag-use warning

Program:

```asm
.code
main PROC
    stc
    mov al, 1
    shl al, 8
    mov ebx, 0
    adc ebx, 0
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 5, column 5, byte offset 42, span length 9: SHL count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
[simulator-warning] undefined-flag-use line 7, column 5, byte offset 71, span length 10: ADC reads CF, but CF is architecturally undefined from SHL at line 5. The simulator preserved the flag deterministically; this flag-dependent behavior is not portable.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Expected final state:

```text
EAX = 00000000h / u: 0 / s: 0
EBX = 00000001h / u: 1 / s: 1
EFLAGS = 00000000h / 0
Memory Changes: none
```

Regression signs:

- Missing `undefined-flag-use` warning.
- Warning is a runtime error by default.
- `EBX` remains zero.
- Execution-complete is missing.
- Section-capacity or section-image warnings appear by default.

### Browser/local program 3 - indirect overlapping uninitialized read

Program:

```asm
.DATA?
x DWORD ?
.code
main PROC
    mov eax, OFFSET x
    mov ebx, DWORD PTR [eax+1]
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] uninitialized-read line 6, column 24, byte offset 78, span length 7: Memory read range 00500001h..00500004h reads 4 bytes from x + 1; 3 of those bytes still originated from uninitialized storage.
[simulator-warning] unaligned-memory-access line 6: Unaligned DWORD memory access at 00500001h.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Regression signs:

- Only `unaligned-memory-access` appears.
- The uninitialized-read count reports zero or omits the warning.
- Execution stops by default.

### Windows CMD local diagnostic producer testing

From the project root, first run:

```cmd
py -3 scripts\run_tests.py
```

Then create `program.asm` at the root and run:

```cmd
build\tests\diagnostic_json_producer.exe program.asm > program.json
type program.json
```

Explicit uninitialized-read opt-out:

```cmd
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=off
build\tests\diagnostic_json_producer.exe program.asm > program_off.json
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=
type program_off.json
```

Expected opt-out behavior:

- no `uninitialized-read` diagnostic;
- deterministic final register values remain unchanged;
- execution-complete is still present.

Explicit undefined-flag-use opt-out:

```cmd
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=off
build\tests\diagnostic_json_producer.exe program.asm > program_off.json
set MASM32_DIAGNOSTIC_UNDEFINED_FLAG_USE=
type program_off.json
```

Expected opt-out behavior:

- no consumer-side `undefined-flag-use` diagnostic;
- producer warning such as `undefined-shift-flag` still appears;
- execution-complete is still present.

## 14. Compliance review summary

The first compliance review checked scope, completeness, code quality, diagnostics, tests, docs, and TODO-style note disposition.

Issues found:

- `docs/FULL_IMPLEMENTATION_SPEC.md` still had stale pre-53C wording saying default uninitialized-origin reads were warning-free.
- `docs/SUPPORTED_SYNTAX.md` had historical wording that could be misread as current default-off behavior.

Fixes applied:

- Updated full spec to state that Phase 53C default user-facing source-run warns on uninitialized-origin reads.
- Updated supported syntax to distinguish historical opt-in behavior from current Phase 53C defaults.

Tests rerun:

```sh
python3 scripts/run_tests.py
```

Result:

```text
All implemented milestone tests passed.
```

Verdict after first compliance review: complete, with environment limitation that Wasm/browser smoke testing could not be run because `emcc` was unavailable.

## 15. Re-review summary

A second compliance review checked the target guide/spec again, all changed files, TODO-style notes, tests, rendered diagnostics, and accidental future work.

Additional issues found:

- The full spec accidentally bundled future Phase 53D compatibility no-op notices into the Phase 53C default policy.
- `src/wasm/wasm_api.h` had stale Doxygen text saying the normal browser export kept region-only validation.
- `tests/core/diagnostic_json_producer.c` could suppress Phase 53C default uninitialized-read warnings when only section-validation environment variables were explicitly set.
- A rendered-message regression test was missing for that combined diagnostic-producer path.

Fixes applied:

- Corrected the spec so Phase 53C defaults are only uninitialized-read warn and undefined-flag-use warn.
- Clarified that compatibility no-op notices belong to Phase 53D and must not be emitted by Phase 53C.
- Updated stale Doxygen text in `src/wasm/wasm_api.h`.
- Changed the diagnostic producer so omitted memory-validation policy remains Phase 53C warning-default behavior, including when section validation is explicitly selected.
- Added an exact rendered Simulator Messages regression test for that path.

Tests rerun:

```sh
python3 scripts/run_tests.py
```

Result:

```text
All implemented milestone tests passed.
```

Final second-review verdict: complete.

## 16. User-test follow-up summary

After manual tests passed, the user reported this additional issue:

```asm
.DATA?
x DWORD ?
.code
main PROC
    mov eax, OFFSET x
    mov ebx, DWORD PTR [eax+1]
main ENDP
END main
```

Observed pre-fix behavior:

- Only `unaligned-memory-access` was emitted.
- The read consumed bytes that still carried uninitialized-origin metadata, so an `uninitialized-read` warning should also have been emitted.

Implemented follow-up fix:

- Corrected the uninitialized-read counter to count tracked overlapping bytes instead of returning zero when the read extended past the tracked mask.
- Added a native source-run regression test.
- Added an exact rendered Simulator Messages regression test.

Expected fixed rendered messages:

```text
[simulator-warning] uninitialized-read line 6, column 24, byte offset 78, span length 7: Memory read range 00500001h..00500004h reads 4 bytes from x + 1; 3 of those bytes still originated from uninitialized storage.
[simulator-warning] unaligned-memory-access line 6: Unaligned DWORD memory access at 00500001h.
[info] execution-complete: Execution completed successfully.
```

Tests rerun:

```sh
python3 scripts/run_tests.py
```

Result:

```text
All implemented milestone tests passed.
```

## 17. Known limitations

- `emcc` is unavailable in this environment, so Wasm artifacts were not rebuilt here.
- Manual browser testing was not run here; browser testing requires a local Emscripten-capable environment and a rebuilt Wasm artifact.
- No browser settings UI exists yet for toggling these policies. Explicit opt-out/error policies are test/API/local-diagnostic paths only until a future settings milestone.
- Numeric source-run phase metadata remains `53` rather than `53C`.
- Compatibility no-op and limited-behavior notices remain future Phase 53D work.
- Phase 53C does not add default section-capacity, section-image, or allocated-object warnings.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 53D - Compatibility No-Op and Limited-Behavior Notices
```

Expected scope for the next milestone:

- Add user-facing notices for accepted compatibility constructs with meaningful real MASM behavior that the simulator does not perform.
- Keep these notices separate from Phase 53C warning defaults.
- Do not add broader future runtime behavior merely because compatibility constructs are noticed.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

- `milestone53C_changed_files.zip`
- `milestone53C_compliance_review_changed_files.zip`
- `milestone53C_second_review_changed_files.zip`
- `milestone53C_user_followup_changed_files.zip`
- `milestone53C_final_gap_check_changed_files.zip`

Recommended final package:

```text
milestone53C_final_gap_check_changed_files.zip
```

This final package includes the implementation, compliance-review fixes, second-review fixes, user-follow-up fix, and final gap-check cleanup.

