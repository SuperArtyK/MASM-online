# Milestone 57-CORR2 report - Compact Negative Register-Indirect Displacement Correction

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57-CORR2 - Compact Negative Register-Indirect Displacement Correction
```

Repository/archive milestone:

```text
Phase 57-CORR2 - Compact Negative Register-Indirect Displacement Correction
```

Runtime/source-run MASM behavior phase:

```text
Phase 57 - Signed IDIV
```

Status interpretation:

Phase 57-CORR2 is a corrective parser-quality milestone after Phase 57-CORR1 - `.CONST` Cross-Region Diagnostic Clarification and before Phase 57A - README Landing Page Cleanup. It advances repository/archive status but intentionally does not advance runtime/source-run MASM behavior metadata. Source-run JSON phase fields, worker/protocol phase values, and browser runtime/source-run behavior phase remain Phase 57.

Scope implemented:

- Corrected the parser so compact negative register-indirect displacements such as `[eax-4]` are accepted when the equivalent spaced form `[eax - 4]` is already supported.
- Applied the correction through the shared simple register-displacement memory operand path rather than adding instruction-specific special cases.
- Preserved equivalence between compact and spaced simple register-minus-constant memory operands.
- Preserved existing successful behavior for zero displacement, compact positive displacement, spaced positive displacement, and spaced negative displacement.
- Preserved `lea` behavior for simple register-minus-constant addressing. `lea eax, [ebx-4]` computes the address only and does not read or write memory.
- Preserved rejection of unsupported scaled-index, base-plus-index, parenthesized, repeated-sign, and general arithmetic forms.
- Preserved existing parser diagnostics for unsupported advanced/scaled addressing.
- Preserved all existing executor, VM memory, diagnostic-routing, source-run JSON, worker protocol, and browser runtime/source-run metadata behavior.
- Updated current-status documentation so repository/archive status reflects Phase 57-CORR2 while runtime/source-run MASM behavior remains Phase 57 - Signed IDIV.
- Added parser, source-run, rendered Simulator Messages, status/static, and regression coverage.

This milestone did not add new MASM syntax beyond the already-supported simple register-minus-constant displacement shape. It only corrected whitespace-sensitive parsing of that existing address family.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57-CORR1 report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_57-CORR1.zip
```

No full latest repository archive was produced during this milestone-report step. The recommended archive name after accepting this milestone is:

```text
Latest_repository_state_milestone_57-CORR2.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, stable cross-cutting parser/memory/diagnostic rules, current/future/non-goal distinctions, and current-status surface hygiene.
- The incremental implementation guide owns phase numbering, phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 57-CORR2 is the only target milestone for this work.
- TODO-style notes are implementation-risk evidence only and do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- Memory reads and writes continue to route through existing checked VM memory helpers; this milestone did not alter runtime memory access behavior.
- User-visible diagnostics remain structured and have exact rendered Simulator Messages coverage.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, WinAPI simulator, host include loader, or macro assembler.

## 3. Exact requirements implemented

Phase 57-CORR2 required correction of compact negative register-indirect displacement parsing.

### 3.1 Accepted compact negative forms

Implemented acceptance for compact register-minus-constant displacements where the equivalent spaced form is already accepted:

```asm
mov DWORD PTR [eax-4], 10
mov DWORD PTR [esi-8], 10
mov DWORD PTR [ebp-10h], 10
mov DWORD PTR [ebp-0x10], 10
mov eax, DWORD PTR [ecx-4]
mov ax, WORD PTR [edx-2]
mov al, BYTE PTR [edi-1]
lea eax, [ebx-4]
```

These forms now behave like their spaced equivalents:

```asm
mov DWORD PTR [eax - 4], 10
mov DWORD PTR [esi - 8], 10
mov DWORD PTR [ebp - 10h], 10
mov DWORD PTR [ebp - 0x10], 10
mov eax, DWORD PTR [ecx - 4]
mov ax, WORD PTR [edx - 2]
mov al, BYTE PTR [edi - 1]
lea eax, [ebx - 4]
```

### 3.2 Parser behavior implemented

The parser's shared simple register-displacement suffix logic now accepts these suffix shapes after a valid 32-bit register base inside brackets:

```text
]
+ numeric-displacement ]
- numeric-displacement ]
signed-negative-numeric-displacement ]
```

The compact signed-negative numeric token is accepted only as a simple displacement suffix. The parser still requires the closing bracket immediately after the displacement token. This prevents malformed or advanced forms from being accepted as if they were simple register-minus-constant operands.

### 3.3 Range behavior implemented

A compliance review found and corrected a range consistency issue. The final implementation mirrors the existing spaced-minus parser behavior for compact negative displacements.

Implemented behavior:

- `[eax-4]` is accepted.
- `[eax-10h]` is accepted.
- `[eax-0x10]` is accepted.
- `[eax-80000000h]` is rejected consistently with `[eax - 80000000h]`.

### 3.4 Preserved existing behavior

The following existing forms remain accepted:

```asm
mov DWORD PTR [eax], 10
mov DWORD PTR [eax+4], 10
mov DWORD PTR [eax + 4], 10
mov DWORD PTR [eax - 4], 10
lea eax, [ebx + 4]
lea eax, [ebx - 4]
```

The following forms remain rejected:

```asm
mov eax, DWORD PTR [eax*4]
mov eax, DWORD PTR [eax * 4]
mov eax, DWORD PTR [eax+ebx]
mov eax, DWORD PTR [eax + ebx]
mov eax, DWORD PTR [eax+ebx*4]
mov eax, DWORD PTR [eax + ebx * 4]
mov eax, DWORD PTR [eax-4*2]
mov eax, DWORD PTR [eax - 4 * 2]
mov eax, DWORD PTR [eax-(4)]
mov eax, DWORD PTR [eax--4]
mov eax, DWORD PTR [eax+-4]
```

### 3.5 Diagnostics implemented or preserved

No new diagnostic code was required.

For malformed advanced/scaled forms such as:

```asm
mov ebx, DWORD PTR [eax-4*2]
```

The existing rendered diagnostic remains:

```text
[unsupported-feature] unsupported-scaled-index line 7, column 30, byte offset 89, span length 1: Scaled-index memory operands are not supported yet.
```

This is intentional because the malformed form reaches the existing unsupported scaled-index path. The diagnostic does not claim that simple subtraction is unsupported.

### 3.6 Runtime/source-run metadata preserved

Phase 57-CORR2 is a corrective parser milestone. It does not add a new runtime instruction family or VM semantic capability. Therefore runtime/source-run MASM behavior metadata remains:

```text
Phase 57 - Signed IDIV
```

The repository/archive milestone advances to:

```text
Phase 57-CORR2 - Compact Negative Register-Indirect Displacement Correction
```

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57-CORR2:

- Scaled-index addressing.
- Base-plus-index addressing.
- SIB addressing.
- Register-plus-register effective addresses.
- Parenthesized effective-address expressions.
- General arithmetic inside brackets.
- Segment overrides.
- Group symbols.
- New executable instructions.
- New memory validation policies.
- Changes to `.CONST` permission behavior.
- `.code` memory-access-denial diagnostics.
- Executable QWORD/SQWORD memory operations.
- Stack behavior.
- Control flow.
- Procedure behavior.
- Broader Irvine32 behavior.
- Macro expansion.
- Host include loading.
- `INCLUDELIB` behavior.
- Windows API behavior.
- PE loading or object linking.
- README landing-page cleanup from Phase 57A.
- Runtime/source-run phase metadata advancement beyond Phase 57.

## 5. Assumptions used

### Assumption 1

- **Assumption:** The lexer should remain unchanged.
- **Reason:** The guide and observed behavior indicate that the lexer already emits signed negative numeric tokens for compact forms such as `[eax-4]`. The defect was in the parser's suffix acceptance path, not tokenization.
- **Risk:** If a later lexer cleanup changes signed numeric tokenization, this parser branch may need corresponding adjustment.
- **How to change later:** A future lexer/parser cleanup phase could normalize `-` plus number handling before memory operand parsing, provided it preserves source locations and existing diagnostics.

### Assumption 2

- **Assumption:** Existing unsupported scaled-index diagnostics should be reused for `[eax-4*2]`.
- **Reason:** The milestone required preserving rejection of advanced addressing and ensuring the diagnostic did not incorrectly say that simple subtraction is unsupported. It did not require a new diagnostic code.
- **Risk:** The diagnostic is broad for some malformed arithmetic forms because the parser sees `*` and uses the existing scaled-index unsupported path.
- **How to change later:** A later diagnostic-quality phase could refine invalid effective-address diagnostics and spans without changing accepted syntax.

### Assumption 3

- **Assumption:** Runtime/source-run MASM behavior metadata remains Phase 57.
- **Reason:** Phase 57-CORR2 is corrective parser work and does not add a new runtime instruction family, VM capability, source-run JSON shape, or browser setting.
- **Risk:** A reader may expect every repository/archive milestone to advance the runtime phase number.
- **How to change later:** Only a future phase that explicitly changes runtime-visible MASM/source behavior or explicitly owns metadata advancement should update runtime/source-run phase values.

### Assumption 4

- **Assumption:** Compact negative displacement range behavior should match the existing spaced-minus path exactly.
- **Reason:** The milestone's intent is whitespace-insensitive equivalence between compact and spaced simple register-minus-constant operands.
- **Risk:** The initial implementation briefly accepted the edge case `[eax-80000000h]` while the spaced form rejected `[eax - 80000000h]`.
- **How to change later:** If the project later broadens signed displacement range policy, both compact and spaced paths should be changed together with tests documenting the new rule.

## 6. Relevant TODO-style notes reviewed

### TODO-style note 1

- **Location:** `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- **Note text or summary:** Future `.code` memory-access-denial phases should reuse the `region-boundary-crossing` diagnostic shape when `.code` becomes protected for a memory access kind.
- **Classification:** future-owned
- **Reason:** Phase 57-CORR2 concerns compact negative displacement parsing only. It does not implement `.code` memory protection.
- **Action for this milestone:** Left unchanged.

### TODO-style note 2

- **Location:** `src/core/vm_memory.c`
- **Note text or summary:** Future protected-region diagnostics should generalize the current `.CONST` overlap helper when later milestones make `.code` memory access-denying.
- **Classification:** future-owned
- **Reason:** This is the implementation-side counterpart to the future `.code` protected-region diagnostic note. It is outside Phase 57-CORR2.
- **Action for this milestone:** Left unchanged.

### TODO-style note 3

- **Location:** `src/wasm/wasm_api.c`
- **Note text or summary:** Future memory-reading opcodes must be added to planned-read collection when implemented.
- **Classification:** future-owned
- **Reason:** Phase 57-CORR2 adds no opcode and no new memory-reading instruction. It fixes parsing for an existing memory operand syntax family.
- **Action for this milestone:** Left unchanged.

## 7. TODO-style note disposition

- **Target-owned TODO-style notes resolved:** None. No target-owned TODO-style notes were found.
- **Future-owned TODO-style notes intentionally preserved:** The three notes listed above were preserved because they belong to later `.code` protected-region or future memory-reading opcode work.
- **Stale or contradicted TODO-style notes corrected:** None found.
- **Unresolved TODO-related risks:** None identified. The preserved TODOs are phase-scoped and did not encourage future behavior to be implemented during Phase 57-CORR2.
- **New TODO-style notes added:** None.

## 8. Design summary

### Parser design

The implementation updates the shared simple register-displacement parser path in `src/parser/parser.c`.

A new internal helper identifies signed negative numeric tokens in the parser token stream:

```c
vm_parser_number_token_is_signed_negative
```

A second internal helper converts compact negative numeric displacement tokens to the same signed 32-bit displacement range accepted by the existing spaced-minus path:

```c
vm_parser_compact_negative_register_displacement_to_i32
```

The parser now handles compact negative suffixes after a valid register base inside brackets, while preserving the existing checks that require a closing bracket after the accepted displacement. This ensures that `[eax-4*2]` is not accidentally accepted as `[eax-4]`.

### Behavior preservation

The change does not modify:

- lexer tokenization;
- IR opcodes;
- executor behavior;
- VM memory helpers;
- memory validation policy;
- diagnostic JSON shape;
- rendered-message formatter behavior;
- source-run runtime phase value;
- worker protocol phase value;
- browser runtime/source-run phase metadata.

### Documentation/status design

The documentation updates distinguish:

- repository/archive milestone: Phase 57-CORR2;
- runtime/source-run MASM behavior phase: Phase 57 - Signed IDIV.

This follows the current-status hygiene rules for corrective and maintenance phases.

## 9. Files changed

Files changed during the milestone:

- `src/parser/parser.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `docs/SUPPORTED_SYNTAX.md`
- `README.md`
- `scripts/run_tests.py`

No header files were changed. No new public API was added.

## 10. Tests added

### Parser tests added

Added parser success coverage for compact negative displacements:

```asm
mov DWORD PTR [eax-4], 10
mov DWORD PTR [esi-8], 10
mov DWORD PTR [ebp-10h], 10
mov DWORD PTR [ebp-0x10], 10
mov eax, DWORD PTR [ecx-4]
mov ax, WORD PTR [edx-2]
mov al, BYTE PTR [edi-1]
lea eax, [ebx-4]
```

Added parser regression coverage for existing accepted forms:

```asm
mov DWORD PTR [eax], 10
mov DWORD PTR [eax+4], 10
mov DWORD PTR [eax + 4], 10
mov DWORD PTR [eax - 4], 10
lea eax, [ebx + 4]
lea eax, [ebx - 4]
```

Added parser rejection coverage for unsupported advanced/malformed forms:

```asm
mov eax, DWORD PTR [eax*4]
mov eax, DWORD PTR [eax * 4]
mov eax, DWORD PTR [eax+ebx]
mov eax, DWORD PTR [eax + ebx]
mov eax, DWORD PTR [eax+ebx*4]
mov eax, DWORD PTR [eax + ebx * 4]
mov eax, DWORD PTR [eax-4*2]
mov eax, DWORD PTR [eax - 4 * 2]
mov eax, DWORD PTR [eax-(4)]
mov eax, DWORD PTR [eax--4]
mov eax, DWORD PTR [eax+-4]
```

Added compliance-review range regression coverage:

```asm
mov eax, DWORD PTR [eax-80000000h]
mov eax, DWORD PTR [eax - 80000000h]
```

Both are rejected consistently.

### Source-run tests added

Added source-run success coverage for compact negative write:

```asm
.data
x DWORD 0, 0

.code
main PROC
    mov eax, OFFSET x
    add eax, 4
    mov DWORD PTR [eax-4], 10
    mov ebx, x
main ENDP
END main
```

Expected result:

- execution completes successfully;
- `EBX = 0000000Ah`;
- memory change for `x` from `00000000h` to `0000000Ah`.

Added source-run success coverage for compact negative read:

```asm
.data
x DWORD 10, 20

.code
main PROC
    mov eax, OFFSET x
    add eax, 4
    mov ebx, DWORD PTR [eax-4]
main ENDP
END main
```

Expected result:

- execution completes successfully;
- `EBX = 0000000Ah`;
- no memory-change rows.

Added source-run success coverage for compact negative `lea`:

```asm
.data
x DWORD 0, 0

.code
main PROC
    mov ebx, OFFSET x
    add ebx, 4
    lea eax, [ebx-4]
main ENDP
END main
```

Expected result:

- execution completes successfully;
- `EAX = 00500000h` under fixed layout;
- `EBX = 00500004h` under fixed layout;
- no memory-change rows from `lea`.

Added source-run rejection coverage for malformed advanced compact form:

```asm
.data
x DWORD 10, 20

.code
main PROC
    mov eax, OFFSET x
    mov ebx, DWORD PTR [eax-4*2]
main ENDP
END main
```

Expected result:

- `ok = false`;
- `status = parse-error`;
- runtime/source-run phase remains `57`;
- diagnostic code is `unsupported-scaled-index`;
- no memory-change rows.

### Rendered Simulator Messages tests added

Added exact rendered-message tests for:

- compact negative write success;
- compact negative read success;
- compact negative `lea` success;
- malformed compact advanced-address rejection.

### Static/status checks updated

Updated runner/static expectations to include Phase 57-CORR2 repository/archive status while preserving Phase 57 runtime/source-run MASM behavior metadata.

## 11. Commands used to test

### Verification before implementation

Aggregate baseline command:

```bash
python3 scripts/run_tests.py --all
```

Result:

- Completed and passed before implementation.
- Final line observed:

```text
All implemented milestone tests passed.
```

### Focused commands during and after implementation

Focused commands run:

```bash
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --protocol
```

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Additional final spot-check command:

```bash
build/tests/diagnostic_json_producer program.asm
```

Used with the manual advanced-address rejection fixture to verify the exact diagnostic payload.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped by the test runner because `emcc` was unavailable in the assistant/container environment.

Observed skip category:

```text
group skipped because dependency was unavailable, such as emcc
```

## 12. Pass/fail results

### Initial implementation pass

- `python3 scripts/run_tests.py --native`: passed.
- `python3 scripts/run_tests.py --source-run`: initially failed because one new source-run test expected nested `new` JSON fields instead of the existing flat `newHex`/`newUnsigned` fields. The test assertion was corrected, then the group passed.
- `python3 scripts/run_tests.py --diagnostics`: passed.
- `python3 scripts/run_tests.py --web`: passed.
- `python3 scripts/run_tests.py --structure`: passed.
- `python3 scripts/run_tests.py --static`: initially failed because static status checks still expected Phase 57-CORR1 repository status. The expected repository/archive milestone was updated to Phase 57-CORR2, then the group passed.
- `python3 scripts/run_tests.py --protocol`: passed.
- `python3 scripts/run_tests.py --all`: completed and passed.

Classification:

```text
aggregate completed and passed
```

### First compliance review pass

- `python3 scripts/run_tests.py --native`: passed.
- `python3 scripts/run_tests.py --source-run`: passed.
- `python3 scripts/run_tests.py --diagnostics`: passed.
- `python3 scripts/run_tests.py --web`: passed.
- `python3 scripts/run_tests.py --structure`: passed.
- `python3 scripts/run_tests.py --static`: passed.
- `python3 scripts/run_tests.py --protocol`: passed.
- `python3 scripts/run_tests.py --all`: completed and passed.

Classification:

```text
aggregate completed and passed
```

### Second compliance review pass

- `python3 scripts/run_tests.py --native`: passed.
- `python3 scripts/run_tests.py --source-run`: passed.
- `python3 scripts/run_tests.py --diagnostics`: passed.
- `python3 scripts/run_tests.py --web`: passed.
- `python3 scripts/run_tests.py --structure`: passed.
- `python3 scripts/run_tests.py --static`: passed.
- `python3 scripts/run_tests.py --protocol`: passed.
- `python3 scripts/run_tests.py --all`: completed and passed.

Classification:

```text
aggregate completed and passed
```

### Final gap-check pass

A chained focused-test command timed out after the following groups had already passed:

- native;
- source-run;
- diagnostics.

The remaining focused groups were rerun individually:

- `python3 scripts/run_tests.py --web`: passed.
- `python3 scripts/run_tests.py --structure`: passed.
- `python3 scripts/run_tests.py --static`: passed.
- `python3 scripts/run_tests.py --protocol`: passed.

Aggregate command was then run separately:

- `python3 scripts/run_tests.py --all`: completed and passed.

Final aggregate success line:

```text
All implemented milestone tests passed.
```

Final classification:

```text
aggregate completed and passed
```

The timeout in the chained focused command was an assistant/container command-duration issue, not a project test failure. It was resolved by rerunning the remaining focused groups individually and then rerunning the aggregate command.

## 13. Manual/browser testing guidance and expected outputs

### Required setup assumptions

For local Windows CMD testing:

- Use Developer Command Prompt for Visual Studio or a CMD session where a C compiler is available.
- Python 3 is available as `python`.
- Node.js is available for rendered-message tests.
- Emscripten is not required for local native/source-run tests.

For served website testing:

- Emscripten is required because Phase 57-CORR2 changes the C parser that is compiled into the browser Wasm artifact.
- Use an Emscripten SDK prompt or set `EMSDK_ROOT` so `scripts\windows\build_wasm.cmd` can find `emcc`.
- Without rebuilding `web\dist\masm32_sim_core.js` and `web\dist\masm32_sim_core.wasm`, the served website may still use the old parser and fail `[eax-4]`.

The default page-load program does not exhaustively test this milestone. It does not cover compact negative register-indirect displacements.

### Browser test setup

From Windows CMD at the project root:

```cmd
scripts\windows\build_wasm.cmd
```

Expected success ending:

```text
Built "<project-root>\web\dist\masm32_sim_core.js".
```

Then serve the site:

```cmd
python -m http.server 8000
```

Open:

```text
http://localhost:8000/web/
```

### Browser Program A - compact negative memory write

```asm
.data
x DWORD 0, 0

.code
main PROC
    mov eax, OFFSET x
    add eax, 4
    mov DWORD PTR [eax-4], 10
    mov ebx, x
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key registers:

```text
EAX = 00500004h / u: 5242884 / s: 5242884
EBX = 0000000Ah / u: 10 / s: 10
EFLAGS = 00000000h / 0
```

Expected memory change:

```text
x DWORD
  old | 00000000h / u: 0 / s: 0
  new | 0000000Ah / u: 10 / s: 10
```

### Browser Program B - compact negative memory read

```asm
.data
x DWORD 10, 20

.code
main PROC
    mov eax, OFFSET x
    add eax, 4
    mov ebx, DWORD PTR [eax-4]
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX = 00500004h / u: 5242884 / s: 5242884
EBX = 0000000Ah / u: 10 / s: 10
```

Expected memory changes:

```text
No memory changes.
```

### Browser Program C - compact negative `lea`

```asm
.data
x DWORD 0, 0

.code
main PROC
    mov ebx, OFFSET x
    add ebx, 4
    lea eax, [ebx-4]
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key registers:

```text
EAX = 00500000h / u: 5242880 / s: 5242880
EBX = 00500004h / u: 5242884 / s: 5242884
```

Expected memory changes:

```text
No memory changes.
```

### Browser Program D - advanced form must still fail

```asm
.data
x DWORD 10, 20

.code
main PROC
    mov eax, OFFSET x
    mov ebx, DWORD PTR [eax-4*2]
main ENDP
END main
```

Expected Simulator Messages with the same line layout:

```text
[unsupported-feature] unsupported-scaled-index line 7, column 30, byte offset 89, span length 1: Scaled-index memory operands are not supported yet.
```

Expected Program Console:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

### Windows CMD local testing

Relevant local test commands:

```cmd
python scripts\run_tests.py --source-run
python scripts\run_tests.py --diagnostics
```

Expected output snippets:

```text
[source-run] PASS - source-run integration binary passed independently
Selected test groups passed.
```

```text
[diagnostics] PASS - native diagnostic producer and rendered messages passed
Selected test groups passed.
```

Manual `program.asm` command shape for local JSON checks:

```cmd
build\tests\diagnostic_json_producer.exe program.asm > result.json
```

For the malformed advanced-address Program D, the expected JSON-derived check output is:

```text
False
parse-error
57
unsupported-feature
unsupported-scaled-index
7
30
1
Scaled-index memory operands are not supported yet.
0
```

Regression signs:

- Compact `[reg-constant]` forms are rejected.
- Spaced `[reg - constant]` forms regress.
- Compact negative forms execute with the wrong displacement.
- `lea` reads memory or creates memory-change rows.
- `[eax-4*2]` executes instead of failing.
- The diagnostic for `[eax-4*2]` claims that simple subtraction is unsupported.
- Runtime/source-run phase is not `57`.

## 14. Compliance review summary

A first compliance review checked:

- target scope control;
- non-goal preservation;
- completeness against the guide section;
- code quality and C99 boundary;
- Doxygen documentation for new internal helper functions;
- TODO-style note disposition;
- diagnostic behavior;
- rendered message coverage;
- docs/status wording;
- test quality.

Issue found:

- The first implementation accepted compact negative displacement magnitude `80000000h`, while the existing spaced-minus path rejected `[eax - 80000000h]`.

Fix applied:

- Added compact-negative displacement conversion that mirrors the existing spaced-minus range behavior.
- Added tests for both compact and spaced rejected edge cases.

Compliance-review result:

- Focused groups passed.
- Aggregate completed and passed.
- Verdict: complete.

## 15. Re-review summary

A second compliance review re-read the target guide section and relevant spec behavior, re-inspected changed files and tests, re-scanned TODO-style notes, and reran focused plus aggregate tests.

Additional issues found:

- None.

Additional fixes applied:

- None.

Re-review result:

- Focused groups passed.
- Aggregate completed and passed.
- Verdict: complete.

## 16. User-test follow-up summary

Prompt 8 was conditional on user-reported discrepancies from manual testing. The user reported that everything appeared to pass and proceeded directly to the final gap check.

User-test follow-up performed:

- None required.

Final gap check result:

- No missing milestone work found.
- No target-owned TODO-style notes remained.
- No stale TODO-style note was introduced.
- No accidental future-milestone behavior was found.
- No stale changed-files package reference requiring correction was found.
- No full latest repository archive was produced during the gap check; the recommended archive name remains `Latest_repository_state_milestone_57-CORR2.zip`.

## 17. Known limitations

- Browser/Wasm rebuild smoke could not be performed in the assistant/container environment because `emcc` is unavailable.
- Served-website testing requires rebuilding the Wasm artifact in an Emscripten-enabled environment.
- Advanced addressing remains unsupported by design.
- Phase 57-CORR2 does not implement scaled-index, base-plus-index, SIB, parenthesized expressions, general bracket arithmetic, `.code` memory protection, stack/control-flow/procedure behavior, broader Irvine32 behavior, or any future instruction family.
- No full latest repository archive was produced in this session. Only changed-files ZIP packages and this report file were produced.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57A - README Landing Page Cleanup
```

## 19. Changed-files ZIP/package produced

Changed-files ZIP packages produced during the milestone session:

```text
/mnt/data/changed_files_57_CORR2_package.zip
/mnt/data/changed_files_57_CORR2_compliance_review_package.zip
/mnt/data/changed_files_57_CORR2_second_review_package.zip
```

The final/current changed-files package is:

```text
/mnt/data/changed_files_57_CORR2_second_review_package.zip
```

Milestone report file produced:

```text
/mnt/data/Milestone 57-CORR2 report.md
```
