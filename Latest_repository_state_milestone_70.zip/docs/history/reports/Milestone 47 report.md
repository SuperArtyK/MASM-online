# Milestone 47 report - SHR

## 1. Milestone title and scope

Milestone 47 implements **Phase 47 - SHR** for the Online MASM32 Educational Simulator.

Scope implemented:

- Add executable runtime support for `shr`.
- Support register destinations at 8-bit, 16-bit, and 32-bit widths.
- Support unambiguous memory destinations through typed symbols, symbol offsets, explicit unsigned PTR forms, and explicit signed PTR aliases.
- Support immediate byte shift counts and `CL` as the only register shift-count operand.
- Apply MASM/x86-compatible count masking for 32-bit educational mode:

```text
effective_count = raw_count & 31
```

- Preserve count-zero no-op behavior: if the effective count is zero, destination and modeled flags are unchanged and no undefined-shift warning is emitted.
- Implement logical right-shift semantics: shifted-in high bits are zero.
- Implement default-mode undefined modeled-flag warnings for architecturally undefined SHR flag cases while allowing execution to complete.
- Implement strict undefined-shift validation through the existing test/API configuration path, where the same undefined modeled-flag condition becomes a runtime error before mutation.
- Add flag-specific diagnostic wording that states which modeled flags were updated, which flags are architecturally undefined, and which flags the simulator preserved deterministically.
- Preserve all prior milestone behavior.
- Update source-run and browser metadata to report phase 47.
- Add native C, parser, executor, source-run JSON, rendered Simulator Messages, protocol/static, documentation, manual-testing, compliance, and regression coverage.

The implementation stayed within the milestone boundary. No future SAR, rotate, control-flow, stack, procedure, Irvine32, QWORD/SQWORD execution, or PF/AF behavior was implemented.

## 2. Source-of-truth files used

Canonical repository files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 46 report.md`

Repository archive used as the implementation base:

- `Latest_repository_state_milestone_46.zip`

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, phase tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.

## 3. Exact requirements implemented

Accepted syntax implemented:

```asm
shr reg, 1
shr reg, imm
shr reg, cl
shr mem, 1
shr mem, imm
shr mem, cl
```

Supported register destinations:

```text
reg8, reg16, reg32
```

Supported memory destinations:

```asm
shr BYTE PTR [eax], 1
shr WORD PTR [eax], 1
shr DWORD PTR [eax], 1
shr SBYTE PTR [eax], 1
shr SWORD PTR [eax], 1
shr SDWORD PTR [eax], 1
shr value, 1
shr values[4], 1
```

Rejected syntax verified:

```asm
shr 1, al
shr eax, ebx
shr eax, cx
shr eax, ecx
shr eax
shr eax, 1, 2
shr [eax], 1
shr QWORD PTR q, 1
shr SQWORD PTR q, 1
```

Runtime semantics implemented:

- Raw count source:
  - immediate byte count, or
  - low 8 bits of `ECX` when the count operand is `CL`.
- Effective count:

```text
effective_count = raw_count & 31
```

- Effective count `0`:
  - destination unchanged;
  - `CF`, `ZF`, `SF`, and `OF` unchanged;
  - no undefined-shift warning.
- Effective count `1`:
  - destination shifted right by one bit;
  - high bit filled with zero;
  - `CF` receives the bit shifted out of bit 0;
  - `ZF` and `SF` update from the result;
  - `OF` receives the original most significant bit of the destination.
- Effective count greater than `1` but less than destination width:
  - destination shifted right logically by effective count;
  - `CF` receives the last bit shifted out of bit 0;
  - `ZF` and `SF` update from the result;
  - `OF` is architecturally undefined and is preserved deterministically by the simulator;
  - default mode emits `undefined-shift-flag` warning;
  - strict mode emits `undefined-shift-flag` runtime error before mutation.
- Effective count greater than or equal to destination width:
  - destination shifted right logically and deterministically;
  - `ZF` and `SF` update from the result;
  - `CF` is architecturally undefined and is preserved deterministically by the simulator;
  - `OF` is architecturally undefined and is preserved deterministically by the simulator;
  - default mode emits `undefined-shift-flag` warning;
  - strict mode emits `undefined-shift-flag` runtime error before mutation.

Diagnostics implemented or verified:

- `undefined-shift-flag` warning in default mode.
- `undefined-shift-flag` runtime error in strict undefined-shift validation mode.
- `ambiguous-memory-width` for untyped memory destinations such as `shr [esi], 1`.
- `invalid-instruction-operands` for immediate destinations, wrong operand counts, and invalid count registers such as `EBX`, `CX`, and `ECX`.
- Existing unsupported-runtime diagnostics for executable `QWORD PTR` and `SQWORD PTR` memory operations remain in force.
- Existing runtime memory diagnostics for invalid addresses and `.CONST` permission failures remain structured and rendered.
- Diagnostic source location data remains preserved: line, column, byte offset, and span length where applicable.

Acceptance examples:

```asm
.code
main PROC
    mov al, 80h
    shr al, 1
main ENDP
END main
```

Expected final state:

```text
EAX = 00000040h / 64
EFLAGS = 00000800h / 2048
OF = 1
```

```asm
.code
main PROC
    mov al, 80h
    shr al, 8
main ENDP
END main
```

Expected default-mode behavior:

```text
[simulator-warning] undefined-shift-flag ...
[info] execution-complete: Execution completed successfully.
EAX = 00000000h / 0
EFLAGS = 00000040h / 64
```

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 47:

- `sar`
- `rol`, `ror`, or other rotates
- `cmp`
- labels, `jmp`, conditional jumps, or `loop`
- `lea`
- `mul`, `imul`, `div`, or `idiv`
- `push`, `pop`, `call`, `ret`, `leave`, or stack behavior
- procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`
- Irvine32 routine bodies beyond the existing `exit` virtual terminator
- Program Console input/output routines
- scaled-index addressing
- executable QWORD/SQWORD memory operations
- PF/AF integration for shift instructions
- browser UI setting for strict undefined-shift validation
- Windows API, PE loading, object linking, host include loading, or macro behavior

Compile-time expression operator `SHR` remains separate from runtime instruction `shr`. Existing expression behavior was preserved.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `shr` should be represented as a dedicated IR opcode.
- **Reason:** Dedicated opcode identity preserves source mnemonic clarity for diagnostics, tests, protocol/debug display, and future debugger output.
- **Risk:** Adds another opcode and executor case instead of one generic shift opcode with direction metadata.
- **How to change later:** A future internal normalization pass could share a lower-level shift helper while preserving public opcode identity.

### Assumption 2

- **Assumption:** Immediate `shr` counts should follow Phase 46's implemented byte-count validation, including accepted values `0..255`.
- **Reason:** Phase 47 explicitly reuses Phase 46 destination/count forms and count policy.
- **Risk:** Future expression support could produce wider evaluated constants that need clearer instruction-encoding validation.
- **How to change later:** Route count expressions through the centralized expression evaluator and keep a documented final byte-count validation step.

### Assumption 3

- **Assumption:** Warning and strict diagnostic wording should mirror the Milestone 46 flag-specific style, replacing `SHL/SAL` with `SHR` and adjusting the flag details.
- **Reason:** Milestone 46 user testing found generic wording too vague, and the final behavior benefits from flag-specific undefined-modeled-flag messages.
- **Risk:** Exact rendered-message strings may need review if future UI wording is standardized further.
- **How to change later:** Keep diagnostic code stable as `undefined-shift-flag` and update only message text/tests if wording needs refinement.

### Assumption 4

- **Assumption:** Strict undefined-shift validation remains test/API-only for Phase 47.
- **Reason:** Phase 46 exposed it through native/Wasm source-run options and explicitly did not add a browser UI setting. Phase 47 does not require a settings UI.
- **Risk:** Users cannot toggle strict shift validation in the browser yet.
- **How to change later:** Add it to the eventual simulator settings/UI schema in a later settings milestone.

### Assumption 5

- **Assumption:** PF and AF remain unmodeled and untouched in Milestone 47.
- **Reason:** The stable project behavior currently models only `CF`, `ZF`, `SF`, and `OF`; PF/AF shift integration is outside Phase 47 scope.
- **Risk:** Future PF/AF integration must revisit `shr` along with `shl`, `sal`, and `sar`.
- **How to change later:** Implement PF/AF in a dedicated later flag-integration phase without changing the Phase 47 `CF/ZF/SF/OF` contract.

## 6. Design summary

### IR changes

One new opcode was added:

```text
VM_IR_OPCODE_SHR
```

The opcode-name helper was updated so diagnostics, tests, and future debugging output can identify the opcode as:

```text
shr
```

### Parser changes

The parser recognizes `shr` as a binary destination-mutating shift instruction.

Parser behavior:

- Accepts register destinations.
- Accepts direct typed symbols and typed symbol offsets as memory destinations.
- Accepts explicit `BYTE PTR`, `WORD PTR`, and `DWORD PTR` memory forms.
- Accepts signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases by width.
- Accepts immediate byte shift counts.
- Accepts `CL` as the only register count operand.
- Rejects immediate destinations.
- Rejects wrong operand counts.
- Rejects count registers other than `CL`, including `CX`, `ECX`, and general registers such as `EBX`.
- Rejects untyped memory destinations such as `shr [eax], 1` with `ambiguous-memory-width`.
- Preserves existing QWORD/SQWORD executable memory-operation rejection.
- Emits static `.CONST` write diagnostics for direct `.CONST` destinations where existing static detection applies.

### Executor changes

The executor handles `SHR` through a logical-right-shift read-modify-write path.

Execution algorithm:

1. Resolve and validate destination and shift-count operands.
2. Resolve raw count from immediate or `CL`.
3. Compute effective count as `raw_count & 31`.
4. If effective count is zero, return success without mutation.
5. In strict undefined-shift validation mode, detect undefined modeled-flag cases before mutation and emit a runtime error.
6. Read destination value.
7. Save pre-instruction CPU/flag state for rollback on failed writes.
8. Compute the logical right-shifted result at operand width.
9. Update or preserve modeled flags according to Phase 47 rules.
10. Write result back to register or memory destination.
11. If a memory write fails, restore CPU/flag state so no partial mutation is visible.

Memory behavior:

- All memory reads go through checked VM read helpers.
- All memory writes go through checked VM write helpers.
- `.CONST` permission checks remain enforced by final address range.
- Invalid reads occur before write-back.
- Failed writes do not create successful memory-change rows.

### Source-run and diagnostics changes

The source-run path emits default-mode `undefined-shift-flag` warnings before executing SHR instructions that have architecturally undefined modeled flags.

Warning-only runs continue to execute and may end with both:

```text
[simulator-warning] undefined-shift-flag ...
[info] execution-complete: Execution completed successfully.
```

Strict undefined-shift validation instead returns a runtime error and does not execute the offending SHR instruction.

### Documentation and metadata

Updated documentation and metadata to describe Phase 47 as the current implemented milestone and list `shr` as a supported runtime instruction.

## 7. Files changed

Final Phase 47 implementation, compliance, diagnostic-quality, and final gap-check work touched these files across the cumulative milestone work:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
src/wasm/wasm_api.h
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

Final gap-check-only cleanup touched:

```text
tests/core/test_parser.c
tests/core/test_wasm_source_run.c
```

## 8. Tests added

### Parser tests

Added or expanded coverage for:

- `shr al, 1`
- `shr ax, 1`
- `shr eax, 1`
- `shr eax, 0`
- `shr eax, 32`
- `shr eax, cl`
- mixed-case `ShR eax, cl`
- `shr BYTE PTR [eax], 1`
- `shr WORD PTR [eax], 1`
- `shr DWORD PTR [eax], 1`
- `shr SBYTE PTR [eax], 1`
- `shr SWORD PTR [eax], 1`
- `shr SDWORD PTR [eax], 1`
- direct typed symbol destinations
- symbol-offset destinations
- immediate destination rejection
- wrong operand count rejection
- missing count rejection
- invalid count-register rejection for `EBX`, `CX`, and `ECX`
- ambiguous memory-width rejection
- QWORD/SQWORD executable memory-operation rejection
- direct `.CONST` write rejection through existing paths

### Executor tests

Added or expanded coverage for:

- `shr al, 1`: `01h -> 00h`, `CF=1`, `ZF=1`, `SF=0`
- `shr al, 1`: `80h -> 40h`, `OF=1`
- `shr ax, 1` logical zero-fill behavior
- `shr eax, 1` logical zero-fill behavior and `OF` from original MSB
- `shr eax, 2` defined result with undefined `OF` preservation
- `shr eax, 32` effective-count-zero no-op
- `shr al, 8` undefined `CF/OF` preservation with result-based `ZF/SF`
- `shr eax, cl` using low 8 bits of `ECX`
- alias-width mutation for `AL` and `AX`
- byte, word, and dword memory read-modify-write success
- invalid memory read failure
- `.CONST` permission failure
- no partial mutation on failed memory writes
- strict undefined-shift validation rejecting before mutation

### Source-run JSON tests

Added or expanded coverage for:

- successful register acceptance program
- successful memory destination program
- `CL` count program
- count-zero no-op program
- default warning plus successful execution
- strict-mode runtime error without execution completion
- invalid immediate destination
- invalid count register
- missing count
- wrong operand count
- ambiguous memory-width diagnostic
- direct `.CONST` assembly diagnostic
- computed `.CONST` runtime failure
- invalid memory destination runtime failure
- phase metadata reporting `47`
- warning text naming affected/preserved flags

### Rendered Simulator Messages tests

Added exact rendered-message coverage for:

- successful execution line through existing success fixture coverage
- `ambiguous-memory-width` from `shr [eax], 1`
- `invalid-instruction-operands` from `shr eax, ebx`
- default `undefined-shift-flag` warning from `shr al, 8`
- strict `undefined-shift-flag` runtime error from `shr al, 8`

### Regression tests

Regression coverage confirms:

- Existing `shl` and `sal` behavior remains intact.
- Existing `not`, `and`, `or`, `xor`, `test`, `inc`, `dec`, `adc`, `sbb`, `neg`, `xchg`, `nop`, and carry-control behavior remains intact.
- Existing compile-time expression `SHR` behavior remains separate from runtime instruction `shr`.
- Existing `.CONST`, object-bounds, uninitialized-read, invalid-address, and strict/warning diagnostic paths remain intact.
- Existing Milestone 42 `exit` behavior remains intact.
- Program Console remains separate from Simulator Messages.

## 9. Commands used to test

Primary aggregate test command:

```sh
cd /mnt/data/repo_m47
python3 scripts/run_tests.py
```

Observed result:

```text
All implemented milestone tests passed.
```

Wasm rebuild check attempted:

```sh
cd /mnt/data/repo_m47
bash scripts/build_wasm.sh
```

Observed result in this container:

```text
scripts/build_wasm.sh: line 18: emcc: command not found
```

Interpretation:

- Native C and Node tests pass.
- This container cannot rebuild Wasm because Emscripten is not installed.
- Served website behavior requires a local Wasm rebuild in an Emscripten-enabled environment.

Additional targeted final gap-check commands were run after stale test wording cleanup:

```sh
cd /mnt/data/repo_m47
./build/tests/test_parser
./build/tests/test_wasm_source_run
node tests/web/test_diagnostic_rendering.mjs
```

Observed result:

```text
Minimal parser tests passed.
Source execution tests through Phase 47 regression coverage passed.
test_parser:0 test_wasm_source_run:0 node_diag:0
```

## 10. Pass/fail results

Final automated test status:

```text
PASS - native C tests
PASS - parser tests
PASS - executor tests
PASS - source-run JSON tests
PASS - Node formatter/protocol tests
PASS - rendered Simulator Messages tests
PASS - milestone/static structure tests
PASS - aggregate test runner
SKIPPED/UNAVAILABLE - Wasm rebuild in this container because emcc is not installed
```

Manual user testing status:

```text
PASS - all provided manual browser programs matched expected behavior.
PASS - local JSON output for default SHR undefined-flag warning matched expected semantics.
NOTE - byteOffset may differ between browser LF source and Windows CRLF program.asm files; line, column, span length, and behavior remain correct.
```

## 11. Manual/browser testing guidance and expected outputs

Website-testable: yes, after rebuilding Wasm locally with Emscripten.

Windows setup assumptions:

```cmd
emcc --version
py --version
node --version
```

Build and serve on Windows:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

Stop server:

```cmd
scripts\windows\stop_web.cmd
```

Local Windows test command:

```cmd
py scripts\run_tests.py
```

Expected:

```text
All implemented milestone tests passed.
```

Optional per-file local source check:

```cmd
build\tests\diagnostic_json_producer.exe program.asm
```

### Manual program 1 - default SHR sample and undefined OF warning

```asm
.code
main PROC
    mov eax, 80000000h
    mov ecx, 2
    shr eax, 1
    shr eax, cl
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 6, column 5, byte offset 73, span length 11: SHR count 2 has effective count 2 for a 32-bit destination. CF, ZF, and SF were updated from the result. OF is architecturally undefined because the effective count is greater than 1. The simulator preserved OF deterministically.
[info] execution-complete: Execution completed successfully.
```

Expected final registers:

```text
EAX    10000000h / 268435456
ECX    00000002h / 2
EFLAGS 00000800h / 2048
```

Expected memory changes:

```text
No memory changes.
```

### Manual program 2 - one-bit logical right shift and OF behavior

```asm
.code
main PROC
    mov al, 80h
    shr al, 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected final registers:

```text
EAX    00000040h / 64
EFLAGS 00000800h / 2048
```

Expected modeled flags:

```text
CF = 0
ZF = 0
SF = 0
OF = 1
```

### Manual program 3 - count-zero no-op through count masking

```asm
.code
main PROC
    stc
    mov eax, 80000000h
    shr eax, 32
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected final registers:

```text
EAX    80000000h / 2147483648
EFLAGS 00000001h / 1
```

Expected memory changes:

```text
No memory changes.
```

### Manual program 4 - default undefined modeled-flag warning with successful execution

```asm
.code
main PROC
    mov al, 80h
    shr al, 8
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 4, column 5, byte offset 36, span length 9: SHR count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
[info] execution-complete: Execution completed successfully.
```

Expected final registers:

```text
EAX    00000000h / 0
EFLAGS 00000040h / 64
```

Note: when the same program is saved as `program.asm` on Windows with CRLF line endings and run through the diagnostic JSON producer, `byteOffset` may be larger than the browser LF-source value. This is expected because `byteOffset` counts raw source bytes. Line, column, and span length should remain correct.

### Manual program 5 - writable memory read-modify-write

```asm
.data
value DWORD 80000000h
.code
main PROC
    shr value, 1
    mov eax, value
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected final registers:

```text
EAX    40000000h / 1073741824
EFLAGS 00000800h / 2048
```

Expected memory changes in the browser:

```text
value: 80000000h / 2147483648 -> 40000000h / 1073741824
```

### Manual program 6 - ambiguous memory width rejected

```asm
.code
main PROC
    mov eax, 0
    shr [eax], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 4, column 9, byte offset 39, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Expected behavior:

```text
Execution does not run.
No execution-complete message.
Program Console remains empty.
```

### Manual program 7 - invalid count register rejected

```asm
.code
main PROC
    shr eax, ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 3, column 14, byte offset 29, span length 3: SHR count must be an immediate byte count or CL.
```

Expected behavior:

```text
Execution does not run.
No execution-complete message.
```

### Local strict-mode test

Strict undefined-shift validation is not exposed as a browser UI setting in Milestone 47. It can be tested locally through the diagnostic producer.

Create `program.asm`:

```asm
.code
main PROC
    mov al, 80h
    shr al, 8
main ENDP
END main
```

Run in Windows CMD:

```cmd
set MASM32_DIAGNOSTIC_SHIFT_VALIDATION=strict
build\tests\diagnostic_json_producer.exe program.asm
set MASM32_DIAGNOSTIC_SHIFT_VALIDATION=
```

Expected JSON contains:

```text
"ok":false
"status":"execution-error"
"instructionCount":1
"kind":"runtime-error"
"code":"undefined-shift-flag"
"SHR count 8 has effective count 8 for an 8-bit destination."
```

Expected JSON must not contain:

```text
execution-complete
```

## 12. Compliance review summary

A first compliance review checked scope, completeness, code quality, diagnostics, tests, and documentation.

Issues found and fixed:

- Edited source/docs/tests had been converted from the repository's CRLF baseline to LF, causing noisy full-file diffs.
- Parser negative coverage was missing explicit SHR `ECX` count rejection.
- Parser negative coverage was missing explicit SHR missing-count behavior.
- Parser negative coverage was missing explicit SHR `QWORD PTR` executable-memory rejection alongside existing `SQWORD PTR` coverage.
- Source-run negative coverage was missing explicit checks for immediate destination `shr 1, al` and missing count `shr eax`.

Fixes applied:

- Restored CRLF line endings for changed text files.
- Added the missing parser and source-run negative tests.
- Reran the aggregate test suite successfully.

Result:

```text
All implemented milestone tests passed.
```

Changed-files package from this pass:

```text
/mnt/data/milestone47_compliance_review_changed_files.zip
```

## 13. Re-review summary

A second compliance review re-read Phase 47, relevant spec sections, changed files, tests, and documentation.

Additional issues found and fixed:

- README implemented-instruction list still omitted `shr`.
- `docs/SUPPORTED_SYNTAX.md` implemented-instruction list still omitted `shr`.
- `docs/SUPPORTED_SYNTAX.md` overview sentence did not include the shift milestones in the current behavior summary.
- Two shared helper comments still described the helpers as `SHL/SAL` only after `SHR` support was added.

Fixes applied:

- Added `shr` to README and supported-syntax instruction lists.
- Updated supported-syntax overview wording to include shift milestones while excluding future `sar`, rotates, multiplication/division, labels/jumps, stack behavior, and Irvine32 expansion.
- Generalized stale comments in `src/core/vm_exec.c` and `src/wasm/wasm_api.c`.
- Reran the aggregate test suite successfully.

Result:

```text
All implemented milestone tests passed.
```

Changed-files package from this pass:

```text
/mnt/data/milestone47_second_review_changed_files.zip
```

## 14. User-test follow-up summary

User manual testing found that the browser outputs for Programs 1-5 matched expected SHR behavior. Programs 6 and 7 failed with expected diagnostics.

One manual-instructions discrepancy was identified:

- The memory-change display for direct symbol writes is compact in the browser:

```text
value: 80000000h / 2147483648 -> 40000000h / 1073741824
```

- The earlier manual guidance had expected extra width/offset/index detail for this direct offset-zero case.
- Diagnosis: manual expectation/documentation issue, not an implementation bug.
- Fix: record the compact direct-symbol row as the expected browser output.

The user also provided local JSON output for the `shr al, 8` default-mode warning case. It matched expected semantics:

- `phase: 47`
- `ok: true`
- `status: ok`
- `instructionCount: 2`
- `EAX = 00000000h / 0`
- `EFLAGS = 00000040h / 64`
- `undefined-shift-flag` warning present
- `execution-complete` info present

The only difference from browser-oriented expected text was `byteOffset` due to Windows CRLF source bytes in `program.asm`. This is expected and not a bug.

No implementation fixes were required from user-test follow-up.

## 15. Known limitations

- The prebuilt Wasm artifact must be rebuilt locally for the served website to show the C/Wasm behavior.
- This environment could not rebuild Wasm because `emcc` is unavailable.
- Strict undefined-shift validation is test/API-only; there is no browser UI toggle in Milestone 47.
- `shr` does not add PF/AF behavior because those flags remain unmodeled in this phase.
- `sar` remains Phase 48 and is not implemented.
- Rotates, control flow, stack behavior, Irvine32 routine bodies, QWORD/SQWORD executable memory operations, and Program Console I/O remain future work or explicit non-goals for this milestone.

## 16. Next recommended milestone

The next recommended milestone is:

```text
Milestone 48 / Phase 48 - SAR
```

Phase 48 should implement arithmetic right shift only, using the established shift infrastructure while preserving Milestone 47 `shr` behavior.

## 17. Changed-files ZIP/package produced

Changed-files packages produced during Milestone 47:

```text
/mnt/data/milestone47_changed_files.zip
/mnt/data/milestone47_compliance_review_changed_files.zip
/mnt/data/milestone47_second_review_changed_files.zip
/mnt/data/milestone47_final_gap_check_changed_files.zip
```

Latest changed-files package:

```text
/mnt/data/milestone47_final_gap_check_changed_files.zip
```

Recommended next full repository archive name after applying the latest changed-files package:

```text
Latest_repository_state_milestone_47.zip
```

## 18. Final status

Milestone 47 is complete.

It implements the requested milestone only, includes tests for success/error/edge/regression paths, updates documentation and static checks, passes the aggregate native/Node test suite, and has successful user manual-test follow-up for browser-visible behavior.
