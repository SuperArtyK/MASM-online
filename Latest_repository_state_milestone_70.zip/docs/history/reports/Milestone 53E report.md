# Milestone 53E report - Memory Validation and Teaching Diagnostic UI Settings

## 1. Milestone title and scope

Milestone 53E implements **Phase 53E - Memory Validation and Teaching Diagnostic UI Settings** for the Online MASM32 Educational Simulator.

This milestone exposes already-implemented memory validation and teaching diagnostic policies through browser UI controls and structured worker/source-run settings. It is a UI/settings/protocol milestone. It does not add new MASM syntax, new instructions, or new runtime validation semantics.

Scope implemented:

- Added browser controls for memory range validation.
- Added browser controls for uninitialized-read diagnostics.
- Added browser controls for undefined-flag-use diagnostics.
- Added browser controls for compatibility notices.
- Preserved Phase 53C and Phase 53D default behavior:
  - uninitialized reads warn by default;
  - undefined flag use warns by default;
  - compatibility notices are on by default;
  - memory range validation defaults to region-only;
  - object and section validation remain off unless selected.
- Routed browser-selected settings through structured, JSON-compatible worker messages.
- Routed worker settings to the same source-run/backend policy paths used by local tests.
- Added renderable `ui-error` Simulator Messages for semantically invalid diagnostic setting values.
- Preserved malformed protocol request handling through the existing worker error path.
- Implemented compatibility-notice opt-out, resolving the target-owned Phase 53D follow-up note.
- Added UI help text under each setting, with expanded memory-range explanations for region-only, section-capacity, section-image, and declared-object-bounds policies.
- Documented that Phase 53E diagnostic settings are local page-session preferences, because share URLs are not yet implemented.
- Updated documentation and aggregate test reporting for Phase 53E.

The implementation stayed within the target milestone boundary. No new runtime instruction behavior, memory behavior, MASM compatibility behavior, macro behavior, stack behavior, procedure behavior, WinAPI behavior, linker behavior, or Phase 54 signed `imul` behavior was implemented.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 53D report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_53D.zip
```

Important source-of-truth interpretation used:

- The full implementation specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 53E is the only target milestone for this implementation session.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- User-visible diagnostics require structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

### 3.1 Browser settings UI

Implemented a **Diagnostic settings** panel in the browser UI.

The panel exposes these settings:

```text
Memory range validation
- Region-only (default)
- Section capacity: warn
- Section capacity: strict stop
- Section image: warn
- Section image: strict stop
- Declared object bounds: warn
- Declared object bounds: strict stop

Uninitialized reads
- Warn (default)
- Off / I know what I'm doing
- Strict stop

Undefined flag use
- Warn (default)
- Off / I know what I'm doing
- Strict stop

Compatibility notices
- On (default)
- Off
```

The UI help text explains the effective diagnostic meaning of memory range validation policies:

- **Region-only** uses the mandatory VM memory checks only. It remains closest to native MASM-style memory behavior while still blocking invalid simulated regions and `.CONST` writes.
- **Section capacity** warns or stops when an access leaves the known simulated section capacity range.
- **Section image** warns or stops when an access leaves the initialized or declared section image range while still passing mandatory region checks.
- **Declared object bounds** warns or stops when an access crosses the bounds of declared data objects.
- **Warn** modes continue execution after reporting a Simulator Message.
- **Strict stop** modes stop before the instruction mutates state.

The UI help text also explains:

- uninitialized storage remains deterministic zero-filled unless overwritten;
- warning mode reports uninitialized-origin reads while continuing execution;
- undefined-flag-use warnings report non-portable flag-dependent behavior while continuing with deterministic simulator values;
- compatibility notices explain accepted MASM directives that are ignored, metadata-only, or modeled partially;
- compatibility-notice opt-out hides those notices without changing execution behavior.

### 3.2 Structured settings and protocol routing

Implemented browser-side settings normalization and worker protocol routing.

New browser-side settings behavior:

- `web/src/settings.js` owns default settings, normalization, validation, and backend enum mapping.
- `web/src/main.js` collects UI selections and sends normalized settings in `RUN_SOURCE` messages.
- `web/src/worker.js` validates semantically invalid settings and routes valid settings to the new Wasm/source-run API path.
- Default values are supplied even when direct/internal worker calls omit settings.
- If the loaded Wasm artifact does not expose the new Phase 53E settings export and non-default settings are requested, the worker returns a renderable `ui-error` explaining that the Wasm artifact is stale.
- Default execution can still use the compatibility fallback path when settings are omitted or default-only.

The settings object remains structured-clone-safe and JSON-compatible.

### 3.3 Wasm/source-run settings API

Added a new Wasm-facing source-run entry point:

```text
masm32_sim_wasm_run_source_json_with_ui_settings
```

This path maps browser UI settings onto existing backend policy values. It does not introduce new runtime behavior.

Implemented setting mappings:

- memory range validation:
  - region-only;
  - section-capacity warn;
  - section-capacity strict;
  - section-image warn;
  - section-image strict;
  - declared-object bounds warn;
  - declared-object bounds strict.
- uninitialized-read diagnostics:
  - off;
  - warn;
  - strict.
- undefined-flag-use diagnostics:
  - off;
  - warn;
  - error/strict.
- compatibility notices:
  - off;
  - on.

The older source-run wrapper path remains available for compatibility.

### 3.4 Compatibility notice opt-out

Implemented compatibility-notice opt-out through parser/source-run configuration.

Behavior:

- Default behavior remains notices on.
- When compatibility notices are off, accepted compatibility constructs still parse and execute normally.
- Turning notices off suppresses only `compatibility-no-op`, `compatibility-metadata-only`, and `compatibility-limited` notice diagnostics.
- Turning notices off does not suppress assembly errors, runtime errors, warnings, `.CONST` protection, or unsupported-feature diagnostics.
- Active semantic constructs still do not receive generic no-op notices.

This resolves the target-owned TODO-style Phase 53D follow-up note that required Phase 53E to add compatibility-notice opt-out if it was not already done in Phase 53D.

### 3.5 Invalid setting diagnostics

Invalid semantic diagnostic setting values now produce renderable `ui-error` Simulator Messages.

Examples covered by tests:

- invalid memory range validation value;
- invalid uninitialized-read setting value;
- invalid undefined-flag-use setting value;
- invalid compatibility-notices setting value.

These setting validation diagnostics are emitted through Simulator Messages, not Program Console.

Malformed protocol shapes and unknown worker message types retain existing worker error behavior.

### 3.6 Default behavior preserved

Default browser/source-run behavior remains:

```text
memory range validation: region-only
uninitialized reads: warn
undefined flag use: warn
compatibility notices: on
```

Object-bound validation and section validation remain off unless explicitly selected.

Existing mandatory behavior remains always enforced:

- invalid VM memory region accesses are blocked;
- `.CONST` writes are blocked;
- assembly errors prevent execution;
- runtime errors stop execution according to existing semantics;
- Program Console remains separate from Simulator Messages.

### 3.7 Documentation and status updates

Updated documentation to describe Phase 53E as implemented:

- README status text.
- Supported syntax/current behavior documentation.
- Testing guide references for browser-exposed validation settings.
- Aggregate test runner reporting.

Stale documentation that previously described object-bound and section validation browser controls as deferred/test-only was corrected during review and final gap check.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 53E:

- New MASM syntax.
- New runtime validation semantics.
- New memory model behavior.
- New parser grammar beyond configuration plumbing.
- New instructions.
- Phase 54 one-operand signed `imul`.
- Broad warning presets.
- Provenance validation unless already implemented by earlier milestones.
- Debugger memory visualization changes.
- Global diagnostic audit or final warning taxonomy.
- Full share URL support for diagnostic settings.
- Macro expansion.
- Real host include loading.
- Listing file generation.
- Runtime stack instructions or procedure frames.
- `call`, `ret`, `push`, `pop`, `leave`, `LOCAL`, `PROTO`, `INVOKE`, or broader procedure behavior.
- Windows calling-convention behavior.
- WinAPI simulation.
- PE loading or object-file linking.
- Program Console behavior changes.

Future work remains owned by later phases, especially Phase 54 - One-Operand Signed IMUL and later share/settings URL phases.

## 5. Assumptions used

### Assumption 1

- **Assumption:** A single memory range selector is appropriate for Phase 53E instead of independent section-capacity, section-image, and declared-object toggles.
- **Reason:** The guide presents browser-facing memory range validation as one list of choices, and a single selector avoids invalid combinations for students.
- **Risk:** Advanced users cannot enable multiple optional range checks simultaneously from the browser UI.
- **How to change later:** A future advanced-settings phase can split the selector into independent toggles if the canonical guide/spec explicitly allows combined policies.

### Assumption 2

- **Assumption:** Browser UI settings should map to existing backend policies, even if the new Wasm settings path needs to separate fields that older wrappers previously combined.
- **Reason:** Phase 53E requires separate UI controls for memory range validation and uninitialized-read diagnostics, while older compatibility wrappers had historically combined some memory-validation options.
- **Risk:** The settings path touches `src/wasm/wasm_api.c` and `src/wasm/wasm_api.h`, not only browser files.
- **How to change later:** Keep the dedicated UI settings API as the forward path while preserving old wrappers for compatibility.

### Assumption 3

- **Assumption:** Compatibility-notice suppression should happen before notices enter normal source-run output, not by filtering rendered text after execution.
- **Reason:** Parser/source-run configuration keeps structured diagnostics aligned with selected policy and avoids hidden diagnostics leaking into tests or future UI state.
- **Risk:** Parser config had to gain a new documented field.
- **How to change later:** If a future central diagnostic policy layer is added, compatibility notice suppression can move there while preserving the same public setting.

### Assumption 4

- **Assumption:** Phase 53E diagnostic settings are local page-session preferences, not share-safe project state.
- **Reason:** Share URL functionality is not implemented yet, and adding it would exceed Phase 53E.
- **Risk:** A user may expect settings to persist across reloads or be included in future shared links.
- **How to change later:** A future share/settings phase can explicitly encode, migrate, or persist settings as project state or local preferences.

### Assumption 5

- **Assumption:** Semantically invalid diagnostic setting values should return source-run-shaped results with `ui-error` Simulator Messages where the request shape is otherwise valid.
- **Reason:** The guide requires unsupported combinations to be rendered through the normal Simulator Messages formatter.
- **Risk:** Some invalid setting issues are reported as run results, while malformed worker messages still use the worker error path.
- **How to change later:** A later protocol-hardening phase can further distinguish schema errors, semantic setting errors, and stale-Wasm errors while keeping rendered UI diagnostics for user-actionable issues.

### Assumption 6

- **Assumption:** The UI help text should favor setting-specific bullet explanations over a large general notes block.
- **Reason:** User testing found the general notes block unnecessary and identified the missing explanation of memory range validation categories as the more important readability problem.
- **Risk:** Some cross-cutting rules are less centralized in the panel.
- **How to change later:** A future UI polish phase can add collapsible help, tooltips, or an advanced explanatory panel if the settings list grows.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and deferral evidence reviewed during planning, implementation, compliance review, re-review, and final gap check:

- **Target-owned Phase 53D follow-up note:** The guide stated that if a backend/test policy for compatibility notices was not added in Phase 53D, Phase 53E must add the compatibility-notice opt-out setting while keeping notices on by default.
- **Future-owned memory-reading opcode TODO:** `src/wasm/wasm_api.c` contains a future instruction milestone note requiring future memory-reading opcodes to be added to a helper when those opcodes are implemented.
- **Future-owned CALL/Irvine32 deferrals:** Parser/source diagnostics and docs preserve deferrals for CALL target classification and broader Irvine32 routine behavior.
- **Documentation deferred-feature notes:** Docs still mention future QWORD/SQWORD execution, stack/procedure behavior, control flow, macro expansion, WinAPI behavior, PE/linking, provenance/taint work, and share URL work.

No TODO-style note was allowed to override the canonical Phase 53E scope.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

Resolved:

- The Phase 53D follow-up requiring Phase 53E compatibility-notice opt-out.

Final behavior:

- Compatibility notices are on by default.
- Browser users can turn compatibility notices off.
- The setting maps to backend/parser configuration.
- Turning notices off does not suppress real warnings, errors, or execution behavior.

### Future-owned TODO-style notes intentionally preserved

Preserved:

- Future memory-reading opcode TODO in `src/wasm/wasm_api.c`.
- CALL target classification and broader Irvine32 routine behavior deferrals.
- Future QWORD/SQWORD execution deferrals.
- Future stack/procedure/control-flow/Irvine32/macro/WinAPI/linking/share URL work.

Reason:

- These belong to later milestones and are outside Phase 53E.

### Stale or contradicted TODO-style notes corrected

Corrected during review/final gap check:

- Stale docs saying browser UI settings for object validation, section validation, or uninitialized-read diagnostics were deferred/test-only.
- Stale browser comments/error wording that still referenced older milestone UI state.

These corrections were documentation/comment/UI-copy cleanup only and did not change behavior outside Phase 53E.

### Unresolved TODO-related risks

None identified.

No new TODO-style notes were added.

## 8. Design summary

### Browser UI design

The settings panel now uses a compact per-setting help layout:

- one short panel intro;
- each dropdown has its own indented bullet explanation directly below it;
- no large general notes block;
- memory range validation help explains the effective diagnostic meaning of each selectable range policy.

This layout was chosen after user feedback because it is easier to scan than a large block of text above or below all settings.

### Browser settings module

`web/src/settings.js` centralizes:

- default settings;
- allowed UI values;
- UI value normalization;
- backend enum mapping;
- validation helpers.

This avoids duplicating settings logic in `main.js`, `worker.js`, and tests.

### Worker/protocol design

The worker accepts `RUN_SOURCE` messages with optional diagnostic settings. Missing settings are filled from defaults.

Semantically invalid settings produce a source-run-shaped result with `ui-error` diagnostics so the normal Simulator Messages formatter can render them.

Malformed protocol messages remain handled by the existing protocol error path.

### Wasm/source-run design

A new settings-specific source-run function maps UI settings onto existing backend configuration.

No new backend policy semantics were introduced. Existing policy machinery remains authoritative for:

- section-capacity validation;
- section-image validation;
- declared-object validation;
- uninitialized-read diagnostics;
- undefined-flag-use diagnostics;
- compatibility notices.

### Compatibility-notice design

Compatibility notices are controlled at parser/source-run configuration time. This avoids producing structured notices only to filter them later.

### Diagnostics design

`ui-error` diagnostics are used only for user-facing invalid setting selections in otherwise valid run requests.

Program Console remains untouched. All settings errors, warnings, notices, and runtime diagnostics remain in Simulator Messages.

## 9. Files changed

Final Phase 53E implementation, compliance review, re-review, user-follow-up polish, and final gap-check changed:

```text
README.md
docs/SUPPORTED_SYNTAX.md
docs/TESTING_GUIDE.md
scripts/build_wasm.sh
scripts/run_tests.py
scripts/windows/build_wasm.cmd
src/parser/parser.c
src/parser/parser.h
src/wasm/wasm_api.c
src/wasm/wasm_api.h
tests/core/test_wasm_source_run.c
tests/web/test_formatters.mjs
tests/web/test_protocol.mjs
tests/web/test_settings.mjs
web/index.html
web/src/main.js
web/src/protocol.js
web/src/settings.js
web/src/styles.css
web/src/worker.js
```

Generated artifacts and build outputs were not included as source changes, except where build scripts were intentionally updated.

## 10. Tests added

### Native/source-run tests

Added or expanded Phase 53E coverage in `tests/core/test_wasm_source_run.c` for:

- compatibility notices default-on;
- compatibility notices off;
- uninitialized-read warn/off/strict behavior through the UI settings path;
- undefined-flag-use warn/off/strict behavior through the UI settings path;
- memory range validation routing for:
  - region-only;
  - section-capacity warn;
  - section-capacity strict;
  - section-image warn;
  - section-image strict;
  - declared-object bounds warn;
  - declared-object bounds strict;
- invalid UI setting enum handling;
- prior behavior regression where defaults still match Phase 53C and Phase 53D.

### Web/settings tests

Added `tests/web/test_settings.mjs` covering:

- default settings object;
- normalization of valid UI settings;
- backend enum mappings for every Phase 53E memory range option;
- uninitialized-read setting mappings;
- undefined-flag-use setting mappings;
- compatibility-notice setting mappings;
- invalid settings validation.

### Worker/protocol tests

Expanded `tests/web/test_protocol.mjs` for:

- `RUN_SOURCE` messages with omitted/default settings;
- `RUN_SOURCE` messages with custom diagnostic settings;
- invalid memory range values;
- invalid uninitialized-read values;
- invalid undefined-flag-use values;
- invalid compatibility-notice values;
- stale-Wasm behavior when non-default settings require the new export.

### Formatter/rendering tests

Expanded `tests/web/test_formatters.mjs` and rendered diagnostic tests for:

- `ui-error` Simulator Message rendering;
- existing warning/notice rendering remaining stable;
- Phase 53E output remaining in Simulator Messages, not Program Console.

### Structure/build tests

Updated structure tests and build script coverage to verify:

- new `web/src/settings.js` module exists;
- new Wasm export is present in build scripts;
- test runner reports Phase 53E coverage.

## 11. Commands used to test

Pre-implementation verification:

```sh
cd /mnt/data/repo_53D
python3 scripts/run_tests.py
```

The aggregate command timed out in the initial container run, so equivalent components were run individually:

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.run_structure_tests()
PY
```

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.run_c_tests()
PY
```

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.build_diagnostic_json_producer()
PY
node tests/web/test_protocol.mjs
node tests/web/test_formatters.mjs
MASM32_DIAGNOSTIC_JSON_PRODUCER="$PWD/build/tests/diagnostic_json_producer" node tests/web/test_diagnostic_rendering.mjs
```

After initial implementation:

```sh
cd /mnt/data/repo_53D
python3 scripts/run_tests.py
```

Compliance review and re-review component tests:

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.run_structure_tests()
PY
```

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.run_c_tests()
PY
```

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.build_diagnostic_json_producer()
PY
node tests/web/test_protocol.mjs
node tests/web/test_settings.mjs
node tests/web/test_formatters.mjs
MASM32_DIAGNOSTIC_JSON_PRODUCER="$PWD/build/tests/diagnostic_json_producer" node tests/web/test_diagnostic_rendering.mjs
```

UI polish follow-up targeted tests:

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.run_structure_tests()
PY
node tests/web/test_settings.mjs
node tests/web/test_protocol.mjs
node tests/web/test_formatters.mjs
```

Final gap-check tests:

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.run_structure_tests()
PY
```

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.run_c_tests()
PY
```

```sh
cd /mnt/data/repo_53D
python3 - <<'PY'
import scripts.run_tests as rt
rt.build_diagnostic_json_producer()
PY
node tests/web/test_protocol.mjs
node tests/web/test_settings.mjs
node tests/web/test_formatters.mjs
MASM32_DIAGNOSTIC_JSON_PRODUCER="$PWD/build/tests/diagnostic_json_producer" node tests/web/test_diagnostic_rendering.mjs
```

## 12. Pass/fail results

### Pre-implementation repository verification

Component-level existing tests passed:

```text
Structure tests: PASS
Native C tests: PASS
Diagnostic JSON producer build: PASS
Node protocol tests: PASS
Node formatter tests: PASS
Rendered diagnostic tests: PASS
```

The initial single aggregate command timed out in the container before final output, but no assertion failure was observed in the separately run equivalent stages.

### Post-implementation

The aggregate test suite completed successfully after implementation:

```text
All implemented milestone tests passed.
```

### Compliance review

Relevant component tests passed:

```text
Structure tests: PASS
Native C tests: PASS
Diagnostic JSON producer build: PASS
Node protocol/settings/formatter tests: PASS
Rendered diagnostic tests: PASS
```

The aggregate command timed out during one compliance review rerun after passing the separately run stages. No assertion failure was observed.

### Re-review and final gap check

Relevant component tests passed:

```text
Structure tests: PASS
Native C tests: PASS
Diagnostic JSON producer build: PASS
Node protocol/settings/formatter tests: PASS
Rendered diagnostic tests: PASS
```

### Browser/Wasm result

Manual browser testing after rebuilding Wasm was not performed in the container because `emcc` is unavailable.

User later reported:

```text
Everything runs.
```

This confirmed the milestone was successfully testable in the user's browser environment after rebuild.

## 13. Manual/browser testing guidance and expected outputs

Phase 53E is website-testable after rebuilding Wasm with Emscripten.

### Setup on Windows CMD

From the project root:

```bat
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000/web/
```

### Manual test 1 - Compatibility notices on/off

Program:

```asm
.686
.model flat, stdcall
.stack 4096
INCLUDE Macros.inc
TITLE Notice Sample
.code
main PROC
    mov eax, 7
main ENDP
END main
```

With default settings, expected Simulator Messages:

```text
[simulator-notice] compatibility-no-op line 1, column 1, byte offset 0, span length 4: .686 is accepted for MASM compatibility but does not change the simulator CPU mode.
[simulator-notice] compatibility-limited line 2, column 1, byte offset 5, span length 6: .model flat, stdcall is accepted for MASM32 textbook compatibility but does not enable real object-file, linker, Windows calling-convention, or WinAPI behavior.
[simulator-notice] compatibility-metadata-only line 3, column 1, byte offset 26, span length 6: .stack size is recorded as parser metadata, but runtime stack instructions and procedure frames remain deferred.
[simulator-notice] compatibility-limited line 4, column 1, byte offset 38, span length 7: INCLUDE Macros.inc is accepted as a virtual compatibility include; general MASM macro expansion remains unsupported until a later macro phase.
[simulator-notice] compatibility-no-op line 5, column 1, byte offset 57, span length 5: TITLE is accepted as a listing/documentation directive for MASM compatibility but does not affect VM execution.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key register:

```text
EAX    | 00000007h / u: 7          / s:  7
```

With Compatibility notices set to Off, expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

### Manual test 2 - Uninitialized reads warn/off/strict

Program:

```asm
.DATA?
x DWORD ?
.code
main PROC
    mov eax, x
main ENDP
END main
```

Default expected Simulator Messages:

```text
[simulator-warning] uninitialized-read line 5: Memory read range 00500000h..00500003h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
[info] execution-complete: Execution completed successfully.
```

Expected key register:

```text
EAX    | 00000000h / u: 0          / s:  0
```

With Uninitialized reads set to Off, expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

With Uninitialized reads set to Strict stop, expected Simulator Messages:

```text
[runtime-error] uninitialized-read line 5: Memory read range 00500000h..00500003h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
```

### Manual test 3 - Undefined flag use warn/off/strict

Program:

```asm
.code
main PROC
    stc
    mov al, 1
    shl al, 8
    mov ebx, 0
    adc ebx, 0
main ENDP
END main
```

Default expected Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 5, column 5, byte offset 42, span length 9: SHL count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
[simulator-warning] undefined-flag-use line 7, column 5, byte offset 71, span length 10: ADC reads CF, but CF is architecturally undefined from SHL at line 5. The simulator preserved the flag deterministically; this flag-dependent behavior is not portable.
[info] execution-complete: Execution completed successfully.
```

Expected key register:

```text
EBX    | 00000001h / u: 1          / s:  1
```

With Undefined flag use set to Off, expected Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 5, column 5, byte offset 42, span length 9: SHL count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
[info] execution-complete: Execution completed successfully.
```

With Undefined flag use set to Strict stop, expected Simulator Messages:

```text
[runtime-error] undefined-flag-use line 7, column 5, byte offset 71, span length 10: ADC reads CF, but CF is architecturally undefined from SHL at line 5. Execution stopped before using the undefined flag.
```

Expected key register in strict mode:

```text
EBX    | 00000000h / u: 0          / s:  0
```

### Manual test 4 - Declared object memory validation

Program:

```asm
.data
x DWORD 1
y DWORD 2
.code
main PROC
    mov eax, DWORD PTR [x+1]
main ENDP
END main
```

With Memory range validation set to Region-only, expected Simulator Messages:

```text
[simulator-warning] unaligned-memory-access line 6: Unaligned DWORD memory access at 00500001h.
[info] execution-complete: Execution completed successfully.
```

With Memory range validation set to Declared object bounds: warn, expected Simulator Messages:

```text
[simulator-warning] object-bounds-warning line 6: Memory read range 00500001h..00500004h spans multiple declared data objects (spans-objects).
[simulator-warning] unaligned-memory-access line 6: Unaligned DWORD memory access at 00500001h.
[info] execution-complete: Execution completed successfully.
```

Expected key register in both cases:

```text
EAX    | 02000000h / u: 33554432   / s:  33554432
```

### Regression signs during manual testing

A regression is indicated if:

- compatibility notices still appear when Compatibility notices is Off;
- default compatibility notices do not appear;
- default uninitialized-read warning does not appear;
- uninitialized-read Off still warns;
- uninitialized-read Strict stop still emits `execution-complete`;
- undefined-flag-use Off suppresses producer warnings such as `undefined-shift-flag`;
- undefined-flag-use Strict stop still mutates the consumer result;
- region-only mode emits object-bound diagnostics;
- declared-object warning mode does not emit `object-bounds-warning`;
- diagnostics appear in Program Console instead of Simulator Messages;
- a rebuilt browser still reports a stale Wasm export error.

## 14. Compliance review summary

First compliance review checked:

- scope control;
- completeness against Phase 53E guide requirements;
- C99 core boundary;
- Doxygen and file-level comment expectations;
- naming and configuration clarity;
- stale comments and stale documentation;
- TODO-style note disposition;
- diagnostic structure and rendered message tests;
- source location preservation;
- Program Console and Simulator Messages separation;
- test coverage and aggregate runner integration.

Issue found:

- `web/src/worker.js` treated missing backend diagnostic settings as non-default settings in one fallback path. A direct/internal call that omitted settings could incorrectly report stale Wasm when an older artifact was loaded.

Fix applied:

- `createRunSourceFunction()` now merges missing backend settings with Phase 53E defaults before stale-Wasm detection and Wasm argument dispatch.

Review result:

```text
Verdict: complete
```

Remaining review limitation:

- Browser/Wasm manual testing could not be performed in the container because `emcc` is unavailable.

## 15. Re-review summary

Second compliance review re-read the Phase 53E guide section and relevant spec sections, then inspected changed files and nearby TODO-style notes.

Additional issues found:

- `README.md` and `docs/SUPPORTED_SYNTAX.md` still contained stale wording saying UI controls/settings were deferred for object validation and uninitialized-read diagnostics.
- `web/src/main.js` and `web/src/styles.css` had stale Milestone 17 comments/error wording.
- Phase 53E tests were strengthened to cover all memory-range enum mappings and strict/section/object routing.

Fixes applied:

- Corrected stale docs to state Phase 53E exposes the relevant browser settings.
- Updated stale browser comments/error text to current generic UI wording.
- Expanded C and Node tests for all memory-range settings and diagnostic routing.

Re-review result:

```text
Final scope verdict: complete
Final documentation verdict: complete
Final test coverage verdict: complete
Final TODO-style note verdict: complete
```

## 16. User-test follow-up summary

Two UI copy/layout follow-ups were implemented after user testing and design feedback.

### Follow-up 1 - Per-setting explanation layout

User feedback:

- A large block of explanation above and below the dropdowns was harder to read.
- Explanation should be directly below each dropdown.
- A separate general notes area might be useful.

Implemented:

- Removed the large explanatory paragraph above the dropdowns.
- Added a short one-line intro.
- Added compact indented bullet explanations directly under each dropdown.
- Added `aria-describedby` links from dropdowns to help text.
- No settings behavior changed.

Tests rerun:

```text
Structure tests: PASS
Node settings/protocol/formatter tests: PASS
```

### Follow-up 2 - Remove general notes and expand memory-range explanation

User feedback:

- General notes was unnecessary for now.
- The missing essential explanation was what region-only, section-capacity, section-image, and declared-object-bounds mean in effective diagnostic terms.

Implemented:

- Removed the General notes block.
- Expanded Memory range validation bullets to explain each memory range policy.
- Kept behavior unchanged.

Tests rerun:

```text
Structure tests: PASS
Node settings/protocol/formatter tests: PASS
```

## 17. Known limitations

- Emscripten (`emcc`) is unavailable in the execution container, so Wasm artifacts were not rebuilt here.
- Browser testing requires rebuilding Wasm locally before using non-default Phase 53E settings on the website.
- If an old Wasm artifact is loaded, default execution can use the compatibility fallback path, but non-default settings report a stale-Wasm `ui-error`.
- Diagnostic settings are local page-session preferences; share URLs do not yet encode them.
- The UI exposes one memory range validation selector at a time; advanced combined policies remain future work if desired.
- No new runtime validation semantics were added; Phase 53E only exposes already implemented policies.
- The aggregate test runner can take longer than this container's command timeout during some reruns, but the relevant component stages passed and the aggregate suite completed successfully after the initial implementation.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 54 - One-Operand Signed IMUL
```

Expected Phase 54 direction:

- Implement one-operand signed `imul` with implicit accumulator operands.
- Preserve Phase 53E settings behavior unchanged.
- Do not modify diagnostic settings UI unless Phase 54 explicitly requires documentation/status text updates.

## 19. Any changed-files ZIP/package produced

Changed-files packages produced during the milestone:

```text
milestone_53E_changed_files.zip
milestone_53E_review_changed_files.zip
milestone_53E_second_review_changed_files.zip
milestone_53E_ui_text_polish_changed_files.zip
milestone_53E_ui_memory_help_changed_files.zip
milestone_53E_final_gap_changed_files.zip
```

Latest recommended changed-files package:

```text
milestone_53E_final_gap_changed_files.zip
```

Recommended full repository archive name after applying the final changed-files package and rebuilding/checking artifacts as desired:

```text
Latest_repository_state_milestone_53E.zip
```

