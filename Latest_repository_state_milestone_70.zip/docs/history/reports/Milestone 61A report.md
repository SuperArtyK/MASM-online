# Milestone 61A report - Direct JMP Runtime Accounting and Status Hardening

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 61A - Direct JMP Runtime Accounting and Status Hardening
```

Repository/archive milestone after this work:

```text
Phase 61A - Direct JMP Runtime Accounting and Status Hardening
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 61 - Direct JMP Runtime Execution
```

Status interpretation:

The repository/archive milestone is newer than the runtime/source-run MASM behavior phase because Phase 61A did not add MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser controls, browser layout, browser interaction behavior, diagnostic codes, diagnostic JSON fields, or rendered Simulator Messages categories. It hardened tests, current-status documentation, and static checks for behavior implemented in Phase 61. Do not update runtime/source-run phase metadata, supported-syntax runtime wording, or tests that assert runtime phase values unless a later target phase explicitly owns that change.

Scope implemented:

- Hardened source-run coverage for direct `jmp label` accounting and status fields.
- Hardened rendered Simulator Messages coverage for direct-JMP success and direct-JMP instruction-limit failure.
- Hardened documentation and static checks so Phase 61A current-status surfaces distinguish repository/archive milestone from runtime/source-run MASM behavior phase.
- Preserved Phase 61 direct-JMP execution behavior without introducing new branch syntax or runtime branch families.
- Preserved `branch-runtime-deferred` as a future-owned status path while adding regression coverage that valid direct `jmp label` no longer emits it.
- Preserved Program Console and Simulator Messages separation.
- Preserved the Phase 59 instruction-accounting fields:
  - `instructionLimit`;
  - `executedInstructionCount`;
  - `attemptedNextInstructionIndex`;
  - `currentInstructionIndex`.
- Preserved all future-work boundaries for conditional jumps, `loop`, indirect jumps, register/memory/immediate jump targets, branch-distance/type overrides, stack/procedure behavior, debugger/editor behavior, active-time watchdog behavior, reserved-word declaration diagnostics, and `OPTION NOKEYWORD`.

This milestone was primarily test, documentation, and static-check hardening. No C runtime implementation files were changed.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_61A.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 61 report.md`
- `Project Audit and Milestones.txt`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_61.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, status-surface hygiene, and broad product constraints.
- The implementation guide owns Phase 61A numbering, exact phase scope, tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

## 3. Exact requirements implemented

### 3.1 Repository/runtime status split

Implemented the Phase 61A status split:

```text
Repository/archive milestone:
Phase 61A - Direct JMP Runtime Accounting and Status Hardening

Runtime/source-run MASM behavior phase:
Phase 61 - Direct JMP Runtime Execution
```

Documentation and static checks now preserve that split. Runtime/source-run JSON continues to report Phase 61 behavior metadata, because Phase 61A does not introduce new runtime-visible MASM/source behavior.

### 3.2 Direct JMP accounting coverage

Added or hardened source-run tests proving that committed direct `jmp label` instructions participate correctly in source-run accounting.

Covered behavior includes:

- A committed direct `jmp` counts as one executed VM instruction.
- `executedInstructionCount` includes committed direct-JMP instructions.
- `attemptedNextInstructionIndex` remains `null` on successful completion.
- `attemptedNextInstructionIndex` is set when the instruction-count watchdog blocks the next attempted instruction.
- `currentInstructionIndex` identifies the last fully committed VM instruction.
- A zero-instruction program retains `currentInstructionIndex: null`.

### 3.3 Direct JMP success behavior coverage

Added or hardened source-run coverage proving that valid direct `jmp label` behaves as actual runtime control transfer rather than a deferred branch.

Covered behavior includes:

- Forward direct `jmp label` skips fall-through instructions.
- Instructions skipped by a direct `jmp` do not execute.
- Skipped memory-writing instructions do not mutate memory.
- Skipped memory-writing instructions do not create memory-change rows.
- Direct `jmp` itself does not create memory-change rows.
- Direct `jmp` does not write Program Console output.
- Valid direct `jmp label` does not emit `branch-runtime-deferred`.
- Successful direct-JMP programs emit `execution-complete` only after true normal completion.

### 3.4 Backward direct JMP watchdog coverage

Added source-run and rendered Simulator Messages coverage for deterministic backward direct-JMP loops stopped by the Phase 59 instruction-count watchdog.

Covered behavior includes:

- Backward `jmp` loops execute until the instruction-count limit blocks the next attempted instruction.
- The watchdog reports `instruction-limit-exceeded`, not `branch-runtime-deferred`.
- The blocked instruction does not execute.
- `executedInstructionCount`, `attemptedNextInstructionIndex`, and `currentInstructionIndex` reflect committed-instruction accounting.
- No `execution-complete` message appears after the fatal instruction-limit diagnostic.
- No future active-time watchdog behavior was added.

### 3.5 Rendered Simulator Messages hardening

Added exact rendered Simulator Messages coverage for a backward direct-JMP instruction-limit failure.

The expected diagnostic is stable and user-facing. It identifies the instruction-limit failure and states that the program stopped before executing the blocked instruction.

Existing rendered-message success coverage remains in place for `execution-complete`.

### 3.6 Static documentation/status checks

Added or strengthened static checks so the repository fails verification if documentation collapses Phase 61A repository status into Phase 61 runtime/source-run status.

The static checks now require that current-status documentation explicitly preserve these facts:

- Repository/archive milestone is Phase 61A.
- Runtime/source-run MASM behavior phase remains Phase 61.
- Direct `jmp label` runtime execution is implemented.
- Conditional jumps remain future work.
- `loop` remains future work.
- `call` and `ret` remain future work.
- Indirect jumps remain future work.
- Register-target jumps remain future work.
- Memory-target jumps remain future work.
- Immediate-target jumps remain future work.
- Branch-distance/type overrides remain future work.

### 3.7 Documentation hardening

Updated current project documentation to describe the repository/runtime status split and Phase 61A scope accurately.

Updated files:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`

Documentation now avoids implying that Phase 61A added new MASM runtime behavior. It also avoids implying future branch/procedure/debugger systems are currently supported.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 61A:

- Conditional jumps.
- `cmp`.
- `loop`, `loope`, `loopne`, `jcxz`, or `jecxz`.
- Indirect branch execution.
- Register-target `jmp` execution.
- Memory-target `jmp` execution.
- Immediate-target `jmp` execution.
- Branch-distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Relative branch encoding or real x86 instruction encoding.
- Native x86 execution.
- Stack or procedure execution semantics.
- `call`, `ret`, `leave`, `push`, or `pop`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 routine calls beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Debugger stepping, breakpoints, current-instruction highlighting, editor source navigation, or label-click navigation.
- Browser UI controls for instruction limits.
- Active-time watchdog behavior.
- Reserved-word declaration diagnostics.
- `OPTION NOKEYWORD`.
- General dynamic keyword-table mutation.
- Full MASM macro expansion.

Future work intentionally preserved:

- Phase 61B - Branch Runtime Watchdog Scope Cleanup.
- Phase 61C - Branch Debugger Dependency Cleanup.
- Phase 61D - Source-Run Capacity Documentation and Diagnostic Hardening.
- Phase 61E - Reserved Word Symbol Diagnostics.
- Phase 62 - CMP Register and Immediate Forms.
- Later conditional jump phases.
- Later `loop` phase.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Future execution-control UI/settings phases if the guide requires them.
- Future `OPTION NOKEYWORD` keyword-control compatibility phase or placeholder when the canonical guide includes it.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 61A advances repository/archive milestone status but does not advance runtime/source-run MASM behavior metadata.
- **Reason:** Phase 61A hardens tests, documentation, and static checks for behavior implemented in Phase 61. It does not add new MASM syntax, VM behavior, executor behavior, Wasm API behavior, browser runtime behavior, diagnostic codes, JSON fields, or rendered-message categories.
- **Risk:** Future readers may think the Phase 61 runtime metadata is stale because repository documentation says Phase 61A.
- **How to change later:** Only update runtime/source-run metadata if a later guide phase explicitly introduces new runtime-visible MASM/source behavior or explicitly requires metadata advancement.

### Assumption 2

- **Assumption:** Phase 61A should primarily add tests and documentation/static-check hardening, not runtime executor changes.
- **Reason:** The Phase 61 report already documented direct-JMP execution, accounting, flag preservation, no memory-change behavior, and removal of `branch-runtime-deferred` for valid direct JMP. Phase 61A exists to harden coverage and status consistency.
- **Risk:** If Phase 61 behavior had hidden bugs, tests could expose a need for small runtime fixes.
- **How to change later:** Add focused tests first, then apply the smallest executor/source-run fix if a Phase 61A-required assertion fails.

### Assumption 3

- **Assumption:** The retained `branch-runtime-deferred` status path should not be removed.
- **Reason:** Phase 61 removed that outcome for valid direct `jmp label`, but the status path may still be useful for future accepted-but-deferred branch forms.
- **Risk:** Its continued presence could be mistaken as a valid outcome for direct `jmp label`.
- **How to change later:** Keep regression tests that direct `jmp label` does not emit `branch-runtime-deferred`; if a future phase removes all deferred branch use, remove the status path in that phase.

### Assumption 4

- **Assumption:** Phase 61A should not touch reserved-word declaration behavior.
- **Reason:** Reserved-word declaration diagnostics belong to Phase 61E. `OPTION NOKEYWORD` remains unsupported until a later explicit phase.
- **Risk:** The current parser may still accept reserved-word labels in some declaration positions and reject later use, which remains a known pre-61E limitation.
- **How to change later:** Implement Phase 61E as the dedicated reserved-word declaration diagnostics phase.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can be dependency-skipped in this environment.
- **Reason:** `emcc` is unavailable on PATH in the assistant/container environment, and Phase 61A did not change C/Wasm runtime files.
- **Risk:** Served local artifacts on a user's machine may be stale if they have not rebuilt after earlier C changes.
- **How to change later:** Run `scripts\windows\build_wasm.cmd` in an Emscripten-enabled Windows environment before browser verification when C/Wasm artifacts need rebuilding.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning, implementation, compliance review, re-review, final gap check, and reporting:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61A - Direct JMP Runtime Accounting and Status Hardening
- Note text or summary:
  Phase 61A must harden source-run accounting, status-surface wording, milestone-report wording, and regression coverage for direct JMP after Phase 61. It must not add new branch syntax or implement conditional jumps, loop, calls/returns, indirect jumps, debugger/editor behavior, stack/procedure behavior, or active-time watchdog behavior.
- Classification:
  target-owned
- Reason:
  This is the canonical target milestone scope.
- Action for this milestone:
  Implemented through source-run tests, rendered Simulator Messages coverage, documentation/status updates, and static checks.
```

```text
- Location:
  src/core/vm_exec.h, src/core/vm_exec.c, src/wasm/wasm_api.c
- Note text or summary:
  branch-runtime-deferred status/message path remains present for accepted branch forms whose runtime behavior is deferred.
- Classification:
  future-owned
- Reason:
  Phase 61 removed this outcome for valid direct jmp label, but the status path may remain for future accepted-but-deferred branch forms.
- Action for this milestone:
  Left in place. Added/hardened regression coverage that valid direct jmp label does not emit branch-runtime-deferred.
```

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
- Classification:
  future-owned
- Reason:
  Direct JMP is not a memory-reading instruction and Phase 61A does not add a memory-capable instruction.
- Action for this milestone:
  Left unchanged.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md, docs/MILESTONE_HISTORY.md, README.md, docs/BUILDING_AND_DEVELOPMENT.md, and guide roadmap text
- Note text or summary:
  Conditional jumps, loop, indirect branches, register/memory/immediate jump targets, branch-distance/type overrides, call/ret, stack/procedure execution, debugger/editor behavior, active-time watchdog behavior, reserved-word diagnostics, and OPTION NOKEYWORD remain future work.
- Classification:
  future-owned
- Reason:
  Phase 61A is accounting/status hardening for direct JMP only.
- Action for this milestone:
  Preserved and clarified in current-status documentation and static checks.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 61A direct-JMP accounting/status hardening was implemented.
- Direct-JMP source-run accounting fields were tested.
- Direct-JMP skipped-instruction behavior was tested.
- Backward direct-JMP instruction-limit behavior was tested.
- Valid direct-JMP absence of `branch-runtime-deferred` was covered.
- Rendered Simulator Messages coverage was added for direct-JMP instruction-limit failure.
- Current-status documentation and static checks were updated for the repository/runtime status split.

### Future-owned TODO-style notes intentionally preserved

- `branch-runtime-deferred` status/message path for future accepted-but-deferred branch forms.
- Future memory-reading opcode planned-access TODO in `src/wasm/wasm_api.c`.
- Conditional jumps.
- `cmp`.
- `loop`.
- Indirect jumps.
- Register-target jumps.
- Memory-target jumps.
- Immediate-target jumps.
- Branch-distance/type overrides.
- `call`, `ret`, stack behavior, procedure frames, and procedure invocation.
- Debugger stepping, breakpoints, editor/source navigation, and UI label navigation.
- Active-time watchdog behavior.
- Irvine32 callable routines beyond the virtual `exit` terminator.
- Reserved-word declaration diagnostics.
- `OPTION NOKEYWORD` keyword-control compatibility.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style notes were found.

Stale or incomplete non-TODO wording corrected:

- Current-status documentation now distinguishes repository/archive Phase 61A from runtime/source-run Phase 61.
- Phase 61A future-work boundary text was tightened to explicitly say conditional jumps, loop, call/ret, indirect jumps, register-target jumps, memory-target jumps, immediate-target jumps, and branch-distance/type overrides remain future work.
- Final gap check corrected wording in `docs/SUPPORTED_SYNTAX.md` from a less explicit “remain unsupported” formulation to “remain future work,” matching the Phase 61A guide boundary.

### Unresolved TODO-related risks

- None for Phase 61A.
- Known future risk: until Phase 61E is implemented, reserved-word declaration diagnostics remain incomplete by design.

## 8. Design summary

Phase 61A was implemented as a hardening layer around Phase 61 direct-JMP runtime execution.

Primary design choices:

1. **Do not alter runtime behavior.** Existing Phase 61 executor/source-run behavior already executed direct `jmp label`. Phase 61A added tests and status checks rather than new semantics.

2. **Preserve runtime/source-run metadata at Phase 61.** The project now reports repository/archive milestone Phase 61A while source-run JSON and runtime behavior metadata continue to identify Phase 61 - Direct JMP Runtime Execution.

3. **Test accounting fields explicitly.** Source-run tests now assert `instructionLimit`, `executedInstructionCount`, `attemptedNextInstructionIndex`, and `currentInstructionIndex` for direct-JMP success and instruction-limit failure cases.

4. **Harden the direct-JMP future boundary.** Documentation and static checks now force current-status text to preserve future-work language for branch families that Phase 61A must not implement.

5. **Keep rendered-message coverage exact.** A rendered Simulator Messages test covers the backward direct-JMP instruction-limit failure with exact expected output.

6. **Preserve future-owned status paths.** `branch-runtime-deferred` remains available for future accepted-but-deferred branch forms but is regression-tested as absent for valid direct `jmp label`.

## 9. Files changed

Changed files in the final Phase 61A state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`

No C runtime/core implementation files were changed.

## 10. Tests added

Added or hardened source-run tests:

- `test_phase61a_jmp_skips_memory_write_and_keeps_console_empty`
- `test_phase61a_backward_jmp_limit_blocks_next_fetch_without_mutation`
- Additional zero-instruction accounting assertions.
- Additional Phase 61 runtime/source-run metadata preservation assertions.

Added or hardened rendered Simulator Messages tests:

- Exact rendered output for Phase 61A backward direct-JMP instruction-limit failure.

Added or hardened static checks:

- Repository/archive status must report Phase 61A.
- Runtime/source-run behavior phase must remain Phase 61.
- Supported-syntax/history wording must preserve direct-JMP scope and explicitly classify conditional jumps, loop, call/ret, indirect jumps, register/memory/immediate jump targets, and branch-distance/type overrides as future work.

## 11. Commands used to test

### Pre-implementation repository verification

Aggregate command:

```cmd
python3 scripts/run_tests.py --all
```

Result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Classification:

```text
aggregate completed and passed
```

Dependency skip:

```text
group skipped because dependency was unavailable, such as emcc
```

### Implementation verification

Focused commands run:

```cmd
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --protocol
```

Initial diagnostic-focused run:

```text
--diagnostics: FAIL
```

Reason:

The newly added expected rendered diagnostic used the wrong blocked-instruction ordinal/byte offset for the backward direct-JMP instruction-limit fixture. The implementation behavior was correct; the test expectation was corrected.

Corrected diagnostic-focused rerun:

```text
--diagnostics: PASS
```

Aggregate command run after implementation:

```cmd
python3 scripts/run_tests.py --all
```

Result:

```text
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

### First compliance review verification

Focused commands run:

```cmd
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command run:

```cmd
python3 scripts/run_tests.py --all
```

Result:

```text
--structure: PASS
--native: PASS
--source-run: PASS
--web: PASS
--diagnostics: PASS
--protocol: PASS
--static: PASS
--all: PASS
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke skipped because emcc is unavailable in this environment.
```

### Second compliance review verification

Additional issue found and fixed:

- Current-status/future-work wording did not consistently name immediate-target jumps and branch-distance/type overrides as future work.

Focused commands run:

```cmd
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --protocol
```

Aggregate command run:

```cmd
python3 scripts/run_tests.py --all
```

Result:

```text
--static: PASS
--source-run: PASS
--web: PASS
--diagnostics: PASS
--structure: PASS
--native: PASS
--protocol: PASS
--all: PASS
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

### Final gap-check verification

Additional issue found and fixed:

- `docs/SUPPORTED_SYNTAX.md` used less explicit wording that excluded branch forms “remain unsupported” instead of “remain future work.” The wording and static assertion were tightened.

Focused commands run:

```cmd
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
```

Aggregate command run:

```cmd
python3 scripts/run_tests.py --all
```

Observed results:

```text
--static: PASS
--source-run: PASS
--diagnostics: PASS
--structure: PASS
--native: PASS
--web: PASS
--protocol: PASS
```

First aggregate attempt:

```text
--all timed out in the assistant/container environment after focused groups had passed.
```

Aggregate rerun with a longer timeout:

```text
--all: PASS
All implemented milestone tests passed.
```

Final classification:

```text
aggregate completed and passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke skipped because emcc is unavailable in this environment.
```

### Manual-testing preparation verification

Focused commands verified before preparing manual testing instructions:

```cmd
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
```

Result:

```text
--source-run: PASS
--diagnostics: PASS
--static: PASS
```

## 12. Pass/fail results summary

- Aggregate completed and passed:
  - Pre-implementation verification.
  - Implementation verification after correction.
  - First compliance review.
  - Second compliance review.
  - Final gap check after a longer-timeout rerun.

- Aggregate timed out but focused groups passed:
  - Final gap-check first aggregate attempt timed out in the assistant/container environment, after focused checks passed. It was rerun with a longer timeout and completed successfully.

- Aggregate failed:
  - None.

- Focused group failed:
  - One initial `--diagnostics` run failed during implementation because the newly added expected rendered diagnostic used the wrong expected blocked-instruction ordinal/byte offset. The expected fixture was corrected and `--diagnostics` passed on rerun.

- Focused group timed out and was rerun by subgroup/fixture:
  - None.

- Group skipped because a dependency was unavailable:
  - Browser/Wasm rebuild smoke skipped because `emcc` is unavailable in the assistant/container environment.

## 13. Manual/browser testing guidance and expected outputs

Phase 61A is partially website-testable. The served website can test the direct-JMP runtime behavior hardened by Phase 61A. Exact Phase 61A accounting/status/static coverage is better tested through local test-suite commands and, optionally, the diagnostic JSON producer.

### Browser test A - default direct-JMP program

Paste or use this source:

```asm
.code
main PROC
    mov eax, 1
    jmp done
    mov ebx, 2
done:
    mov ecx, 3
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key final registers:

```text
EAX = 00000001h / 1
EBX = 00000000h / 0
ECX = 00000003h / 3
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `EBX = 00000002h / 2`.
- Any `branch-runtime-deferred` message.
- Missing `execution-complete` on this successful fixture.

### Browser test B - skipped memory write

Paste this source:

```asm
.data
value DWORD 0

.code
main PROC
    jmp done
    mov value, 77
done:
    mov eax, value
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key final register:

```text
EAX = 00000000h / 0
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `EAX = 0000004Dh / 77`.
- A memory-change row for `value`.
- Any `branch-runtime-deferred` message.

### Windows CMD local testing

From the project root, run:

```cmd
python scripts\run_tests.py --source-run
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --static
```

Expected snippets:

```text
[source-run] PASS - source-run integration binary passed independently
Selected test groups passed.
```

```text
[diagnostics] PASS - native diagnostic producer and rendered messages passed
Selected test groups passed.
```

```text
[static] PASS - runner/documentation consistency checks passed
Selected test groups passed.
```

Full suite:

```cmd
python scripts\run_tests.py --all
```

Expected snippets:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
All implemented milestone tests passed.
```

`emcc`/browser-Wasm rebuild status:

- Emscripten rebuild is optional for Phase 61A itself because no C/Wasm files changed.
- Rebuild is required only if served browser artifacts are stale, missing, or intentionally refreshed.
- If rebuilding on Windows with Emscripten configured:

```cmd
scripts\windows\build_wasm.cmd
```

If `emcc` is unavailable, that is an environment/PATH issue, not a Phase 61A project failure.

Optional raw JSON tests can be run with `build\tests\diagnostic_json_producer.exe program.asm` after `python scripts\run_tests.py --diagnostics` builds the diagnostic producer.

## 14. Compliance review summary

First compliance review:

- No issues requiring fixes were found.
- Scope remained limited to Phase 61A.
- No future milestone behavior was implemented.
- Runtime/source-run MASM behavior metadata correctly remained Phase 61.
- Core remained C99-only.
- No core source files were changed.
- Rendered Simulator Messages coverage was present for direct-JMP success and instruction-limit failure.
- All focused groups and aggregate tests passed.
- No new changed-files package was generated during first compliance because no files changed in that pass.

## 15. Re-review summary

Second compliance review:

- Found a documentation/static-check gap: current-status/future-work wording did not consistently name immediate-target jumps and branch-distance/type overrides as future work.
- Fixed current-status wording in:
  - `README.md`;
  - `docs/BUILDING_AND_DEVELOPMENT.md`;
  - `docs/MILESTONE_HISTORY.md`;
  - `docs/SUPPORTED_SYNTAX.md`.
- Strengthened static checks in `scripts/run_tests.py`.
- Re-ran focused tests and aggregate tests; all passed.
- Produced changed-files package:
  - `milestone_61A_second_compliance_check.zip`.

Final gap check:

- Found one final wording/static-check gap: `docs/SUPPORTED_SYNTAX.md` used “remain unsupported” instead of explicitly saying the excluded forms “remain future work.”
- Fixed `docs/SUPPORTED_SYNTAX.md` and strengthened the related static assertion in `scripts/run_tests.py`.
- Re-ran focused tests and aggregate tests; aggregate completed and passed after a longer-timeout rerun.
- Produced changed-files package:
  - `milestone_61A_final_compliance_check.zip`.

## 16. User-test follow-up summary

No Prompt 8 user-test discrepancy report was provided.

The user indicated that Prompt 8 would be conditional and would only be provided if manual/browser/local tests produced discrepancies. Since the workflow continued directly to final gap check and report generation, there were no user-reported discrepancies to triage for Phase 61A.

## 17. Known limitations

- Browser/Wasm rebuild smoke was skipped in the assistant/container environment because `emcc` is unavailable.
- Phase 61A did not modify C/Wasm runtime files, so this dependency skip does not block Phase 61A acceptance.
- Runtime/source-run MASM behavior phase remains Phase 61 by design.
- Phase 61A is only partially visible on the served website because it is mostly test/documentation/static-check hardening.
- Exact accounting fields such as `executedInstructionCount`, `attemptedNextInstructionIndex`, and `currentInstructionIndex` are best verified through source-run JSON/local tests rather than through the normal browser UI.
- Reserved-word declaration diagnostics remain future work for Phase 61E.
- `OPTION NOKEYWORD` remains unsupported until a later explicit phase.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 61B - Branch Runtime Watchdog Scope Cleanup
```

## 19. Changed-files ZIP/package produced

Packages produced during this milestone sequence:

- `phase61a_changed_files.zip`
  - Initial changed-files package after implementation.
- `milestone_61A_second_compliance_check.zip`
  - Changed-files package after second compliance review wording/static-check fixes.
- `milestone_61A_final_compliance_check.zip`
  - Changed-files package after final gap-check wording/static-check fixes.

No first-compliance changed-files package was produced because no files were changed during the first compliance pass.

Latest repository/archive recommendation:

```text
Latest_repository_state_milestone_61A.zip
```
