# Milestone 66 report - Unsigned Relational Conditional Jumps

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 66 - Unsigned Relational Conditional Jumps
```

Repository/archive milestone after this work:

```text
Phase 66 - Unsigned Relational Conditional Jumps
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 66 - Unsigned Relational Conditional Jumps
```

Status interpretation:

Phase 66 adds accepted MASM syntax, parser lowering, VM execution behavior, source-run diagnostics, runtime/source-run metadata, web/protocol status text, supported-syntax updates, and browser default-source updates for unsigned relational conditional jumps. Repository/archive status and runtime/source-run MASM behavior status therefore match after this milestone.

Scope implemented:

- Direct-label unsigned relational conditional jumps are parsed, lowered, and executed:
  - `ja label` and `jnbe label`
  - `jae label` and `jnb label`
  - `jb label` and `jnae label`
  - `jbe label` and `jna label`
- Accepted targets match the existing direct branch target model used by direct `jmp`, equality conditional jumps, and signed relational conditional jumps: executable code labels and procedure-entry labels only.
- Unsigned relational jumps evaluate the correct modeled flags for each mnemonic:
  - `JA` / `JNBE`: branch when `CF == 0 && ZF == 0`.
  - `JAE` / `JNB`: branch when `CF == 0`.
  - `JB` / `JNAE`: branch when `CF == 1`.
  - `JBE` / `JNA`: branch when `CF == 1 || ZF == 1`.
- No unsigned relational jump consumes `SF` or `OF`.
- `JAE`, `JNB`, `JB`, and `JNAE` do not consume `ZF`.
- The existing Phase 50B undefined-flag-use policy is applied before the branch decision.
- Warning mode emits `undefined-flag-use` diagnostics and continues with the deterministic preserved flag value.
- Off mode suppresses only the consumer `undefined-flag-use` diagnostic and continues with deterministic preserved values.
- Strict/error mode emits the diagnostic and stops before the branch decision, with no partial mutation and no `execution-complete` message.
- Taken and not-taken unsigned relational jumps count as one executed VM instruction.
- Unsigned relational jumps preserve registers, memory, modeled flag bits, flag-validity metadata, Program Console output, and memory-change rows.
- Unsigned relational jumps produce no memory-change rows of their own.
- Valid unsigned relational jumps no longer use or emit the deferred runtime branch diagnostic path.
- `web/index.html` was updated to identify Phase 66 and use a default source program demonstrating unsigned `ja` branching.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_66.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, audit, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 65 report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_65.zip
```

Changed-files packages produced during implementation and review:

```text
milestone_66_implementation.zip
milestone_66_first_compliance_check.zip
milestone_66_second_compliance_check.zip
milestone_66_final_compliance_check.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, UI stream separation, C99 core policy, diagnostic policy, memory-safety policy, reserved-word policy, and status-surface hygiene.
- The incremental implementation guide owns Phase 66 numbering, scope, tasks, required tests, acceptance criteria, branch-status reporting obligations, and milestone-report obligations.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or guide.
- TODO-style notes are implementation-risk evidence only and do not override the target milestone, canonical guide, or canonical specification.

## 3. Exact requirements implemented

### 3.1 Accepted unsigned relational conditional jump syntax

The parser now accepts the Phase 66 direct-label unsigned relational jump mnemonics:

```asm
ja label
jnbe label
jae label
jnb label
jb label
jnae label
jbe label
jna label
```

Mnemonic matching follows the existing case-insensitive instruction keyword policy. The new mnemonics are also reserved words and cannot be used as user-defined symbols.

### 3.2 Direct branch target validation

The implementation reuses the existing direct branch target classification model. Accepted Phase 66 targets are executable code labels and procedure-entry labels. Rejected targets include:

- unknown labels;
- data symbols;
- Irvine32 virtual routine/terminator names such as `exit` when used as a branch target;
- register targets;
- memory targets;
- immediate or numeric targets;
- branch distance/type override target forms that remain future work.

Target diagnostics preserve source line, column, byte offset, and span length. Rendered Simulator Messages tests cover representative UI-visible errors.

### 3.3 Unsigned branch condition behavior

The implemented branch conditions are:

```text
JA / JNBE:  branch if CF == 0 and ZF == 0
JAE / JNB:  branch if CF == 0
JB / JNAE:  branch if CF == 1
JBE / JNA:  branch if CF == 1 or ZF == 1
```

Functional source-run tests cover taken and not-taken paths, alias equivalence, equality behavior, unsigned below/above behavior, and signed-vs-unsigned raw-value behavior.

### 3.4 Modeled flag consumption and undefined-flag-use policy

The implementation routes flag consumption through the existing shared undefined-flag-use policy path before evaluating the branch decision.

Consumed-flag sets are exact:

- `JA` / `JNBE`: `CF`, `ZF`
- `JBE` / `JNA`: `CF`, `ZF`
- `JAE` / `JNB`: `CF`
- `JB` / `JNAE`: `CF`

Explicit test coverage verifies that:

- unsigned relational jumps do not consume `SF`;
- unsigned relational jumps do not consume `OF`;
- `JAE`, `JNB`, `JB`, and `JNAE` do not consume `ZF`;
- default warning mode emits a warning and continues;
- off mode suppresses only the consumer warning;
- strict/error mode stops before the branch decision;
- strict/error mode preserves registers, flags, flag-validity metadata, memory, Program Console output, and memory-change rows;
- strict/error mode does not emit `execution-complete`.

### 3.5 Instruction-count watchdog behavior

Taken and not-taken unsigned relational jumps count as executed VM instructions. Backward taken unsigned relational jump loops are covered by the existing instruction-count watchdog behavior and can produce the existing `instruction-limit-exceeded` runtime diagnostic.

No active-time or wall-clock watchdog behavior was added.

### 3.6 Runtime/source-run metadata and status surfaces

Runtime/source-run MASM behavior metadata advances to Phase 66 because this phase adds accepted MASM syntax and executable runtime behavior.

Updated current-status surfaces include:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `web/index.html`
- `web/src/protocol.js`
- source-run/status JSON/protocol-facing constants and tests

### 3.7 Browser/default source update

`web/index.html` now identifies Milestone 66 and its default editor source demonstrates an unsigned comparison and `ja` branch.

The default program is a smoke demonstration, not exhaustive coverage. The full focused test suite covers all primary and alias unsigned jump groups, diagnostics, policy behavior, and edge cases.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 66:

- `loop` or loop-family instructions.
- Indirect branch targets.
- Register-target branches.
- Memory-target branches.
- Immediate or numeric-address branch targets.
- Branch distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Anonymous labels.
- `call`, `ret`, `leave`, stack execution, stack frames, procedure invocation, arguments, locals, `USES`, `PROTO`, or `INVOKE` behavior.
- Irvine32 callable routines beyond already-existing virtual behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Macro expansion.
- Debugger/editor branch behavior, including breakpoints, current-instruction highlighting, source navigation, CodeMirror gutter behavior, or branch-target highlighting.
- Active-time or wall-clock watchdog behavior.
- New memory operand behavior.
- New memory-validation policy behavior.
- New Program Console behavior.
- New browser UI controls.
- `OPTION NOKEYWORD` keyword-control behavior.

Future work intentionally preserved:

- Phase 67 - Arithmetic, Branch, and Watchdog Integration Harness.
- Later `loop` runtime behavior.
- Later indirect/register/memory/immediate branch target phases.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future Irvine32 routine expansion.
- Future `OPTION NOKEYWORD` keyword-control compatibility.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 66 should mirror the Phase 65 implementation pattern where practical.
- **Reason:** Phase 66 is the unsigned counterpart to Phase 65 and has nearly identical branch-target, undefined-flag-use, deferred-runtime, reserved-word, status-surface, and no-memory-change obligations.
- **Risk:** Blind copying could accidentally reuse signed flag logic or consume the wrong flags.
- **How to change later:** Refactor signed and unsigned conditional branch handling into a shared descriptor table only after regression tests prove exact mnemonic, condition, consumed-flag, target-diagnostic, and rendered-message behavior remains stable.

### Assumption 2

- **Assumption:** Runtime/source-run MASM behavior metadata should advance from Phase 65 to Phase 66.
- **Reason:** Phase 66 adds new accepted source syntax and executable runtime behavior.
- **Risk:** Missing one status surface could create inconsistent UI, docs, protocol, or source-run output.
- **How to change later:** Use the status-surface hygiene checklist and update only runtime/source-run surfaces that actually describe implemented MASM behavior. Maintenance-only phases should preserve the latest runtime/source-run behavior phase until a later runtime behavior phase advances it.

### Assumption 3

- **Assumption:** Existing direct branch target validation should be extended rather than replaced.
- **Reason:** Phase 66 requires unsigned conditional jumps to accept the same executable label/procedure-entry targets as direct `jmp`, equality conditional jumps, and signed relational conditional jumps, while rejecting the same future target categories.
- **Risk:** A broad rewrite could accidentally alter Phase 61 direct `jmp`, Phase 64 equality conditional jump, or Phase 65 signed relational jump diagnostics.
- **How to change later:** Refactor branch target validation only with regression tests proving existing diagnostic wording, source spans, target categories, and runtime behavior remain stable.

### Assumption 4

- **Assumption:** Phase 66 should not add planned-read or planned-write memory access coverage.
- **Reason:** Unsigned relational jumps read modeled flags and instruction metadata only. They do not read or write simulated memory.
- **Risk:** Touching planned-access tables unnecessarily could regress Phase 64A memory-read validation behavior or unrelated memory diagnostics.
- **How to change later:** Future memory-capable branch, stack, call, procedure, debugger, or Irvine32 features must complete the planned-read/planned-write audit required by the guide.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in the assistant/container environment.
- **Risk:** A locally served browser could show stale Phase 65 behavior if Wasm artifacts are not rebuilt after applying Phase 66 C source changes.
- **How to change later:** On Windows, activate Emscripten with the local `emsdk_env.bat`, run `scripts\windows\build_wasm.cmd`, then serve the site with `scripts\windows\serve_web.cmd`.

## 6. Relevant TODO-style notes reviewed

```text
- Location:
  README.md, docs/BUILDING_AND_DEVELOPMENT.md, docs/SUPPORTED_SYNTAX.md
- Note text or summary:
  Unsigned relational jumps were listed as future/deferred work after Phase 65.
- Classification:
  target-owned
- Reason:
  Phase 66 directly implements unsigned relational conditional jumps.
- Action for this milestone:
  Resolved. Current-status and supported-syntax wording now describe unsigned relational direct-label jumps as implemented and preserve future-work wording for loop, indirect branches, stack/procedure behavior, debugger/editor behavior, and active-time watchdog behavior.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 66 section
- Note text or summary:
  Phase 66 implements only direct-label unsigned relational conditional jumps and requires exact consumed-flag behavior, undefined-flag-use policy integration, no-partial-mutation behavior, instruction-count watchdog coverage, target diagnostics, branch-status reporting, reserved-word behavior, deferred-runtime regression coverage, and no-memory-access disposition.
- Classification:
  target-owned
- Reason:
  This is the canonical target milestone scope and acceptance contract.
- Action for this milestone:
  Resolved by implementation, documentation/status updates, and tests. The implementation does not broaden beyond Phase 66.
```

```text
- Location:
  src/core/vm_exec.h
- Note text or summary:
  File-level or API comments identified unsigned relational branches as later/future work.
- Classification:
  target-owned
- Reason:
  This statement was true in the Phase 65 baseline but became stale once Phase 66 implemented unsigned relational branches.
- Action for this milestone:
  Resolved. The wording was updated during implementation/compliance review.
```

```text
- Location:
  src/core/vm_exec.h, src/core/vm_exec.c, src/wasm/wasm_api.c
- Note text or summary:
  `VM_EXEC_STATUS_BRANCH_RUNTIME_DEFERRED` and `branch-runtime-deferred` describe accepted branch forms whose runtime behavior remains deferred.
- Classification:
  target-owned for Phase 66 branch forms; future-owned for genuinely deferred branch forms.
- Reason:
  Valid Phase 66 unsigned relational jumps must execute and must not use the deferred-runtime path.
- Action for this milestone:
  Resolved for Phase 66. Valid unsigned relational branches avoid `branch-runtime-deferred`. The deferred path remains available only for future-owned metadata-only/deferred branch behavior.
```

```text
- Location:
  tests/core/test_wasm_source_run.c and tests/web/test_diagnostic_rendering.mjs
- Note text or summary:
  Existing `ja main_loop` fixtures expected unsigned conditional jump unsupported behavior.
- Classification:
  target-owned
- Reason:
  The expectation was correct for the Phase 65 baseline but invalid after Phase 66.
- Action for this milestone:
  Resolved. Unsupported-`ja` expectations were replaced/refactored, and new Phase 66 execution and diagnostic coverage was added.
```

```text
- Location:
  src/parser/parser.c and related branch target handling
- Note text or summary:
  Branch distance/type overrides, memory targets, register targets, and immediate targets are deferred to later branch phases.
- Classification:
  future-owned
- Reason:
  Phase 66 accepts only direct executable label/procedure-entry targets.
- Action for this milestone:
  Preserved. The implementation extends direct-label validation to unsigned relational jumps without enabling deferred target forms.
```

```text
- Location:
  README.md, docs/SUPPORTED_SYNTAX.md, docs/BUILDING_AND_DEVELOPMENT.md, docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md
- Note text or summary:
  Loop-family instructions, indirect branches, stack/procedure transfer, active-time watchdog behavior, debugger/editor branch behavior, and OPTION NOKEYWORD remain future-owned.
- Classification:
  future-owned
- Reason:
  These features are explicitly outside Phase 66.
- Action for this milestone:
  Preserved. Documentation and tests keep these deferrals intact.
```

```text
- Location:
  src/wasm/wasm_api.c planned-read/planned-write future instruction reminder
- Note text or summary:
  Future memory-reading opcodes must be added to planned-read collection when implemented.
- Classification:
  irrelevant-to-target
- Reason:
  Phase 66 has no simulated memory reads or writes.
- Action for this milestone:
  Preserved. Phase 66 intentionally does not update planned-read/planned-write collection.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Unsigned relational jumps are no longer documented as future work in current status/syntax surfaces after Phase 66 implementation.
- Phase 66 implementation requirements from the guide are implemented and tested.
- Valid unsigned relational branches do not emit `branch-runtime-deferred`.
- Phase 65-era unsupported-`ja` fixtures were updated or replaced.
- `src/core/vm_exec.h` unsigned-branch future wording was updated.
- Reserved-word coverage now includes unsigned relational mnemonics as data symbols, numeric equates, code labels, and procedure names where applicable.

### Future-owned TODO-style notes intentionally preserved

- `loop` and loop-family instructions remain deferred.
- Indirect/register/memory/immediate branch targets remain deferred.
- Branch distance/type overrides remain deferred.
- Stack/procedure/call/return behavior remains deferred.
- Debugger/editor branch behavior remains deferred.
- Active-time watchdog behavior remains deferred.
- `OPTION NOKEYWORD` remains unsupported until a future explicit keyword-control phase.
- Future memory-reading opcode planned-access reminders remain preserved.

### Stale or contradicted TODO-style notes corrected

- Stale README Phase 65 current-status wording and unsigned-jump future wording were corrected during the final gap check.
- Stale test/header comments discovered during compliance review were corrected.
- A historical Phase 57T milestone-history sentence was clarified so it cannot be mistaken for current Phase 66 behavior.

### Unresolved TODO-related risks

- None identified for Phase 66.

### New TODO-style notes added

- None.

## 8. Design summary

Phase 66 was implemented as a focused branch-runtime feature.

Primary design choices:

1. **Reuse existing branch infrastructure.** Unsigned relational jumps use the same direct-label target classification and branch fixup behavior as direct `jmp`, equality conditional jumps, and signed relational conditional jumps.

2. **Add distinct unsigned relational IR/runtime opcodes.** The IR and executor now distinguish `JA`, `JAE`, `JB`, and `JBE` alias groups and evaluate each group from modeled `CF`/`ZF` state.

3. **Use exact flag-consumption sets.** The implementation calls the shared undefined-flag-use helper with only the flags each mnemonic actually consumes.

4. **Preserve no-mutation branch behavior.** Unsigned relational jumps affect only control flow and instruction count. They do not change registers, memory, modeled flags, Program Console output, or memory-change rows.

5. **Keep future branch forms rejected.** Register, memory, immediate, numeric, indirect, and distance/type override targets remain rejected or deferred according to existing branch-target diagnostics.

6. **Advance runtime metadata intentionally.** Because Phase 66 adds accepted syntax and executable behavior, source-run/runtime status surfaces advance to Phase 66.

7. **Avoid planned-access changes.** Unsigned conditional jumps do not read or write simulated memory, so memory planned-read/planned-write collection was not changed.

8. **Update reserved-word behavior.** The new unsigned jump mnemonics are treated as reserved words and cannot be user-defined symbols.

## 9. Files changed

Changed project files in the final Phase 66 state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_ir.c`
- `src/core/vm_ir.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

Generated/native build artifacts may have been created or updated by local test runs under build directories. They are not treated as source changes for milestone design purposes.

## 10. Tests added

### 10.1 Native parser tests

Added or updated tests covering:

- parsing/lowering for each Phase 66 primary and alias mnemonic;
- case-insensitive mnemonic recognition;
- invalid target diagnostics for unsupported direct-branch target forms;
- reserved-word rejection for unsigned jump mnemonics used as data symbols, numeric equates, code labels, and procedure names;
- `OPTION CASEMAP:NONE` not making new mnemonics available as user symbols.

### 10.2 Native executor and helper tests

Added or updated tests covering:

- unsigned relational jump runtime behavior;
- taken and not-taken branch paths;
- alias equivalence for `JA`/`JNBE`, `JAE`/`JNB`, `JB`/`JNAE`, and `JBE`/`JNA`;
- exact consumed-flag sets;
- no `SF` or `OF` consumption by unsigned relational jumps;
- no `ZF` consumption by `JAE`, `JNB`, `JB`, and `JNAE`;
- preservation of registers, memory, modeled flag values, and flag-validity metadata where applicable.

### 10.3 Source-run tests

Added or updated source-run fixtures covering:

- `ja` taken and not taken;
- `jae` taken for above and equality, and not taken for below;
- `jb` taken and not taken;
- `jbe` taken for below and equality, and not taken for above;
- equality not taken by `ja` or `jb`;
- alias behavior for `jnbe`, `jnb`, `jnae`, and `jna`;
- signed-vs-unsigned raw-value behavior, such as `FFFFFFFFh` compared with `1`;
- valid Phase 66 branches not emitting `branch-runtime-deferred`;
- invalid targets;
- instruction-count watchdog behavior for unsigned conditional jump loops;
- undefined-flag-use warning mode;
- undefined-flag-use off mode;
- undefined-flag-use strict/error mode with no partial mutation and no `execution-complete`;
- no memory-change rows for unsigned conditional jumps.

### 10.4 Rendered Simulator Messages and web/protocol tests

Added or updated tests covering:

- exact rendered Simulator Messages for representative invalid unsigned branch target diagnostics;
- exact rendered `undefined-flag-use` warning/error behavior;
- absence of `execution-complete` after fatal strict/error undefined-flag-use;
- web/protocol status metadata advancement to Phase 66;
- diagnostic rendering tests corrected for stale test names.

### 10.5 Static/status tests

Updated static and status tests for:

- Phase 66 repository/archive status;
- Phase 66 runtime/source-run MASM behavior phase;
- supported-syntax status text;
- README current-scope/current-status text;
- browser default source and milestone banner text;
- runner/test inventory references.

## 11. Commands used to test

### Pre-implementation verification

Aggregate command attempted first:

```bash
python3 scripts/run_tests.py --all
```

Result during repository verification:

```text
Timed out in the assistant/container environment before producing log output.
```

Focused commands run after aggregate timeout:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
```

### Implementation verification

Focused commands run after implementation:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
```

Aggregate command run after implementation:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
All implemented milestone tests passed.
Browser/Wasm rebuild smoke dependency skipped because emcc is unavailable.
```

### First compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
Timed out in the assistant/container environment.
```

### Second compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --structure
```

Result:

```text
All focused groups passed.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
Timed out in the assistant/container environment.
```

### Final gap-check verification

Documentation/status-only fix was applied to `README.md`. Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --static
```

Result:

```text
Both focused groups passed.
```

The native/source-run/web/protocol/diagnostic groups were not rerun after the final README-only fix because prior compliance runs had already passed them and the final change was documentation/status-only. Static/structure checks cover that final edit category.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped in the assistant/container environment because:

```text
emcc is unavailable on PATH.
```

This is a dependency skip, not a project test failure. Local browser testing requires an Emscripten environment and a fresh Wasm rebuild after applying the Phase 66 C changes.

## 12. Pass/fail result classification

- Pre-implementation aggregate: aggregate timed out in assistant/container environment; focused groups passed.
- Implementation aggregate: aggregate completed and passed; browser/Wasm rebuild smoke dependency skipped because `emcc` was unavailable.
- First compliance aggregate: aggregate timed out in assistant/container environment; focused groups passed.
- Second compliance aggregate: aggregate timed out in assistant/container environment; focused groups passed.
- Final gap-check: structure/static focused groups passed after a documentation-only fix.
- No focused group failed.
- No focused group timed out and required subgroup/fixture reruns.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Phase 66 is website-testable after applying the changed files and rebuilding Wasm locally with Emscripten.

### Browser setup on Windows

From Windows CMD in the project root:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Expected build output includes:

```text
Built "<project-root>\web\dist\masm32_sim_core.js".
```

Open:

```text
http://localhost:8000/web/
```

The page should identify:

```text
Milestone 66: Unsigned relational conditional jumps now execute for direct code-label targets.
```

### Browser Program 1 - `ja` unsigned-above branch

```asm
.code
main PROC
    mov eax, 0FFFFFFFFh
    cmp eax, 1
    ja above
    mov ebx, 0
    jmp done
above:
    mov ebx, 1
done:
    nop
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected key final registers:

```text
EAX    | FFFFFFFFh / u: 4294967295 / s: -1
EBX    | 00000001h / u: 1          / s:  1
EFLAGS | 00000080h / 128
  CF   | 0
  ZF   | 0
  SF   | 1
  OF   | 0
```

Expected Memory Changes:

```text
No memory changes.
```

Expected Program Console:

```text
<blank>
```

Regression signs:

- `EBX` is `0`.
- `ja` is rejected.
- `branch-runtime-deferred` appears.
- Program Console contains simulator diagnostics.

### Browser Program 2 - `jb` unsigned-below branch

```asm
.code
main PROC
    mov eax, 0
    cmp eax, 1
    jb below_unsigned
    mov ebx, 0
    jmp done
below_unsigned:
    mov ebx, 2
done:
    nop
main ENDP
END main
```

Expected key final registers:

```text
EAX    | 00000000h / u: 0          / s:  0
EBX    | 00000002h / u: 2          / s:  2
EFLAGS | 00000081h / 129
  CF   | 1
  ZF   | 0
  SF   | 1
  OF   | 0
```

Expected Simulator Messages are the same startup notice plus `execution-complete`. Expected Program Console is blank and Memory Changes should show no memory changes.

### Browser Program 3 - equality is not taken by `ja` or `jb`

```asm
.code
main PROC
    mov eax, 5
    cmp eax, 5
    ja above_unsigned
    jb below_unsigned
    mov ebx, 3
    jmp done
above_unsigned:
    mov ebx, 1
    jmp done
below_unsigned:
    mov ebx, 2
done:
    nop
main ENDP
END main
```

Expected key final registers:

```text
EAX    | 00000005h / u: 5          / s:  5
EBX    | 00000003h / u: 3          / s:  3
EFLAGS | 00000040h / 64
  CF   | 0
  ZF   | 1
  SF   | 0
  OF   | 0
```

Regression signs:

- `EBX` is `1` or `2`.
- Equality incorrectly takes `ja` or `jb`.

### Browser Program 4 - alias mnemonics

```asm
.code
main PROC
    mov eax, 0FFFFFFFFh
    cmp eax, 1
    jnbe first
    mov ebx, 90
first:
    mov ebx, 1
    jnb second
    mov ebx, 91
second:
    mov eax, 0
    cmp eax, 1
    jnae third
    mov ebx, 92
third:
    mov ebx, 3
    jna fourth
    mov ebx, 93
fourth:
    mov ebx, 4
    nop
main ENDP
END main
```

Expected key final registers:

```text
EAX    | 00000000h / u: 0          / s:  0
EBX    | 00000004h / u: 4          / s:  4
EFLAGS | 00000081h / 129
  CF   | 1
  ZF   | 0
  SF   | 1
  OF   | 0
```

Expected Simulator Messages are the startup notice plus `execution-complete`. Expected Program Console is blank and Memory Changes should show no memory changes.

### Browser Program 5 - invalid register branch target diagnostic

```asm
.code
main PROC
    mov eax, 0
    ja eax
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-branch-target-form line 4, column 8, byte offset 38, span length 3: JA register targets are not supported. Indirect branch behavior is deferred to a later branch phase.
```

Expected behavior:

- No `execution-complete` message.
- No execution-result register mutation.
- Memory Changes show no memory changes.
- Program Console is blank.

### Windows CMD local test-runner guidance

`program.asm` is not applicable for focused local test-runner checks.

From the project root:

```cmd
set CC=clang
py scripts\run_tests.py --structure --quiet
py scripts\run_tests.py --native --quiet
py scripts\run_tests.py --source-run --quiet
py scripts\run_tests.py --web --quiet
py scripts\run_tests.py --diagnostics --quiet
py scripts\run_tests.py --protocol --quiet
py scripts\run_tests.py --static --quiet
```

Expected output pattern for each command:

```text
[<group>] START
[<group>] PASS

Group        Status    Details
...
Selected test groups passed.
```

Optional full aggregate command:

```cmd
py scripts\run_tests.py --all
```

Expected local success output:

```text
All implemented milestone tests passed.
```

If `emcc` is not installed, a browser/Wasm rebuild smoke skip is acceptable for local non-browser test runs.

## 14. Compliance review summary

First compliance review found and fixed:

- A Doxygen comment in `src/core/vm_exec.c` attached to the wrong helper after insertion of the unsigned-branch helper.
- `src/parser/parser.h` documentation still described parser branch metadata as only Phase 60 direct-JMP metadata.
- `tests/core/test_vm_exec.c` file header still said tests were through Phase 65.
- `tests/core/test_wasm_source_run.c` had a stale Phase 65 function name for current runtime metadata.
- Phase 66 reserved-word parser coverage did not explicitly test unsigned jump mnemonics as numeric equates and procedure names.
- `docs/MILESTONE_HISTORY.md` contained historical Phase 57T wording that could be misread as saying unsigned conditional jumps are still unsupported now.

First compliance fixes applied:

- Corrected Doxygen placement/wording in `src/core/vm_exec.c`.
- Updated `src/parser/parser.h` API documentation.
- Updated file headers/test names for Phase 66.
- Added reserved-word tests for numeric equates and procedure names.
- Clarified historical milestone-history wording.

First compliance verification:

- Focused groups passed: structure, native, source-run, web, diagnostics, protocol, static.
- Aggregate timed out in the assistant/container environment.
- Browser/Wasm rebuild smoke skipped due to unavailable `emcc`.

## 15. Re-review summary

Second compliance review found and fixed:

- Several rendered-message test names incorrectly said `Phase 64 equality loop` instead of `Phase 64 equality conditional jump`.
- Phase 66 source-run coverage was missing explicit `ja` and `jb` not-taken-on-equality checks.
- Phase 66 source-run coverage was missing explicit `undefined-flag-use=off` behavior for an unsigned relational jump.

Second compliance fixes applied:

- Corrected stale rendered-message test names.
- Added Phase 66 source-run fixture proving `ja` and `jb` are not taken for equal values.
- Added Phase 66 source-run fixture proving `undefined-flag-use=off` suppresses only the consumer diagnostic, preserves producer diagnostics, continues execution, and uses deterministic preserved flag values.

Second compliance verification:

- Focused groups passed: source-run, native, web, diagnostics, protocol, static, structure.
- Aggregate timed out in the assistant/container environment.
- Browser/Wasm rebuild smoke skipped due to unavailable `emcc`.

Final gap check found and fixed:

- `README.md` still contained stale Phase 65 current-status text and still listed unsigned relational jumps as future work.

Final gap-check fix:

- Updated README current-status/current-scope wording to Phase 66 and preserved only future-owned exclusions.

Final gap-check verification:

- `python3 scripts/run_tests.py --structure`: PASS
- `python3 scripts/run_tests.py --static`: PASS

## 16. User-test follow-up summary

Prompt 8 was conditional and was not provided. No user-run manual/browser/local discrepancies were reported before this milestone report.

## 17. Known limitations

- Browser/Wasm rebuild smoke was skipped in the assistant/container environment because `emcc` is unavailable.
- Manual browser testing was not performed in the assistant/container environment.
- A local browser test requires applying the changed files, activating Emscripten, rebuilding Wasm, and serving the site.
- Future-owned behavior remains unimplemented: `loop`, indirect/register/memory/immediate branch targets, branch distance/type overrides, stack/procedure/call/return behavior, debugger/editor branch behavior, active-time watchdog behavior, and `OPTION NOKEYWORD`.
- Phase 66 does not add new Program Console behavior.
- Phase 66 does not change memory operand behavior or memory validation policies.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 67 - Arithmetic, Branch, and Watchdog Integration Harness
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced:

```text
milestone_66_implementation.zip
milestone_66_first_compliance_check.zip
milestone_66_second_compliance_check.zip
milestone_66_final_compliance_check.zip
```

The recommended latest repository archive after acceptance is:

```text
Latest_repository_state_milestone_66.zip
```

No full latest repository archive was produced in this assistant step unless the user or local maintainer creates it from the accepted repository state.
