# Milestone 42 detailed report — Irvine32 `exit` virtual terminator

## 1. Scope implemented

Milestone 42 implemented the first executable Irvine32-related behavior: a narrow virtual `exit` terminator.

The implementation stayed within the milestone boundary:

Implemented:

* `exit` is recognized only when `INCLUDE Irvine32.inc` is active.
* `exit` is accepted as a **zero-operand** virtual terminator.
* `exit` terminates execution successfully.
* Instructions after `exit` are not executed.
* `exit` preserves registers, flags, memory, and Program Console output.
* `exit` without `INCLUDE Irvine32.inc` reports a structured `unknown-instruction` diagnostic.
* `exit` with operands reports a structured `invalid-instruction-operands` diagnostic.
* Phase/browser metadata advanced to Milestone 42.
* Browser default sample updated to demonstrate the acceptance path.
* Documentation and tests updated.

Not implemented:

* No `call`.
* No `ret`.
* No executable `call ExitProcess`.
* No Windows API execution.
* No stack behavior.
* No Irvine32 routine bodies besides the special `exit` terminator.
* No Program Console output/input routines.
* No linker/include loading behavior.
* No future Milestone 43 instruction behavior.

## 2. Assumptions used

### Assumption 1

* **Assumption:** `exit` should be represented as a dedicated IR opcode.
* **Reason:** It keeps termination semantics in the normal parser → IR → executor pipeline instead of doing parser-only truncation.
* **Risk:** One virtual-Irvine32-specific opcode exists before the broader Irvine32 runtime dispatcher is implemented.
* **How to change later:** Future CALL/Irvine32 phases can route `exit` through a shared virtual-intrinsic dispatch path while preserving this opcode or mapping it internally.

### Assumption 2

* **Assumption:** `exit` matching should be case-insensitive.
* **Reason:** The project already treats instruction-like names, directives, registers, and Irvine32 routine names case-insensitively.
* **Risk:** Future user-symbol `CASEMAP` logic must not accidentally affect instruction/routine keyword recognition.
* **How to change later:** Keep instruction and virtual-routine keyword matching separate from user-symbol lookup policy.

### Assumption 3

* **Assumption:** `call ExitProcess` should remain unsupported CALL behavior.
* **Reason:** CALL target parsing/classification is explicitly future work, and Milestone 42 excludes Windows API behavior.
* **Risk:** The current error is still CALL-level rather than target-aware.
* **How to change later:** Future CALL/RET milestones can classify CALL targets using the virtual Irvine32 registry and distinguish Irvine32, Windows/API, unknown, and user procedures.

### Assumption 4

* **Assumption:** `exit` should not emit Program Console output or a special user-facing success message beyond normal execution completion.
* **Reason:** Milestone 42 defines termination behavior, not console/runtime messaging.
* **Risk:** Users may expect an explicit “program exited” console line.
* **How to change later:** Add debugger/runtime status display in a future UI milestone without changing execution semantics.

## 3. Implementation summary

### IR changes

A new opcode was added:

```text
VM_IR_OPCODE_EXIT
```

The opcode-name helper was updated so diagnostics, tests, and future debugging output can identify it as:

```text
exit
```

### Parser changes

The parser now recognizes `exit` as a valid instruction-like virtual terminator only when `INCLUDE Irvine32.inc` has been parsed.

Accepted:

```asm
INCLUDE Irvine32.inc

.code
main PROC
    exit
main ENDP
END main
```

Rejected without the virtual Irvine32 include:

```asm
.code
main PROC
    exit
main ENDP
END main
```

Expected diagnostic code:

```text
unknown-instruction
```

Expected message:

```text
Unknown instruction or virtual Irvine32 terminator. Add INCLUDE Irvine32.inc to use exit.
```

Rejected with operands:

```asm
INCLUDE Irvine32.inc

.code
main PROC
    exit 0
main ENDP
END main
```

Expected diagnostic code:

```text
invalid-instruction-operands
```

### Executor changes

The executor handles `VM_IR_OPCODE_EXIT` as a successful termination instruction.

Behavior:

* Sets execution state to completed/halted successfully.
* Does not execute later IR instructions.
* Does not mutate registers.
* Does not mutate flags.
* Does not mutate memory.
* Does not write to Program Console.
* Does not create memory-change rows.
* Does not report a runtime error.

The main acceptance behavior is:

```asm
INCLUDE Irvine32.inc

.code
main PROC
    mov eax, 123
    exit
    mov eax, 999
main ENDP
END main
```

Expected final result:

```text
EAX = 0000007Bh / 123
```

The `mov eax, 999` instruction is intentionally skipped.

## 4. Diagnostics and user-facing behavior

Milestone 42 added or verified these user-visible diagnostic paths:

### Missing Irvine32 include

```asm
.code
main PROC
    exit
main ENDP
END main
```

Expected:

```text
[assembly-error] unknown-instruction ... Unknown instruction or virtual Irvine32 terminator. Add INCLUDE Irvine32.inc to use exit.
```

### Invalid operands

```asm
INCLUDE Irvine32.inc

.code
main PROC
    exit 0
main ENDP
END main
```

Expected:

```text
[assembly-error] invalid-instruction-operands ... exit is a zero-operand virtual Irvine32 terminator.
```

### Macros include does not enable `exit`

```asm
INCLUDE Macros.inc

.code
main PROC
    exit
main ENDP
END main
```

Expected:

```text
unknown-instruction
```

This confirms `INCLUDE Macros.inc` remains a separate compatibility include and does not populate/enable the Irvine32 virtual terminator.

## 5. Files changed

Final Milestone 42 implementation and compliance passes changed:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_exec.h
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/parser/parser.h
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

Final changed-files package:

[Download milestone42_second_review_changed_files.zip](sandbox:/mnt/data/milestone42_second_review_changed_files.zip)

## 6. Tests added and updated

### Unit tests

Added/updated coverage for:

* `VM_IR_OPCODE_EXIT` opcode naming.
* Executor halting on `exit`.
* Executor preserving registers on `exit`.
* Executor preserving flags on `exit`.
* Executor preserving memory on `exit`.
* Executor producing no memory deltas for `exit`.
* Executor rejecting malformed internal `exit` operand shapes.

### Parser tests

Added/updated coverage for:

* `INCLUDE Irvine32.inc` enables `exit`.
* Mixed-case `ExIt` works.
* `exit` without `INCLUDE Irvine32.inc` reports `unknown-instruction`.
* `exit 0` reports `invalid-instruction-operands`.
* `INCLUDE Macros.inc` alone does not enable `exit`.
* Irvine32 registry classifies `exit` as a supported virtual intrinsic.
* Existing unsupported Irvine32 routine behavior remains intact for names such as `WriteString`.

### Source-run integration tests

Added/updated coverage for:

* Acceptance program leaves `EAX = 123`.
* Instruction after `exit` does not execute.
* `exit` does not emit Program Console output.
* No-include `exit` returns structured assembly diagnostics.
* Operand-bearing `exit` returns structured assembly diagnostics.
* `call ExitProcess` remains unsupported CALL behavior.
* Phase metadata is `42`.

### Rendered Simulator Messages tests

Added/updated exact rendered-message checks for:

* Missing `INCLUDE Irvine32.inc`.
* Invalid `exit` operands.

These tests validate the same formatting path used by the browser Simulator Messages panel.

### Static compliance checks

Updated `scripts/run_tests.py` to assert the presence of Milestone 42 artifacts, including:

* `VM_IR_OPCODE_EXIT`
* executor helper coverage
* parser tests
* executor tests
* source-run tests
* rendered diagnostic tests
* required no-include diagnostic wording

## 7. Compliance review work

After the initial implementation, I performed two follow-up compliance passes.

### First compliance pass

Found and fixed:

* Stale documentation wording in `docs/SUPPORTED_SYNTAX.md` that still implied the post-30 infrastructure milestones added no runtime semantics. That was no longer accurate because Milestone 42 intentionally adds the narrow `exit` terminator runtime behavior.
* Missing static structure checks for the new Milestone 42 artifacts.

### Second compliance pass

Found and fixed:

* Stale assertion text in tests that still described expected source-run responses as “Milestone 30” or “phase 30,” even though the actual asserted JSON phase was already correctly `42`.

Fixed files:

```text
tests/core/test_data_section.c
tests/core/test_wasm_source_run.c
```

This was a test-maintenance clarity issue, not a runtime behavior bug.

## 8. Test commands and results

Primary test command:

```sh
cd /mnt/data/project41
python3 scripts/run_tests.py
```

Result:

```text
All implemented milestone tests passed.
```

Wasm rebuild check:

```sh
cd /mnt/data/project41
bash scripts/build_wasm.sh
```

Result in this container:

```text
emcc: command not found
```

That is an environment limitation here. The source and native/Node tests pass, but this container cannot rebuild `web/dist` because Emscripten is not installed.

The code uses Doxygen-style special documentation comments; Doxygen’s documentation describes special marked comment blocks as the mechanism it uses to extract structured documentation. ([Doxygen][1])

## 9. Manual browser verification programs

Milestone 42 is user-visible after rebuilding Wasm.

### Success path

```asm
INCLUDE Irvine32.inc

.code
main PROC
    mov eax, 123
    exit
    mov eax, 999
main ENDP
END main
```

Expected:

```text
Execution succeeds.
EAX = 0000007Bh / 123.
The instruction after exit does not execute.
Program Console remains empty.
```

### Missing include

```asm
.code
main PROC
    exit
main ENDP
END main
```

Expected:

```text
Execution does not run.
Diagnostic code: unknown-instruction.
Message asks the user to add INCLUDE Irvine32.inc to use exit.
```

### Invalid operands

```asm
INCLUDE Irvine32.inc

.code
main PROC
    exit 0
main ENDP
END main
```

Expected:

```text
Execution does not run.
Diagnostic code: invalid-instruction-operands.
Message explains that exit is zero-operand.
```

### Macros include does not enable exit

```asm
INCLUDE Macros.inc

.code
main PROC
    exit
main ENDP
END main
```

Expected:

```text
Execution does not run.
Diagnostic code: unknown-instruction.
```

## 10. Known limitations

* The prebuilt Wasm artifact must be rebuilt locally for the served website to show the C/Wasm behavior.
* This environment could not rebuild Wasm because `emcc` is unavailable.
* `exit` is not a general Irvine32 runtime dispatcher.
* `exit` is not implemented through CALL.
* `call ExitProcess` is not supported.
* No stack unwinding or process-status behavior exists.
* No Program Console output/input routines were added.
* No other Irvine32 routines were made executable.

## 11. Final status

Milestone 42 is complete.

It implements the requested milestone only, includes tests for success/error/edge/regression paths, updates documentation and static checks, and passes the aggregate test suite. The next recommended milestone is Milestone 43.

[1]: https://www.doxygen.nl/manual/docblocks.html?utm_source=chatgpt.com "Documenting the code - Doxygen"
