# Milestone 57D report - Existing Diagnostic Policy Migration

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57D - Existing Diagnostic Policy Migration
```

Repository/archive milestone:

```text
Phase 57D - Existing Diagnostic Policy Migration
```

Runtime/source-run MASM behavior phase:

```text
Phase 57 - Signed IDIV
```

Status interpretation:

The repository/archive milestone is newer than the runtime/source-run MASM behavior phase because this target phase did not add MASM syntax, parser behavior, VM instruction behavior, memory semantics, Irvine32 behavior, browser controls, browser layout, browser interaction behavior, diagnostic codes, diagnostic JSON fields, rendered Simulator Messages wording, or source-run runtime behavior metadata. Runtime/source-run MASM behavior remains Phase 57 - Signed IDIV.

Scope implemented:

- Migrated existing configurable diagnostic-policy lookup toward the shared Phase 57C diagnostic-policy registry where practical.
- Added registry-backed compatibility helpers for existing implemented diagnostic-policy families.
- Preserved all existing public setting names, defaults, behavior, diagnostic codes, rendered Simulator Messages text, and source-run/browser behavior.
- Preserved legacy `strict` public inputs by mapping them to the central registry value `error`.
- Preserved legacy compatibility-notice `on` public input by mapping it to the central registry value `warn`.
- Kept compatibility notices non-fatal; registry acceptance for `compatibility-notice` now rejects the central `error` value because a fatal compatibility-notice mode is not current behavior.
- Left section-capacity, section-image, and declared-object validation on existing compatibility-layer paths because those validation systems were not Phase 57C registry families.
- Updated documentation, current-status surfaces, tests, and aggregate test-runner checks for Phase 57D.

No user-visible diagnostic wording or runtime behavior was intentionally changed.

## 2. Source-of-truth files used

Canonical repository files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57C report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_57C.zip
```

Changed-files packages produced during the milestone:

```text
milestone_57D_changed_files.zip
milestone_57D_compliance_review_changed_files.zip
milestone_57D_second_review_changed_files.zip
milestone_57D_final_gap_check_changed_files.zip
```

No full latest repository archive was produced during this milestone-report step. The recommended full archive name after accepting and applying the final Phase 57D changed-files package is:

```text
Latest_repository_state_milestone_57D.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, stable cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, and current-status surface hygiene.
- The implementation guide owns phase numbering, phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 57D is the only target milestone for this implementation session.
- TODO-style notes are implementation-risk evidence only and do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- User-visible diagnostics remain structured and have rendered Simulator Messages coverage where behavior exists.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, WinAPI simulator, host include loader, or macro assembler.

## 3. Exact requirements implemented

### 3.1 Registry-backed helpers for implemented diagnostic families

Added central helper behavior for existing implemented diagnostic families:

- Determine whether a diagnostic-policy family is implemented/current.
- Retrieve the current default policy value for implemented families.
- Determine whether a central registry value is accepted by a given implemented family.

Implemented-current families remain:

```text
uninitialized-read
undefined-flag-use
compatibility-notice
```

Reserved/inactive families remain inactive:

```text
const-uninitialized-storage
startup-state-notice
code-image-read
```

Reserved families remain discoverable by name through registry metadata but reject active policy use.

### 3.2 Existing uninitialized-read policy migrated through compatibility mapping

The existing uninitialized-read setting path now uses registry-backed compatibility helpers while preserving legacy public inputs.

Preserved public values:

```text
off
warn
strict
```

Central registry mapping:

```text
off    -> off
warn   -> warn
strict -> error
```

Preserved behavior:

- Default omitted setting remains warning mode.
- `off` suppresses uninitialized-read teaching warnings only.
- `warn` emits non-fatal `uninitialized-read` warnings and continues execution.
- `strict` stops before the read is consumed or visible state is mutated.
- Mandatory VM memory validation, `.CONST` protection, invalid-address diagnostics, and unrelated diagnostic families are not disabled by this setting.

### 3.3 Existing undefined-flag-use policy migrated through compatibility mapping

The existing undefined-flag-use setting path now uses registry-backed compatibility helpers while preserving legacy public inputs.

Preserved public values:

```text
off
warn
strict
```

Central registry mapping:

```text
off    -> off
warn   -> warn
strict -> error
```

Preserved behavior:

- Default omitted setting remains warning mode.
- `off` suppresses only undefined-flag-use consumer diagnostics.
- `warn` emits non-fatal `undefined-flag-use` warnings and continues using deterministic preserved flag values.
- `strict` stops before the consumer instruction uses the undefined flag or mutates visible state.
- Producer diagnostics such as `undefined-shift-flag` remain independent and are not suppressed by undefined-flag-use opt-out.

### 3.4 Existing compatibility-notice policy migrated through compatibility mapping

The existing compatibility-notice setting path now uses registry-backed compatibility helpers while preserving legacy public inputs.

Preserved public values:

```text
off
on
```

Central registry mapping:

```text
off -> off
on  -> warn
```

Important interpretation:

For compatibility notices, registry `warn` means “emit a non-fatal Simulator Message.” It does not change the rendered severity from `simulator-notice` to `simulator-warning`.

Preserved behavior:

- Default omitted setting remains notices on.
- `off` suppresses only compatibility notices.
- `on` emits compatibility notices for accepted no-op, metadata-only, and limited MASM compatibility constructs.
- Compatibility notices remain non-fatal.
- Compatibility notices do not become runtime errors.
- The central acceptance helper rejects `error` for `compatibility-notice`, because a fatal compatibility-notice mode is not current Phase 57D behavior.

### 3.5 Existing memory-range validation compatibility paths preserved

Section-capacity, section-image, and declared-object validation were intentionally not converted into new active registry families.

Preserved behavior:

- Region-only remains default.
- Section-capacity validation remains off unless selected.
- Section-image validation remains off unless selected.
- Declared-object validation remains off unless selected.
- Existing warn/strict behavior for those systems remains unchanged.
- Existing diagnostic codes and rendered message behavior remain unchanged.

Reason:

Phase 57C did not register section-capacity, section-image, or declared-object validation as diagnostic-policy families. Phase 57D required migration of existing configurable diagnostic-policy lookup where practical, not expansion of the registry taxonomy or activation of new families.

### 3.6 Current-status documentation and test-runner reporting updated

Updated current-status documentation to state:

```text
Repository/archive milestone:
Phase 57D - Existing Diagnostic Policy Migration

Runtime/source-run MASM behavior phase:
Phase 57 - Signed IDIV
```

Updated documentation/status surfaces without claiming new MASM syntax or source-run behavior.

Updated test-runner/static checks so Phase 57D current-status text and milestone-history ordering are validated.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57D:

- No new MASM syntax.
- No parser acceptance changes.
- No new VM instructions.
- No executor semantic changes.
- No memory validation semantic changes.
- No Irvine32 routine behavior changes.
- No Program Console behavior changes.
- No browser UI controls.
- No browser layout changes.
- No worker protocol phase advancement.
- No source-run JSON phase advancement.
- No diagnostic code additions.
- No diagnostic JSON field additions.
- No rendered Simulator Messages wording changes.
- No startup randomization.
- No startup-state notices.
- No `.CONST ?` or `.CONST DUP(?)` compatibility.
- No `.CONST` uninitialized-storage diagnostics.
- No `.code` read policy behavior.
- No `.code` access denial.
- No new section-capacity, section-image, or declared-object validation semantics.
- No broad diagnostic preset taxonomy.
- No activation of reserved registry families.
- No Phase 57E behavior.

Reserved/future diagnostic-policy families intentionally remain inactive:

```text
const-uninitialized-storage
startup-state-notice
code-image-read
```

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 57D should preserve the central registry value vocabulary from Phase 57C: `off`, `warn`, and `error`.
- **Reason:** Phase 57C deliberately established the central vocabulary and rejected adding legacy-specific central values such as `strict` or `on`.
- **Risk:** Public UI/source-run settings still expose older user-facing values, so direct comparison between public values and registry values can be confusing.
- **How to change later:** A later settings/protocol phase can expose registry metadata directly to the browser or revise public setting names, but it must explicitly own schema and UI changes.

### Assumption 2

- **Assumption:** Legacy public `strict` inputs should map to central registry `error`.
- **Reason:** Existing strict modes are fatal policies that stop before consumption or mutation, which matches the central registry `error` meaning.
- **Risk:** Tests or readers could expect the central registry to format or parse `strict` directly.
- **How to change later:** Add a separate central aliasing layer only if a future source-of-truth update says central policy parsing should accept legacy aliases.

### Assumption 3

- **Assumption:** Compatibility-notice `on` should map to central registry `warn` while preserving rendered severity `simulator-notice`.
- **Reason:** Registry `warn` is the closest central non-fatal “emit a Simulator Message” value. Compatibility notices are informational notices, not warnings or errors.
- **Risk:** The term `warn` may look semantically mismatched for a rendered notice.
- **How to change later:** A future registry expansion could distinguish “emit non-fatal notice” from “emit warning,” but that would require a reviewed source-of-truth update and tests.

### Assumption 4

- **Assumption:** Compatibility notices should not accept registry `error` in Phase 57D.
- **Reason:** Current Phase 53E behavior exposes compatibility notices only as On/Off. A fatal compatibility-notice mode would be new behavior and outside Phase 57D scope.
- **Risk:** A future diagnostic preset system may want fatal compatibility-notice enforcement.
- **How to change later:** Add a future phase that explicitly introduces fatal compatibility notices, updates UI/source-run settings, adds diagnostic tests, and updates docs.

### Assumption 5

- **Assumption:** Section-capacity, section-image, and declared-object validation should remain compatibility-layer memory-range settings rather than Phase 57D registry families.
- **Reason:** Phase 57C did not define those as registry family identifiers, and Phase 57D did not authorize adding new active families.
- **Risk:** The phrase “existing diagnostic policy migration” could be read as requiring every memory validation mode to become registry-native.
- **How to change later:** A later registry-taxonomy phase can add active families for memory validation layers if the spec/guide is updated to own that expansion.

## 6. Relevant TODO-style notes reviewed

### Target-owned notes

- Location: `docs/FULL_IMPLEMENTATION_SPEC.md`, modular diagnostic policy model.
- Summary: Existing diagnostic settings may keep pre-registry paths until a later migration phase explicitly routes them through the registry.
- Classification: target-owned.
- Disposition: Resolved by Phase 57D registry-backed compatibility adapters and updated documentation explaining the current state.

- Location: `src/core/vm_diagnostic_policy.h`, file header/commentary.
- Summary: Phase 57C added registry scaffolding while existing diagnostic settings continued using existing paths until a later migration phase.
- Classification: target-owned.
- Disposition: Resolved by updating comments to describe Phase 57D compatibility adapters as current behavior.

### Future-owned notes

- Location: `src/core/vm_memory.c`.
- Summary: Future protected-region diagnostics should generalize `.CONST` overlap handling when `.code` becomes memory-access-denying.
- Classification: future-owned.
- Disposition: Preserved. Phase 57D does not own `.code` memory-access denial.

- Location: `src/wasm/wasm_api.c`.
- Summary: Add future memory-reading opcodes to planned-read collection when those opcodes are implemented.
- Classification: future-owned.
- Disposition: Preserved. Phase 57D does not add memory-reading opcodes.

- Location: `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, protected-region guidance.
- Summary: Future `.code` memory-access-denial phases should reuse `region-boundary-crossing`.
- Classification: future-owned.
- Disposition: Preserved. The guide explicitly says not to implement `.code` access denial unless the owning future phase requires it.

- Location: `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, Phase 57E section.
- Summary: Add opt-out through the diagnostic policy registry if Phase 57D made that practical.
- Classification: future-owned.
- Disposition: Preserved. Phase 57E startup-state notice behavior was not implemented.

## 7. TODO-style note disposition

- **Target-owned TODO-style notes resolved:**
  - The spec and `vm_diagnostic_policy.h` migration notes were updated or superseded by Phase 57D implementation and documentation.

- **Future-owned TODO-style notes intentionally preserved:**
  - Future `.code` protected-region/access-denial note.
  - Future memory-reading opcode planned-access note.
  - Phase 57E startup-state notice opt-out note.

- **Stale or contradicted TODO-style notes corrected:**
  - No stale or contradicted TODO-style notes remained after review.

- **Unresolved TODO-related risks:**
  - None blocking. Remaining TODO-style notes are future-scoped and do not authorize Phase 57D future behavior.

## 8. Design summary

Phase 57D keeps the registry as the central source for implemented diagnostic-policy family metadata while preserving the public setting surface introduced by earlier milestones.

The implemented design has three layers:

1. **Central registry layer**
   - Owns family identifiers, stable family names, default central values, implemented/reserved status, and accepted central values.
   - Keeps the central value vocabulary as `off`, `warn`, and `error`.

2. **Compatibility adapter layer**
   - Converts legacy public settings to central registry values where practical.
   - Preserves `strict` as a public fatal input for teaching diagnostics by mapping it to `error`.
   - Preserves `on` as a public compatibility-notice input by mapping it to `warn`.
   - Rejects central `error` for compatibility notices because fatal compatibility notices are not current behavior.

3. **Existing behavior layer**
   - Keeps source-run, browser, worker, diagnostics, and rendered-message behavior unchanged.
   - Keeps memory-range validation paths unchanged where those systems are not registry families.

This design minimizes risk by avoiding broad rewrites and avoiding public schema changes. It also gives later phases a clearer place to add new policy families or expose registry metadata, if explicitly required later.

## 9. Files changed

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_diagnostic_policy.c`
- `src/core/vm_diagnostic_policy.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_diagnostic_policy.c`
- `tests/core/test_wasm_source_run.c`

A temporary generated root file observed during final gap check was removed and is not part of the intended repository changes:

```text
run_fixture_tmp.mjs
```

## 10. Tests added

Added or extended tests for:

- Registry implemented-family detection.
- Registry current-default lookup.
- Accepted central value validation per implemented family.
- Reserved/inactive family rejection.
- `compatibility-notice` rejecting central `error`.
- Legacy `strict` public input mapping to central `error` for teaching diagnostics.
- Compatibility-notice `on` mapping to central `warn` while preserving notice behavior.
- Source-run policy-family independence:
  - uninitialized-read off does not suppress undefined-flag-use;
  - undefined-flag-use off does not suppress uninitialized-read;
  - compatibility notices off suppresses only notices.
- Current-status/static documentation checks for Phase 57D.

No new rendered Simulator Messages tests were needed for changed wording because Phase 57D intentionally changed no user-visible diagnostic text. Existing rendered-message tests were preserved and rerun.

## 11. Commands used to test

Pre-implementation verification:

```text
python3 scripts/run_tests.py --all
```

Implementation and review focused groups:

```text
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command after implementation and reviews:

```text
python3 scripts/run_tests.py --all
```

No documented subgroup or individual fixture-family reruns were required because focused groups completed.

Skipped dependency check:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

## 12. Pass/fail results

### Pre-implementation repository verification

Classification:

```text
aggregate completed and passed
```

Observed summary:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Post-implementation testing

Focused groups passed:

```text
python3 scripts/run_tests.py --native      -> PASS
python3 scripts/run_tests.py --source-run  -> PASS
python3 scripts/run_tests.py --structure   -> PASS
python3 scripts/run_tests.py --static      -> PASS
python3 scripts/run_tests.py --web         -> PASS
python3 scripts/run_tests.py --protocol    -> PASS
python3 scripts/run_tests.py --diagnostics -> PASS
```

Aggregate result:

```text
python3 scripts/run_tests.py --all -> aggregate completed and passed
```

Observed aggregate summary included:

```text
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### First compliance review testing

Focused groups passed:

```text
python3 scripts/run_tests.py --static      -> PASS
python3 scripts/run_tests.py --native      -> PASS
python3 scripts/run_tests.py --source-run  -> PASS
python3 scripts/run_tests.py --web         -> PASS
python3 scripts/run_tests.py --diagnostics -> PASS
python3 scripts/run_tests.py --protocol    -> PASS
python3 scripts/run_tests.py --structure   -> PASS
```

Aggregate result:

```text
python3 scripts/run_tests.py --all -> aggregate completed and passed
```

Skipped dependency:

```text
Browser/Wasm rebuild smoke skipped because emcc was unavailable.
```

### Second compliance review testing

Focused groups passed:

```text
python3 scripts/run_tests.py --native      -> PASS
python3 scripts/run_tests.py --source-run  -> PASS
python3 scripts/run_tests.py --static      -> PASS
python3 scripts/run_tests.py --web         -> PASS
python3 scripts/run_tests.py --protocol    -> PASS
python3 scripts/run_tests.py --diagnostics -> PASS
python3 scripts/run_tests.py --structure   -> PASS
```

Aggregate result:

```text
python3 scripts/run_tests.py --all -> aggregate completed and passed
```

Skipped dependency:

```text
Browser/Wasm rebuild smoke skipped because emcc was unavailable.
```

### Final gap-check testing

Focused groups passed:

```text
python3 scripts/run_tests.py --static      -> PASS
python3 scripts/run_tests.py --native      -> PASS
python3 scripts/run_tests.py --source-run  -> PASS
python3 scripts/run_tests.py --web         -> PASS
python3 scripts/run_tests.py --protocol    -> PASS
python3 scripts/run_tests.py --diagnostics -> PASS
python3 scripts/run_tests.py --structure   -> PASS
```

Aggregate command:

```text
python3 scripts/run_tests.py --all
```

Final gap-check classification:

```text
aggregate timed out but focused groups passed
```

Reason:

The final aggregate invocation printed all focused groups as passed and printed `All implemented milestone tests passed.`, but the container tool reported a timeout before returning a normal process exit. Therefore, the final gap-check result was reported conservatively as focused verification rather than a completed aggregate return.

Skipped dependency:

```text
Browser/Wasm rebuild smoke skipped because emcc was unavailable.
```

No focused group failed. No focused group timed out. No subgroup/fixture-family rerun was required.

## 13. Manual/browser testing guidance and expected outputs

Phase 57D is backend policy migration. Manual/browser tests should verify unchanged behavior for existing diagnostic settings.

Website testing is valid only after rebuilding the Wasm artifact from Phase 57D source. Without a Wasm rebuild, the served site may still execute an older backend artifact.

Required browser setup:

- Emscripten available for Wasm rebuild.
- Served website started from the updated repository.
- Diagnostic settings panel available.

### Browser test A - default uninitialized-read warning

Settings:

```text
Memory range validation: Region-only
Uninitialized reads: Warn
Undefined flag use: Warn
Compatibility notices: On
```

Program:

```asm
.DATA?
x DWORD ?
.code
main PROC
    mov eax, x
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] uninitialized-read line 5: Memory read range 00500000h..00500003h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected register check:

```text
EAX = 00000000h
EFLAGS = 00000000h
```

Expected memory changes:

```text
No memory changes.
```

### Browser test B - uninitialized-read opt-out

Use the same program as Browser test A.

Setting change:

```text
Uninitialized reads: Off / I know what I'm doing
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected register check:

```text
EAX = 00000000h
```

### Browser test C - undefined-flag-use warning

Settings:

```text
Undefined flag use: Warn
```

Program:

```asm
.code
main PROC
    mov al, 80h
    shl al, 8
    adc bl, 0
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 4, column 5, byte offset 36, span length 9: SHL count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
[simulator-warning] undefined-flag-use line 5, column 5, byte offset 50, span length 9: ADC reads CF, but CF is architecturally undefined from SHL at line 4. The simulator preserved the flag deterministically; this flag-dependent behavior is not portable.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected register check:

```text
AL = 00h
BL = 00h
EFLAGS = 00000040h
```

### Browser test D - undefined-flag-use opt-out suppresses only consumer warning

Use the same program as Browser test C.

Setting change:

```text
Undefined flag use: Off / I know what I'm doing
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-shift-flag line 4, column 5, byte offset 36, span length 9: SHL count 8 has effective count 8 for an 8-bit destination. ZF and SF were updated from the result. CF is architecturally undefined because the effective count is greater than or equal to the destination width. OF is architecturally undefined because the effective count is not 1. The simulator preserved CF and OF deterministically.
[info] execution-complete: Execution completed successfully.
```

### Browser test E - compatibility notices default on

Settings:

```text
Compatibility notices: On
```

Program:

```asm
.386
.model flat, stdcall
.stack 4096
.code
main PROC
    mov eax, 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] compatibility-no-op line 1, column 1, byte offset 0, span length 4: .386 is accepted for MASM compatibility but does not change the simulator CPU mode.
[simulator-notice] compatibility-limited line 2, column 1, byte offset 5, span length 6: .model flat, stdcall is accepted for MASM32 textbook compatibility but does not enable real object-file, linker, Windows calling-convention, or WinAPI behavior.
[simulator-notice] compatibility-metadata-only line 3, column 1, byte offset 26, span length 6: .stack size is recorded as parser metadata, but runtime stack instructions and procedure frames remain deferred.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected register check:

```text
EAX = 00000001h
```

### Browser test F - compatibility notices off suppresses only notices

Use the same program as Browser test E.

Setting change:

```text
Compatibility notices: Off
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected register check:

```text
EAX = 00000001h
```

### Windows CMD local testing guidance

`program.asm` is not applicable for Phase 57D local verification. The milestone is covered by local C/Node test groups rather than a standalone command-line MASM source runner.

Required setup:

- Windows CMD or Visual Studio Developer Command Prompt.
- Python 3 available as `python`.
- Node.js available as `node`.
- C compiler available through the configured build environment.
- Emscripten optional. If `emcc` is unavailable, Browser/Wasm rebuild smoke is expected to be skipped.

Commands from repository root:

```bat
python scripts\run_tests.py --native
python scripts\run_tests.py --source-run
python scripts\run_tests.py --web
python scripts\run_tests.py --protocol
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --static
python scripts\run_tests.py --all
```

Expected focused output pattern:

```text
[<group>] START
[<group>] PASS - ...
Selected test groups passed.
```

Expected aggregate output pattern:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
All implemented milestone tests passed.
```

Expected skip when Emscripten is unavailable:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Regression signs:

- Any focused group reports `FAIL`.
- Aggregate does not end with `All implemented milestone tests passed.`
- Static tests complain about Phase 57D status text.
- Protocol tests fail around diagnostic settings.
- Web tests fail around settings normalization.
- Diagnostic tests fail around rendered Simulator Messages.
- Browser default warnings or notices disappear unexpectedly.
- Off settings suppress unrelated diagnostic families.
- Compatibility notices become warnings or errors.
- Runtime/source-run behavior phase advances beyond Phase 57.

## 14. Compliance review summary

First compliance review found one documentation hygiene issue:

- `docs/MILESTONE_HISTORY.md` concise milestone ledger listed Phase 57D before Phase 57C.

Fix applied:

- Reordered the concise milestone ledger so Phase 57C appears before Phase 57D.

No code fixes were required in the first compliance review.

Scope review result:

- No accidental future milestone behavior found.
- No C++ core code introduced.
- No parser, instruction, memory-semantics, Irvine32, Program Console, diagnostic wording, or runtime/source-run MASM behavior change found.

Tests rerun in first compliance review:

```text
python3 scripts/run_tests.py --static      -> PASS
python3 scripts/run_tests.py --native      -> PASS
python3 scripts/run_tests.py --source-run  -> PASS
python3 scripts/run_tests.py --web         -> PASS
python3 scripts/run_tests.py --diagnostics -> PASS
python3 scripts/run_tests.py --protocol    -> PASS
python3 scripts/run_tests.py --structure   -> PASS
python3 scripts/run_tests.py --all         -> aggregate completed and passed; emcc skip noted
```

## 15. Re-review summary

Second compliance review found two issues:

1. Stale comment in `src/core/vm_diagnostic_policy.h` still described legacy value mapping as work for a later migration phase.
2. `vm_diagnostic_policy_family_accepts_value` initially treated all implemented families as accepting all central values, including `error` for `compatibility-notice`.

Fixes applied:

- Updated `vm_diagnostic_policy.h` comments to describe Phase 57D compatibility adapters as current behavior.
- Changed `vm_diagnostic_policy_family_accepts_value` so:
  - `uninitialized-read` accepts `off/warn/error`;
  - `undefined-flag-use` accepts `off/warn/error`;
  - `compatibility-notice` accepts only `off/warn`;
  - reserved inactive families reject all values.
- Added a unit regression asserting `compatibility-notice` rejects registry `error`.

Final re-review verdict:

- Scope complete.
- Documentation complete after stale comment fix.
- Test coverage complete.
- TODO-style notes correctly scoped.

Tests rerun in second compliance review:

```text
python3 scripts/run_tests.py --native      -> PASS
python3 scripts/run_tests.py --source-run  -> PASS
python3 scripts/run_tests.py --static      -> PASS
python3 scripts/run_tests.py --web         -> PASS
python3 scripts/run_tests.py --protocol    -> PASS
python3 scripts/run_tests.py --diagnostics -> PASS
python3 scripts/run_tests.py --structure   -> PASS
python3 scripts/run_tests.py --all         -> aggregate completed and passed; emcc skip noted
```

## 16. User-test follow-up summary

Prompt 8 user-test triage was not run because the user reported that everything appeared to pass and proceeded directly to the final gap check.

No user-observed discrepancies were provided.

No user-test fixes were required.

## 17. Known limitations

- Browser/Wasm rebuild smoke could not be performed in this environment because `emcc` was unavailable.
- Served-website testing is valid only after rebuilding the Wasm artifact from Phase 57D source.
- No full latest repository archive was produced during this milestone-report step.
- Section-capacity, section-image, and declared-object validation remain on compatibility-layer paths rather than registry-native families. This is intentional for Phase 57D and matches the documented assumption.
- Phase 57D does not expose registry metadata to the browser UI.
- Phase 57D does not add or activate reserved diagnostic-policy families.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57E - Startup State Notice and Zero-Default Documentation
```

Expected scope of next milestone, by title only:

- Startup-state notice behavior and zero-default documentation.
- It should not be implemented as part of Phase 57D.

## 19. Changed-files ZIP/package produced

Changed-files packages produced:

```text
milestone_57D_changed_files.zip
milestone_57D_compliance_review_changed_files.zip
milestone_57D_second_review_changed_files.zip
milestone_57D_final_gap_check_changed_files.zip
```

Recommended package to apply last:

```text
milestone_57D_final_gap_check_changed_files.zip
```

After applying the final package and accepting the milestone, produce a full repository archive named:

```text
Latest_repository_state_milestone_57D.zip
```
