# Milestone 44 report - AND, OR, and XOR

## 1. Milestone title and scope

Milestone 44 implements Phase 44 - AND, OR, and XOR for the Online MASM32 Educational Simulator.

Scope implemented:

- Add `and`, `or`, and `xor` as executable runtime instructions.
- Support register destinations with register, immediate, and memory sources.
- Support memory destinations with register and immediate sources when memory width is explicit or inferable.
- Preserve MASM-compatible rejection for ambiguous memory/immediate forms such as `and [eax], 1`, `or [eax], 1`, and `xor [eax], 1`.
- Preserve rejection for immediate destinations and memory-to-memory forms.
- Preserve existing MASM32 Educational Mode rejection for executable QWORD/SQWORD memory operations.
- Route all memory reads and writes through checked VM memory helpers.
- Update modeled flags for logical operations: update `ZF` and `SF`, clear `CF` and `OF`.
- Update source-run and browser metadata to report phase 44.
- Add native C, parser, source-run JSON, rendered Simulator Messages, protocol, and regression coverage.

The implementation stayed within the milestone boundary. No future instruction groups or control-flow behavior were added.

## 2. Source-of-truth files used

Canonical files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 43 report.md`

Interpretation rules used:

- The full implementation specification owns stable behavior and product boundaries.
- The incremental implementation guide owns phase numbering, phase tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.

Repository archive used as the implementation base:

- `Latest_repository_state_milestone_43.zip`

## 3. Exact requirements implemented

Phase 44 required `and`, `or`, and `xor` together because they share operand shapes, destination mutation, width rules, and modeled flag behavior.

Accepted syntax implemented:

```asm
and reg, reg
and reg, imm
and reg, mem
and mem, reg
and mem, imm

or reg, reg
or reg, imm
or reg, mem
or mem, reg
or mem, imm

xor reg, reg
xor reg, imm
xor reg, mem
xor mem, reg
xor mem, imm
```

Memory width behavior implemented:

- Explicit `PTR` width overrides work for memory destinations and sources.
- Signed `PTR` aliases continue to work by width where executable in MASM32 Educational Mode:
  - `SBYTE PTR`
  - `SWORD PTR`
  - `SDWORD PTR`
- Direct typed symbols and typed symbol offsets infer memory width from symbol metadata.
- Register operands in the same instruction supply width where the form is unambiguous.
- Untyped memory/immediate forms remain rejected as ambiguous.

Rejected syntax verified:

```asm
and imm, reg
or  imm, reg
xor imm, reg

and [eax], 1
or  [eax], 1
xor [eax], 1

and value, other
or  value, other
xor value, other

and eax
or  eax
xor eax

and eax, ebx, ecx
or  eax, ebx, ecx
xor eax, ebx, ecx

and QWORD PTR q, 1
or  SQWORD PTR q, 1
xor QWORD PTR q, 1
```

Runtime semantics implemented:

- `and` computes `dest = dest & src` at the selected operand width.
- `or` computes `dest = dest | src` at the selected operand width.
- `xor` computes `dest = dest ^ src` at the selected operand width.
- Register destinations mutate only the selected register or alias width.
- Memory destinations are read-modify-write operations.
- Memory reads and memory writes route through checked VM memory helpers.
- Direct `.CONST` destinations fail during assembly when obvious.
- Computed `.CONST` destinations fail through central runtime memory permissions.
- Failed reads/writes do not mutate registers, flags, memory, console state, or memory-change rows.

Flag behavior implemented:

- `ZF` updates from the result.
- `SF` updates from the result sign bit at operand width.
- `CF` is cleared.
- `OF` is cleared.
- Other x86 flags remain unmodeled.

Acceptance program:

```asm
.code
main PROC
    mov eax, 0F0F0h
    and eax, 00FFh
    or  eax, 0100h
    xor eax, 000Fh
main ENDP
END main
```

Expected result:

```text
EAX = 000001FFh / 511
CF = 0
OF = 0
ZF = 0
SF = 0
```

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 44:

- `not`
- `shl`, `sal`, `shr`, `sar`
- `rol`, `ror`
- `cmp`
- labels, `jmp`, conditional jumps, or `loop`
- `lea`
- `mul`, `imul`, `div`, or `idiv`
- `push`, `pop`, `call`, `ret`, `leave`, or stack behavior
- procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`
- Irvine32 routine bodies beyond the existing `exit` virtual terminator
- Program Console input/output routines
- scaled-index addressing
- executable QWORD/SQWORD memory operations
- Windows API, PE loading, object linking, host include loading, or macro behavior

Compile-time expression operators `AND`, `OR`, and `XOR` remain separate from runtime logical instructions. Existing expression behavior was preserved.

Next planned instruction family is Phase 45 - NOT.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `and`, `or`, and `xor` should be represented as dedicated IR opcodes.
- **Reason:** Dedicated opcodes keep runtime instruction identity clear for diagnostics, opcode-name helpers, tests, future debugger display, and future instruction-specific behavior.
- **Risk:** Adds three opcodes and executor cases rather than one generic logical opcode.
- **How to change later:** A future IR normalization pass could share one lower-level logical helper internally while preserving public opcode identity.

### Assumption 2

- **Assumption:** Existing binary operand parsing and memory-width validation should remain the source of truth for Phase 44 operand forms.
- **Reason:** Earlier milestones established global memory-width resolution and binary operand parsing. Reusing those paths reduces risk of introducing alternate MASM-incompatible width behavior.
- **Risk:** Existing helpers may need targeted adaptation if a later instruction family has similar but not identical validation needs.
- **How to change later:** Introduce a documented shared parser helper for binary read/write instructions, with instruction-specific validation hooks.

### Assumption 3

- **Assumption:** Logical flag updates should use a narrow shared executor helper.
- **Reason:** `and`, `or`, and `xor` share identical modeled flag behavior: update `ZF`/`SF` and clear `CF`/`OF`.
- **Risk:** A helper could be overgeneralized and accidentally reused for future instructions with different flag behavior.
- **How to change later:** Keep the helper scoped to logical binary operations. Add separate helpers for `not`, shifts, rotates, and `test` if needed.

### Assumption 4

- **Assumption:** Direct `.CONST` logical destinations should use the existing static const-write diagnostic path, while computed `.CONST` destinations should fail at runtime through checked memory permissions.
- **Reason:** The specification requires both static diagnostics for obvious `.CONST` writes and runtime protection based on final effective address ranges.
- **Risk:** Static and runtime `.CONST` cases produce different diagnostic categories because they fail at different phases.
- **How to change later:** Extend static `.CONST` detection coverage if desired, while keeping runtime memory permission checks authoritative.

### Assumption 5

- **Assumption:** Phase metadata should advance to `44` in source-run JSON and browser protocol metadata.
- **Reason:** Milestone 43 advanced metadata, and the test suite verifies current implemented phase information.
- **Risk:** Metadata updates touch browser/protocol files even though the primary behavior is in parser/executor code.
- **How to change later:** Centralize feature-level metadata if the project later separates runtime support metadata from browser sample/status metadata.

## 6. Design summary

### IR changes

Three new opcodes were added:

```text
VM_IR_OPCODE_AND
VM_IR_OPCODE_OR
VM_IR_OPCODE_XOR
```

The opcode-name helper was updated so diagnostics, tests, and future debugging output can identify the opcodes as:

```text
and
or
xor
```

### Parser changes

The parser now recognizes `and`, `or`, and `xor` as binary destination-mutating logical instructions.

Parser behavior:

- Accepts register destinations with register, immediate, or memory sources.
- Accepts memory destinations with register or immediate sources when width is explicit or inferable.
- Accepts direct typed symbols and typed symbol offsets as memory destinations.
- Accepts explicit `BYTE PTR`, `WORD PTR`, and `DWORD PTR` memory forms.
- Accepts signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases by width.
- Rejects immediate destinations.
- Rejects memory-to-memory operands.
- Rejects wrong operand counts.
- Rejects untyped memory/immediate operands with `ambiguous-memory-width`.
- Preserves existing QWORD/SQWORD executable memory-operation rejection.
- Emits static `.CONST` write diagnostics for direct `.CONST` destinations.

### Executor changes

The executor handles `AND`/`OR`/`XOR` through a narrow logical binary helper.

Execution algorithm:

1. Resolve and validate destination and source operands.
2. Read destination value.
3. Read source value.
4. Save pre-instruction CPU/flag state where needed for rollback on failed write.
5. Compute result at operand width.
6. Update `ZF` and `SF` from result.
7. Clear `CF` and `OF`.
8. Write result back to the register or memory destination.
9. If a write fails, restore CPU/flag state so no partial mutation is visible.

Memory behavior:

- All memory reads go through checked VM read helpers.
- All memory writes go through checked VM write helpers.
- `.CONST` permission checks remain enforced by final effective address range.
- Invalid read failures occur before write-back.
- Failed writes do not create successful memory-change rows.

### Documentation and metadata

Updated documentation and metadata to describe Phase 44 as the current implemented milestone and to list `and`, `or`, and `xor` as supported runtime instructions.

## 7. Files changed

Final Phase 44 changed files:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

Changed-files packages produced:

```text
/mnt/data/milestone44_changed_files.zip
/mnt/data/milestone44_compliance_review_changed_files.zip
/mnt/data/milestone44_second_review_changed_files.zip
```

The latest package is:

```text
/mnt/data/milestone44_second_review_changed_files.zip
```

## 8. Tests added

### Parser tests

Added or expanded coverage for:

- `and eax, ebx`
- `and eax, 0FFh`
- `and eax, value`
- `and value, eax`
- `and DWORD PTR [eax], 1`
- equivalent accepted forms for `or` and `xor`
- direct typed symbol destinations
- symbol-offset destinations
- `BYTE PTR`, `WORD PTR`, and `DWORD PTR` memory forms
- signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases
- immediate destination rejection
- wrong operand count rejection
- extra operand rejection
- memory-to-memory rejection
- ambiguous memory-width rejection
- QWORD/SQWORD executable memory-operation rejection
- direct `.CONST` write rejection

### Executor tests

Added or expanded coverage for:

- register/register logical operations
- register/immediate logical operations
- register/memory logical operations
- memory/register logical operations
- memory/immediate logical operations
- 8-bit alias destination mutation
- 16-bit alias destination mutation
- 32-bit destination mutation
- zero-result flag behavior
- sign-bit flag behavior
- clearing `CF` and `OF`
- memory read-modify-write success
- invalid memory source read failure
- invalid memory destination read failure
- `.CONST` permission failure
- no partial mutation on failed memory writes

### Source-run JSON tests

Added or expanded coverage for:

- successful register/immediate acceptance program
- successful memory destination/source program
- invalid immediate destination
- memory-to-memory rejection
- ambiguous memory-width diagnostic
- direct `.CONST` assembly diagnostic
- computed `.CONST` runtime failure
- invalid memory source runtime failure
- invalid memory destination runtime failure
- phase metadata reporting `44`

### Rendered Simulator Messages tests

Added or expanded exact rendered-message coverage for:

- successful execution line
- `ambiguous-memory-width` from logical memory/immediate form
- `invalid-instruction-operands` from immediate destination
- `invalid-instruction-operands` from memory-to-memory operands
- direct `.CONST` write diagnostic
- runtime permission failure from computed `.CONST` logical write
- runtime invalid-address diagnostic for invalid memory source
- runtime invalid-address diagnostic for invalid memory destination

### Regression tests

Regression coverage confirms:

- Existing `test` behavior remains read-only and still clears `CF`/`OF`.
- Existing `inc`/`dec` behavior remains intact and preserves `CF`.
- Existing `adc`/`sbb` behavior remains intact.
- Existing `neg`, `xchg`, `nop`, and carry-control behavior remains intact.
- Existing compile-time expression `AND`/`OR`/`XOR` remains intact.
- Existing `.CONST`, object-bounds, and uninitialized-read validation paths remain intact.
- Existing Milestone 42 `exit` behavior remains intact.
- Program Console remains separate from Simulator Messages.

## 9. Commands used to test

Primary aggregate test command:

```sh
cd /mnt/data/repo_m44
python3 scripts/run_tests.py
```

Observed result:

```text
All implemented milestone tests passed.
```

Wasm rebuild check attempted:

```sh
cd /mnt/data/repo_m44
bash scripts/build_wasm.sh
```

Observed result in this container:

```text
scripts/build_wasm.sh: line 18: emcc: command not found
```

Interpretation:

- Native C and Node tests pass.
- This container cannot rebuild Wasm because Emscripten is not installed.
- Served website behavior requires a local Wasm rebuild in an Emscripten-enabled environment.

## 10. Pass/fail results

Final automated test status:

```text
PASS - native C tests
PASS - parser tests
PASS - executor tests
PASS - source-run JSON tests
PASS - Node formatter/protocol tests
PASS - rendered Simulator Messages tests
PASS - milestone/static structure tests
PASS - aggregate test runner
SKIPPED/UNAVAILABLE - Wasm rebuild in this container because emcc is not installed
```

Manual user testing status:

```text
PASS - all 10 provided manual programs matched expected output
```

## 11. Manual/browser testing guidance and expected outputs

Website-testable: yes, after rebuilding Wasm locally with Emscripten.

Windows setup assumptions:

```cmd
emcc --version
py --version
node --version
```

Build and serve on Windows:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

Stop server:

```cmd
scripts\windows\stop_web.cmd
```

Local Windows test command:

```cmd
set CC=clang
py scripts\run_tests.py
```

Expected:

```text
All implemented milestone tests passed.
```

Optional per-file local source check:

```cmd
build\tests\diagnostic_json_producer.exe program.asm
```

### Manual program 1 - register/immediate acceptance path

```asm
.code
main PROC
    mov eax, 0F0F0h
    and eax, 00FFh
    or  eax, 0100h
    xor eax, 000Fh
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    000001FFh / 511
EFLAGS 00000000h / 0
```

Expected flags:

```text
CF = 0
ZF = 0
SF = 0
OF = 0
```

Expected Memory Changes:

```text
No memory changes.
```

### Manual program 2 - memory destinations and memory changes

```asm
.data
value DWORD 0F0F0F0Fh
bytes BYTE 0F0h, 0Fh
.code
main PROC
    and value, 00FF00FFh
    or  BYTE PTR bytes[1], 0F0h
    xor eax, eax
    mov eax, value
    mov bl, BYTE PTR bytes[1]
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    000F000Fh / 983055
EBX    000000FFh / 255
EFLAGS 00000040h / 64
```

Expected flags:

```text
CF = 0
ZF = 1
SF = 0
OF = 0
```

Expected Memory Changes:

```text
value: 0F0F0F0Fh / 252645135 -> 000F000Fh / 983055
bytes + 1 BYTE
  byte offset: +1
  element index: 1
  0Fh / 15 -> FFh / 255
```

### Manual program 3 - alias-width behavior and flag clearing

```asm
.code
main PROC
    stc
    mov eax, 12345678h
    xor al, 0FFh
    or ax, 8000h
    and eax, 0000FFFFh
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    0000D687h / 54919
EFLAGS 00000000h / 0
```

Expected flags after final `and`:

```text
CF = 0
ZF = 0
SF = 0
OF = 0
```

Expected Memory Changes:

```text
No memory changes.
```

### Manual program 4 - ambiguous memory width diagnostic

```asm
.code
main PROC
    and [eax], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 3, column 9, byte offset 24, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Expected result:

```text
No register state available.
No memory changes.
```

### Manual program 5 - invalid immediate destination

```asm
.code
main PROC
    or 1, eax
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 3, column 8, byte offset 23, span length 1: OR requires a register or memory destination.
```

Expected result:

```text
No register state available.
No memory changes.
```

### Manual program 6 - memory-to-memory rejection

```asm
.data
value DWORD 1
other DWORD 2
.code
main PROC
    xor value, other
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 6, column 16, byte offset 65, span length 5: XOR does not support memory-to-memory operands.
```

Expected result:

```text
No register state available.
No memory changes.
```

### Manual program 7 - direct `.CONST` write diagnostic

```asm
.CONST
limit DWORD 10
.code
main PROC
    and limit, 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] const-write line 5, column 9, byte offset 46, span length 5: Cannot write to .CONST data. Constant data is read-only.
```

Expected result:

```text
No register state available.
No memory changes.
```

### Manual program 8 - computed `.CONST` write runtime diagnostic

```asm
.CONST
limit DWORD 10
.code
main PROC
    mov eax, OFFSET limit
    or DWORD PTR [eax], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] permission-denied line 6: Memory write at 00600000h for 4 bytes is not permitted in .const.
```

Expected important registers:

```text
EAX    00600000h / 6291456
EFLAGS 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

### Manual program 9 - invalid memory source runtime diagnostic

```asm
.code
main PROC
    mov eax, 0
    and ebx, DWORD PTR [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] invalid-address line 4: Invalid memory read at 00000000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

Expected important registers:

```text
EAX    00000000h / 0
EBX    00000000h / 0
EFLAGS 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

### Manual program 10 - invalid memory destination runtime diagnostic

```asm
.code
main PROC
    mov eax, 0
    xor DWORD PTR [eax], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] invalid-address line 4: Invalid memory read at 00000000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

Expected important registers:

```text
EAX    00000000h / 0
EFLAGS 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `and`, `or`, or `xor` reported as unknown.
- `EAX` differs from `000001FFh / 511` in Program 1.
- `CF` or `OF` remains set after logical instructions.
- `xor eax, eax` does not set `ZF`.
- Memory changes are missing or incorrect in Program 2.
- Program Console shows output for these programs.
- `and [eax], 1` executes instead of producing `ambiguous-memory-width`.
- Memory-to-memory forms execute instead of producing `invalid-instruction-operands`.
- `.CONST` storage mutates or creates memory-change rows.
- Runtime invalid-address failures still show `execution-complete`.

## 12. Compliance review summary

First compliance review checked:

- scope control;
- completeness against the Phase 44 guide section;
- code quality and C99 boundaries;
- diagnostics and source locations;
- rendered Simulator Messages tests;
- test quality;
- documentation freshness.

Issues found and fixed:

- Missing explicit Phase 44 runtime invalid memory-source coverage.
- Stale test header still said source-run tests were through Phase 43.
- Two diagnostic fixture descriptions mislabeled Phase 42 `exit` diagnostics as Phase 43.

Files changed during first compliance review:

```text
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
```

Test result after fixes:

```text
All implemented milestone tests passed.
```

Verdict after first compliance review:

```text
complete
```

## 13. Re-review summary

Second compliance review checked:

- exact Phase 44 guide requirements;
- stable behavior in the full specification;
- changed code and docs;
- changed tests for meaningful assertions;
- stale comments and stale documentation;
- future-milestone scope creep;
- diagnostic exactness and user-facing wording.

Additional issue found and fixed:

- Direct `.CONST` logical destinations were parser-tested but not source-run/rendered-tested.

Files changed during second review:

```text
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
```

Test result after fixes:

```text
All implemented milestone tests passed.
```

Final re-review verdict:

```text
complete
```

## 14. User-test follow-up summary

The user ran all 10 manual programs.

Observed results:

- Program 1 matched expected output.
- Program 2 matched expected output.
- Program 3 matched expected output.
- Program 4 matched expected output.
- Program 5 matched expected output.
- Program 6 matched expected output.
- Program 7 matched expected output.
- Program 8 matched expected output.
- Program 9 matched expected output.
- Program 10 matched expected output.

Diagnosis:

```text
No discrepancies. No fixes required.
```

Regression tests added after user test follow-up:

```text
None required.
```

Final gap-check result:

```text
No additional Phase 44 implementation, fixes, tests, or documentation changes are needed.
```

## 15. Known limitations

- Wasm artifacts were not rebuilt in this container because `emcc` is unavailable.
- Served website testing requires a local Emscripten-enabled rebuild.
- Browser manual testing is valid only after rebuilding `web/dist` from the updated C/Wasm source.
- Executable QWORD/SQWORD memory operations remain deferred to a future Extended 32-bit Mode phase.
- Future instruction groups remain unimplemented until their own milestones.
- No new Program Console or Irvine32 routine behavior was added.

## 16. Next recommended milestone

Next recommended milestone:

```text
Phase 45 - NOT
```

Phase 45 should remain limited to the unary bitwise `not` instruction and must not implement shifts, rotates, `cmp`, jumps, multiplication, division, stack behavior, or any future instruction family beyond the target phase.

## 17. Changed-files ZIP/package produced

Latest changed-files package:

```text
/mnt/data/milestone44_second_review_changed_files.zip
```

Earlier packages produced during the milestone:

```text
/mnt/data/milestone44_changed_files.zip
/mnt/data/milestone44_compliance_review_changed_files.zip
```

Recommended full repository archive name after applying the latest changed-files package:

```text
Latest_repository_state_milestone_44.zip
```

## 18. Final status

Milestone 44 is complete.

It implements `and`, `or`, and `xor` only, includes success/error/edge/regression tests, preserves prior milestone behavior, updates user-visible documentation and metadata, passes the aggregate test suite, and passed user manual verification.
