# Milestone 48 report - SAR

## 1. Milestone title and scope

Milestone 48 implements **Phase 48 - SAR** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added executable runtime support for `sar`.
- Supported register destinations at 8-bit, 16-bit, and 32-bit widths.
- Supported unambiguous memory destinations through:
  - typed data symbols;
  - symbol offsets;
  - explicit unsigned `BYTE PTR`, `WORD PTR`, and `DWORD PTR` forms;
  - explicit signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases.
- Supported immediate byte shift counts and `CL` as the only register shift-count operand.
- Applied the existing MASM/x86-compatible shift count masking policy for 32-bit educational mode:

```text
effective_count = raw_count & 31
```

- Preserved effective-count-zero no-op behavior: destination and modeled flags are unchanged and no undefined-shift warning is emitted.
- Implemented arithmetic right-shift semantics: high bits are filled from the original sign bit.
- Implemented default-mode undefined modeled-flag warnings for architecturally undefined SAR flag cases while allowing execution to complete.
- Implemented strict undefined-shift validation through the existing native/source-run API configuration path, where the same undefined modeled-flag condition becomes a runtime error before mutation.
- Preserved all prior milestone behavior, especially Phase 46 `shl`/`sal` and Phase 47 `shr` behavior.
- Updated source-run and browser metadata to report phase 48.
- Added native C, parser, executor, source-run JSON, rendered Simulator Messages, protocol/static, documentation, manual-testing, compliance, and regression coverage.

The implementation stayed within the milestone boundary. No future rotate, control-flow, stack, procedure, Irvine32, QWORD/SQWORD execution, PF/AF, WinAPI, PE, linker, or macro behavior was implemented.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 47 report.md`

Repository archive used as the implementation base:

- `Latest_repository_state_milestone_47.zip`

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.
- Phase 48 is the only target milestone for this work session.

## 3. Exact requirements implemented

Phase 48 required `sar` as the arithmetic-right-shift counterpart to Phase 47 `shr`, while reusing the Phase 46/47 shift destination/count policy and undefined-modeled-flag handling.

Accepted syntax implemented:

```asm
sar reg, 1
sar reg, imm
sar reg, cl
sar mem, 1
sar mem, imm
sar mem, cl
```

Supported register destinations:

```text
reg8
reg16
reg32
```

Supported memory destinations:

```asm
sar BYTE PTR [eax], 1
sar WORD PTR [eax], 1
sar DWORD PTR [eax], 1
sar SBYTE PTR [eax], 1
sar SWORD PTR [eax], 1
sar SDWORD PTR [eax], 1
sar value, 1
sar values[4], 1
```

Rejected syntax verified:

```asm
sar 1, al
sar eax, ebx
sar eax, cx
sar eax, ecx
sar eax
sar eax, 1, 2
sar [eax], 1
sar QWORD PTR q, 1
sar SQWORD PTR q, 1
```

Runtime semantics implemented:

- Raw count source:
  - immediate byte count, or
  - low 8 bits of `ECX` when the count operand is `CL`.
- Effective count:

```text
effective_count = raw_count & 31
```

- Effective count `0`:
  - destination unchanged;
  - `CF`, `ZF`, `SF`, and `OF` unchanged;
  - no undefined-shift warning.
- Effective count `1`:
  - destination shifted right by one bit;
  - high bit filled from the original sign bit;
  - `CF` receives the bit shifted out of bit 0;
  - `ZF` and `SF` update from the result;
  - `OF` is cleared.
- Effective count greater than `1` but less than destination width:
  - destination shifted right arithmetically by the effective count;
  - high bits filled from the original sign bit;
  - `CF` receives the last bit shifted out of bit 0;
  - `ZF` and `SF` update from the result;
  - `OF` is architecturally undefined and is preserved deterministically by the simulator;
  - default mode emits `undefined-shift-flag` warning;
  - strict mode emits `undefined-shift-flag` runtime error before mutation.
- Effective count greater than or equal to destination width:
  - destination shifted right arithmetically and deterministically;
  - the result is all sign bits for negative inputs or zero for non-negative inputs;
  - `ZF` and `SF` update from the result;
  - `CF` is architecturally undefined and is preserved deterministically by the simulator;
  - `OF` is architecturally undefined and is preserved deterministically by the simulator;
  - default mode emits `undefined-shift-flag` warning;
  - strict mode emits `undefined-shift-flag` runtime error before mutation.

Diagnostics implemented or verified:

- `undefined-shift-flag` warning in default mode.
- `undefined-shift-flag` runtime error in strict undefined-shift validation mode.
- `ambiguous-memory-width` for untyped memory destinations such as `sar [esi], 1`.
- `invalid-instruction-operands` for immediate destinations, wrong operand counts, and invalid count registers such as `EBX`, `CX`, and `ECX`.
- Existing unsupported-runtime diagnostics for executable `QWORD PTR` and `SQWORD PTR` memory operations remain in force.
- Existing runtime memory diagnostics for invalid addresses and `.CONST` permission failures remain structured and rendered.
- Diagnostic source location data remains preserved: line, column, byte offset, and span length where applicable.

Acceptance examples:

```asm
.code
main PROC
    mov al, 80h
    sar al, 1
main ENDP
END main
```

Expected final state:

```text
EAX = 000000C0h / 192
EFLAGS = 00000080h / 128
```

```asm
.code
main PROC
    mov al, 01h
    sar al, 1
main ENDP
END main
```

Expected final state:

```text
EAX = 00000000h / 0
EFLAGS = 00000041h / 65
```

```asm
.code
main PROC
    mov al, 80h
    sar al, 8
main ENDP
END main
```

Expected default-mode behavior:

```text
[simulator-warning] undefined-shift-flag ...
[info] execution-complete: Execution completed successfully.
EAX = 000000FFh / 255
EFLAGS = 00000080h / 128
```

Expected strict-mode behavior:

```text
[runtime-error] undefined-shift-flag ...
EAX remains 00000080h / 128
EFLAGS remains 00000000h / 0
No execution-complete message.
```

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 48:

- `rol`, `ror`, or other rotate instructions.
- `cmp`.
- labels, `jmp`, conditional jumps, or `loop`.
- `lea`.
- `mul`, `imul`, `div`, or `idiv`.
- `push`, `pop`, `call`, `ret`, `leave`, or stack behavior.
- procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`.
- Irvine32 routine bodies beyond the existing `exit` virtual terminator.
- Program Console input/output routines.
- scaled-index addressing.
- executable QWORD/SQWORD memory operations.
- PF/AF integration for shift instructions.
- browser UI setting for strict undefined-shift validation.
- Windows API, PE loading, object linking, host include loading, or macro behavior.

Compile-time expression operator behavior remains separate from runtime instruction behavior. Existing expression behavior was preserved.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `sar` should be represented as a dedicated IR opcode.
- **Reason:** Dedicated opcode identity preserves source mnemonic clarity for diagnostics, tests, protocol/debug display, and future debugger output.
- **Risk:** Adds another opcode and executor case instead of using one generic shift opcode with direction/type metadata.
- **How to change later:** A future internal normalization pass can share a lower-level shift helper while preserving public opcode identity and original source mnemonic.

### Assumption 2

- **Assumption:** Immediate `sar` counts should follow Phase 46/47 byte-count validation, including accepted values `0..255`.
- **Reason:** Phase 48 explicitly reuses the Phase 46 destination/count and count/undefined-flag policy. Phase 47 `shr` already followed that model.
- **Risk:** Future expression support could produce wider evaluated constants that need clearer instruction-encoding validation.
- **How to change later:** Route count expressions through the centralized expression evaluator and keep a documented final immediate-count validation step.

### Assumption 3

- **Assumption:** Default and strict `undefined-shift-flag` wording should mirror the flag-specific wording style established in Milestones 46 and 47, but with SAR-specific mnemonic details.
- **Reason:** Earlier review/user testing found generic shift warning wording too vague. The current style states which modeled flags were updated and which were preserved because they are architecturally undefined.
- **Risk:** Exact rendered-message tests may need adjustment if a future diagnostic catalog standardizes wording.
- **How to change later:** Keep the diagnostic code stable as `undefined-shift-flag`; update message templates and golden tests together if wording is intentionally refined.

### Assumption 4

- **Assumption:** PF and AF remain unmodeled and untouched in Phase 48.
- **Reason:** The current stable modeled flag set is `CF`, `ZF`, `SF`, and `OF`; PF/AF integration is outside Phase 48 scope.
- **Risk:** Future PF/AF implementation must revisit all shift helpers, including `shl`, `sal`, `shr`, and `sar`.
- **How to change later:** Implement PF/AF in a dedicated later flag-integration phase without changing the Phase 48 `CF/ZF/SF/OF` contract.

### Assumption 5

- **Assumption:** Strict undefined-shift validation remains available through the existing test/API configuration path only.
- **Reason:** Milestones 46 and 47 did not add a browser UI setting, and Phase 48 does not require a settings UI.
- **Risk:** Browser users cannot toggle strict undefined-shift validation yet.
- **How to change later:** Add this setting to the future simulator settings/UI schema when that milestone explicitly introduces user-facing settings.

## 6. Design summary

### IR changes

One new opcode was added:

```text
VM_IR_OPCODE_SAR
```

The opcode-name helper was updated so diagnostics, tests, and future debugging output can identify the opcode as:

```text
sar
```

### Parser changes

The parser recognizes `sar` as a binary destination-mutating shift instruction.

Parser behavior:

- Accepts register destinations.
- Accepts direct typed symbols and typed symbol offsets as memory destinations.
- Accepts explicit `BYTE PTR`, `WORD PTR`, and `DWORD PTR` memory forms.
- Accepts signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases by width.
- Accepts immediate byte shift counts.
- Accepts `CL` as the only register count operand.
- Rejects immediate destinations.
- Rejects wrong operand counts.
- Rejects count registers other than `CL`, including `CX`, `ECX`, and general registers such as `EBX`.
- Rejects untyped memory destinations such as `sar [eax], 1` with `ambiguous-memory-width`.
- Preserves existing QWORD/SQWORD executable memory-operation rejection.
- Emits static `.CONST` write diagnostics for direct `.CONST` destinations where existing static detection applies.

### Executor changes

The executor handles `SAR` through an arithmetic-right-shift read-modify-write path.

Execution algorithm:

1. Resolve and validate destination and shift-count operands.
2. Resolve raw count from immediate or `CL`.
3. Compute effective count as `raw_count & 31`.
4. If effective count is zero, return success without mutation.
5. In strict undefined-shift validation mode, detect undefined modeled-flag cases before mutation and emit a runtime error.
6. Read destination value.
7. Save pre-instruction CPU/flag state for rollback on failed writes.
8. Compute the arithmetic right-shifted result at operand width.
9. Update or preserve modeled flags according to Phase 48 rules.
10. Write result back to register or memory destination.
11. If a memory write fails, restore CPU/flag state so no partial mutation is visible.

Memory behavior:

- All memory reads go through checked VM read helpers.
- All memory writes go through checked VM write helpers.
- `.CONST` permission checks remain enforced by final address range.
- Invalid reads occur before write-back.
- Failed writes do not create successful memory-change rows.

### Source-run and diagnostics changes

The source-run path emits default-mode `undefined-shift-flag` warnings before executing SAR instructions that have architecturally undefined modeled flags.

Warning-only runs continue to execute and may end with both:

```text
[simulator-warning] undefined-shift-flag ...
[info] execution-complete: Execution completed successfully.
```

Strict undefined-shift validation instead returns a runtime error and does not execute the offending SAR instruction.

### Documentation and metadata

Updated documentation and metadata to describe Phase 48 as the current implemented milestone and list `sar` as a supported runtime instruction.

## 7. Files changed

Final Phase 48 implementation, compliance, diagnostic-quality, second-review, and gap-check work touched these files across the cumulative milestone work:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_exec.h
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

Review-only cleanup touched:

```text
tests/core/test_parser.c
tests/core/test_wasm_source_run.c
```

## 8. Tests added

### Parser tests

Added or expanded coverage for:

- `sar al, 1`
- `sar ax, 1`
- `sar eax, 1`
- `sar eax, 0`
- `sar eax, 32`
- `sar eax, cl`
- mixed-case `SaR eax, cl`
- `sar BYTE PTR [eax], 1`
- `sar WORD PTR [eax], 1`
- `sar DWORD PTR [eax], 1`
- `sar SBYTE PTR [eax], 1`
- `sar SWORD PTR [eax], 1`
- `sar SDWORD PTR [eax], 1`
- direct typed symbol destinations
- symbol-offset destinations
- immediate destination rejection
- wrong operand count rejection
- missing count rejection
- invalid count-register rejection for `EBX`, `CX`, and `ECX`
- ambiguous memory-width rejection
- QWORD/SQWORD executable memory-operation rejection
- direct `.CONST` write rejection through existing paths

### Executor tests

Added or expanded coverage for:

- `sar al, 1`: `80h -> C0h`, sign-fill, `SF=1`, `OF=0`.
- `sar al, 1`: `01h -> 00h`, `CF=1`, `ZF=1`.
- `sar ax, 1` arithmetic sign-fill behavior.
- `sar eax, 1` arithmetic sign-fill behavior.
- `sar eax, 32` effective-count-zero no-op.
- `sar al, 8` undefined `CF/OF` preservation with result-based `ZF/SF`.
- `sar eax, cl` using low 8 bits of `ECX`.
- alias-width mutation for `AL` and `AX`.
- byte, word, and dword memory read-modify-write success.
- invalid memory destination read failure.
- `.CONST` permission failure.
- no partial mutation on failed memory writes.
- no memory-change rows on failed writes.

### Source-run JSON tests

Added or expanded coverage for:

- successful register acceptance program.
- successful memory destination program.
- default warning-mode undefined shift behavior.
- strict undefined-shift runtime error behavior.
- invalid immediate destination.
- invalid count-register diagnostic.
- wrong operand count diagnostic.
- ambiguous memory-width diagnostic.
- direct `.CONST` assembly diagnostic.
- computed `.CONST` runtime failure.
- invalid memory destination runtime failure.
- phase metadata reporting `48`.

### Rendered Simulator Messages tests

Added or expanded exact rendered-message coverage for:

- successful execution line.
- `ambiguous-memory-width` from `sar [eax], 1`.
- `invalid-instruction-operands` from invalid count register.
- `undefined-shift-flag` default warning from `sar al, 8`.
- `undefined-shift-flag` strict runtime error from `sar al, 8`.
- runtime invalid-address diagnostic for invalid memory destination.

### Regression tests

Regression coverage confirms:

- Existing `shl` and `sal` behavior remains intact.
- Existing `shr` behavior remains intact, including `OF` from the original MSB for count 1 and logical zero-fill behavior.
- Existing strict/default undefined-shift validation remains intact for earlier shift instructions.
- Existing `not`, `and`, `or`, `xor`, `test`, `inc`, `dec`, `neg`, `xchg`, `nop`, `adc`, `sbb`, and carry-control behavior remains intact.
- Existing `.CONST`, object-bounds, uninitialized-read, and invalid-address validation paths remain intact.
- Existing Milestone 42 `exit` behavior remains intact.
- Program Console remains separate from Simulator Messages.

## 9. Commands used to test

Primary aggregate test command:

```sh
cd /mnt/data/repo_m48
python3 scripts/run_tests.py
```

Observed result:

```text
All implemented milestone tests passed.
```

Wasm rebuild check attempted:

```sh
cd /mnt/data/repo_m48
bash scripts/build_wasm.sh
```

Observed result in this container:

```text
scripts/build_wasm.sh: line 18: emcc: command not found
```

Strict-mode manual verification command used during user-test follow-up:

```sh
cd /mnt/data/repo_m48
MASM32_DIAGNOSTIC_SHIFT_VALIDATION=strict build/tests/diagnostic_json_producer /tmp/m48_sar_strict_user_program.asm
```

Observed strict-mode behavior:

```text
ok=false
status=execution-error
kind=runtime-error
code=undefined-shift-flag
EAX remains 00000080h / 128
EFLAGS remains 00000000h / 0
```

## 10. Pass/fail results

Final automated test status:

```text
PASS - native C tests
PASS - parser tests
PASS - executor tests through Milestone 48
PASS - source-run JSON tests through Phase 48 regression coverage
PASS - Node formatter/protocol tests
PASS - rendered Simulator Messages tests
PASS - milestone/static structure tests
PASS - aggregate test runner
SKIPPED/UNAVAILABLE - Wasm rebuild in this container because emcc is not installed
```

Manual user testing status:

```text
PASS - Program 4 default warning behavior matched expected output exactly.
PASS - Program 8 default-mode JSON output was diagnosed as correct default warning-mode behavior.
PASS - Program 8 strict-mode behavior was verified locally when MASM32_DIAGNOSTIC_SHIFT_VALIDATION=strict is active.
```

## 11. Manual/browser testing guidance and expected outputs

Website-testable: yes, after rebuilding Wasm locally with Emscripten.

Windows setup assumptions:

```cmd
emcc --version
py --version
node --version
clang --version
```

Build and serve on Windows:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

Stop server:

```cmd
scripts\windows\stop_web.cmd
```

Local Windows test command:

```cmd
set CC=clang
py scripts\run_tests.py
```

Expected:

```text
All implemented milestone tests passed.
```

### Manual program 1 - SAR sign-fill, count 1

```asm
.code
main PROC
    mov al, 80h
    sar al, 1
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[info] execution-complete: Execution completed successfully.

Final Registers:
EAX    000000C0h / 192
EFLAGS 00000080h / 128

Program Console:
(empty)

Memory Changes:
No memory changes.
```

Regression signs:

- `EAX` becomes `00000040h`, which would indicate logical right shift instead of arithmetic right shift.
- `OF` is not cleared for count 1.

### Manual program 2 - SAR shifts out bit 0 into CF and sets ZF

```asm
.code
main PROC
    mov al, 01h
    sar al, 1
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[info] execution-complete: Execution completed successfully.

Final Registers:
EAX    00000000h / 0
EFLAGS 00000041h / 65

Program Console:
(empty)
```

Regression signs:

- `CF` is not set.
- `ZF` is not set.
- A warning or error appears for count 1.

### Manual program 3 - Effective count zero no-op

```asm
.code
main PROC
    stc
    mov eax, 80000000h
    sar eax, 32
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[info] execution-complete: Execution completed successfully.

Final Registers:
EAX    80000000h / 2147483648
EFLAGS 00000001h / 1

Program Console:
(empty)
```

Regression signs:

- An `undefined-shift-flag` warning appears.
- `EAX` changes.
- `CF` is cleared.

### Manual program 4 - CL count with default warning

```asm
.code
main PROC
    mov eax, 80000000h
    mov ecx, 2
    sar eax, cl
main ENDP
END main
```

Expected:

```text
[simulator-warning] undefined-shift-flag line 5, column 5, byte offset 58, span length 11: SAR count 2 has effective count 2 for a 32-bit destination. CF, ZF, and SF were updated from the result. OF is architecturally undefined because the effective count is greater than 1. The simulator preserved OF deterministically.
[info] execution-complete: Execution completed successfully.

EAX    E0000000h / 3758096384
ECX    00000002h / 2
EFLAGS 00000080h / 128
```

Regression signs:

- No warning appears.
- Execution stops in default mode.
- `EAX` becomes `20000000h`, which would indicate logical right shift.

### Manual program 5 - SAR memory destination

```asm
.data
value DWORD 80000000h
.code
main PROC
    sar value, 1
main ENDP
END main
```

Expected:

```text
Simulator Messages:
[info] execution-complete: Execution completed successfully.

Memory Changes:
value: 80000000h / 2147483648 -> C0000000h / 3221225472

Program Console:
(empty)
```

Regression signs:

- No memory change appears.
- New value is `40000000h`, which would indicate logical right shift.
- A direct typed symbol destination is incorrectly rejected as ambiguous.

### Manual program 6 - Ambiguous memory width rejection

```asm
.code
main PROC
    mov eax, 0
    sar [eax], 1
main ENDP
END main
```

Expected:

```text
[assembly-error] ambiguous-memory-width line 4, column 9, byte offset 39, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Regression signs:

- Program executes.
- Diagnostic says unsupported syntax instead of ambiguous memory width.
- Diagnostic points to the wrong line.

### Manual program 7 - Invalid count register rejection

```asm
.code
main PROC
    sar eax, ebx
main ENDP
END main
```

Expected:

```text
[assembly-error] invalid-instruction-operands line 3, column 14, byte offset 29, span length 3: SAR count must be an immediate byte count or CL.
```

Regression signs:

- `EBX`, `CX`, or `ECX` is accepted as a count register.
- Error wording does not identify the accepted count forms.

### Manual program 8 - Strict undefined-shift validation

Save as `program.asm` at the project root:

```asm
.code
main PROC
    mov al, 80h
    sar al, 8
main ENDP
END main
```

Windows CMD strict-mode command:

```cmd
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=
set MASM32_DIAGNOSTIC_LAYOUT_MODE=
set MASM32_DIAGNOSTIC_SHIFT_VALIDATION=strict
echo %MASM32_DIAGNOSTIC_SHIFT_VALIDATION%
build\tests\diagnostic_json_producer.exe program.asm
set MASM32_DIAGNOSTIC_SHIFT_VALIDATION=
```

The `echo` line must print:

```text
strict
```

Expected strict JSON fields:

```text
"phase":48
"ok":false
"status":"execution-error"
"kind":"runtime-error"
"code":"undefined-shift-flag"
EAX remains 00000080h / 128
EFLAGS remains 00000000h / 0
No execution-complete message.
```

Regression signs:

- Strict mode returns `ok=true`.
- `EAX` changes from `00000080h`.
- An `execution-complete` message appears.

## 12. Compliance review summary

The first compliance review checked scope control, completeness, code quality, diagnostics, tests, and documentation.

Findings:

- No scope violations were found.
- No accidental future milestone behavior was found.
- No C99/core-language violations were found.
- No missing rendered Simulator Messages coverage was found for SAR diagnostics and warnings.
- One documentation-only issue was found: two Milestone 45 NOT parser regression comments still said "Phase 47 regression" after Phase 48 was implemented.

Fix applied:

- Updated those parser-test comments to "Phase 48 regression."

Tests rerun:

```sh
cd /mnt/data/repo_m48
python3 scripts/run_tests.py
```

Result:

```text
All implemented milestone tests passed.
```

## 13. Re-review summary

The second compliance review rechecked Phase 48 guide requirements, changed code, changed docs, assumptions, tests, rendered diagnostics, stale wording, line endings, and accidental future work.

Additional findings:

- `tests/core/test_parser.c` had been converted from CRLF to LF during the prior review, creating a noisy full-file diff.
- Three Phase 47 SHR source-run regression comments/assertion labels were incorrectly worded as "Phase 48 SHR," which could confuse future milestone review.

Fixes applied:

- Restored CRLF line endings for `tests/core/test_parser.c`.
- Reworded SHR source-run comments/assertion labels to "Phase 47 SHR ... as a Phase 48 regression."

Tests rerun:

```sh
cd /mnt/data/repo_m48
python3 scripts/run_tests.py
```

Result:

```text
All implemented milestone tests passed.
```

Final re-review verdict:

```text
Scope: complete
Documentation: complete
Test coverage: complete
```

## 14. User-test follow-up summary

User manual test results were reviewed.

### Program 4

User-observed output:

```text
[simulator-warning] undefined-shift-flag line 5, column 5, byte offset 58, span length 11: SAR count 2 has effective count 2 for a 32-bit destination. CF, ZF, and SF were updated from the result. OF is architecturally undefined because the effective count is greater than 1. The simulator preserved OF deterministically.
[info] execution-complete: Execution completed successfully.

EAX    E0000000h / 3758096384
ECX    00000002h / 2
EFLAGS 00000080h / 128
```

Diagnosis:

- Expected behavior. The output matched the documented Phase 48 default warning-mode behavior exactly.

### Program 8

User-observed JSON output used default warning mode:

```text
ok=true
status=ok
EAX=000000FFh
simulator-warning undefined-shift-flag
execution-complete
```

Diagnosis:

- The output was correct for default warning mode.
- The discrepancy was a manual invocation/environment issue, not an implementation bug.
- Strict mode requires the native diagnostic producer process to see:

```cmd
set MASM32_DIAGNOSTIC_SHIFT_VALIDATION=strict
```

Fix:

- No source-code fix was needed.
- Manual instructions were corrected to include an `echo` check confirming that the strict environment variable is active.

Local strict-mode verification passed with:

```sh
MASM32_DIAGNOSTIC_SHIFT_VALIDATION=strict build/tests/diagnostic_json_producer /tmp/m48_sar_strict_user_program.asm
```

Observed strict behavior:

```text
ok=false
status=execution-error
kind=runtime-error
code=undefined-shift-flag
EAX remains 00000080h / 128
EFLAGS remains 00000000h / 0
```

No implementation bug was found during user-test triage.

## 15. Known limitations

- This environment cannot rebuild Wasm because Emscripten is not installed.
- Served website behavior requires a local Wasm rebuild in an Emscripten-enabled environment.
- Strict undefined-shift validation is available through test/API configuration only; no browser UI toggle exists yet.
- PF and AF remain unmodeled.
- Executable QWORD/SQWORD memory operations remain unsupported in MASM32 Educational Mode.
- No rotate instructions are implemented yet.
- Program Console input/output routines remain future work.
- Browser manual testing depends on the rebuilt Wasm artifact matching the updated C implementation.

## 16. Next recommended milestone

Next recommended milestone:

```text
Phase 49 - ROL
```

Do not implement Phase 49 until the next session explicitly targets it.

## 17. Changed-files ZIP/package produced

Changed-files packages produced during Milestone 48:

```text
/mnt/data/milestone48_changed_files.zip
/mnt/data/milestone48_compliance_review_changed_files.zip
/mnt/data/milestone48_second_review_changed_files.zip
```

Latest valid package:

```text
/mnt/data/milestone48_second_review_changed_files.zip
```

Recommended next repository archive name after applying the final package:

```text
Latest_repository_state_milestone_48.zip
```

## 18. Final status

Milestone 48 is complete.

It implements the requested milestone only, includes tests for success/error/edge/regression paths, updates documentation and static checks, includes rendered Simulator Messages tests for user-visible diagnostics/warnings, passed the aggregate native/Node test suite, and was manually triaged after user testing.

