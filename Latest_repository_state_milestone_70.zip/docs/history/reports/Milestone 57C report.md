# Milestone 57C report - Diagnostic Policy Registry Design

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57C - Diagnostic Policy Registry Design
```

Repository/archive milestone:

```text
Phase 57C - Diagnostic Policy Registry Design
```

Runtime/source-run MASM behavior phase:

```text
Phase 57 - Signed IDIV
```

Status interpretation:

The repository/archive milestone is newer than the runtime/source-run MASM behavior phase because this target phase did not add MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser controls, browser layout, browser interaction behavior, diagnostic codes, diagnostic JSON fields, or rendered Simulator Messages wording. Do not update runtime/source-run phase metadata, supported-syntax runtime wording, or tests that assert runtime phase values unless the current target phase explicitly owns that change.

Scope implemented:

- Added a behavior-preserving C99 diagnostic-policy registry skeleton.
- Added a central diagnostic-policy value vocabulary:
  - `off`
  - `warn`
  - `error`
- Added central diagnostic-policy family identifiers and stable family names for:
  - `uninitialized-read`
  - `undefined-flag-use`
  - `compatibility-notice`
  - `const-uninitialized-storage`
  - `startup-state-notice`
  - `code-image-read`
- Marked existing diagnostic-policy families as implemented/current registry entries without routing current diagnostic behavior through the registry yet.
- Marked future diagnostic-policy families as reserved/inactive so they are discoverable by name without activating future behavior.
- Added exact parse/format helpers for central policy values and family names.
- Added registry metadata helpers for family lookup, count, default values, and reserved/inactive status.
- Added C99 native unit tests for the new registry module.
- Updated native build scripts, the aggregate test runner, and static checks to include the new module and tests.
- Updated current-status documentation so repository/archive status reflects Phase 57C while runtime/source-run MASM behavior remains Phase 57 - Signed IDIV.

This milestone is backend architecture and test scaffolding only. It intentionally preserves every existing user-visible diagnostic, source-run setting, browser setting, worker protocol behavior, and runtime execution behavior.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57B report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_57B.zip
```

Changed-files packages produced during this milestone:

```text
milestone_57C_changed_files.zip
milestone_57C_compliance_review_changed_files.zip
```

No full latest repository archive was produced during this milestone-report step. The recommended archive name after applying the changed-files package and accepting the milestone is:

```text
Latest_repository_state_milestone_57C.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, stable cross-cutting rules, current/future/non-goal distinctions, and product-level diagnostic/status policy.
- The implementation guide owns phase numbering, phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 57C is the only target milestone for this implementation session.
- TODO-style notes are implementation-risk evidence only and do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- User-visible diagnostics remain structured and have rendered Simulator Messages coverage where behavior exists.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, WinAPI simulator, host include loader, or macro assembler.

## 3. Exact requirements implemented

### 3.1 Central diagnostic-policy value vocabulary

Implemented the central policy-value enum:

```text
VM_DIAGNOSTIC_POLICY_VALUE_OFF
VM_DIAGNOSTIC_POLICY_VALUE_WARN
VM_DIAGNOSTIC_POLICY_VALUE_ERROR
```

Implemented exact lowercase formatting:

```text
off
warn
error
```

Implemented exact lowercase parsing for those same strings.

Important behavior-preservation detail:

- `strict` is intentionally not accepted by the central Phase 57C vocabulary.
- Existing UI/source-run concepts such as "strict stop" remain in their existing settings paths until a future migration phase maps them explicitly to central registry values.
- The Phase 57C registry therefore avoids silently changing existing source-run, worker, or UI setting semantics.

### 3.2 Central diagnostic-policy family identifiers

Implemented the central policy-family enum and names:

```text
VM_DIAGNOSTIC_POLICY_FAMILY_UNINITIALIZED_READ          -> uninitialized-read
VM_DIAGNOSTIC_POLICY_FAMILY_UNDEFINED_FLAG_USE         -> undefined-flag-use
VM_DIAGNOSTIC_POLICY_FAMILY_COMPATIBILITY_NOTICE       -> compatibility-notice
VM_DIAGNOSTIC_POLICY_FAMILY_CONST_UNINITIALIZED_STORAGE -> const-uninitialized-storage
VM_DIAGNOSTIC_POLICY_FAMILY_STARTUP_STATE_NOTICE       -> startup-state-notice
VM_DIAGNOSTIC_POLICY_FAMILY_CODE_IMAGE_READ            -> code-image-read
```

Implemented exact lowercase/hyphenated parsing and formatting for every Phase 57C family.

Invalid or out-of-scope names are rejected, including:

```text
section-image
UNINITIALIZED-READ
```

### 3.3 Family state metadata

Implemented a family-state enum:

```text
VM_DIAGNOSTIC_POLICY_FAMILY_STATE_IMPLEMENTED
VM_DIAGNOSTIC_POLICY_FAMILY_STATE_RESERVED_INACTIVE
```

Implemented metadata for existing/current families:

```text
uninitialized-read       state: implemented, current default: warn
undefined-flag-use       state: implemented, current default: warn
compatibility-notice     state: implemented, current default: warn
```

Implemented reserved/inactive metadata for future families:

```text
const-uninitialized-storage  state: reserved/inactive, no current default
startup-state-notice         state: reserved/inactive, no current default
code-image-read              state: reserved/inactive, no current default
```

This satisfies Phase 57C's requirement to identify future families while preventing accidental behavior activation.

### 3.4 Registry helper API

Added these public C99 helpers:

```text
vm_diagnostic_policy_value_name
vm_diagnostic_policy_parse_value
vm_diagnostic_policy_family_name
vm_diagnostic_policy_parse_family
vm_diagnostic_policy_family_info
vm_diagnostic_policy_family_count
vm_diagnostic_policy_family_is_reserved
```

All new public types and functions have Doxygen-style `///` comments. New source and header files have file-level block comments.

### 3.5 Behavior preservation

Preserved existing behavior:

- no diagnostic routing migrated to the registry;
- no source-run setting schema changes;
- no worker protocol changes;
- no browser Diagnostic settings UI changes;
- no new diagnostic codes;
- no new diagnostic JSON fields;
- no rendered Simulator Messages wording changes;
- no Program Console changes;
- no MASM syntax changes;
- no parser behavior changes;
- no executor or VM behavior changes;
- no runtime/source-run MASM behavior phase advancement.

### 3.6 Build and test integration

Updated the native test runner and build scripts so the new module is compiled and tested:

- `scripts/run_tests.py`
- `scripts/build_wasm.sh`
- `scripts/windows/build_wasm.cmd`

The new test binary is included in the native focused group.

### 3.7 Documentation/status updates

Updated current status documentation to distinguish:

```text
Repository/archive milestone:
Phase 57C - Diagnostic Policy Registry Design

Runtime/source-run MASM behavior phase:
Phase 57 - Signed IDIV
```

Updated documentation to describe Phase 57C as behavior-preserving scaffolding, not a user-visible settings or diagnostic behavior change.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57C:

- Phase 57D - Existing Diagnostic Policy Migration.
- Migration of existing source-run/browser settings to registry-backed lookup.
- New source-run JSON setting fields.
- New worker protocol fields.
- New browser Diagnostic settings controls.
- Any new user-visible diagnostic code or message.
- Any rendered Simulator Messages wording change.
- Any Program Console output change.
- Any MASM syntax, parser, VM, executor, memory, or instruction behavior change.
- `.CONST ?` compatibility.
- `.CONST DUP(?)` compatibility.
- `const-uninitialized-storage` warnings or errors.
- Startup-state notices.
- Startup randomized-state behavior.
- `.code` memory-read policy.
- `.code` memory-access denial.
- `.code` protected-region overlap behavior.
- Changes to planned-read collection for future memory-reading opcodes.
- Section-capacity, section-image, or declared-object validation changes.
- New manual browser-visible functionality.

Future work intentionally deferred:

- Phase 57D should migrate existing diagnostic settings onto the registry if the guide requires it.
- Later diagnostic-family phases may activate reserved families one at a time.
- Future `.code` memory-access-denial phases may use the reserved `code-image-read` family and the existing protected-region TODO guidance.

## 5. Assumptions used

### Assumption 1

- **Assumption:** The registry should be implemented as a new small C99 core module rather than added to `vm_exec`, `vm_memory`, `wasm_api`, or browser settings code.
- **Reason:** Phase 57C requires shared policy-family metadata without migrating current behavior. A dedicated module keeps the registry independent and reusable by later parser, runtime, Wasm, and UI migration phases.
- **Risk:** The module is lightly integrated in Phase 57C and could appear unused outside tests.
- **How to change later:** Phase 57D can route existing policy lookups through this module and add adapter helpers while preserving the central vocabulary.

### Assumption 2

- **Assumption:** Existing families should be registered as implemented/current, while future families should be registered as reserved/inactive.
- **Reason:** The guide requires both existing and planned family names. Marking future families inactive prevents accidental behavior activation while allowing tests and future code to discover the reserved names.
- **Risk:** `implemented` could be misread as meaning the family is already routed through the registry.
- **How to change later:** A later migration phase can add a separate migration/routing status field if needed, or clarify comments further when existing settings are migrated.

### Assumption 3

- **Assumption:** The central policy value parser should accept only `off`, `warn`, and `error`.
- **Reason:** Phase 57C defines this common vocabulary. Existing `strict stop` UI wording and prior strict-mode source-run settings are legacy/interface terminology and should not be silently accepted by the central registry before migration.
- **Risk:** Future migration code must explicitly map `strict`/`strict stop` to the central `error` value.
- **How to change later:** Phase 57D can add compatibility adapter helpers that translate existing public setting values to central policy values without changing the central vocabulary.

### Assumption 4

- **Assumption:** Phase 57C should not add source-run setting schema fields, worker protocol fields, or browser controls.
- **Reason:** The guide makes this a registry-design milestone and explicitly excludes UI controls and public behavior changes.
- **Risk:** The browser and source-run settings remain on existing code paths until Phase 57D or a later phase.
- **How to change later:** A later migration/settings phase can expose registry-backed settings while preserving backward compatibility and existing defaults.

### Assumption 5

- **Assumption:** Repository/archive status advances to Phase 57C while runtime/source-run MASM behavior remains Phase 57.
- **Reason:** Phase 57C changes backend architecture and documentation only; it does not add MASM/source execution behavior.
- **Risk:** Future status checks may confuse repository/archive milestone with runtime/source-run behavior phase.
- **How to change later:** Runtime/source-run metadata should advance only in a future phase that explicitly changes runtime-visible MASM/source behavior or public schema/status fields.

## 6. Relevant TODO-style notes reviewed

### TODO note 1

- **Location:** `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` protected-region guidance around future `.code` memory-access-denial phases.
- **Note text or summary:** Future `.code` memory-access-denial phases should reuse the `region-boundary-crossing` diagnostic shape and runtime `.code` base metadata. They must not hardcode fixed-layout addresses.
- **Classification:** future-owned.
- **Reason:** Phase 57C may reserve `code-image-read` as an inactive diagnostic-policy family, but it does not own `.code` access denial or `.code` read policy behavior.
- **Action for this milestone:** Preserved. The registry includes `code-image-read` only as a reserved/inactive family.

### TODO note 2

- **Location:** `src/core/vm_memory.c`
- **Note text or summary:** Generalize `.CONST` protected-region overlap handling when future milestones make `.code` memory access-denying.
- **Classification:** future-owned.
- **Reason:** This is future protected-region diagnostic behavior. Phase 57C is registry scaffolding only.
- **Action for this milestone:** Preserved unchanged. No `.code` memory-access behavior was implemented.

### TODO note 3

- **Location:** `src/wasm/wasm_api.c`
- **Note text or summary:** Add each future memory-reading opcode to planned-read collection when that opcode is implemented.
- **Classification:** future-owned.
- **Reason:** Phase 57C adds no memory-reading opcode and does not change planned-read collection.
- **Action for this milestone:** Preserved unchanged.

### TODO note 4

- **Location:** `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` future display guidance.
- **Note text or summary:** A future display phase may add a TODO if write-tracking is unavailable for unchanged-register display markers.
- **Classification:** irrelevant-to-target.
- **Reason:** This belongs to a later display/formatter phase, not diagnostic-policy registry design.
- **Action for this milestone:** Ignored for implementation.

## 7. TODO-style note disposition

- **Target-owned TODO-style notes resolved:** None found.
- **Future-owned TODO-style notes intentionally preserved:** Future `.code` protected-region/access-denial notes and future planned-read opcode note were preserved.
- **Stale or contradicted TODO-style notes corrected:** None found.
- **Unresolved TODO-related risks:** Future `.code` notes remain broad. The Phase 57C implementation reduces accidental-scope risk by keeping `code-image-read` reserved/inactive and by not implementing `.code` read/access-denial behavior.
- **New TODO-style notes added:** None.

## 8. Design summary

The implementation adds a single C99 registry module:

```text
src/core/vm_diagnostic_policy.h
src/core/vm_diagnostic_policy.c
```

The module centralizes two concepts:

1. A common policy-value vocabulary for optional teaching diagnostics:

   ```text
   off
   warn
   error
   ```

2. A stable family registry for current and future optional diagnostic families.

The registry is table-driven. Each family entry stores:

- enum identifier;
- stable lowercase hyphenated name;
- current family state;
- whether a current default value exists;
- current default value when applicable.

The implementation deliberately separates **family existence** from **behavior activation**. Future families are known by name but reserved/inactive, so future phases can refer to the same stable names without turning behavior on in Phase 57C.

The existing diagnostic systems remain on their prior paths:

- uninitialized-read diagnostics;
- undefined-flag-use diagnostics;
- compatibility notices;
- browser settings normalization;
- worker/source-run settings routing.

This keeps Phase 57C narrow and behavior-preserving while preparing for future migration.

## 9. Files changed

Source files added:

- `src/core/vm_diagnostic_policy.h`
- `src/core/vm_diagnostic_policy.c`

Test files added:

- `tests/core/test_diagnostic_policy.c`

Build/test integration changed:

- `scripts/run_tests.py`
- `scripts/build_wasm.sh`
- `scripts/windows/build_wasm.cmd`

Documentation/status files changed:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

## 10. Tests added

Added native C test coverage in:

```text
tests/core/test_diagnostic_policy.c
```

Coverage added:

- Successful policy value formatting:
  - `off`
  - `warn`
  - `error`
- Successful policy value parsing:
  - `off`
  - `warn`
  - `error`
- Invalid policy value rejection:
  - empty string;
  - `strict`;
  - `on`;
  - uppercase input;
  - `NULL` input;
  - `NULL` output pointer;
  - out-of-range enum formatting.
- Successful family formatting for all Phase 57C family names.
- Successful family parsing for all Phase 57C family names.
- Unknown/out-of-scope family rejection:
  - empty string;
  - `section-image`;
  - uppercase input;
  - `NULL` input;
  - `NULL` output pointer;
  - out-of-range enum formatting and metadata lookup.
- Implemented/current family metadata:
  - `uninitialized-read` default `warn`;
  - `undefined-flag-use` default `warn`;
  - `compatibility-notice` default `warn`.
- Reserved/inactive family metadata:
  - `const-uninitialized-storage`;
  - `startup-state-notice`;
  - `code-image-read`.
- Table-integrity tests:
  - registry family count matches enum count;
  - every enum has metadata;
  - every metadata entry has a non-empty name;
  - family names are unique.

No new rendered Simulator Messages tests were required because Phase 57C adds no new UI-visible diagnostic or warning path.

## 11. Commands used to test

### Focused group commands

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed results:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Aggregate command

```bash
python3 scripts/run_tests.py --all
```

Observed result:

```text
All implemented milestone tests passed.
```

The aggregate command completed and returned the final success status in the assistant/container environment.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because Emscripten was unavailable:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

No subgroup or fixture-family reruns were required because the aggregate command completed and focused groups passed.

## 12. Pass/fail result classification

- **Aggregate completed and passed:** Yes.
- **Aggregate timed out but focused groups passed:** No.
- **Aggregate failed:** No.
- **Focused group failed:** No.
- **Focused group timed out and was rerun by subgroup/fixture:** No.
- **Group skipped because a dependency was unavailable:** Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

Final test classification:

```text
aggregate completed and passed
```

Dependency note:

```text
emcc unavailable; browser/Wasm rebuild smoke skipped
```

## 13. Manual/browser testing guidance and expected outputs

Phase 57C is backend-only registry scaffolding. It is not directly testable with a MASM program in the served website.

Website-testable:

```text
no
```

Local-test-only:

```text
yes
```

`program.asm` applicability:

```text
program.asm is not applicable
```

Windows CMD setup assumptions:

- Use Visual Studio Developer Command Prompt or a CMD session with C compiler tooling available.
- `py -3` should run Python 3.
- Node.js should be available for web/protocol/diagnostic renderer tests.
- Emscripten is optional for Phase 57C and may be skipped.

Recommended Windows CMD commands from the repository root:

```bat
py -3 scripts\run_tests.py --native
py -3 scripts\run_tests.py --static
py -3 scripts\run_tests.py --all
```

Expected output snippets:

```text
[native] PASS - native C non-source-run tests passed
[static] PASS - runner/documentation consistency checks passed
All implemented milestone tests passed.
```

If Emscripten is unavailable, this expected skip may appear:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Regression signs:

- Any focused group reports `FAIL`.
- The aggregate command does not end with `All implemented milestone tests passed.`.
- Source-run/browser runtime metadata changes from Phase 57 to Phase 57C.
- Browser Diagnostic settings UI changes.
- Existing Simulator Messages wording changes.
- `strict` is accepted as a central registry policy value.
- Reserved families such as `code-image-read`, `startup-state-notice`, or `const-uninitialized-storage` become active runtime behavior.

## 14. Compliance review summary

First compliance review result:

- No compliance-blocking issues found.
- Scope remained limited to Phase 57C.
- No future milestone behavior was implemented.
- Existing diagnostics, rendered Simulator Messages, source-run defaults, protocol behavior, browser UI behavior, and runtime/source-run MASM behavior metadata remained unchanged.
- Core remained C99-only.
- New source/header/test files had file-level block comments.
- New public types/functions and internal test helpers were documented with Doxygen-style comments.
- Build scripts and aggregate runner included the new C module/test.
- No fixes were required.

Tests rerun during compliance review:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Result:

```text
All implemented milestone tests passed.
```

## 15. Re-review summary

Second compliance/re-review result:

- No missed Phase 57C requirements were found.
- No stale comments were found.
- No incomplete Doxygen coverage was found.
- No test gaps were found for the Phase 57C scope.
- No accidental future-milestone behavior was found.
- No contradictions with the spec/guide were found.
- Reserved families remained inactive.
- Runtime/source-run MASM behavior metadata remained Phase 57 - Signed IDIV.
- No additional fixes were required.

Final gap-check result:

- No missing work found.
- No target-owned TODO-style note remained unresolved.
- No stale TODO-style note was introduced.
- No stale generated artifact issue was found.
- No full latest repository archive was produced, so `Latest_repository_state_milestone_57C.zip` remains the recommended archive name after acceptance rather than a produced artifact.

## 16. User-test follow-up summary

Prompt 8 user-test triage was skipped because no user-reported discrepancy was provided after manual testing guidance.

No user-test fixes were applied.

## 17. Known limitations

- Existing diagnostic settings are not yet routed through the registry. This is intentional and belongs to Phase 57D - Existing Diagnostic Policy Migration.
- Browser UI and worker protocol still use existing settings paths.
- The registry does not expose new public source-run JSON setting fields.
- Reserved families do not activate behavior.
- `const-uninitialized-storage`, `startup-state-notice`, and `code-image-read` are names only in Phase 57C.
- Browser/Wasm rebuild smoke was skipped in the assistant/container environment because `emcc` was unavailable.
- A full latest repository archive was not produced during this report step; only changed-files packages were produced.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57D - Existing Diagnostic Policy Migration
```

Expected Phase 57D direction:

- migrate existing diagnostic policy settings onto the Phase 57C registry;
- preserve existing defaults and public behavior unless Phase 57D explicitly requires a change;
- continue keeping reserved future families inactive until their owning phases.

## 19. Changed-files ZIP/package produced

Changed-files packages produced:

```text
milestone_57C_changed_files.zip
milestone_57C_compliance_review_changed_files.zip
```

The compliance-review package is the current changed-files package to apply:

```text
milestone_57C_compliance_review_changed_files.zip
```

Recommended full archive name after applying the changed-files package and accepting this milestone:

```text
Latest_repository_state_milestone_57C.zip
```
