# Milestone 57T report - Playground Program Diagnostic-Recovery Smoke Fixtures

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57T - Playground Program Diagnostic-Recovery Smoke Fixtures
```

Repository/archive milestone after this work:

```text
Phase 57T - Playground Program Diagnostic-Recovery Smoke Fixtures
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 57S - Unsupported High-Level Flow Diagnostics
```

Status interpretation:

The repository/archive milestone is newer than the runtime/source-run MASM behavior phase because Phase 57T added diagnostic-recovery smoke fixtures, documentation, and status-surface/test-runner coverage. It did not add MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser controls, browser layout, browser interaction behavior, new diagnostic codes, new diagnostic JSON fields, or new rendered Simulator Messages categories. Runtime/source-run metadata therefore remains Phase 57S.

Scope implemented:

- Added realistic MASM32 playground-program diagnostic-recovery smoke coverage.
- Verified that common AI/tutorial-style MASM32 source containing host include paths, `INCLUDELIB`, `INVOKE`, `ADDR`, MASM32 runtime-style names, CRT routine names, high-level MASM flow, `CALL`, `RET`, `CMP`, conditional jumps, and WinAPI/external routine names produces concise Simulator Messages diagnostics.
- Verified those diagnostics do not collapse into repeated path-character lexer diagnostics or a generic `lexer-failed` diagnostic.
- Verified diagnostics refuse execution before runtime begins.
- Verified no Program Console output is produced for these assembly-diagnostic failures.
- Verified no `execution-complete` message appears for these failures.
- Updated repository/archive status surfaces to Phase 57T while preserving runtime/source-run MASM behavior metadata at Phase 57S.
- Updated documentation to explain realistic playground-code diagnostics without promising unsupported future behavior.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status and verification files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57S report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_57S.zip
```

Repository archive recommended after implementation:

```text
Latest_repository_state_milestone_57T.zip
```

A full latest repository archive was not produced during this session. Changed-files packages were produced and are listed in Section 19.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, and current-status surface hygiene.
- The incremental implementation guide owns phase numbering, target milestone scope, per-phase tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only. They do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

## 3. Exact requirements implemented

### 3.1 Realistic playground diagnostic-recovery smoke fixture

Added source-run coverage for a realistic trimmed MASM32 playground program containing:

- `.386`
- `.model flat, stdcall`
- `option casemap:none`
- host/path-like MASM32 include paths such as `\masm32\include\masm32.inc`
- host/path-like Windows include paths such as `\masm32\include\kernel32.inc`
- `INCLUDELIB` entries for MASM32 and Windows import libraries
- data declarations and labels used by the sample
- `INVOKE StdOut, ADDR ...`
- `INVOKE crt_printf, ADDR ...`
- basic implemented instructions such as `mov`, `and`, and `inc`
- `.IF` / `.ELSE` / `.ENDIF`
- unsupported `CALL`

The fixture confirms that the parser/source-run path emits useful high-level unsupported diagnostics and does not stop at low-level path-token noise.

### 3.2 Source-run checks for no execution and no console output

The source-run test verifies:

- the playground fixture returns unsuccessful source-run status;
- diagnostics include expected unsupported families;
- `execution-complete` is absent;
- `programConsole` is absent;
- `unexpected-character` is absent;
- `lexer-failed` is absent;
- wording does not imply probing for missing local files.

### 3.3 Diagnostic-family coverage

The source-run fixture verifies these diagnostic families or stable current equivalents:

- `unsupported-masm32-library-include`
- `unsupported-windows-api-include`
- `unsupported-masm32-library`
- `unsupported-windows-api-library`
- `unsupported-invoke`
- `unsupported-addr`
- `unsupported-masm32-runtime-routine`
- `unsupported-crt-routine`
- `unsupported-high-level-if`
- `unsupported-high-level-else`
- `unsupported-high-level-endif`
- current `unsupported-instruction` behavior for unsupported `CALL`

### 3.4 Smaller fixture-family coverage

Added smaller source-run smoke fixtures for unsupported constructs that the trimmed playground fixture cannot all reach after the first unsupported low-level instruction:

- `CALL`
- `RET`
- `CMP`
- conditional jump `JL`
- WinAPI/external `ExitProcess` under `INCLUDE Irvine32.inc`

These fixtures verify no execution, no Program Console output, no `execution-complete`, and expected current diagnostic classifications.

### 3.5 Rendered Simulator Messages tests

Added exact rendered Simulator Messages tests for:

- realistic playground diagnostics;
- unsupported `RET` diagnostic;
- unsupported `CMP` diagnostic;
- unsupported conditional-jump diagnostic;
- `ExitProcess` WinAPI boundary diagnostic.

These tests use the existing browser Simulator Messages formatter harness, preserving exact user-visible wording.

### 3.6 `INCLUDELIB` non-goal wording retention

The playground fixture verifies `INCLUDELIB` diagnostics retain Phase 57Q non-goal wording:

```text
INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines.
```

This prevents future regressions that might misclassify `INCLUDELIB` as host include loading or imply the simulator should link `.lib` files.

### 3.7 Status-surface updates

Updated repository/archive status to:

```text
Phase 57T - Playground Program Diagnostic-Recovery Smoke Fixtures
```

Kept runtime/source-run MASM behavior metadata at:

```text
Phase 57S - Unsupported High-Level Flow Diagnostics
```

Updated or checked status-bearing surfaces including:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `web/index.html`
- static status checks in `scripts/run_tests.py`

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57T:

- Real host include-file loading.
- `INCLUDELIB` linking.
- Object-file loading or linking.
- PE imports or Windows loader behavior.
- Windows API execution.
- Executable `INVOKE`.
- `ADDR` lowering.
- Procedure argument lowering.
- Calling-convention setup.
- Executable `CALL`.
- Executable `RET`.
- Executable `CMP`.
- Executable conditional jumps such as `JL`.
- Any other branch/jump/control-flow execution behavior.
- High-level `.IF`, `.ELSE`, `.ENDIF`, `.WHILE`, `.REPEAT`, `.BREAK`, or `.CONTINUE` execution.
- High-level-flow condition parsing or expression evaluation.
- Stack/procedure runtime behavior.
- Macro expansion.
- Irvine32 routine execution beyond already-implemented virtual `exit` behavior.
- Browser UI controls or settings.
- New diagnostic codes beyond the existing Phase 57P through Phase 57S diagnostic families and existing current unsupported-instruction behavior.

Future work intentionally preserved:

- Phase 58 - Code Label Table and Label Diagnostics.
- Later real control-flow and branch instruction milestones.
- Later stack, procedure, call/return, and calling-convention milestones.
- Later high-level-flow parsing/lowering and debugger/source-map phases.
- Later Irvine32 routine implementation phases.
- Later macro and MASM compatibility phases.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 57T should be implemented primarily by adding tests, documentation, and repository/archive status updates, not parser/runtime behavior.
- **Reason:** The guide defines Phase 57T as playground diagnostic-recovery fixture coverage and documentation. It explicitly forbids implementing the unsupported features in the playground program.
- **Risk:** A realistic fixture could expose an existing diagnostic-recovery defect that might require a narrow parser diagnostic fix.
- **How to change later:** If a future defect is found, implement the smallest diagnostic-only correction in the owning milestone and document whether runtime/source-run metadata remains Phase 57S or advances.

### Assumption 2

- **Assumption:** Runtime/source-run MASM behavior phase metadata should remain Phase 57S.
- **Reason:** Phase 57T did not add MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser behavior, new diagnostic codes, or new rendered-message categories.
- **Risk:** A reader may initially expect all status surfaces to advance to 57T.
- **How to change later:** Advance runtime/source-run metadata only in a future phase that actually changes runtime-visible MASM/source behavior or explicitly owns such metadata advancement.

### Assumption 3

- **Assumption:** A trimmed realistic playground fixture plus smaller exact fixtures is preferable to one oversized fixture for all unsupported features.
- **Reason:** The guide allows splitting large playground coverage into named smaller fixtures to keep line, column, byte offset, and span assertions maintainable.
- **Risk:** The split fixture family is less visually identical to one full AI-generated playground sample.
- **How to change later:** Add a broader smoke-only fixture later while retaining smaller exact fixtures for stable source-location assertions.

### Assumption 4

- **Assumption:** Existing `unsupported-instruction` classification is acceptable for `CALL`, `RET`, `CMP`, and `JL` in Phase 57T.
- **Reason:** Phase 57T permits stable current equivalents and does not require new diagnostic codes for those future instruction families.
- **Risk:** Future users may prefer more specific diagnostics for control-flow or procedure instructions.
- **How to change later:** A future diagnostic-quality phase or the relevant implementation phase can add dedicated classifications and update exact rendered-message tests deliberately.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can remain skipped in this environment when `emcc` is unavailable.
- **Reason:** The existing runner reports `emcc` unavailability as a dependency skip, and Phase 57T does not change Wasm behavior.
- **Risk:** Served browser artifacts must still be rebuilt locally or in CI if a distribution package is prepared.
- **How to change later:** Run `scripts\windows\build_wasm.cmd` on Windows or the equivalent shell script in an Emscripten environment, then retest the served website.

## 6. Relevant TODO-style notes reviewed

Target-owned TODO-style notes and TODO-style evidence reviewed:

- Phase 57T guide requirements for realistic playground diagnostic-recovery smoke fixtures.
- Phase 57T guide requirements to avoid low-level path-character diagnostic floods.
- Phase 57T guide requirements to verify no `lexer-failed` collapse.
- Phase 57T guide requirements to verify no Program Console output and no `execution-complete` message.
- Phase 57T guide requirements to preserve `INCLUDELIB` linker/import-library non-goal wording.
- Phase 57T fixture-size guidance allowing smaller fixture families.
- Full-spec realistic playground recovery policy.

Future-owned TODO-style notes reviewed and intentionally not implemented:

- Future memory-reading opcode TODO in `src/wasm/wasm_api.c`.
- Deferred high-level-flow condition/expression parsing notes in parser code/comments.
- Later stack/procedure/control-flow/Irvine32/macro/debugger roadmap notes.

Broad TODO-style categories reviewed and excluded as irrelevant to Phase 57T:

- Future debugger/editor/share/URL work.
- Future stack and heap runtime behavior.
- Future QWORD/SQWORD execution.
- Future scaled-index memory operands.
- Historical milestone-report wording and generated artifacts.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 57T playground diagnostic-recovery smoke fixture coverage was added.
- Phase 57T no path-character diagnostic flood coverage was added.
- Phase 57T no generic `lexer-failed` coverage was added.
- Phase 57T `INCLUDELIB` non-goal wording coverage was added.
- Phase 57T documentation/status updates were completed.

### Future-owned TODO-style notes intentionally preserved

- Future memory-reading opcode TODO in `src/wasm/wasm_api.c` remains future-owned.
- Deferred high-level-flow condition/expression parsing notes remain future-owned.
- Later stack/procedure/control-flow/Irvine32/macro/debugger roadmap notes remain deferred.

### Stale or contradicted TODO-style notes corrected

- None found.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 57T was implemented as a fixture/documentation/status milestone, not a parser or runtime expansion milestone.

Primary design choices:

1. **Keep behavior unchanged.** The milestone locks down existing Phase 57P through Phase 57S diagnostics with broader realistic smoke coverage rather than adding executable behavior.

2. **Use one realistic trimmed playground sample.** The sample includes representative MASM32 tutorial/AI-generated constructs while keeping source locations stable enough for assertions.

3. **Use smaller exact fixtures for unreachable later constructs.** Since the parser reaches `CALL` in the realistic sample and stops before later unsupported low-level instructions, smaller fixtures cover `RET`, `CMP`, `JL`, and `ExitProcess` exactly.

4. **Preserve exact rendered-message tests.** User-visible diagnostic quality remains covered by Node tests using the browser formatter.

5. **Preserve runtime/source-run phase metadata.** Repository/archive status advances to 57T, but runtime/source-run MASM behavior remains 57S because no MASM behavior changed.

6. **Avoid future-feature leakage.** Diagnostics remain explanatory and non-executable. No host filesystem, linker, WinAPI, procedure, call/return, branch, macro, or high-level-flow behavior was implemented.

## 9. Files changed

Files changed across implementation and retained through compliance review:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `web/index.html`

No source C parser/executor/runtime implementation files were changed. No new public APIs or Doxygen obligations were introduced.

## 10. Tests added

### Source-run tests

Added Phase 57T source-run coverage in `tests/core/test_wasm_source_run.c` for:

- realistic MASM32 playground diagnostic-recovery fixture;
- MASM32 host include path classification;
- Windows API host include path classification;
- MASM32 `INCLUDELIB` classification;
- Windows import-library `INCLUDELIB` classification;
- `INVOKE` diagnostics;
- `ADDR` diagnostics;
- MASM32 runtime-style routine diagnostics;
- CRT routine diagnostics;
- high-level `.IF` / `.ELSE` / `.ENDIF` diagnostics;
- `CALL` unsupported diagnostic;
- smaller `RET` fixture;
- smaller `CMP` fixture;
- smaller `JL` conditional-jump fixture;
- smaller `ExitProcess` WinAPI/external fixture;
- no `execution-complete` after assembly diagnostics;
- no Program Console output;
- no `unexpected-character` path flood;
- no generic `lexer-failed` collapse;
- no misleading missing-local-file wording.

### Rendered Simulator Messages tests

Added exact rendered-message coverage in `tests/web/test_diagnostic_rendering.mjs` for:

- realistic playground diagnostics;
- `RET` unsupported diagnostic;
- `CMP` unsupported diagnostic;
- `JL` unsupported diagnostic;
- `ExitProcess` WinAPI/external diagnostic.

### Static/status tests

Updated `scripts/run_tests.py` static checks for:

- repository/archive Phase 57T status;
- runtime/source-run Phase 57S status retention;
- documentation status split;
- supported syntax/status documentation;
- milestone history and README status wording;
- browser static status text.

## 11. Commands used to test

### Aggregate command

Final aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Observed final result:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Focused group commands

Focused groups run during implementation and compliance review:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused results:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Subgroup or fixture-family commands

No subgroup or individual fixture-family reruns were required after final fixes.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is a dependency skip, not a test failure. Served browser testing with freshly rebuilt Wasm requires Emscripten locally or in CI.

## 12. Pass/fail results

Final result classification:

```text
aggregate completed and passed
group skipped because a dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

Detailed classification:

- Final aggregate command completed and returned final success status.
- Focused groups completed and passed:
  - `--structure`
  - `--native`
  - `--source-run`
  - `--web`
  - `--diagnostics`
  - `--protocol`
  - `--static`
- No aggregate timeout occurred in final verification.
- No focused group failed.
- No focused group timed out.
- No subgroup reruns were required.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

One transient implementation-time issue was corrected before final verification:

- The `--diagnostics` group initially failed due JavaScript fixture backslash escaping in the new rendered-message test fixture.
- The fixture escaping was corrected.
- `--diagnostics` was rerun and passed.
- The final aggregate run passed.

## 13. Manual/browser testing guidance and expected outputs

Phase 57T can be tested on the served website because it validates browser-visible Simulator Messages for unsupported playground source. The milestone does not require a Wasm rebuild if a compatible Phase 57S/57T Wasm artifact is already present, because no Wasm behavior changed. Rebuild is optional for a fresh served bundle.

### Browser setup on Windows

From the project root in Windows CMD:

```cmd
scripts\windows\serve_web.cmd
```

Open the served URL, paste the programs below, and click **Run**.

### Program 1 - realistic MASM32 playground diagnostic recovery

```asm
.386
.model flat, stdcall
option casemap:none

include \masm32\include\masm32.inc
include \masm32\include\kernel32.inc

includelib \masm32\lib\masm32.lib
includelib \masm32\lib\kernel32.lib

.data
    titleMsg   db "=== MASM32 Playground ===",13,10,0
    startMsg   db "Counting from 1 to 5",13,10,0
    evenMsg    db " -> even number",13,10,0
    oddMsg     db " -> odd number",13,10,0
    numberFmt  db "Number: %d",13,10,0
    counter    dd 1
    total      dd 0

.code
main PROC
    invoke StdOut, addr titleMsg
    invoke StdOut, addr startMsg
    invoke crt_printf, addr numberFmt, counter

    mov eax, counter
    and eax, 1

    .IF eax == 0
        invoke StdOut, addr evenMsg
    .ELSE
        invoke StdOut, addr oddMsg
    .ENDIF

    mov eax, counter
    call AddToTotal

    inc counter

    cmp counter, 6
    jl main_loop

    invoke crt_printf, addr numberFmt, total
    invoke ExitProcess, 0
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] compatibility-no-op line 1, column 1, byte offset 0, span length 4: .386 is accepted for MASM compatibility but does not change the simulator CPU mode.
[simulator-notice] compatibility-limited line 2, column 1, byte offset 5, span length 6: .model flat, stdcall is accepted for MASM32 textbook compatibility but does not enable real object-file, linker, Windows calling-convention, or WinAPI behavior.
[unsupported-feature] unsupported-masm32-library-include line 5, column 9, byte offset 55, span length 26: Host filesystem include path '\masm32\include\masm32.inc' is not supported. This browser simulator does not read the local MASM32 SDK; use supported virtual includes only.
[unsupported-feature] unsupported-windows-api-include line 6, column 9, byte offset 90, span length 28: Windows API include path '\masm32\include\kernel32.inc' is not supported. Windows API execution is outside this simulator; PE loading, imports, and WinAPI calls are not performed.
[unsupported-feature] unsupported-masm32-library line 8, column 12, byte offset 131, span length 22: INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines. MASM32 library '\masm32\lib\masm32.lib' requires external library linking.
[unsupported-feature] unsupported-windows-api-library line 9, column 12, byte offset 165, span length 24: INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines. Windows import library '\masm32\lib\kernel32.lib' requires PE imports and WinAPI execution.
[unsupported-feature] unsupported-invoke line 22, column 5, byte offset 487, span length 6: INVOKE syntax is not implemented in MASM32 Educational Mode; the simulator does not lower procedure arguments, set up calling conventions, or call routines.
[unsupported-feature] unsupported-addr line 22, column 20, byte offset 502, span length 4: ADDR operands are not implemented; ADDR depends on INVOKE/procedure argument lowering and future calling-convention support.
[unsupported-feature] unsupported-masm32-runtime-routine line 22, column 12, byte offset 494, span length 6: StdOut is an external MASM32 runtime-style routine. MASM32 Educational Mode does not link MASM32 runtime libraries or execute external routines.
[unsupported-feature] unsupported-invoke line 23, column 5, byte offset 520, span length 6: INVOKE syntax is not implemented in MASM32 Educational Mode; the simulator does not lower procedure arguments, set up calling conventions, or call routines.
[unsupported-feature] unsupported-addr line 23, column 20, byte offset 535, span length 4: ADDR operands are not implemented; ADDR depends on INVOKE/procedure argument lowering and future calling-convention support.
[unsupported-feature] unsupported-masm32-runtime-routine line 23, column 12, byte offset 527, span length 6: StdOut is an external MASM32 runtime-style routine. MASM32 Educational Mode does not link MASM32 runtime libraries or execute external routines.
[unsupported-feature] unsupported-invoke line 24, column 5, byte offset 553, span length 6: INVOKE syntax is not implemented in MASM32 Educational Mode; the simulator does not lower procedure arguments, set up calling conventions, or call routines.
[unsupported-feature] unsupported-addr line 24, column 24, byte offset 572, span length 4: ADDR operands are not implemented; ADDR depends on INVOKE/procedure argument lowering and future calling-convention support.
[unsupported-feature] unsupported-crt-routine line 24, column 12, byte offset 560, span length 10: crt_printf is a C runtime formatted-output routine. MASM32 Educational Mode does not link or execute CRT routines.
[unsupported-feature] unsupported-high-level-if line 29, column 5, byte offset 638, span length 3: .IF high-level MASM flow is not implemented; the simulator does not lower high-level conditions into labels or branches.
[unsupported-feature] unsupported-high-level-else line 31, column 5, byte offset 691, span length 5: .ELSE high-level MASM flow is not implemented; the simulator does not lower high-level alternatives into labels or branches.
[unsupported-feature] unsupported-high-level-endif line 33, column 5, byte offset 736, span length 6: .ENDIF closes unsupported high-level MASM flow; the simulator does not lower high-level conditions into labels or branches.
[assembly-error] unsupported-instruction line 36, column 5, byte offset 769, span length 4: CALL is not supported yet.
```

Expected Program Console:

```text
(empty)
```

Expected additional panels:

```text
Final Registers
No register state available.
Memory Changes
No memory changes.
```

### Program 2 - RET unsupported diagnostic

```asm
.code
main PROC
    ret
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-instruction line 3, column 5, byte offset 20, span length 3: Unsupported instruction. This mnemonic has no executable behavior in MASM32 Educational Mode; use an implemented instruction listed in docs/SUPPORTED_SYNTAX.md.
```

Expected Program Console:

```text
(empty)
```

### Program 3 - CMP unsupported diagnostic

```asm
.code
main PROC
    cmp eax, 6
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-instruction line 3, column 5, byte offset 20, span length 3: Unsupported instruction. This mnemonic has no executable behavior in MASM32 Educational Mode; use an implemented instruction listed in docs/SUPPORTED_SYNTAX.md.
```

Expected Program Console:

```text
(empty)
```

### Program 4 - conditional jump unsupported diagnostic

```asm
.code
main PROC
    jl main_loop
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-instruction line 3, column 5, byte offset 20, span length 2: Unsupported instruction. This mnemonic has no executable behavior in MASM32 Educational Mode; use an implemented instruction listed in docs/SUPPORTED_SYNTAX.md.
```

Expected Program Console:

```text
(empty)
```

### Program 5 - ExitProcess is not Irvine32 virtual exit

```asm
INCLUDE Irvine32.inc
.code
main PROC
    invoke ExitProcess, 0
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-invoke line 4, column 5, byte offset 41, span length 6: INVOKE syntax is not implemented in MASM32 Educational Mode; the simulator does not lower procedure arguments, set up calling conventions, or call routines.
[unsupported-feature] unsupported-winapi-execution line 4, column 12, byte offset 48, span length 11: ExitProcess is WinAPI/external process termination behavior. MASM32 Educational Mode does not execute Windows API calls; this is not the virtual Irvine32 exit terminator.
```

Expected Program Console:

```text
(empty)
```

### Local Windows CMD checks

From the project root:

```cmd
py -3 scripts\run_tests.py --source-run
py -3 scripts\run_tests.py --web
py -3 scripts\run_tests.py --diagnostics
py -3 scripts\run_tests.py --all
```

Expected snippets:

```text
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
All implemented milestone tests passed.
```

If Emscripten is unavailable, this expected skip may appear:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Regression signs:

- Program 1 reports `unexpected-character` for MASM32 path backslashes.
- Program 1 reports `lexer-failed`.
- Program 1 says a local MASM32 file is missing or implies host filesystem probing.
- Any program reports `execution-complete`.
- Any program writes Program Console output.
- `INCLUDELIB` is described as host include loading rather than linker/import-library behavior.
- `ExitProcess` is treated as virtual Irvine32 `exit`.
- `CALL`, `RET`, `CMP`, or `JL` executes instead of producing unsupported diagnostics.

## 14. Compliance review summary

First compliance review result:

- No scope, completeness, code-quality, diagnostics, test, or documentation compliance defects requiring fixes were found.
- Phase 57T remained a fixture/documentation/status milestone.
- No future feature behavior was implemented.
- Target-owned TODO-style notes were considered resolved by tests/docs/status coverage.
- Future-owned TODO-style notes were preserved.
- No stale TODO-style notes were found.
- All focused groups and aggregate verification passed.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

First compliance changed-files package:

```text
milestone_57T_first_compliance_check.zip
```

## 15. Re-review summary

Second compliance/re-review result:

- No additional issues were found.
- No additional fixes were applied.
- Changed files were rechecked for stale comments, docs promises, hidden assumptions, TODO-style issues, accidental future work, and test quality.
- Source-run, web, diagnostics, static, structure, native, protocol, and aggregate commands were rerun.
- All focused groups passed.
- Aggregate completed and passed.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

Second compliance changed-files package:

```text
milestone_57T_second_compliance_check.zip
```

## 16. User-test follow-up summary

The user manually ran the five browser programs from the manual testing instructions and reported observed output.

Result:

- The observed diagnostics matched expected output.
- No `execution-complete` message appeared.
- No Program Console output appeared.
- No `unexpected-character`, `lexer-failed`, or host-file-loading wording appeared.
- `ExitProcess` was correctly diagnosed as WinAPI/external behavior, not virtual Irvine32 `exit`.
- The additional UI sections `Final Registers / No register state available` and `Memory Changes / No memory changes` were expected because assembly diagnostics prevented execution.

Diagnosis:

- No implementation bug.
- No test expectation bug.
- No stale Wasm/build artifact issue.
- Only a documentation clarification was noted: manual expectations now explicitly mention the final-register and memory-change empty-state panels.

Fixes required:

- None.

## 17. Known limitations

- `emcc` was unavailable in the assistant/container environment, so Browser/Wasm rebuild smoke was skipped.
- A full `Latest_repository_state_milestone_57T.zip` archive was not produced during this session; only changed-files packages were produced.
- `CALL`, `RET`, `CMP`, and `JL` still use existing `unsupported-instruction` diagnostics rather than more specific future control-flow/procedure diagnostics.
- Phase 57T does not make the realistic playground sample executable.
- The served website can display the updated static Phase 57T repository status and can exercise existing diagnostics, but a fresh Wasm rebuild still requires Emscripten locally or in CI.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 58 - Code Label Table and Label Diagnostics
```

Expected next archive name after that future milestone, if completed:

```text
Latest_repository_state_milestone_58.zip
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced during this milestone:

- `milestone_57T_changed_files.zip`
- `milestone_57T_first_compliance_check.zip`
- `milestone_57T_second_compliance_check.zip`

No final compliance ZIP was produced because the final gap check made no project-file changes.

Recommended final repository/archive name for the accepted Phase 57T repository state:

```text
Latest_repository_state_milestone_57T.zip
```
