# Milestone 53 report - Unsigned MUL

## 1. Milestone title and scope

Milestone 53 implements **Phase 53 - Unsigned MUL** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added executable runtime support for one-operand unsigned `mul`.
- Supported register source operands at 8-bit, 16-bit, and 32-bit widths.
- Supported unambiguous memory source operands through:
  - typed data symbols;
  - typed symbol offsets;
  - explicit unsigned `BYTE PTR`, `WORD PTR`, and `DWORD PTR` forms;
  - explicit signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases by width.
- Implemented x86-style implicit accumulator result behavior for MASM32 Educational Mode:
  - `mul r/m8`: `AL * r/m8 -> AX`;
  - `mul r/m16`: `AX * r/m16 -> DX:AX`;
  - `mul r/m32`: `EAX * r/m32 -> EDX:EAX`.
- Implemented unsigned upper-half flag behavior:
  - `CF = 1` and `OF = 1` when the upper half of the product is nonzero;
  - `CF = 0` and `OF = 0` when the upper half of the product is zero.
- Preserved `ZF` and `SF` deterministically, matching the Phase 53 guide requirement for undefined real-x86 flags in this educational simulator.
- Routed all memory sources through checked VM memory reads.
- Ensured failed memory reads do not partially mutate result registers, flags, Program Console output, or memory-change rows.
- Ensured memory-source reads do not create memory-change rows.
- Integrated `mul` with opt-in uninitialized-read diagnostics for memory sources.
- Updated source-run and browser metadata to report runtime phase `53`.
- Updated documentation and default/sample UI text for Phase 53.
- Added exact structured and rendered Simulator Messages tests for new user-visible diagnostics.
- Added a small user-requested display-polish follow-up for Phase 52A-style final-register formatting: `AH`, `BH`, `CH`, and `DH` now visually align with the high byte of `AX`, `BX`, `CX`, and `DX`.

The implementation stayed within the milestone boundary. No signed multiply, division, control flow, stack behavior, procedure behavior, QWORD/SQWORD execution, scaled-index addressing, or Irvine32 expansion was implemented.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 52A report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_52A.zip
```

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, phase tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 53 is the only runtime target milestone for this implementation session.
- The post-implementation display adjustment is a display-only Phase 52A polish follow-up and does not change Phase 53 runtime semantics.

Relevant stable project constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- All memory reads and writes go through checked memory helpers.
- User-visible diagnostics require structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

Phase 53 required one-operand unsigned `mul`.

### Accepted syntax implemented

```asm
mul reg8
mul reg16
mul reg32
mul BYTE PTR [reg32]
mul WORD PTR [reg32]
mul DWORD PTR [reg32]
mul symbol
mul symbol[offset]
```

Signed PTR aliases were accepted by width because previous milestones established them as executable 8-bit, 16-bit, and 32-bit width aliases:

```asm
mul SBYTE PTR [esi]
mul SWORD PTR [esi]
mul SDWORD PTR [esi]
```

Case-insensitive mnemonics remain supported through the existing instruction-matching policy:

```asm
MUL ebx
Mul ebx
mul ebx
```

### Rejected syntax implemented or preserved

```asm
mul 5
mul eax, ebx
mul [eax]
mul QWORD PTR q
mul SQWORD PTR q
mul
mul eax, ebx, ecx
```

Diagnostic behavior:

- `mul 5` reports `invalid-instruction-operands`.
- `mul eax, ebx` reports `invalid-instruction-operands`.
- `mul` with no operand reports `invalid-instruction-operands`.
- `mul eax, ebx, ecx` reports `invalid-instruction-operands`.
- `mul [eax]` reports `ambiguous-memory-width`.
- `mul QWORD PTR q` and `mul SQWORD PTR q` preserve the existing executable-64-bit memory-operation rejection with `unsupported-ptr-width`.

### Runtime semantics implemented

For 8-bit source operands:

```text
AX = AL * source8
```

For 16-bit source operands:

```text
DX:AX = AX * source16
```

For 32-bit source operands:

```text
EDX:EAX = EAX * source32
```

The multiplication is unsigned. Source operands are masked to their resolved width before multiplication.

### Flag behavior implemented

For all supported widths:

- If the upper half of the product is nonzero:
  - `CF = 1`
  - `OF = 1`
- If the upper half of the product is zero:
  - `CF = 0`
  - `OF = 0`
- `ZF` is preserved deterministically.
- `SF` is preserved deterministically.
- Other x86 flags remain unmodeled.

Because Phase 50A added flag-validity metadata, Phase 53 also preserves the relevant existing metadata behavior for preserved flags and defines `CF`/`OF` through the normal flag helpers.

### Memory behavior implemented

- Register-source `mul` does not touch memory.
- Memory-source `mul` performs a checked read through the VM memory helper path.
- Memory-source `mul` does not write memory.
- Memory-source `mul` does not create memory-change rows.
- `.CONST` memory sources are readable.
- Invalid memory-source reads fail at runtime and stop execution before result-register or flag mutation.
- Opt-in uninitialized-read warning mode detects `mul` memory sources that read bytes still carrying uninitialized-origin metadata.

### Metadata and display implemented

- Runtime source-run metadata now reports phase `53`.
- Browser protocol metadata and status text were updated to identify Phase 53 support.
- The default/sample page program demonstrates `mul ebx`.
- The final-register formatter was polished after user testing so high-byte aliases are easier to interpret:

```text
EAX    | 00001234h / u: 4660       / s:  4660
  AX   |     1234h / u: 4660       / s:  4660
  AH   |     12h   / u: 18         / s:  18
    AL |       34h / u: 52         / s:  52
```

The display-polish follow-up changed only formatter behavior and formatter tests. It did not change C core semantics, source-run JSON, the protocol schema, or Phase 53 runtime behavior.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 53:

- `imul`.
- `div`.
- `idiv`.
- Signed multiplication behavior.
- Two-operand or three-operand multiplication.
- Executable `QWORD PTR` or `SQWORD PTR` memory operations in MASM32 Educational Mode.
- Extended 32-bit Mode 64-bit arithmetic.
- Labels, `jmp`, conditional jumps, `loop`, `SETcc`, or `CMOVcc`.
- `cmp`.
- New flag-consumer instructions.
- `push`, `pop`, `call`, `ret`, `leave`, or stack behavior.
- Procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`.
- Irvine32 routine bodies beyond existing behavior.
- Program Console input/output routines.
- Scaled-index addressing.
- Macro expansion.
- Windows API simulation.
- PE loading.
- Object linking.
- Host filesystem behavior.
- Browser settings for diagnostic policy.
- New raw JSON signed-display fields or BigInt payloads.
- Signed QWORD/SQWORD decimal display.

Next arithmetic work is expected to be Phase 54 - One-Operand Signed IMUL.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Signed `PTR` aliases `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` should be accepted for `mul` as width aliases.
- **Reason:** Earlier milestones established signed PTR aliases as executable 8-bit, 16-bit, and 32-bit memory-width overrides anywhere their unsigned-width counterparts are legal. Phase 53 lists unsigned examples but does not explicitly forbid signed aliases.
- **Risk:** If the guide intended only the exact unsigned forms listed under Phase 53, accepting signed aliases slightly broadens syntax relative to the literal examples.
- **How to change later:** Add explicit guide wording or tests either confirming signed PTR aliases for `mul` by width or narrowing this one instruction family.

### Assumption 2

- **Assumption:** Phase metadata should advance to numeric `53`.
- **Reason:** Phase 53 adds runtime MASM instruction behavior. This differs from Phase 52A, which was display-only and intentionally preserved numeric runtime metadata at `52`.
- **Risk:** Metadata updates touch documentation, UI/protocol status, and tests in addition to core/parser/executor files.
- **How to change later:** Centralize feature metadata or add a separate string milestone label if future suffix phases need first-class protocol representation.

### Assumption 3

- **Assumption:** `mul` should be represented as a dedicated IR opcode.
- **Reason:** `mul` has implicit accumulator operands, width-specific result registers, and instruction-specific flag behavior. A dedicated opcode keeps diagnostics, opcode names, future debugger display, and tests clear.
- **Risk:** Adds another opcode and executor case instead of using a generic arithmetic opcode.
- **How to change later:** A later arithmetic abstraction could share product-computation helpers internally while preserving public opcode identity.

### Assumption 4

- **Assumption:** `ZF` and `SF` preservation should include preserving the existing deterministic flag bits and the existing flag-validity metadata behavior.
- **Reason:** The Phase 53 guide requires `ZF` and `SF` to be preserved. Phase 50A made validity metadata part of the modeled CPU flag state.
- **Risk:** If a future guide clarification says `mul` should mark `ZF`/`SF` invalid while preserving their deterministic bits, Phase 53 behavior would need adjustment.
- **How to change later:** Add explicit flag-validity wording for `mul` and update tests around Phase 50A metadata accordingly.

### Assumption 5

- **Assumption:** The high-byte alias display polish should be treated as a Phase 52A display follow-up rather than a Phase 53 runtime change.
- **Reason:** It modifies only visual formatting of already-existing final register display rows. It does not change parsing, execution, diagnostics, JSON, or protocol shape.
- **Risk:** It changes exact expected output in formatter tests and manual examples that mention `AH`, `BH`, `CH`, or `DH`.
- **How to change later:** Keep the display convention documented in formatter tests. If a future UI design changes register layout, update the formatter and exact tests together.

## 6. Relevant TODO-style notes reviewed

TODO-style notes were reviewed in changed files and nearby modules during implementation, compliance review, second review, and final gap check.

The relevant TODO discovered and touched was in `src/wasm/wasm_api.c`, in the planned memory-read collector used by opt-in uninitialized-read diagnostics. Before review, the note was too narrow because it mentioned only future read-modify-write opcodes, while Phase 53 introduced a source-only memory-reading opcode.

The note was corrected to be future-phase scoped:

```text
TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
```

No TODO-style note was added that claims Phase 53 owns future instructions.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- `mul` was added to the planned memory-read collector in `src/wasm/wasm_api.c` so opt-in uninitialized-read warning mode covers Phase 53 memory sources.
- No target-owned TODO-style note remains unresolved.

### Future-owned TODO-style notes intentionally preserved

- The future-scoped memory-reading-opcode TODO remains in `src/wasm/wasm_api.c`. It applies to future instruction milestones when they add new opcodes that read memory.

### Stale or contradicted TODO-style notes corrected

- The stale/narrow TODO wording in `src/wasm/wasm_api.c` was corrected from a read-modify-write-only framing to a future memory-reading-opcode framing.

### Unresolved TODO-related risks

- Low. The remaining TODO names future instruction milestones and does not imply current Phase 53 work.

## 8. Design summary

### IR design

A new opcode was added:

```text
VM_IR_OPCODE_MUL
```

Opcode-name mapping now reports:

```text
mul
```

This gives diagnostics, tests, protocol/debug display, and future tooling a stable identity for the instruction.

### Parser design

The parser recognizes `mul` as a unary source instruction. It does not parse or store an explicit destination because destination/result registers are implicit and width-dependent.

Parser behavior:

- Accepts register sources at 8-bit, 16-bit, and 32-bit widths.
- Accepts memory sources when width is inferable from typed symbols or symbol offsets.
- Accepts explicit `BYTE PTR`, `WORD PTR`, and `DWORD PTR` memory sources.
- Accepts signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases by width.
- Rejects immediate sources.
- Rejects missing or extra operands.
- Rejects two-operand and three-operand forms.
- Rejects ambiguous untyped register-indirect memory such as `mul [eax]`.
- Preserves existing QWORD/SQWORD executable memory-operation rejection.

### Executor design

The executor handles `mul` in a dedicated helper path.

Execution algorithm:

1. Determine source operand width.
2. Read the source value from register or memory.
3. If the source is memory, route the read through checked VM memory helpers.
4. If a memory read fails, stop before mutation.
5. Read the implicit accumulator value for the selected width:
   - `AL` for 8-bit source;
   - `AX` for 16-bit source;
   - `EAX` for 32-bit source.
6. Compute the unsigned product wide enough to retain both lower and upper halves.
7. Write result registers:
   - `AX` for 8-bit source;
   - `DX` and `AX` for 16-bit source;
   - `EDX` and `EAX` for 32-bit source.
8. Set or clear `CF` and `OF` based on whether the upper half is nonzero.
9. Preserve `ZF` and `SF`.

### Diagnostics design

Phase 53 reuses existing diagnostic categories where appropriate:

- `invalid-instruction-operands` for invalid `mul` operand shapes.
- `ambiguous-memory-width` for `mul [reg]` without a width source.
- `unsupported-ptr-width` for executable QWORD/SQWORD source memory operations.
- Existing runtime memory diagnostics for invalid checked reads.
- Existing `uninitialized-read` warning path for opt-in uninitialized memory validation.

All user-visible diagnostics added or newly routed through Phase 53 have rendered Simulator Messages tests.

### Display polish design

The user-requested display polish was implemented entirely in `web/src/formatters.js` and formatter tests.

High-byte aliases now use:

- shallower label indentation than low-byte aliases;
- high-byte hex placement inside the existing fixed-width hex column.

This makes `AH`, `BH`, `CH`, and `DH` visually compose the high byte of `AX`, `BX`, `CX`, and `DX` respectively.

## 9. Files changed

Final changed files:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_exec.h
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_formatters.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/formatters.js
web/src/protocol.js
```

No new core C++ files or C++ dependencies were added.

## 10. Tests added

### Native executor tests

Added coverage for:

- 8-bit `mul` with upper half zero.
- 8-bit `mul` with upper half nonzero.
- 16-bit `mul` into `DX:AX`.
- 32-bit `mul` into `EDX:EAX`.
- `CF`/`OF` clear when upper half is zero.
- `CF`/`OF` set when upper half is nonzero.
- `ZF` and `SF` preservation.
- Memory-source `mul` using checked memory reads.
- Invalid memory-source read rollback/no-partial-mutation.
- Memory-source reads not creating memory-change rows.

### Parser tests

Added coverage for accepted forms:

```asm
mul al
mul ax
mul eax
mul BYTE PTR [esi]
mul WORD PTR [esi]
mul DWORD PTR [esi]
mul SBYTE PTR [esi]
mul SWORD PTR [esi]
mul SDWORD PTR [esi]
mul value
mul values[4]
```

Added coverage for rejected forms:

```asm
mul 5
mul eax, ebx
mul [eax]
mul QWORD PTR q
mul SQWORD PTR q
mul
mul eax, ebx, ecx
```

### Source-run tests

Added coverage for:

- Basic 32-bit register-source acceptance program.
- 8-bit register-source product.
- 16-bit register-source product.
- 32-bit overflow into `EDX`.
- Direct symbol memory source.
- Symbol-offset memory source.
- Explicit `PTR [reg]` memory source.
- `.CONST` readable source.
- Memory-source read without memory-change rows.
- Runtime invalid-address memory-source failure.
- Opt-in uninitialized-read warning for `mul` memory source.
- Phase metadata update to `53`.

### Rendered Simulator Messages tests

Added exact rendered diagnostics for:

- `mul [eax]` ambiguous memory width.
- `mul 5` invalid immediate source.
- `mul eax, ebx` invalid two-operand form.
- invalid runtime memory-source read.
- QWORD source rejection.

### Formatter/protocol tests

Added or updated coverage for:

- Phase 53 protocol metadata.
- Phase 53 default/sample text where applicable.
- Phase 52A display preservation after Phase 53.
- High-byte alias display polish for `AH`, `BH`, `CH`, and `DH`.

### Regression tests

Preserved and reran existing coverage for:

- Phases 0-52 behavior.
- Phase 52A signed register/memory display.
- LEA behavior from Phase 52.
- Shift/rotate undefined-flag producer diagnostics.
- Phase 50A/50B flag-validity and undefined-flag-use behavior.
- Phase 51 smoke harness.
- QWORD/SQWORD execution rejection.
- Memory diagnostics and `.CONST` protection.
- Program Console and Simulator Messages separation.

## 11. Commands used to test

Baseline verification before implementation:

```bash
cd /mnt/data/repo_verify_52A
python3 scripts/run_tests.py
```

Implementation and review test command:

```bash
cd /mnt/data/repo_m53_work
python3 scripts/run_tests.py
```

The aggregate command compiles native C tests with strict C99 flags and runs Node-based web/protocol/formatter/diagnostic-rendering tests.

Final report-time rerun:

```bash
cd /mnt/data/repo_m53_work
python3 scripts/run_tests.py
```

Environment observed during repository verification:

```text
cc: available
python3: available
node: available
emcc: unavailable
```

Because `emcc` is unavailable in this environment, Wasm rebuild and served-browser validation after rebuild were not performed here.

## 12. Pass/fail results

Baseline before implementation:

```text
PASS - All implemented milestone tests passed.
```

After Phase 53 implementation:

```text
PASS - All implemented milestone tests passed.
```

After first compliance fixes:

```text
PASS - All implemented milestone tests passed.
```

After second compliance review fixes:

```text
PASS - All implemented milestone tests passed.
```

After display-polish follow-up:

```text
PASS - All implemented milestone tests passed.
```

After final gap check:

```text
PASS - All implemented milestone tests passed.
```

Report-time rerun:

```text
All implemented milestone tests passed.
```

Final command exit status:

```text
0
```

## 13. Manual/browser testing guidance and expected outputs

Milestone 53 is website-testable after rebuilding Wasm in an Emscripten-capable environment.

### Browser setup on Windows

From the project root in an Emscripten-enabled CMD environment:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

### Program 1 - 32-bit register-source MUL

```asm
.code
main PROC
    mov eax, 10
    mov ebx, 20
    mul ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key final register rows:

```text
EAX    | 000000C8h / u: 200        / s:  200
EDX    | 00000000h / u: 0          / s:  0
EFLAGS | 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `EAX` is not `000000C8h`.
- `EDX` is not zero.
- `EFLAGS` is not zero.
- An error appears.
- A memory-change row appears.

### Program 2 - 8-bit MUL overflow into AX

```asm
.code
main PROC
    mov al, 0FFh
    mov bl, 2
    mul bl
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key final register rows after the display polish:

```text
EAX    | 000001FEh / u: 510        / s:  510
  AX   |     01FEh / u: 510        / s:  510
  AH   |     01h   / u: 1          / s:  1
    AL |       FEh / u: 254        / s: -2
EFLAGS | 00000801h / 2049
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `AX` is not `01FEh`.
- `AH` is not visually aligned under the high byte of `AX`.
- `AL` is not visually aligned under the low byte of `AX`.
- `EFLAGS` is not `00000801h`.

### Program 3 - 16-bit MUL into DX:AX

```asm
.code
main PROC
    mov ax, 1234h
    mov bx, 0010h
    mul bx
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key final register rows:

```text
EAX    | 00002340h / u: 9024       / s:  9024
  AX   |     2340h / u: 9024       / s:  9024
EDX    | 00000001h / u: 1          / s:  1
  DX   |     0001h / u: 1          / s:  1
EFLAGS | 00000801h / 2049
```

Regression signs:

- `DX:AX` is not `0001:2340`.
- `EFLAGS` is not `00000801h`.
- Any memory-change row appears.

### Program 4 - Memory source and no memory changes

```asm
.data
values DWORD 5, 20

.code
main PROC
    mov eax, 10
    mul values[4]
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key final register rows:

```text
EAX    | 000000C8h / u: 200        / s:  200
EDX    | 00000000h / u: 0          / s:  0
EFLAGS | 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `mul values[4]` is rejected.
- `EAX` is not `200`.
- A memory-change row appears for `values`.

### Program 5 - Readable `.CONST` source

```asm
.CONST
factor DWORD 20

.code
main PROC
    mov eax, 10
    mul factor
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected key final register rows:

```text
EAX    | 000000C8h / u: 200        / s:  200
EDX    | 00000000h / u: 0          / s:  0
EFLAGS | 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `.CONST` read is rejected.
- A permission error appears for reading `.CONST`.
- A memory-change row appears.

### Program 6 - Ambiguous memory width diagnostic

```asm
.code
main PROC
    mov eax, 0
    mul [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 4, column 9, byte offset 39, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Expected register display:

```text
No register state available.
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- The program executes.
- The diagnostic is classified as a generic unsupported feature.
- Location fields are missing.
- The message does not tell the user to use `BYTE PTR`, `WORD PTR`, or `DWORD PTR`.

### Program 7 - Invalid memory read runtime diagnostic

```asm
.code
main PROC
    mov eax, 0
    mul DWORD PTR [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] invalid-address line 4: Invalid memory read at 00000000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

Expected key final register rows:

```text
EAX    | 00000000h / u: 0          / s:  0
EDX    | 00000000h / u: 0          / s:  0
EFLAGS | 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- Execution completes successfully.
- `EAX`, `EDX`, or flags mutate after the failed read.
- The diagnostic is an assembly error instead of a runtime error.
- A memory-change row appears.

### Program 8 - QWORD source remains deferred

```asm
.data
q QWORD 2

.code
main PROC
    mul QWORD PTR q
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-ptr-width line 5, column 9, byte offset 40, span length 5: QWORD and SQWORD PTR execution is deferred until Extended 32-bit Mode.
```

Expected register display:

```text
No register state available.
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- The program executes.
- QWORD multiplication works in MASM32 Educational Mode.
- The diagnostic omits location fields.

### Local-only test - opt-in uninitialized-read warning for MUL

This test is local-only because the website does not yet expose the uninitialized-read validation setting.

Save as `program.asm` at the project root:

```asm
.DATA?
x DWORD ?

.code
main PROC
    mov eax, 10
    mul x
main ENDP
END main
```

Run in Windows CMD after `python scripts\run_tests.py` has built the native diagnostic producer:

```cmd
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=uninitialized-read-warnings
build\tests\diagnostic_json_producer.exe program.asm
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=
```

Expected JSON diagnostics include:

```json
[
  {
    "kind": "simulator-warning",
    "code": "uninitialized-read",
    "message": "Memory read range 00500000h..00500003h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.",
    "line": 6
  },
  {
    "kind": "info",
    "code": "execution-complete",
    "message": "Execution completed successfully."
  }
]
```

Expected result fields:

```json
"EAX": { "hex": "00000000h", "unsigned": 0 }
"EDX": { "hex": "00000000h", "unsigned": 0 }
"EFLAGS": { "hex": "00000000h", "unsigned": 0 }
"memoryChanges": []
```

Regression signs:

- No `uninitialized-read` warning appears with warning mode enabled.
- The warning stops execution instead of continuing.
- `memoryChanges` is not empty.
- `EAX` or `EDX` does not remain zero after multiplying by the deterministic zero-filled uninitialized source.

## 14. Compliance review summary

First compliance review found and fixed:

- `mul` memory sources were missing from the Wasm/source-run planned-read collector used by opt-in uninitialized-read diagnostics.
- Several test assertion descriptions still referred to Milestone 52 after metadata advanced to `53`.
- A TODO in `src/wasm/wasm_api.c` was too narrow because it described only future read-modify-write opcodes.

Fixes applied:

- Added `VM_IR_OPCODE_MUL` to the planned memory-read collector.
- Added a Phase 53 uninitialized-read regression test for `mul x` where `x DWORD ?`.
- Updated aggregate structure checks to require the new test.
- Corrected stale test assertion wording.
- Reworded the TODO to future-scoped memory-reading-opcode wording.

Review result:

```text
PASS - All implemented milestone tests passed.
```

Verdict after first compliance review:

```text
complete
```

## 15. Re-review summary

Second compliance review found and fixed:

- Stale file-level comments in changed C files:
  - `src/core/vm_exec.c` still described executor support only through `rol`/`ror`.
  - `src/wasm/wasm_api.c` still described source-run support only through ROL/ROR plus `exit`, omitting LEA and MUL.

Fixes applied:

- Updated `src/core/vm_exec.c` file header to include `lea`, `mul`, and Irvine32 `exit`.
- Updated `src/wasm/wasm_api.c` file header to include LEA and unsigned MUL.

Review result:

```text
PASS - All implemented milestone tests passed.
```

Final second-review verdict:

- Scope complete.
- Documentation complete after header cleanup.
- Test coverage complete.
- TODO-style note status acceptable.

## 16. User-test follow-up summary

After milestone implementation and reviews, the user reported that everything passed and suggested a small display improvement originally missed during Milestone 52A:

- Reduce label indentation for `AH`, `BH`, `CH`, and `DH`.
- Align their hex values under the high byte of `AX`, `BX`, `CX`, and `DX`.

Implemented as a display-only follow-up:

- Updated `web/src/formatters.js`.
- Updated and added exact formatter tests in `tests/web/test_formatters.mjs`.
- Preserved low-byte alias placement for `AL`, `BL`, `CL`, and `DL`.
- Preserved C core, parser, VM, Wasm API, protocol schema, source-run JSON, and runtime behavior.

Example final formatting:

```text
EAX    | 00001234h / u: 4660       / s:  4660
  AX   |     1234h / u: 4660       / s:  4660
  AH   |     12h   / u: 18         / s:  18
    AL |       34h / u: 52         / s:  52
```

Test result after the display follow-up:

```text
PASS - All implemented milestone tests passed.
```

## 17. Known limitations

Known limitations after Milestone 53:

- `imul` remains unimplemented and is the recommended next milestone.
- `div` and `idiv` remain unimplemented.
- Only one-operand unsigned `mul` is implemented.
- Two-operand and three-operand multiplication remain unsupported.
- QWORD/SQWORD executable memory operations remain deferred in MASM32 Educational Mode.
- Extended 32-bit Mode 64-bit arithmetic is not implemented here.
- Labels, jumps, conditional jumps, `loop`, `SETcc`, and `CMOVcc` remain future work.
- Stack, procedure, call/return, `LOCAL`, `PROTO`, `INVOKE`, and `ADDR` behavior remain future work.
- Irvine32 routine expansion beyond existing behavior remains future work.
- Scaled-index addressing remains unsupported.
- Browser settings for uninitialized-read warning mode are not implemented; that validation mode remains local/test API controlled.
- Emscripten was unavailable in this environment, so rebuilt Wasm and served-browser testing after rebuild were not performed here.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 54 - One-Operand Signed IMUL
```

Phase 54 should implement signed one-operand `imul` only. It should not implement division, two-/three-operand `imul`, control flow, stack/procedure behavior, QWORD/SQWORD execution, or unrelated future features.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

```text
milestone53_changed_files.zip
milestone53_compliance_review_changed_files.zip
milestone53_second_review_changed_files.zip
milestone53_display_polish_changed_files.zip
milestone53_final_gap_changed_files.zip
```

Final recommended changed-files package:

```text
milestone53_final_gap_changed_files.zip
```

The final changed-files package preserves repository structure and includes all Phase 53 implementation, review fixes, and the display-polish follow-up.

Recommended next full repository archive name after applying the final changed-files package:

```text
Latest_repository_state_milestone_53.zip
```

