# Milestone 57I report - .CONST Uninitialized Storage Acceptance

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57I - .CONST Uninitialized Storage Acceptance
```

Repository/archive milestone:

```text
Phase 57I - .CONST Uninitialized Storage Acceptance
```

Runtime/source-run MASM behavior phase:

```text
Phase 57I - .CONST Uninitialized Storage Acceptance
```

Status interpretation:

Phase 57I is a runtime/source behavior milestone. It changes accepted MASM source behavior by accepting `.CONST ?` and `.CONST DUP(?)` declarations. Therefore repository/archive status and runtime/source-run MASM behavior metadata both advance to Phase 57I.

Scope implemented:

- Accepted `.CONST ?` declarations.
- Accepted `.CONST DUP(?)` declarations.
- Allocated accepted uninitialized `.CONST` declarations in the `.CONST` region.
- Preserved read-only `.CONST` protection for direct and computed writes.
- Preserved uninitialized-origin metadata for accepted `.CONST ?` and `.CONST DUP(?)` storage.
- Included accepted `.CONST` uninitialized-origin bytes in existing Phase 57G seeded uninitialized-storage visible-byte behavior.
- Integrated accepted `.CONST` uninitialized-origin reads with the existing `uninitialized-read` diagnostic policy.
- Preserved initialized `.CONST` behavior.
- Preserved `.DATA?`, `.data`, and existing data-initializer behavior.
- Advanced source-run/browser/protocol metadata to Phase 57I.
- Updated documentation, tests, static checks, and manual testing guidance.

No Phase 57J declaration diagnostic policy or browser UI controls were implemented.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57H report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_57H.zip
```

Relevant interpretation rules used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, current-status surface hygiene, memory safety, and display/source-run behavior expectations.
- The implementation guide owns phase numbering, target milestone scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical specification and guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 57I is the only target milestone for this implementation session.
- TODO-style notes are implementation-risk evidence only and do not override the canonical specification, guide, target milestone, or verified repository behavior.

## 3. Exact requirements implemented

### 3.1 Accepted `.CONST` uninitialized declarations

Accepted `.CONST` uninitialized scalar declarations, including representative forms such as:

```asm
.CONST
limit DWORD ?
byteValue BYTE ?
wordValue WORD ?
signedValue SDWORD ?
```

Accepted `.CONST DUP(?)` declarations, including representative forms such as:

```asm
.CONST
buf BYTE 4 DUP(?)
words WORD 4 DUP(?)
values DWORD 2 DUP(?)
```

The accepted initializer grammar reuses the existing `?` and `DUP(?)` support already present for compatible data declarations. Phase 57I did not broaden unrelated initializer grammar.

### 3.2 `.CONST` allocation and metadata

Implemented `.CONST` initialized-byte mask tracking separately from the existing `.data`/`.DATA?` initialized-byte tracking because `.CONST` is a distinct VM region.

Implemented behavior:

- `.CONST ?` bytes are allocated in the `.CONST` region.
- `.CONST DUP(?)` bytes are allocated in the `.CONST` region.
- Accepted `.CONST` uninitialized-origin bytes retain metadata identifying them as uninitialized-origin bytes.
- Initialized `.CONST` bytes remain initialized-origin bytes.
- Mixed initialized and uninitialized `.CONST` declarations in the same section are supported according to existing declaration grammar.
- Object-map metadata can represent uninitialized-origin `.CONST` bytes for tests and source-run validation.

### 3.3 Reads from `.CONST ?` and `.CONST DUP(?)`

Reads from accepted `.CONST` uninitialized-origin storage are allowed when the final effective address and byte range pass mandatory memory validation.

Default behavior remains deterministic:

- Visible bytes are zero-filled by default.
- Uninitialized-origin metadata is preserved.
- Default uninitialized-read policy emits existing non-fatal `uninitialized-read` warnings and continues execution.

Strict behavior is preserved:

- In strict uninitialized-read mode, reading accepted `.CONST` uninitialized-origin bytes stops execution before the consumer instruction mutates destination state.

Opt-out behavior is preserved:

- Explicit uninitialized-read opt-out allows deterministic reads without an `uninitialized-read` warning.

### 3.4 Seeded uninitialized visible-byte mode

The existing Phase 57G `uninitialized_storage_visible_byte_mode = seeded-random` behavior now includes `.CONST` bytes that carry uninitialized-origin metadata.

Implemented behavior:

- Default mode keeps visible bytes zero-filled.
- Seeded-random mode deterministically seeds visible bytes for uninitialized-origin `.CONST` storage.
- Initialized `.CONST` bytes are not randomized.
- Initialized `.data` bytes are not randomized.
- Existing `.DATA?`, scalar `?`, and `DUP(?)` behavior remains unchanged.
- The deterministic seed stream covers uninitialized-origin storage consistently across `.data` and `.CONST` source-run setup.

### 3.5 `.CONST` write protection preserved

Direct writes to accepted `.CONST ?` declarations remain rejected by existing static/direct `.CONST` write checks where those checks can identify the target.

Computed writes to accepted `.CONST ?` declarations remain rejected by mandatory runtime memory permission checks.

Implemented regression behavior:

- Failed direct `.CONST` writes do not execute.
- Failed computed `.CONST` writes do not mutate memory.
- Failed computed `.CONST` writes do not create memory-change rows.
- Fatal `.CONST` write diagnostics do not emit `execution-complete`.
- `.CONST` write failures are not reclassified as `uninitialized-read`, section-capacity, section-image, declared-object, or future Phase 57J declaration-policy diagnostics.

### 3.6 Runtime/source-run metadata advanced

Updated runtime/source-run metadata to report:

```text
phase: 57
phaseSuffix: I
phaseName: Phase 57I - .CONST Uninitialized Storage Acceptance
```

Updated browser/protocol stale-Wasm checks, docs, status surfaces, and tests accordingly.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57I:

- Phase 57J - `.CONST` Uninitialized Storage Diagnostics and Policy.
- Configurable `const-uninitialized-storage` policy activation.
- Declaration-time warning or error for `.CONST ?` usage.
- Browser UI controls for `.CONST` declaration diagnostics.
- New diagnostic code for `.CONST ?` declarations.
- New diagnostic-family UI.
- New source-run policy fields beyond existing startup/uninitialized-read behavior.
- Broader `DUP` syntax.
- Broader expression syntax.
- Broader initializer grammar.
- Executable QWORD/SQWORD memory operations.
- `.code` memory-access policy work.
- Control flow, stack, procedure, debugger, or Irvine32 routine expansion.
- WinAPI, PE, linker, host include, macro, or external-symbol behavior.

Future work intentionally preserved:

- Phase 57J should activate/configure `const-uninitialized-storage` declaration diagnostics.
- Future `.code` memory-access-denial phases should handle `.code` protected-region access policy when explicitly scheduled.
- Future memory-reading opcodes should be added to planned-read collection when those opcodes are implemented.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `.CONST ?` and `.CONST DUP(?)` should reuse the existing parser initializer grammar for `?` and `DUP(?)` rather than adding new initializer forms.
- **Reason:** The guide states that Phase 57I should accept `.CONST ?` / `.CONST DUP(?)` using current compatible initializer behavior and must not broaden unrelated initializer grammar.
- **Risk:** Existing supported `DUP(?)` behavior may have edge cases that are broader than the minimal examples.
- **How to change later:** A later parser/initializer phase can explicitly broaden or refine initializer syntax with targeted parser diagnostics and tests.

### Assumption 2

- **Assumption:** `.CONST` uninitialized-origin metadata should be represented separately from `.data`/`.DATA?` metadata.
- **Reason:** `.CONST` and `.data` are separate VM regions and may have different base addresses under fixed, automatic deterministic, or randomized layouts.
- **Risk:** More code paths need to pass `.CONST` mask metadata alongside existing `.data` mask metadata.
- **How to change later:** A future cleanup can generalize section-origin tracking over a region-indexed metadata table if additional sections need the same behavior.

### Assumption 3

- **Assumption:** Seeded visible-byte behavior must apply to `.CONST` uninitialized-origin bytes in Phase 57I.
- **Reason:** Phase 57G explicitly planned that `.CONST ?` bytes would participate in `uninitialized_storage_visible_byte_mode` once Phase 57I accepts those declarations.
- **Risk:** Deterministic seeded-byte ordering must remain stable across sections and tests.
- **How to change later:** A future startup-state refactor can centralize seed-stream sequencing across all uninitialized-origin storage regions while preserving documented deterministic behavior.

### Assumption 4

- **Assumption:** Phase 57I should advance runtime/source-run MASM behavior metadata.
- **Reason:** The phase changes accepted MASM/source behavior, unlike display-only or documentation-only milestones.
- **Risk:** Status strings and stale-Wasm checks need synchronized updates across docs, web, tests, and protocol metadata.
- **How to change later:** Future maintenance-only milestones should advance repository/archive status without advancing runtime/source-run metadata unless their guide section explicitly requires it.

### Assumption 5

- **Assumption:** `const-uninitialized-storage` remains reserved/inactive in Phase 57I.
- **Reason:** Phase 57J owns configurable declaration diagnostics for `.CONST ?` usage.
- **Risk:** Users may expect a teaching warning immediately when writing `.CONST ?`.
- **How to change later:** Phase 57J can activate the diagnostic-policy family, add warning/error policy behavior, and update browser/source-run policy routing.

## 6. Relevant TODO-style notes reviewed

Reviewed target-owned notes:

- `docs/SUPPORTED_SYNTAX.md`: note that `.CONST ?` and `.CONST DUP(?)` remained rejected until Phase 57I.
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`: Phase 57G follow-up requiring tests after Phase 57I for `.CONST ?` / `.CONST DUP(?)` seeded visible-byte behavior while retaining read-only protection and uninitialized-origin metadata.
- `tests/core/test_data_section.c`: existing baseline test expectation that `.CONST` uninitialized storage was rejected before Phase 57I.

Reviewed future-owned notes:

- Future `.code` memory-access-denial TODO guidance in `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` and `src/core/vm_memory.c`.
- Future memory-reading opcode planned-access TODO in `src/wasm/wasm_api.c`.
- Reserved/inactive `const-uninitialized-storage` diagnostic-policy expectation in diagnostic-policy tests.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Updated supported-syntax documentation to describe `.CONST ?` and `.CONST DUP(?)` as accepted Phase 57I behavior.
- Added tests for `.CONST ?` / `.CONST DUP(?)` seeded visible-byte behavior.
- Added tests for retained uninitialized-origin metadata.
- Added tests for retained `.CONST` read-only protection.
- Replaced stale pre-57I `.CONST ?` rejection test expectations with acceptance and regression coverage.

### Future-owned TODO-style notes intentionally preserved

- Future `.code` memory-access-denial notes remain unchanged.
- Future memory-reading opcode planned-read notes remain unchanged.
- Phase 57J `const-uninitialized-storage` policy remains reserved/inactive.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style notes remain for Phase 57I.
- No new TODO-style notes were added.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 57I was implemented as a narrow extension of existing data-layout and source-run metadata plumbing.

The core design choices were:

1. **Allow `.CONST` uninitialized initializers through the existing parser path.**
   The parser no longer rejects `?` / `DUP(?)` solely because the active section is `.CONST`.

2. **Track `.CONST` initialized-byte state separately.**
   `.CONST` now has initialized-byte metadata similar to existing data-region metadata, allowing tests and source-run diagnostics to distinguish initialized constants from accepted uninitialized constants.

3. **Preserve existing memory permissions.**
   `.CONST` remains read-only. The implementation did not relax mandatory write protection.

4. **Extend existing uninitialized-read diagnostics.**
   Source-run planned-read validation now counts uninitialized-origin bytes in `.CONST` as well as `.data` where applicable.

5. **Extend existing seeded visible-byte initialization.**
   The Phase 57G seeded mode now seeds `.CONST` uninitialized-origin visible bytes without affecting initialized `.CONST` bytes.

6. **Keep Phase 57J out of scope.**
   No new declaration warning/error policy was added. The reserved `const-uninitialized-storage` family remains inactive.

7. **Use active layout metadata.**
   Review fixes ensured test-only metadata and diagnostics honor selected layout bases rather than fixed addresses.

## 9. Files changed

Changed files in the final changed-files package:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/object_map.c`
- `src/parser/object_map.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/parser/symbols.c`
- `src/parser/symbols.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_object_map.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

Added or updated tests for:

- `.CONST x DWORD ?` acceptance.
- `.CONST buf BYTE 16 DUP(?)` acceptance.
- `.CONST words WORD 4 DUP(?)` acceptance.
- `.CONST` initialized-byte masks and object-map metadata.
- Source-run reads from `.CONST ?` with default deterministic zero visible bytes.
- Source-run reads from `.CONST DUP(?)` with default deterministic zero visible bytes.
- Default `uninitialized-read` warning behavior for `.CONST ?` reads.
- Strict uninitialized-read behavior stopping before consumer mutation.
- Explicit off-mode behavior for uninitialized-read diagnostics where applicable.
- Seeded-random uninitialized visible-byte mode affecting `.CONST ?`.
- Initialized `.CONST` bytes not being randomized.
- Existing `.CONST` direct write protection with accepted `.CONST ?` symbols.
- Existing `.CONST` computed write protection with accepted `.CONST ?` symbols.
- No memory-change row on failed computed `.CONST` writes.
- Rendered Simulator Messages for `.CONST ?` uninitialized-read warning.
- Phase 57I protocol/stale-Wasm metadata.
- Malformed `.CONST` declarations still rejected after `.CONST ?` acceptance.
- Unsupported/out-of-range `.CONST` initializer forms still rejected after `.CONST ?` acceptance.
- Regression coverage for Phase 57G seeded storage behavior and Phase 57H register metadata behavior.

## 11. Commands used to test

Focused commands run during implementation and reviews:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

No subgroup or individual fixture-family reruns were required because focused groups and aggregate verification completed successfully.

Skipped dependency checks:

- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

## 12. Pass/fail results

Final verification result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Result classification:

- Aggregate completed and passed.
- Focused groups completed and passed.
- No aggregate timeout occurred.
- No focused group failed.
- No focused group timed out.
- Browser/Wasm rebuild smoke was skipped because the `emcc` dependency was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Phase 57I is website-testable after rebuilding `web/dist` with Emscripten. It is also local-testable through native/source-run tests without Emscripten.

### Browser setup

On Windows CMD with Emscripten activated:

```cmd
where emcc
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open:

```text
http://localhost:8000
```

If `emcc` is unavailable, skip browser testing and use local tests.

### Browser Program 1 - `.CONST ?` and `.CONST DUP(?)` accepted and readable

```asm
.CONST
limit DWORD ?
buf BYTE 4 DUP(?)
ready DWORD 9
.code
main PROC
    mov eax, limit
    mov ebx, DWORD PTR buf
    mov ecx, ready
main ENDP
END main
```

Expected Program Console:

```text
```

Expected Simulator Messages:

```text
[simulator-warning] uninitialized-read line 7: Memory read range 00600000h..00600003h reads 4 bytes from limit + 0; 4 of those bytes still originated from uninitialized storage.
[simulator-warning] uninitialized-read line 8: Memory read range 00600004h..00600007h reads 4 bytes from buf + 0; 4 of those bytes still originated from uninitialized storage.
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected key final registers:

```text
EAX = 00000000h / u: 0 / s: 0
EBX = 00000000h / u: 0 / s: 0
ECX = 00000009h / u: 9 / s: 9
```

Expected Memory Changes:

```text
No memory changes.
```

### Browser Program 2 - direct write to `.CONST ?` remains rejected

```asm
.CONST
limit DWORD ?
.code
main PROC
    mov limit, 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] const-write line 5: Cannot write to .CONST data. Constant data is read-only.
```

Expected behavior:

- Program does not execute.
- No final memory change is committed.
- No `execution-complete` message appears.

### Browser Program 3 - computed write to `.CONST ?` remains rejected at runtime

```asm
.CONST
limit DWORD ?
.code
main PROC
    mov eax, OFFSET limit
    mov DWORD PTR [eax], 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] permission-denied line 6: Memory write at 00600000h for 4 bytes is not permitted in .const.
```

Expected key final register:

```text
EAX = 00600000h / u: 6291456 / s: 6291456
```

Expected Memory Changes:

```text
No memory changes.
```

### Windows CMD focused local checks

```cmd
py scripts\run_tests.py --source-run
py scripts\run_tests.py --diagnostics
py scripts\run_tests.py --protocol
```

Expected snippets:

```text
[source-run] PASS
[diagnostics] PASS
[protocol] PASS
```

Full verification:

```cmd
py scripts\run_tests.py --all
```

Expected snippets:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
All implemented milestone tests passed.
```

If `emcc` is unavailable, this skip line is expected and is not a regression:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Regression signs:

- `.CONST x DWORD ?` still reports an assembly error.
- `.CONST buf BYTE 4 DUP(?)` still reports an assembly error.
- Reading `.CONST ?` succeeds but emits no `uninitialized-read` warning under default settings.
- Seeded uninitialized-storage mode leaves `.CONST ?` at zero when seeded-random is enabled.
- Initialized `.CONST` data changes under seeded uninitialized-storage mode.
- Direct `.CONST ?` writes execute successfully.
- Computed `.CONST ?` writes create memory-change rows.
- Phase metadata does not include `phaseSuffix:"I"` and `Phase 57I - .CONST Uninitialized Storage Acceptance`.
- Browser shows stale-Wasm artifact warnings after rebuilding.

## 14. Compliance review summary

First compliance review found and corrected these issues:

- Test-only uninitialized-origin metadata for `.CONST` used fixed bases instead of selected layout-policy bases.
- Source-run tests did not explicitly cover direct and computed writes to `.CONST ?`.
- Rendered Simulator Messages did not yet include an exact Phase 57I `.CONST ?` uninitialized-read warning fixture.

Fixes applied during compliance review:

- Updated test-only metadata emission to use selected layout-policy bases.
- Added direct/computed `.CONST ?` write-protection source-run coverage.
- Added rendered Simulator Messages coverage for `.CONST ?` uninitialized-read warning.

Compliance result:

- Focused test groups passed.
- Aggregate test suite completed and passed.
- No runtime/source behavior outside Phase 57I was introduced.

## 15. Re-review summary

Second compliance review found two documentation/comment issues:

- `tests/core/test_wasm_source_run.c` file-level brief still referred to Phase 57H display metadata.
- `docs/MILESTONE_HISTORY.md` current status was correct, but the concise milestone ledger ended at Phase 57H.

Fixes applied during re-review:

- Updated the source-run test file header to Phase 57I.
- Added a concise Phase 57I ledger entry to milestone history.

Final gap check found one additional test-coverage gap:

- Explicit `.CONST` regression coverage for malformed declarations and unsupported/out-of-range initializer forms was missing after `.CONST ?` acceptance.

Fix applied during final gap check:

- Added `.CONST BYTE 0 DUP(?)` rejection coverage for `invalid-dup`.
- Added `.CONST SBYTE 128` rejection coverage for `number-out-of-range`.

Final result:

- Aggregate test suite completed and passed.
- No stale TODO-style notes remained.
- Phase 57I was judged complete.

## 16. User-test follow-up summary

No Prompt 8 user-test discrepancy triage occurred. The user reported that everything appeared to pass and proceeded directly to the final gap check.

No user-test follow-up fixes were required.

## 17. Known limitations

- Emscripten `emcc` was unavailable in the assistant/container environment, so browser/Wasm rebuild smoke was skipped.
- Browser testing requires rebuilding `web/dist` in an environment with Emscripten available.
- No browser UI controls were added for `.CONST` declaration diagnostics.
- The `const-uninitialized-storage` diagnostic-policy family remains reserved/inactive until Phase 57J.
- No latest full repository archive was produced during this milestone-report step.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57J - .CONST Uninitialized Storage Diagnostics and Policy
```

Phase 57J should add the configurable declaration diagnostic/policy behavior that was intentionally excluded from Phase 57I.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

- `milestone_57I_changed_files.zip`
- `milestone_57I_compliance_review_changed_files.zip`
- `milestone_57I_second_review_changed_files.zip`
- `milestone_57I_final_gap_check_changed_files.zip`

Latest consolidated changed-files package:

```text
milestone_57I_final_gap_check_changed_files.zip
```

Recommended full repository archive name after applying the final changed-files package and accepting the milestone:

```text
Latest_repository_state_milestone_57I.zip
```

A full latest repository archive was not produced in this report step.
