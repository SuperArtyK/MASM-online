# Milestone 43 report - INC and DEC

## 1. Milestone title and scope

Milestone 43 implements Phase 43 - INC and DEC for the Online MASM32 Educational Simulator.

Scope implemented:

- Add `inc` and `dec` as executable runtime instructions.
- Support register destinations at 8-bit, 16-bit, and 32-bit widths.
- Support unambiguous memory destinations through typed symbols, symbol offsets, and explicit PTR forms.
- Support signed PTR aliases by width for `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR`.
- Preserve MASM-compatible rejection for ambiguous memory destinations such as `inc [eax]` and `dec [eax]`.
- Preserve existing MASM32 Educational Mode rejection for executable QWORD/SQWORD memory operations.
- Update source-run and browser metadata to report phase 43.
- Add native C, parser, source-run JSON, and rendered Simulator Messages coverage.

The implementation stayed within the milestone boundary. No future instruction groups or control-flow behavior were added.

## 2. Source-of-truth files used

Canonical files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 42 report.md`

Interpretation rules used:

- The full implementation specification owns stable behavior and product boundaries.
- The incremental implementation guide owns phase numbering, phase tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are evidence and continuity documents, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.

## 3. Exact requirements implemented

Phase 43 required `inc` and `dec` as a focused read-modify-write instruction milestone.

Accepted syntax implemented:

```asm
inc reg8
inc reg16
inc reg32
inc BYTE PTR [reg32]
inc WORD PTR [reg32]
inc DWORD PTR [reg32]
inc symbol
inc symbol[offset]

dec reg8
dec reg16
dec reg32
dec BYTE PTR [reg32]
dec WORD PTR [reg32]
dec DWORD PTR [reg32]
dec symbol
dec symbol[offset]
```

Signed PTR aliases implemented equivalently by width:

```asm
inc SBYTE PTR [esi]
dec SWORD PTR [esi]
inc SDWORD PTR [esi]
```

Rejected syntax verified:

```asm
inc 1
dec 1
inc eax, ebx
dec eax, ebx
inc [eax]
dec [eax]
inc QWORD PTR q
dec SQWORD PTR q
```

Runtime semantics implemented:

- `inc` computes `dest = dest + 1` at selected operand width.
- `dec` computes `dest = dest - 1` at selected operand width.
- Register destinations mutate only the selected register or alias width.
- Memory destinations are read-modify-write operations.
- Memory reads and writes route through checked VM memory helpers.
- `.CONST` direct memory destinations fail during assembly when obvious.
- `.CONST` computed memory destinations fail through central runtime memory permissions.
- Failed reads/writes do not mutate registers, flags, memory, console state, or memory-change rows.

Flag behavior implemented:

- `ZF` updates from result.
- `SF` updates from result sign bit at operand width.
- `OF` updates for signed overflow.
- `CF` is preserved exactly.
- Other x86 flags remain unmodeled.

Diagnostics implemented or verified:

- `invalid-instruction-operands` for immediate destinations, wrong operand counts, and invalid operand shapes.
- `ambiguous-memory-width` for untyped register-indirect memory destinations.
- Existing unsupported-runtime diagnostics for executable QWORD/SQWORD memory operations remain in force.
- Runtime memory diagnostics for invalid address, permission failure, and `.CONST` overlap remain structured and rendered.
- Diagnostic source location data remains preserved: line, column, byte offset, and span length where applicable.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 43:

- `and`, `or`, `xor`
- `not`
- `shl`, `sal`, `shr`, `sar`
- `rol`, `ror`
- `lea`
- `mul`, `imul`, `div`, `idiv`
- `cmp`
- labels, `jmp`, conditional jumps, or `loop`
- `push`, `pop`, `call`, `ret`, `leave`, or stack behavior
- procedure metadata, stack frames, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR`
- Irvine32 routine bodies beyond the existing `exit` virtual terminator
- Program Console input/output routines
- scaled-index addressing
- executable QWORD/SQWORD memory operations
- Windows API, PE loading, object linking, host include loading, or macro behavior

Next planned instruction family is Phase 44 - AND, OR, and XOR.

## 5. Assumptions used

### Assumption 1

Assumption: `inc` and `dec` should be represented as dedicated IR opcodes rather than lowered to `add dest, 1` and `sub dest, 1`.

Reason: `inc` and `dec` differ from `add` and `sub` because they preserve `CF`. Dedicated opcodes make that behavior explicit and testable.

Risk: Adds two opcodes and executor cases.

How to change later: A future internal lowering pass could map them to a shared arithmetic helper if CF preservation remains explicit and covered by tests.

### Assumption 2

Assumption: Existing arithmetic helper behavior should be reused conceptually, but INC/DEC should have an explicit executor path that preserves CF and rolls back state on failed writes.

Reason: Existing arithmetic behavior already handles width-aware flag edge cases, but Phase 43 requires no partial mutation when memory writes fail.

Risk: If a future executor refactor changes helper side effects, INC/DEC rollback behavior could regress.

How to change later: Keep dedicated INC/DEC unit tests around failed writes and CF preservation; optionally factor a documented flag-only helper for INC/DEC.

### Assumption 3

Assumption: Direct `.CONST` symbol destinations should use the existing static const-write diagnostic path, while computed `.CONST` destinations should fail through checked memory at runtime.

Reason: The specification requires both static diagnostics for obvious `.CONST` writes and runtime protection for final effective address ranges.

Risk: A direct symbol-offset form missed by static detection could still fail at runtime but produce a different diagnostic phase.

How to change later: Extend static `.CONST` detection coverage without weakening runtime checks.

### Assumption 4

Assumption: Phase metadata should advance to 43 in source-run JSON and browser protocol metadata.

Reason: Milestone 42 advanced metadata, and tests already verify current implemented phase information.

Risk: Metadata updates touch UI/protocol files even though the feature is implemented in core/parser/executor.

How to change later: Centralize phase metadata if the project later separates runtime support metadata from browser sample metadata.

## 6. Design summary

### IR

Added two opcodes:

```text
VM_IR_OPCODE_INC
VM_IR_OPCODE_DEC
```

Opcode-name mapping now reports:

```text
inc
dec
```

### Parser

The parser recognizes `inc` and `dec` as unary destination instructions. It reuses existing destination parsing and memory-width resolution rules.

Parser behavior:

- Accepts register destinations.
- Accepts direct typed symbols and typed symbol offsets.
- Accepts explicit PTR memory destinations.
- Accepts signed PTR aliases by width.
- Rejects immediate destinations.
- Rejects extra operands.
- Rejects untyped register-indirect memory destinations with `ambiguous-memory-width`.
- Rejects executable QWORD/SQWORD memory operations using the existing unsupported-runtime path.
- Emits static `.CONST` write diagnostics for direct `.CONST` destinations.

### Executor

The executor handles INC/DEC through a narrow read-modify-write helper.

Execution algorithm:

1. Resolve and validate the destination operand.
2. Read the destination value.
3. Save pre-instruction CPU/flag state.
4. Compute result at operand width.
5. Update `ZF`, `SF`, and `OF`.
6. Restore the original `CF` bit.
7. Write the result back to the register or memory destination.
8. If a write fails, restore CPU/flag state so no partial mutation is visible.

Memory behavior:

- All memory reads go through checked VM read helpers.
- All memory writes go through checked VM write helpers.
- `.CONST` permission checks remain enforced by final address range.
- Invalid read failures occur before write-back.
- Failed writes do not create successful memory-change rows.

### Documentation and metadata

Updated documentation and metadata to describe Phase 43 as the current implemented milestone and to list `inc`/`dec` as supported instructions.

## 7. Files changed

Final Phase 43 changed files:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

Changed-files packages produced:

```text
/mnt/data/milestone43_changed_files.zip
/mnt/data/milestone43_compliance_review_changed_files.zip
/mnt/data/milestone43_second_review_changed_files.zip
```

The latest package is:

```text
/mnt/data/milestone43_second_review_changed_files.zip
```

## 8. Tests added

### Parser tests

Added or expanded coverage for:

- `inc al`
- `inc ax`
- `inc eax`
- `dec al`
- `dec ax`
- `dec eax`
- explicit `BYTE PTR`, `WORD PTR`, and `DWORD PTR` forms
- signed `SBYTE PTR`, `SWORD PTR`, and `SDWORD PTR` aliases
- direct symbol destinations
- symbol-offset destinations
- immediate destination rejection
- extra operand rejection
- ambiguous memory-width rejection
- QWORD/SQWORD executable memory-operation rejection
- direct `.CONST` write rejection

### Executor tests

Added or expanded coverage for:

- `inc al`: `7Fh -> 80h`, `OF=1`, `CF` preserved
- `dec al`: `80h -> 7Fh`, `OF=1`, `CF` preserved
- `inc ax`: `7FFFh -> 8000h`, `OF=1`, `CF` preserved
- `dec ax`: `8000h -> 7FFFh`, `OF=1`, `CF` preserved
- `inc eax`: `FFFFFFFFh -> 00000000h`, `ZF=1`, `CF` preserved
- `dec eax`: `00000000h -> FFFFFFFFh`, `SF=1`, `CF` preserved
- register alias-width mutation
- memory read-modify-write success
- invalid memory read failure
- `.CONST` permission failure
- no partial mutation on failed memory writes

### Source-run JSON tests

Added or expanded coverage for:

- successful register program
- successful memory program
- ambiguous memory-width diagnostic
- invalid operand diagnostics
- direct `.CONST` diagnostic
- computed `.CONST` runtime failure
- invalid runtime address failure
- phase metadata reporting `43`

### Rendered Simulator Messages tests

Added or expanded exact rendered-message coverage for:

- successful execution line
- `ambiguous-memory-width` from `inc [eax]`
- `invalid-instruction-operands` from `inc 1`
- `invalid-instruction-operands` from `inc eax, ebx`
- direct `.CONST` write diagnostic from `dec limit`
- runtime permission failure from computed `.CONST` INC
- runtime invalid address from DEC memory read

### Regression tests

Regression coverage confirms:

- Existing `add`, `sub`, `adc`, `sbb`, `neg`, `test`, `xchg`, `nop`, and carry-control behavior remains intact.
- Existing Milestone 42 `exit` behavior remains intact.
- Ambiguous memory-width behavior remains MASM-compatible.
- Executable QWORD/SQWORD memory operations remain rejected in MASM32 Educational Mode.
- Program Console remains separate from Simulator Messages.

## 9. Commands used to test

Primary aggregate test command:

```sh
cd /mnt/data/repo_m43
python3 scripts/run_tests.py
```

Observed result:

```text
All implemented milestone tests passed.
```

Wasm rebuild check attempted:

```sh
cd /mnt/data/repo_m43
bash scripts/build_wasm.sh
```

Observed result in this container:

```text
scripts/build_wasm.sh: line 18: emcc: command not found
```

Interpretation:

- Native C and Node tests pass.
- This container cannot rebuild Wasm because Emscripten is not installed.
- Served website behavior requires a local Wasm rebuild in an Emscripten-enabled environment.

## 10. Pass/fail results

Final automated test status:

```text
PASS - native C tests
PASS - parser tests
PASS - executor tests
PASS - source-run JSON tests
PASS - Node formatter/protocol tests
PASS - rendered Simulator Messages tests
PASS - milestone/static structure tests
PASS - aggregate test runner
SKIPPED/UNAVAILABLE - Wasm rebuild in this container because emcc is not installed
```

Manual user testing status:

```text
PASS - all 8 provided manual programs matched expected output
```

## 11. Manual/browser testing guidance and expected outputs

Website-testable: yes, after rebuilding Wasm locally with Emscripten.

Windows setup assumptions:

```cmd
emcc --version
py --version
node --version
```

Build and serve on Windows:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

Stop server:

```cmd
scripts\windows\stop_web.cmd
```

Local Windows test command:

```cmd
set CC=clang
py scripts\run_tests.py
```

Expected:

```text
All implemented milestone tests passed.
```

Manual program 1 - register INC/DEC and CF preservation:

```asm
.code
main PROC
    stc
    mov eax, 0FFFFFFFFh
    inc eax
    dec eax
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    FFFFFFFFh / 4294967295
EFLAGS 00000081h / 129
```

Expected flags:

```text
CF = 1
ZF = 0
SF = 1
OF = 0
```

Expected Memory Changes:

```text
No memory changes.
```

Manual program 2 - writable memory read-modify-write:

```asm
.data
value DWORD 41
bytes BYTE 1, 2, 3
.code
main PROC
    inc value
    dec BYTE PTR bytes[1]
    mov eax, value
    mov bl, BYTE PTR bytes[1]
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected important registers:

```text
EAX    0000002Ah / 42
EBX    00000001h / 1
EFLAGS 00000000h / 0
```

Expected Memory Changes:

```text
value: 00000029h / 41 -> 0000002Ah / 42
bytes + 1 BYTE
  byte offset: +1
  element index: 1
  02h / 2 -> 01h / 1
```

Manual program 3 - alias-width overflow edge cases:

```asm
.code
main PROC
    stc
    mov eax, 0
    mov al, 7Fh
    inc al
    mov bx, 8000h
    dec bx
main ENDP
END main
```

Expected important registers:

```text
EAX    00000080h / 128
EBX    00007FFFh / 32767
EFLAGS 00000801h / 2049
```

Expected flags after final `dec bx`:

```text
CF = 1
ZF = 0
SF = 0
OF = 1
```

Manual program 4 - ambiguous memory width:

```asm
.code
main PROC
    inc [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 3, column 9, byte offset 24, span length 1: Memory operand width is ambiguous. Use BYTE PTR, WORD PTR, or DWORD PTR.
```

Manual program 5 - invalid INC destination:

```asm
.code
main PROC
    inc 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 3, column 9, byte offset 24, span length 1: INC requires a register or memory destination.
```

Manual program 6 - direct `.CONST` DEC:

```asm
.CONST
limit DWORD 10
.code
main PROC
    dec limit
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] const-write line 5, column 9, byte offset 46, span length 5: Cannot write to .CONST data. Constant data is read-only.
```

Manual program 7 - computed `.CONST` INC runtime failure:

```asm
.CONST
limit DWORD 10

.code
main PROC
    mov eax, OFFSET limit
    inc DWORD PTR [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] permission-denied line 7: Memory write at 00600000h for 4 bytes is not permitted in .const.
```

Expected important registers:

```text
EAX    00600000h / 6291456
EFLAGS 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Manual program 8 - invalid runtime address:

```asm
.code
main PROC
    mov eax, 0
    dec DWORD PTR [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[runtime-error] invalid-address line 4: Invalid memory read at 00000000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

Expected important registers:

```text
EAX    00000000h / 0
EFLAGS 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- `inc` or `dec` reported as unknown.
- `CF` changes after INC/DEC.
- `ZF`, `SF`, or `OF` edge cases are wrong.
- Untyped `[eax]` executes instead of producing `ambiguous-memory-width`.
- `.CONST` storage mutates.
- Failed runtime writes produce memory-change rows.
- Program Console receives unexpected output.
- Source-run metadata does not report phase 43.

## 12. Compliance review summary

First compliance review found and fixed:

- Missing explicit parser coverage for `WORD PTR`, `DWORD PTR`, and `SDWORD PTR` INC/DEC memory forms.
- Missing source-run/rendered coverage for INC/DEC invalid runtime address.
- Minor stale assertion wording in two source-run tests.

Files changed during first compliance review:

```text
tests/core/test_parser.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
```

Test result after fixes:

```text
All implemented milestone tests passed.
```

Verdict after first compliance review:

```text
complete
```

## 13. Re-review summary

Second compliance review found and fixed:

- Additional test gaps for `SBYTE PTR`, `dec 1`, `inc eax, ebx`, `dec SQWORD PTR`, and direct `dec .CONST`.
- Missing rendered-message coverage for INC/DEC invalid-operand and direct `.CONST` diagnostics.
- One stale executor test file comment that described only the older execution slice plus Phase 42 exit.

Files changed during second review:

```text
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
```

Test result after fixes:

```text
All implemented milestone tests passed.
```

Final re-review verdict:

```text
complete
```

## 14. User-test follow-up summary

The user ran all 8 manual programs.

Observed results:

- Program 1 matched expected output.
- Program 2 matched expected output.
- Program 3 matched expected output.
- Program 4 matched expected output.
- Program 5 matched expected output.
- Program 6 matched expected output.
- Program 7 matched expected output.
- Program 8 matched expected output.

Diagnosis:

```text
No discrepancies. No fixes required.
```

Regression tests added after user test follow-up:

```text
None required.
```

## 15. Known limitations

- Wasm artifacts were not rebuilt in this container because `emcc` is unavailable.
- Served website testing requires a local Emscripten-enabled rebuild.
- Browser manual testing is valid only after rebuilding `web/dist` from the updated C/Wasm source.
- Executable QWORD/SQWORD memory operations remain deferred to a future Extended 32-bit Mode phase.
- Future instruction groups remain unimplemented until their own milestones.
- No new Program Console or Irvine32 routine behavior was added.

## 16. Next recommended milestone

Next recommended milestone:

```text
Phase 44 - AND, OR, and XOR
```

Phase 44 should remain limited to the logical binary instruction family and must not implement `not`, shifts, rotates, `test`, `cmp`, jumps, multiplication, division, or future bitwise instructions beyond `and`, `or`, and `xor`.

## 17. Changed-files ZIP/package produced

Latest changed-files package:

```text
/mnt/data/milestone43_second_review_changed_files.zip
```

Earlier packages produced during the milestone:

```text
/mnt/data/milestone43_changed_files.zip
/mnt/data/milestone43_compliance_review_changed_files.zip
```

Recommended full repository archive name after applying the latest changed-files package:

```text
Latest_repository_state_milestone_43.zip
```

## 18. Final status

Milestone 43 is complete.

It implements `inc` and `dec` only, includes success/error/edge/regression tests, preserves prior milestone behavior, updates user-visible documentation and metadata, passes the aggregate test suite, and passed user manual verification.
