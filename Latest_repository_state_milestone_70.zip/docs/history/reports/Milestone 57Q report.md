# Milestone 57Q report - INCLUDELIB and External Library Diagnostics

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57Q - INCLUDELIB and External Library Diagnostics
```

Repository/archive milestone after this work:

```text
Phase 57Q - INCLUDELIB and External Library Diagnostics
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 57Q - INCLUDELIB and External Library Diagnostics
```

Scope implemented:

- Added narrow, directive-context recognition for `INCLUDELIB` operand tails, including basename `.lib` operands and path-like library operands.
- Added structured parser/source-run diagnostics for unsupported linker/library/import-library directives.
- Replaced path-like `INCLUDELIB` lexer noise with one directive-level diagnostic per `INCLUDELIB` line.
- Added distinct diagnostic codes for generic libraries, MASM32 libraries, and Windows/API import libraries.
- Preserved Phase 57P host/path-like `INCLUDE` diagnostics.
- Preserved supported virtual include behavior for `INCLUDE Irvine32.inc` and `INCLUDE Macros.inc`.
- Preserved the project boundary that the simulator does not link, load `.lib` files, resolve PE imports, or execute external routines.
- Updated status surfaces to Phase 57Q because this milestone changes runtime/source-run source-diagnostic behavior.
- Updated exact rendered Simulator Messages tests and docs after user feedback to make all `INCLUDELIB` diagnostics share the same support-boundary explanation before category-specific details.

Representative source forms now diagnosed cleanly:

```asm
includelib customlib.lib
includelib masm32.lib
includelib kernel32.lib
includelib \masm32\lib\masm32.lib
includelib \masm32\lib\kernel32.lib
includelib C:\masm32\lib\kernel32.lib
```

These forms are not accepted as no-ops and are not executed. They are recognized only to produce stable, user-friendly diagnostics.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status and verification files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57P report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_57P.zip
```

Repository archive recommended after implementation:

```text
Latest_repository_state_milestone_57Q.zip
```

A full latest repository archive was not produced during this session. Changed-files packages were produced and are listed in Section 19.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, status-surface hygiene, and stable browser/source-run behavior expectations.
- The incremental implementation guide owns phase numbering, target milestone scope, per-phase tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only. They do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

## 3. Exact requirements implemented

### 3.1 `INCLUDELIB` directive diagnostics

Phase 57Q adds targeted handling for `INCLUDELIB` directive operands. The implementation recognizes `INCLUDELIB` in line-leading directive context and captures a library operand tail so the parser can emit one structured assembly diagnostic for the directive.

The implementation covers the required examples:

```asm
includelib \masm32\lib\masm32.lib
includelib \masm32\lib\kernel32.lib
includelib kernel32.lib
includelib masm32.lib
includelib C:\masm32\lib\kernel32.lib
```

It also covers generic `.lib` operands such as:

```asm
includelib customlib.lib
```

### 3.2 Diagnostic taxonomy

The milestone implements distinct diagnostics:

```text
unsupported-includelib
unsupported-windows-api-library
unsupported-masm32-library
```

Classification implemented:

- `unsupported-includelib` for generic library operands such as `customlib.lib`.
- `unsupported-masm32-library` for `masm32.lib` and path-qualified MASM32 library references.
- `unsupported-windows-api-library` for `kernel32.lib`, `user32.lib`, `gdi32.lib`, `windows.lib`, and path-qualified Windows/API import-library references.

The guide permitted a single `unsupported-includelib` diagnostic, but recommended distinct codes. The implementation uses the distinct-code path to preserve the diagnostic clarity established by Phase 57P.

### 3.3 Shared support-boundary wording

After manual user review, the exact diagnostic wording was reworked so all `INCLUDELIB` diagnostics start with the same support-boundary explanation:

```text
INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines.
```

Category-specific details are then appended:

- Generic library: `Library operand '<operand>' cannot be used; execution stops before program start.`
- MASM32 library: `MASM32 library '<operand>' requires external library linking.`
- Windows/API library: `Windows import library '<operand>' requires PE imports and WinAPI execution.`

This avoids implying that some `INCLUDELIB` form might work while still explaining why a specific operand received a specialized diagnostic.

### 3.4 Lexer noise suppression for recognized `INCLUDELIB` operands

Before Phase 57Q, path-like `INCLUDELIB` operands containing backslashes could still degrade into low-level lexer diagnostics, such as repeated `unexpected-character`, because Phase 57P intentionally handled only `INCLUDE` path operands.

Phase 57Q extends the narrow directive-tail path to `INCLUDELIB` so recognized library path tails are passed to the parser as one operand for diagnostic classification. This does not make path syntax generally valid MASM syntax.

### 3.5 Execution refusal and stream separation

Source containing `INCLUDELIB` diagnostics refuses execution before runtime begins.

Required behavior implemented:

- No `execution-complete` message after an `INCLUDELIB` assembly diagnostic.
- No Program Console output for `INCLUDELIB` failures.
- No register mutation from subsequent `.code` instructions.
- No linker metadata, import metadata, or external routine metadata is created.

### 3.6 Existing behavior preserved

The following existing behavior was preserved:

- Phase 57P host/path-like `INCLUDE` diagnostics:
  - `unsupported-host-include-path`
  - `unsupported-masm32-library-include`
  - `unsupported-windows-api-include`
- `INCLUDE Irvine32.inc` remains a supported virtual include.
- `INCLUDE Macros.inc` remains limited virtual compatibility metadata/no-op behavior.
- Virtual `exit` remains available when `INCLUDE Irvine32.inc` is active.
- Path separators outside recognized directive-tail contexts remain invalid syntax.

### 3.7 Status surfaces updated

Because Phase 57Q changes source-visible parser and diagnostic behavior, both project status values advanced:

```text
Repository/archive milestone:
Phase 57Q - INCLUDELIB and External Library Diagnostics

Runtime/source-run MASM behavior phase:
Phase 57Q - INCLUDELIB and External Library Diagnostics
```

Updated status surfaces include:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- source-run/Wasm status metadata
- browser static status text
- worker/protocol metadata
- protocol/static tests

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57Q:

- Host filesystem access.
- Include search paths.
- Library search paths.
- MASM32 SDK file loading.
- MASM32 SDK `.lib` loading.
- `.lib` parsing or loading.
- Object-file linking.
- PE loading.
- PE import resolution.
- Windows imports.
- WinAPI execution.
- External library routine execution.
- `ExitProcess` handling.
- `INVOKE`, `PROTO`, `LOCAL`, `EXTERN`, `PUBLIC`, `COMM`, or object-linkage behavior.
- Procedure, stack, call, return, control-flow, debugger, or Irvine32 routine expansion.
- Macro expansion.
- New virtual include behavior.
- General path expression grammar.
- General backslash token support outside narrow directive-tail contexts.
- Broader MASM preprocessor behavior.

Future work intentionally preserved:

- Phase 57R - Unsupported INVOKE, ADDR, and External Routine Diagnostics.
- Later external-symbol, procedure, stack, call/return, control-flow, debugger, and Irvine32 routine milestones.
- Later macro/high-level-flow milestones.
- Later realistic playground or multi-feature recovery fixtures.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Use the distinct recommended diagnostic codes `unsupported-includelib`, `unsupported-windows-api-library`, and `unsupported-masm32-library` rather than a single generic `unsupported-includelib` code.
- **Reason:** The guide recommends distinct codes, and Phase 57P already established a similar diagnostic taxonomy for host/path-like `INCLUDE` operands.
- **Risk:** More parser, JSON, rendered-message, documentation, and static-test updates are required than a single-code implementation.
- **How to change later:** Collapse categories to one generic code only if a future guide revision deliberately simplifies diagnostic taxonomy. Preserve clear category-specific rendered wording if this happens.

### Assumption 2

- **Assumption:** Reuse the narrow line-oriented directive-tail approach introduced by Phase 57P, extended only to `INCLUDELIB`.
- **Reason:** Phase 57Q requires path-like `INCLUDELIB` diagnostics without making library paths general expressions or general MASM tokens. The existing directive-tail seam is the smallest reviewable change.
- **Risk:** The token/helper path must remain carefully scoped so path syntax does not leak into ordinary MASM syntax.
- **How to change later:** Replace this with a neutral directive-tail lexer state or parser-owned token mode in a later cleanup phase while preserving the Phase 57P/57Q diagnostics and tests.

### Assumption 3

- **Assumption:** Classify `kernel32.lib`, `user32.lib`, `gdi32.lib`, and `windows.lib` as Windows/API import libraries; classify `masm32.lib` as a MASM32 library; classify other `.lib` operands as generic unsupported `INCLUDELIB`.
- **Reason:** The guide explicitly names `kernel32.lib` and `masm32.lib`. Adding a small set of common Windows import library names keeps diagnostics useful without implementing future behavior.
- **Risk:** Users may expect additional Windows import libraries, such as `advapi32.lib` or `shell32.lib`, to receive the Windows/API diagnostic.
- **How to change later:** Add more recognized Windows import library basenames in a future diagnostic-refinement phase with parser/source-run/rendered-message tests.

### Assumption 4

- **Assumption:** The diagnostic source span should point to the library operand, not the `INCLUDELIB` keyword.
- **Reason:** The operand is the user-actionable text and matches the Phase 57P path-tail diagnostic pattern.
- **Risk:** A future diagnostic-style cleanup might standardize all directive diagnostics on directive-token spans instead.
- **How to change later:** Update parser/source-run/rendered-message tests together if the project adopts directive-keyword spans for this family later.

### Assumption 5

- **Assumption:** The shared support-boundary wording should be short enough to fit the existing parser diagnostic message buffer.
- **Reason:** Initial user-approved wording exceeded the current 256-byte formatted diagnostic message buffer after operand substitution. Shorter wording preserves meaning without requiring a broader diagnostic-buffer change outside target scope.
- **Risk:** The message is slightly denser than the first draft.
- **How to change later:** If a later diagnostic-infrastructure phase expands the buffer or uses dynamically sized diagnostic text, the wording can be expanded while keeping the same shared-invariant/category-specific structure.

### Assumption 6

- **Assumption:** Browser/Wasm rebuild smoke can be reported as skipped when `emcc` is unavailable in the assistant/container environment.
- **Reason:** Emscripten is not installed in this environment.
- **Risk:** Served browser artifacts can remain stale until rebuilt locally or in CI.
- **How to change later:** Rebuild with Emscripten locally or in CI and run the manual browser verification programs in Section 13.

## 6. Relevant TODO-style notes reviewed

Target-owned TODO-style notes and TODO-style evidence reviewed:

- Phase 57Q requirements in `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` for `INCLUDELIB` and external library diagnostics.
- Phase 57P guide boundary text stating that `INCLUDELIB` is handled separately by Phase 57Q.
- Existing generic unsupported parser path in `src/parser/parser.c` that emitted `INCLUDELIB linker declarations are not supported yet.`
- Existing source-run regression in `tests/core/test_wasm_source_run.c` that intentionally left path-like `INCLUDELIB` diagnostics to Phase 57Q.
- Existing parser test in `tests/core/test_parser.c` for `INCLUDELIB kernel32.lib` through the previous generic unsupported path.
- Milestone 57P report note preserving Phase 57Q as the owner of `INCLUDELIB` diagnostics.

Future-owned TODO-style notes reviewed and intentionally not implemented:

- `INVOKE`, `ADDR`, and external routine diagnostics, now owned by Phase 57R.
- `PROTO`, `LOCAL`, `EXTERN`, `PUBLIC`, `COMM`, procedure, call, stack, return, and control-flow behavior.
- Irvine32 routine bodies beyond current virtual `exit` behavior.
- WinAPI/external execution behavior.
- Macro expansion.
- QWORD/SQWORD executable memory operations.
- Scaled-index memory operands.
- Future realistic playground fixture expansion.

Broad TODO-style categories reviewed and excluded as irrelevant to Phase 57Q:

- Future debugger/editor/share/URL work.
- Future high-level flow.
- Future stack and heap runtime behavior.
- Historical milestone-report wording and generated artifacts.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 57Q `INCLUDELIB` diagnostics implemented and tested.
- Existing generic `INCLUDELIB ... not supported yet` parser path replaced with stable Phase 57Q linker/library/import diagnostics.
- Existing path-like `INCLUDELIB` lexer-noise regression updated to expect structured Phase 57Q diagnostics.
- Existing parser test for `INCLUDELIB kernel32.lib` updated and expanded.
- Supported-syntax and current-status documentation updated to Phase 57Q.

### Future-owned TODO-style notes intentionally preserved

- Phase 57R `INVOKE`, `ADDR`, and external routine diagnostics remain future-owned.
- Later stack/procedure/control-flow, WinAPI/external execution, macro, Irvine32 routine, QWORD/SQWORD execution, scaled-index addressing, debugger, and playground-fixture work remain deferred.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style notes required correction.
- Stale file-level comments in touched files were corrected during compliance review.
- Stale README Phase 57P current-status wording was corrected during second review.
- Duplicated current-status wording in milestone history was corrected during second review.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 57Q was implemented as a focused diagnostics-quality milestone.

Primary design choices:

1. **Keep `INCLUDELIB` out of executable semantics.** `INCLUDELIB` is recognized only to emit stable diagnostics. It does not become a virtual include, no-op, metadata declaration, linker declaration, or external-call enabler.

2. **Keep path syntax narrow.** Library path tails are recognized only when `INCLUDELIB` appears as a line-leading directive. Backslashes, slashes, drive-letter paths, and `.lib` basenames are not made valid general MASM syntax.

3. **Classify by library category.** The parser maps operands to generic unsupported library, MASM32 library, or Windows/API import-library diagnostics.

4. **Use shared invariant wording.** All `INCLUDELIB` diagnostics now begin by stating that `INCLUDELIB` is unsupported and that the simulator does not link objects, load `.lib` files, process PE imports, or execute external routines. Category-specific text follows.

5. **Preserve existing virtual include behavior.** `INCLUDE Irvine32.inc` and `INCLUDE Macros.inc` remain on their existing virtual include paths and are not reclassified as host filesystem or library-loading attempts.

6. **Preserve UI stream separation.** All Phase 57Q diagnostics are assembly diagnostics rendered through Simulator Messages. Program Console output remains empty for these failures.

7. **Advance runtime/source-run metadata.** Phase 57Q changes source-visible parser/diagnostic behavior, so repository/archive and runtime/source-run phase metadata both advance to Phase 57Q.

## 9. Files changed

Files changed across implementation, compliance review, second review, user-test follow-up, and final wording cleanup:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/lexer.c`
- `src/parser/lexer.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_lexer.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

### Lexer tests

Added coverage for:

- line-leading `includelib` with host/path-like library tails;
- basename `.lib` operands such as `kernel32.lib`, `masm32.lib`, and `customlib.lib`;
- indented mixed-case `INCLUDELIB` with path tail and trailing comment;
- ordinary non-include text with path separators not being accepted as generic path syntax;
- directive-context source position and span preservation;
- path-tail token name/helper behavior.

### Parser tests

Added or updated coverage for:

- `includelib \masm32\lib\masm32.lib` producing `unsupported-masm32-library`;
- `includelib masm32.lib` producing `unsupported-masm32-library`;
- `includelib \masm32\lib\kernel32.lib` producing `unsupported-windows-api-library`;
- `includelib C:\masm32\lib\kernel32.lib` producing `unsupported-windows-api-library`;
- `includelib kernel32.lib` producing `unsupported-windows-api-library`;
- `includelib customlib.lib` producing `unsupported-includelib`;
- multiple `INCLUDELIB` diagnostics in stable source order;
- indented mixed-case source location details;
- diagnostic code-name helpers for the new Phase 57Q codes;
- updated generic unsupported-keyword coverage so `INCLUDELIB kernel32.lib` no longer uses the old generic unsupported path.

### Source-run tests

Added or updated coverage for:

- source-run JSON exposing Phase 57Q diagnostic codes;
- source-run JSON preserving line, column, byte offset, and span length;
- `INCLUDELIB` diagnostics preventing execution;
- no `execution-complete` message after `INCLUDELIB` assembly errors;
- no Program Console output after `INCLUDELIB` assembly errors;
- no repeated `unexpected-character` diagnostics for recognized path-like `INCLUDELIB` operands;
- Phase 57P host `INCLUDE` diagnostics remaining unchanged;
- virtual include regression behavior.

### Rendered Simulator Messages tests

Added exact rendered-message tests for:

- generic unsupported `INCLUDELIB`;
- unsupported MASM32 library;
- unsupported Windows/API import library;
- multiple `INCLUDELIB` diagnostics in one source file.

After user feedback, these exact tests were updated to require the shared `INCLUDELIB` support-boundary wording plus category-specific details.

### Protocol/static/status tests

Updated tests for:

- repository/archive milestone Phase 57Q;
- runtime/source-run MASM behavior phase Phase 57Q;
- browser status text Phase 57Q;
- supported syntax/status documentation Phase 57Q;
- milestone history Phase 57Q;
- README/status wording;
- static checks preserving legacy Phase 57P include diagnostics and Phase 57O NOP wording references.

## 11. Commands used to test

### Aggregate command

Final aggregate command run:

```bash
cd /mnt/data/repo_57P_verify
python3 scripts/run_tests.py --all
```

Observed final aggregate result:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Focused group commands

The following focused groups were run during implementation, compliance review, second review, user-test follow-up, and final gap check:

```bash
cd /mnt/data/repo_57P_verify
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused results:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Subgroup or fixture-family commands

No subgroup or individual fixture-family reruns were required. No focused group timed out.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is a dependency skip, not a test failure. Served browser testing requires rebuilding Wasm in an environment with Emscripten.

## 12. Pass/fail results

Final result classification:

```text
aggregate completed and passed
group skipped because a dependency was unavailable: Browser/Wasm rebuild smoke skipped because emcc was unavailable
```

Detailed classification:

- Aggregate command completed and returned final success status.
- Focused groups completed and passed:
  - `--structure`
  - `--native`
  - `--source-run`
  - `--web`
  - `--diagnostics`
  - `--protocol`
  - `--static`
- No focused group failed.
- No focused group timed out.
- No subgroup reruns were required.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Phase 57Q is browser-testable after rebuilding the Wasm artifact. Because the milestone changes C lexer/parser behavior, the served website must use a rebuilt `web/dist/masm32_sim_core.wasm`. If the browser serves the old Phase 57P artifact, old behavior may still appear.

### Browser setup on Windows

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open the served page and paste the following programs.

### Program 1 - Generic `INCLUDELIB`

```asm
includelib customlib.lib

.code
main PROC
    mov eax, 123
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-includelib line 1, column 12, byte offset 11, span length 13: INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines. Library operand 'customlib.lib' cannot be used; execution stops before program start.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message.
- No register result from `mov eax, 123`.
- No memory changes.

### Program 2 - MASM32 library path

```asm
includelib \masm32\lib\masm32.lib

.code
main PROC
    mov eax, 123
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-masm32-library line 1, column 12, byte offset 11, span length 22: INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines. MASM32 library '\masm32\lib\masm32.lib' requires external library linking.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message.
- No repeated `unexpected-character` diagnostics for backslashes.

### Program 3 - Windows/API import library path

```asm
includelib C:\masm32\lib\kernel32.lib

.code
main PROC
    mov eax, 123
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-windows-api-library line 1, column 12, byte offset 11, span length 26: INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines. Windows import library 'C:\masm32\lib\kernel32.lib' requires PE imports and WinAPI execution.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message.
- No repeated `unexpected-character` diagnostics for `C:\...`.

### Program 4 - Multiple `INCLUDELIB` diagnostics

```asm
includelib customlib.lib
includelib kernel32.lib

.code
main PROC
    mov eax, 123
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-includelib line 1, column 12, byte offset 11, span length 13: INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines. Library operand 'customlib.lib' cannot be used; execution stops before program start.
[unsupported-feature] unsupported-windows-api-library line 2, column 12, byte offset 36, span length 12: INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines. Windows import library 'kernel32.lib' requires PE imports and WinAPI execution.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Exactly two diagnostics.
- Program does not execute.
- No `execution-complete` message.

### Program 5 - Virtual include regression

```asm
INCLUDE Irvine32.inc

.code
main PROC
    mov eax, 42
    exit
    mov eax, 99
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected register result:

```text
EAX = 0000002Ah / u: 42 / s: 42
```

`EAX` must not become `99`, because virtual `exit` terminates execution before the later instruction.

### Windows CMD local testing

Emscripten is not required for local native/source-run/Node verification. Visual Studio tooling, Python 3, and Node.js are required.

Recommended focused tests:

```cmd
python scripts\run_tests.py --structure
python scripts\run_tests.py --native
python scripts\run_tests.py --source-run
python scripts\run_tests.py --web
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --protocol
python scripts\run_tests.py --static
```

Expected each focused command to end with:

```text
Selected test groups passed.
```

Aggregate test:

```cmd
python scripts\run_tests.py --all
```

Expected aggregate snippets:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
All implemented milestone tests passed.
```

If Emscripten is unavailable, this skip is expected:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Regression signs:

- `INCLUDELIB` is accepted silently.
- Any program containing `INCLUDELIB` executes.
- `execution-complete` appears after an `INCLUDELIB` diagnostic.
- Program Console contains output for an `INCLUDELIB` failure.
- Path-like `INCLUDELIB` emits repeated `unexpected-character` diagnostics.
- `INCLUDELIB kernel32.lib` does not report `unsupported-windows-api-library`.
- `INCLUDELIB masm32.lib` does not report `unsupported-masm32-library`.
- `INCLUDE Irvine32.inc` or `INCLUDE Macros.inc` stops working.
- Browser still reports Phase 57P after rebuilding Wasm and refreshing the served page.

## 14. Compliance review summary

First compliance review checked scope, completeness, C99 language policy, diagnostics, tests, docs, and TODO-style note handling.

Issues found:

- No scope creep.
- No functional gaps.
- Minor stale file-level comments in touched C/test files still described earlier Phase 57O/57P coverage.

Fixes applied:

- Updated stale file-level comments in touched files.
- No behavior changes.

Tests rerun after compliance fixes:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Result:

- All focused groups passed.
- Aggregate completed and passed.
- Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

Verdict:

```text
complete
```

## 15. Re-review summary

Second compliance review checked the guide/spec requirements again, changed files, docs, diagnostics, TODO-style notes, and test quality.

Issues found:

- `README.md` still described the current repository/runtime status as Phase 57P instead of Phase 57Q.
- `docs/MILESTONE_HISTORY.md` had duplicated current-status wording after the Phase 57Q summary.
- Static verification initially failed because one README edit removed required legacy-regression substrings for Phase 57P include diagnostics and Phase 57O zero-operand NOP coverage.

Fixes applied:

- Updated `README.md` current status to Phase 57Q.
- Added Phase 57Q `INCLUDELIB` diagnostic summary to `README.md`.
- Preserved static-check-required README references to:
  - `unsupported-host-include-path`
  - `unsupported-windows-api-include`
  - `unsupported-masm32-library-include`
  - `Zero-operand nop remains`
- Removed duplicated current-status wording from `docs/MILESTONE_HISTORY.md`.
- No behavior changes.

Tests rerun:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Result:

- All focused groups passed.
- Aggregate completed and passed.
- Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

Final re-review verdict:

```text
complete
```

## 16. User-test follow-up summary

The user ran manual tests and reported that everything appeared to pass. The user then raised a diagnostics clarity concern:

- Different `INCLUDELIB` diagnostic categories used different wording.
- The generic diagnostic implied `INCLUDELIB` is unsupported, while the MASM32-library diagnostic could be read as implying some `INCLUDELIB` forms might work through Irvine32.

Diagnosis:

- Functional behavior was correct.
- The issue was a user-facing diagnostic wording clarity issue.
- It was within Phase 57Q scope because it affected exact user-visible diagnostics for the target milestone.

Fix applied:

- Reworked all `INCLUDELIB` diagnostics to share the same support-boundary wording:

  ```text
  INCLUDELIB is not supported in MASM32 Educational Mode; the simulator does not link objects, load .lib files, process PE imports, or execute external routines.
  ```

- Added category-specific second sentences for generic, MASM32, and Windows/API library diagnostics.
- Removed the confusing Irvine32 wording from `INCLUDELIB` diagnostics.
- Shortened the wording to fit the current parser diagnostic message buffer.
- Updated exact rendered-message tests and parser/source-run message assertions.
- Updated guide examples to match the clearer wording.

Tests rerun after user-test follow-up:

```bash
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --all
```

Result:

- All focused groups passed.
- Aggregate completed and passed.
- Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

## 17. Known limitations

Known limitations after Phase 57Q:

- Browser/Wasm rebuild smoke was not run because `emcc` is unavailable in the assistant/container environment.
- Served browser testing requires rebuilding Wasm locally or in CI with Emscripten.
- A full `Latest_repository_state_milestone_57Q.zip` repository archive was not produced during this session.
- The current parser diagnostic message buffer constrained the final wording length; the selected wording preserves the intended meaning without broadening infrastructure scope.

Intentional product limitations preserved:

- No host include loading.
- No library loading.
- No object linking.
- No PE/import behavior.
- No WinAPI execution.
- No external routine execution.
- No macro expansion.
- No stack/procedure/control-flow expansion.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57R - Unsupported INVOKE, ADDR, and External Routine Diagnostics
```

Reason:

- The implementation guide lists Phase 57R after Phase 57Q.
- Phase 57Q completes `INCLUDELIB` external-library diagnostics.
- Phase 57R continues the same non-goal/diagnostic-quality track for `INVOKE`, `ADDR`, and external-routine-looking code without implementing future procedure, stack, call, or WinAPI behavior.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during this milestone session:

- `phase57q_changed_files.zip`
- `phase57q_compliance_changed_files.zip`
- `phase57q_second_review_changed_files.zip`
- `phase57q_user_followup_changed_files.zip`

Current recommended changed-files package:

```text
phase57q_user_followup_changed_files.zip
```

This is the latest package and includes the final user-test follow-up wording cleanup.

A full latest repository archive was not produced during this milestone-report step. Recommended full repository archive name after applying the changed files:

```text
Latest_repository_state_milestone_57Q.zip
```
