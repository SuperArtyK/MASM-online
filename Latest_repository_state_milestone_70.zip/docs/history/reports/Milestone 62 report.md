# Milestone 62 report - CMP Register and Immediate Forms

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 62 - CMP Register and Immediate Forms
```

Repository/archive milestone after this work:

```text
Phase 62 - CMP Register and Immediate Forms
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 62 - CMP Register and Immediate Forms
```

Scope implemented:

- Added `cmp` as an implemented instruction mnemonic.
- Implemented `cmp` for register/register forms.
- Implemented `cmp` for register/immediate forms.
- Implemented flag-only subtraction semantics for `cmp`.
- Preserved all compared operands; `cmp` does not mutate registers or memory.
- Ensured successful `cmp` execution creates no memory-change rows.
- Advanced source-run/runtime metadata and browser/protocol status surfaces to Phase 62.
- Updated user-facing documentation and the default `web/index.html` sample to reflect Phase 62.
- Preserved Phase 63 memory-operand work as future scope.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_62.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 61E report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_61E.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, status-surface hygiene, and broad product constraints.
- The implementation guide owns Phase 62 numbering, exact phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or implementation guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or implementation guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

## 3. Exact requirements implemented

### 3.1 `cmp` instruction recognition

Implemented parser recognition and IR representation for:

```asm
cmp r8/r16/r32, r8/r16/r32
cmp r8/r16/r32, imm
```

The new IR opcode is:

```text
VM_IR_OPCODE_CMP
```

### 3.2 Register/register CMP forms

Implemented same-width register/register comparisons for 8-bit, 16-bit, and 32-bit register operands. The comparison computes destination minus source for flag purposes only.

Examples now accepted:

```asm
cmp al, bl
cmp ax, bx
cmp eax, ebx
```

Width-mismatched register/register comparisons remain rejected, for example:

```asm
cmp al, ax
```

### 3.3 Register/immediate CMP forms

Implemented register/immediate comparisons for 8-bit, 16-bit, and 32-bit destination registers, using existing immediate parsing and range validation.

Examples now accepted:

```asm
cmp al, 0FFh
cmp ax, 0FFFFh
cmp eax, 0FFFFFFFFh
cmp eax, -1
```

Immediate values that do not fit the destination width remain rejected through existing immediate range diagnostics.

### 3.4 Flag-only subtraction semantics

Implemented Phase 62 `cmp` runtime behavior as a read-only comparison:

- computes subtraction for flags only;
- updates the currently modeled flags `CF`, `ZF`, `SF`, and `OF` through the shared compare/subtraction helper;
- does not introduce `PF` or `AF`, because they are not part of the current modeled flag set;
- keeps flag behavior consistent with existing compare/subtraction helper semantics.

### 3.5 No operand mutation

`cmp` preserves all compared operands. Tests cover both register/register and register/immediate forms to prove that destination registers are unchanged.

### 3.6 No memory-change rows

Successful `cmp` execution creates no memory-change rows. Source-run tests verify that the `memoryChanges` array is empty for successful Phase 62 comparison programs.

### 3.7 Memory operands remain deferred

Phase 62 deliberately does not implement memory operand forms. The following remain deferred to Phase 63 - CMP Memory Operand Forms:

```asm
cmp reg, mem
cmp mem, reg
cmp mem, imm
```

Diagnostics for attempted Phase 62 memory forms explain that CMP memory operand forms are deferred to Phase 63.

### 3.8 Reserved-word integration

Because `cmp` is now a recognized instruction mnemonic, it participates in Phase 61E reserved-word symbol diagnostics. Declarations such as these are rejected:

```asm
.code
main PROC
cmp:
main ENDP
END main
```

```asm
.data
cmp DWORD 1
```

### 3.9 Runtime/source-run metadata advancement

Because Phase 62 changes accepted executable MASM/source behavior, runtime/source-run metadata was advanced to:

```json
{
  "phase": 62,
  "phaseSuffix": "",
  "phaseName": "Phase 62 - CMP Register and Immediate Forms"
}
```

Status surfaces and tests were updated consistently.

### 3.10 Browser page default sample update

`web/index.html` was updated so the page header/sample reflects Phase 62. The default editor program now includes:

```asm
.code
main PROC
    mov eax, 6
    mov ebx, 6
    cmp eax, ebx
    cmp eax, 7
main ENDP
END main
```

This covers the two accepted Phase 62 forms on page load once the browser Wasm artifact is rebuilt.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 62:

- Phase 63 CMP memory operands:
  - `cmp reg, mem`
  - `cmp mem, reg`
  - `cmp mem, imm`
- Planned-read validation for CMP memory forms.
- Conditional jumps such as `je`, `jz`, `jne`, `jnz`, signed relational jumps, or unsigned relational jumps.
- `loop`, `loope`, `loopne`, `jcxz`, or `jecxz` runtime behavior.
- Indirect jumps.
- Register-target, memory-target, or immediate-target `jmp` execution.
- Branch-distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Relative branch encoding or real x86 instruction encoding.
- Native x86 execution.
- Stack or procedure execution semantics.
- `call`, `ret`, `leave`, `push`, or `pop`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 callable routines beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Active-time watchdog behavior.
- Wall-clock execution limits.
- Worker yielding/chunking for responsiveness.
- Browser UI controls for execution time or capacity limits.
- Macro expansion.
- Debugger stepping, breakpoints, breakpoint binding, editor source navigation, current-instruction highlighting, CodeMirror gutter behavior, or branch-target editor highlighting.
- PF/AF flag storage or display.
- `OPTION NOKEYWORD` behavior or dynamic keyword-table mutation.

Future work intentionally preserved:

- Phase 63 - CMP Memory Operand Forms.
- Later conditional jump phases.
- Later `loop` phase.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- Future memory-reading opcode planned-access work noted in `src/wasm/wasm_api.c`.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 62 `cmp` should reuse the existing shared compare/subtraction flag helper.
- **Reason:** The implementation guide requires flags to match the shared subtraction/compare helper.
- **Risk:** If the shared helper has an undiscovered edge-case bug, `cmp` will inherit it.
- **How to change later:** Fix the shared helper in its owning phase or corrective phase, then keep `sub`/`cmp` parity tests together.

### Assumption 2

- **Assumption:** `PF` and `AF` should not be introduced in Phase 62.
- **Reason:** The Phase 62 guide says to update implemented `PF`/`AF` if present, but the current modeled flag set remains `CF`, `ZF`, `SF`, and `OF`.
- **Risk:** Future `PF`/`AF` phases will need to revisit `cmp` when those flags are implemented.
- **How to change later:** Add `PF`/`AF` behavior to the shared compare helper in the owning extended-flag phase and add CMP regression coverage there.

### Assumption 3

- **Assumption:** CMP memory operand diagnostics may use a Phase 63 deferral message rather than a new Phase 62 diagnostic family.
- **Reason:** Phase 63 explicitly owns memory operand forms and planned-read validation.
- **Risk:** A future Phase 63 implementation must replace or revise these deferral diagnostics when memory forms become implemented.
- **How to change later:** In Phase 63, convert the relevant parser paths from deferred diagnostics to supported memory forms and add planned-read validation tests.

### Assumption 4

- **Assumption:** Runtime/source-run phase metadata must advance from Phase 61E to Phase 62.
- **Reason:** Phase 62 changes executable MASM/source behavior by making `cmp` register/register and register/immediate forms accepted and executable.
- **Risk:** Status-surface tests and documentation must be kept synchronized.
- **How to change later:** Only advance metadata again when a later phase changes runtime/source-run MASM behavior or explicitly owns metadata advancement.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in this environment.
- **Risk:** Locally served browser artifacts may remain stale until a developer rebuilds Wasm with Emscripten configured.
- **How to change later:** Run the Windows Emscripten build script in an environment where `emcc` is available.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning, implementation, compliance review, second review, index update, and final gap check:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 62 - CMP Register and Immediate Forms
- Note text or summary:
  Phase 62 implements `cmp` for register/register and register/immediate forms only. It must compute subtraction for flags only, preserve operands, update modeled flags through the shared compare helper, produce no memory-change rows, and add required tests for equality/inequality, signed-negative bit patterns, unsigned carry, immediate boundaries, helper parity, width mismatch, and malformed operands.
- Classification:
  target-owned
- Reason:
  This is the selected TARGET_MILESTONE.
- Action for this milestone:
  Implemented CMP register/register and register/immediate behavior and tests.
```

```text
- Location:
  docs/FULL_IMPLEMENTATION_SPEC.md, read-only instruction behavior
- Note text or summary:
  Read-only instructions such as `cmp`, `test`, `lea`, and jumps must not create successful memory-change rows.
- Classification:
  target-owned
- Reason:
  Directly constrains Phase 62 CMP behavior.
- Action for this milestone:
  Implemented and tested no operand mutation and no memory-change rows.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 63 - CMP Memory Operand Forms
- Note text or summary:
  CMP memory operand forms and planned-read validation belong to Phase 63.
- Classification:
  future-owned
- Reason:
  Phase 62 accepts only register/register and register/immediate forms.
- Action for this milestone:
  Left memory forms deferred and added diagnostics/tests proving they are not implemented early.
```

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
- Classification:
  future-owned
- Reason:
  Phase 62 is not a memory-reading instruction milestone; CMP memory forms are Phase 63.
- Action for this milestone:
  Left unchanged.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, later branch/control-flow phases
- Note text or summary:
  Equality and relational conditional jumps follow after comparison support.
- Classification:
  future-owned
- Reason:
  Phase 62 updates flags only; it does not implement flag-consuming branches.
- Action for this milestone:
  Left conditional jumps and later branch behavior unimplemented.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 62 `cmp` register/register and register/immediate behavior was implemented.
- Flag-only semantics were implemented through the shared compare/subtraction helper.
- Operand preservation was implemented and tested.
- No memory-change rows were produced by successful CMP execution.
- Rendered diagnostics were added for user-visible CMP errors.
- `cmp` reserved-word behavior was integrated and tested.

### Future-owned TODO-style notes intentionally preserved

- Phase 63 CMP memory operand forms.
- Future planned-read memory validation for memory-reading opcodes.
- Conditional jump phases.
- Later `loop` runtime behavior.
- Stack/procedure/call/return phases.
- Debugger/editor/source-map behavior.
- Active-time watchdog behavior.
- Irvine32 routine expansion.
- Macro/linker/WinAPI behavior.
- `OPTION NOKEYWORD` keyword-control compatibility.

### Stale or contradicted TODO-style notes corrected

- None found.

The compliance and final gap-check passes corrected stale ordinary wording in tests/docs/static-check helper names, but no stale TODO-style note required correction.

### Unresolved TODO-related risks

- None specific to Phase 62.

## 8. Design summary

Phase 62 was implemented as a focused parser/IR/executor/runtime-status milestone.

Primary design choices:

1. **Narrow parser support.** The parser accepts only Phase 62 forms: same-width register/register and register/immediate comparisons.

2. **Dedicated CMP IR opcode.** `VM_IR_OPCODE_CMP` represents the instruction distinctly while reusing existing operand machinery.

3. **Shared flag helper reuse.** CMP delegates flag behavior to the existing compare/subtraction helper so results match established subtraction semantics.

4. **Read-only runtime behavior.** CMP does not write back the subtraction result, does not mutate operands, and does not create memory-change rows.

5. **Future-scope protection.** Memory operands are explicitly deferred to Phase 63 and tested as not implemented in Phase 62.

6. **Reserved-word consistency.** `cmp` is treated as a recognized instruction mnemonic and therefore cannot be used as a user-defined symbol.

7. **Runtime metadata advancement.** Because source execution behavior changed, source-run/runtime metadata was advanced to Phase 62 and protocol/status tests were updated.

8. **Browser sample update.** The default page sample now demonstrates Phase 62 CMP behavior, but browser execution requires rebuilding the Wasm artifact in an environment with `emcc` available.

## 9. Files changed

Changed files in the final Phase 62 state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_ir.c`
- `src/core/vm_ir.h`
- `src/parser/parser.c`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

Added or strengthened tests/checks:

- Parser tests for accepted CMP register/register forms.
- Parser tests for accepted CMP register/immediate forms.
- Parser tests for width mismatch diagnostics such as `cmp al, ax`.
- Parser tests for immediate range diagnostics.
- Parser tests for malformed CMP operands.
- Parser tests proving CMP memory operands remain deferred to Phase 63.
- Parser tests proving `cmp` is now rejected as a reserved user-defined symbol.
- Executor tests for `cmp eax, ebx`.
- Executor tests for `cmp al, imm` and `cmp eax, imm`.
- Executor tests for equal and unequal comparisons.
- Executor tests for signed-negative bit patterns and unsigned carry cases.
- Executor tests proving operands are not mutated.
- Executor/source-run tests proving no memory-change rows are created.
- Source-run tests for Phase 62 metadata.
- Rendered Simulator Messages tests for CMP diagnostics.
- Rendered Simulator Messages tests for CMP success.
- Protocol/status tests updated for Phase 62.
- Static checks updated to verify Phase 62 status and `index.html` sample text.
- Regression coverage preserving earlier `sub`, `test`, direct-`jmp`, watchdog, and reserved-word behavior.

## 11. Commands used to test

### Pre-implementation repository verification

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
aggregate timed out in assistant/container environment before final status
```

Focused commands run after aggregate timeout:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
All focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Implementation verification

Focused commands run:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
All focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Aggregate command run:

```bash
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
aggregate timed out in assistant/container environment before final status
```

### First compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
All focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
aggregate timed out in assistant/container environment before final status
```

### Second compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
All focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
aggregate timed out in assistant/container environment before final status
```

### Index.html update verification

Focused commands run:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
Focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Final gap-check verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
All focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
aggregate completed and passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

No subgroup or fixture-family reruns were required because focused groups completed and the final aggregate completed successfully.

## 12. Pass/fail result classification

Final classification:

```text
aggregate completed and passed
group skipped because dependency was unavailable, such as emcc
```

Earlier implementation/compliance passes had this classification before the final gap-check run:

```text
aggregate timed out in assistant/container environment, focused groups passed
group skipped because dependency was unavailable, such as emcc
```

Final focused groups all passed:

```text
structure: PASS
native: PASS
source-run: PASS
web: PASS
diagnostics: PASS
protocol: PASS
static: PASS
```

No aggregate failure occurred.

No focused group failed.

No focused group timed out.

No subgroup or fixture-family reruns were needed.

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

This is an environment dependency skip, not a project test failure.

## 13. Manual/browser testing guidance and expected outputs

### Browser testing status

Website-testable: yes, after rebuilding Wasm with Emscripten.

Required Windows setup:

- Windows CMD from the project root.
- Emscripten environment activated so `emcc` is on PATH.
- Python and Node.js available.

Build and serve:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open:

```text
http://localhost:8000
```

The default page-load program is:

```asm
.code
main PROC
    mov eax, 6
    mov ebx, 6
    cmp eax, ebx
    cmp eax, 7
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected final registers include:

```text
EAX    | 00000006h / u: 6
EBX    | 00000006h / u: 6
EFLAGS | 00000081h / 129
```

Expected memory changes:

```text
No memory changes.
```

Expected Program Console output:

```text
<empty>
```

### Additional browser programs

Equality comparison:

```asm
.code
main PROC
    mov eax, 7
    mov ebx, 7
    cmp eax, ebx
main ENDP
END main
```

Expected final registers include:

```text
EAX    | 00000007h / u: 7
EBX    | 00000007h / u: 7
EFLAGS | 00000040h / 64
```

Signed-overflow comparison:

```asm
.code
main PROC
    mov eax, 80000000h
    cmp eax, 1
main ENDP
END main
```

Expected final registers include:

```text
EAX    | 80000000h / u: 2147483648
EFLAGS | 00000800h / 2048
```

Width mismatch diagnostic:

```asm
.code
main PROC
    cmp al, ax
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] operand-width-mismatch line 3, column 13, byte offset 28, span length 2: Source operand width does not match the destination operand width.
```

Expected behavior:

- no execution;
- no `execution-complete` message;
- no memory changes.

CMP memory operand remains deferred to Phase 63:

```asm
.data
value DWORD 7
.code
main PROC
    mov eax, 7
    cmp eax, value
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-syntax line 6, column 14, byte offset 64, span length 5: CMP Phase 62 accepts only register or immediate second operands. CMP memory operand forms are deferred to Phase 63 - CMP Memory Operand Forms.
```

Expected behavior:

- no execution;
- no `execution-complete` message;
- confirms Phase 63 behavior was not implemented early.

### Windows CMD local testing

These commands do not require `emcc`:

```cmd
python scripts\run_tests.py --source-run --quiet
python scripts\run_tests.py --diagnostics --quiet
python scripts\run_tests.py --web --quiet
python scripts\run_tests.py --static --quiet
```

Expected snippets:

```text
[source-run] PASS
Selected test groups passed.
```

```text
[diagnostics] PASS
Selected test groups passed.
```

```text
[web] PASS
Selected test groups passed.
```

```text
[static] PASS
Selected test groups passed.
```

If `emcc` is not available, this is acceptable:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Optional native JSON test with `program.asm` at the project root:

```asm
.code
main PROC
    mov eax, 6
    mov ebx, 6
    cmp eax, ebx
    cmp eax, 7
main ENDP
END main
```

Build the diagnostic producer:

```cmd
python scripts\run_tests.py --diagnostics --quiet
```

Run:

```cmd
build\tests\diagnostic_json_producer.exe program.asm
```

Expected JSON snippets:

```json
"phase":62
```

```json
"phaseName":"Phase 62 - CMP Register and Immediate Forms"
```

```json
"ok":true
```

```json
"status":"ok"
```

```json
"EAX":{"hex":"00000006h","unsigned":6}
```

```json
"EBX":{"hex":"00000006h","unsigned":6}
```

```json
"EFLAGS":{"hex":"00000081h","unsigned":129}
```

```json
"memoryChanges":[]
```

Regression signs:

- `cmp eax, ebx` or `cmp eax, 7` reports `unsupported-instruction`.
- `cmp` changes `EAX`, `EBX`, or any compared register operand.
- Successful `cmp` creates a memory-change row.
- `cmp eax, value` executes successfully, indicating Phase 63 memory forms were implemented early.
- Width mismatch `cmp al, ax` does not produce `operand-width-mismatch`.
- Runtime/source-run metadata still says Phase 61E.
- Browser UI says Phase 62 but execution behaves like Phase 61E, usually meaning Wasm was not rebuilt.

## 14. Compliance review summary

First compliance review found no scope or functional compliance issues. It found stale test wording in assertion descriptions and file headers. Fixes applied:

- Updated stale assertion descriptions to say Phase 62 metadata.
- Updated test file headers to describe coverage through Phase 62.
- Renamed a stale source-run phase metadata helper to Phase 62 wording.

No runtime behavior changes were made during the first compliance pass.

Focused tests passed after the first compliance pass. Aggregate timed out in the assistant/container environment during that pass, so aggregate completion was not claimed at that stage.

## 15. Re-review summary

Second compliance review found one additional stale web diagnostic fixture name/reason:

- stale fixture name: `phase57tCmpUnsupported`
- stale reason: CMP described as an unsupported Phase 57T fixture

Fixes applied:

- Renamed the fixture to `phase62CmpRegisterImmediateSuccess`.
- Updated its reason text to `Phase 62 CMP register/immediate success fixture.`
- Updated the Phase 62 rendered-success test to use the renamed fixture.

No runtime, parser, protocol, source-run, or documentation behavior changed during the second review.

Focused tests passed after the second review. Aggregate timed out in the assistant/container environment during that pass, so aggregate completion was not claimed at that stage.

## 16. User-test follow-up summary

The user requested that `web/index.html` be updated to reflect the current `TARGET_MILESTONE`.

Fixes applied:

- Updated `web/index.html` header comment to `Milestone 62: CMP Register and Immediate Forms`.
- Updated the UI intro text to describe CMP register/register and register/immediate support.
- Updated the default editor sample to use CMP register/register and register/immediate forms.
- Updated static checks in `scripts/run_tests.py` so `--static` verifies the Phase 62 `index.html` text.

Focused verification after this update passed:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --static --quiet
```

The user did not provide discrepancy results from manual/browser testing, so Prompt 8 triage was skipped.

## 17. Known limitations

Known limitations after Phase 62:

- CMP memory operands are not implemented; they remain Phase 63 work.
- Planned-read validation for CMP memory forms is not implemented; it remains Phase 63 work.
- Conditional jumps are not implemented.
- `loop` is not implemented.
- Stack/procedure/call/return behavior is not implemented.
- Debugger/editor branch behavior is not implemented.
- Active-time watchdog behavior is not implemented.
- PF/AF are not modeled or displayed.
- Browser/Wasm rebuild smoke could not be run in this assistant/container environment because `emcc` is unavailable.
- Served-website testing requires rebuilding Wasm in a local Emscripten-enabled environment.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 63 - CMP Memory Operand Forms
```

Expected archive name for the current completed milestone:

```text
Latest_repository_state_milestone_62.zip
```

## 19. Changed-files ZIP/packages produced

Changed-files and compliance packages produced during Phase 62:

- `phase62_changed_files.zip`
- `milestone_62_first_compliance_check.zip`
- `milestone_62_second_compliance_check.zip`
- `milestone_62_index_html_update.zip`
- `milestone_62_changed_files_with_index.zip`
- `milestone_62_final_compliance_check.zip`

Report file produced:

- `Milestone 62 report.md`

