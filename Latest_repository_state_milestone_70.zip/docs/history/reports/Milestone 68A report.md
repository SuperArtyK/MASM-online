# Milestone 68A report

## 1. Milestone title and scope

**Milestone:** Phase 68A - Stack Runtime Initialization and ESP Startup Contract

**Scope:** Phase 68A adds a narrow runtime stack-startup contract. The simulator now initializes `ESP` from the active stack-region metadata when a program is loaded for execution. The stack is considered empty when `ESP` equals the first address past the high end of the active stack region. This contract prepares later `CALL`, `RET`, `PUSH`, and `POP` phases without implementing those future instructions.

The milestone is intentionally limited to startup state. It does not add stack mutation behavior, procedure calls, return-token storage, stack frames, or Irvine32 callable routine dispatch.

## 2. Source-of-truth files used

Canonical source-of-truth files:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`

Implementation-history and context files reviewed:

- `docs/history/reports/Milestone 68 report.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `README.md`
- `docs/history/HISTORY_README.md`
- `docs/history/PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `docs/history/PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`

The active canonical guide section was:

- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, `Phase 68A - Stack Runtime Initialization and ESP Startup Contract`

## 3. Exact requirements implemented

Implemented Phase 68A requirements:

- Initialize `ESP` when a program is loaded for execution.
- Derive `ESP` from the active runtime stack-region metadata, not from a hardcoded executor-only constant.
- Document and implement the empty-stack convention:
  - `ESP` starts at the stack region exclusive limit.
  - A future 32-bit push-like operation should compute `ESP - 4`, then perform a checked 4-byte memory write.
- Preserve fixed-layout behavior and existing layout-policy sizing behavior.
- Preserve existing `.stack` parsing and layout metadata behavior.
- Ensure automatic/layout-policy runs that already honor `.stack size` expose that selected stack capacity through `ESP` startup.
- Keep seeded startup deterministic while preserving the Phase 68A `ESP` stack contract.
- Update user-visible startup-state notice text so it no longer says every modeled register starts from the same zero or seeded state.
- Update `.stack` compatibility notice text so it states that `.stack` contributes to ESP startup in layout-policy runs while source-level stack instructions and frames remain deferred.
- Update current milestone/status surfaces to Phase 68A.
- Update `web/index.html`, web protocol metadata, displayed milestone text, and default editor code to demonstrate `ESP` startup.
- Preserve successful-program behavior: exactly one `execution-complete` message.
- Preserve error behavior: assembly/runtime errors prevent `execution-complete` where required.
- Preserve Phase 67A selected-entry startup boundaries.
- Preserve Phase 68 call-target classification behavior.
- Improve runtime invalid-address diagnostics discovered during user testing so register-indirect memory operands include best-effort source span metadata.

## 4. Explicit non-goals and future work not implemented

The milestone did not implement:

- Executable `CALL`.
- `RET`, root `RET`, `RET imm16`, or `LEAVE`.
- Source-level `PUSH` or `POP`.
- Stack mutation instructions.
- Stack overflow or stack underflow semantics tied to stack mutation operations.
- Procedure frames.
- `PROC USES` preservation/restoration behavior.
- `LOCAL` allocation.
- `PROTO`.
- `INVOKE`.
- `ADDR`.
- Irvine32 callable routine dispatch beyond existing virtual `exit` behavior.
- Debugger stack display.
- Call-depth accounting.
- New stack-layout sizing behavior.
- New automatic-layout sizing behavior.
- New randomized-layout behavior.
- Heap sizing changes.
- Stack-size UI settings.
- URL state changes.
- WinAPI simulation.
- Full MASM compilation.
- Full x86 emulation.
- Windows emulation.
- PE loading/linking/import-library behavior.

Direct writes to `ESP`, such as `mov esp, 1`, remain legal because MASM/x86 permits explicit writes to `ESP`. Later stack-safety phases may add educational warnings or stack-specific runtime diagnostics when future stack-using operations consume an invalid `ESP` value.

## 5. Assumptions used

- **Assumption:** Phase 68A should initialize `ESP` to the stack region exclusive limit in all source-run startup register modes, including seeded startup mode.  
  **Reason:** The guide requires `ESP` to be initialized from active stack layout metadata before future `CALL`/`RET` work can depend on it. A seed-randomized `ESP` would break that contract.  
  **Risk:** Earlier seeded-startup wording implied all general-purpose registers could be seed-derived.  
  **How to change later:** Add a separate explicit diagnostic/testing mode if a future phase wants deliberately invalid randomized `ESP`; do not weaken the default stack contract used by procedure execution.

- **Assumption:** The empty-stack convention is `ESP = stack_region_limit`, with future push-like operations writing at `ESP - 4`.  
  **Reason:** This is the guide-recommended convention and matches downward-growing x86 stack intuition.  
  **Risk:** If future code assumes `ESP` points at the highest writable slot instead of the exclusive limit, future CALL/PUSH tests would fail.  
  **How to change later:** Change the convention only by updating the spec/guide and all future stack-instruction tests together.

- **Assumption:** Phase 68A changes runtime-visible behavior, so source-run/browser protocol phase metadata should advance from Phase 68 to Phase 68A.  
  **Reason:** `ESP` appears in final register output and can be observed by source programs.  
  **Risk:** Phase-suffix handling must stay consistent across C metadata, JS protocol metadata, tests, docs, and browser surfaces.  
  **How to change later:** If a future suffix milestone is documentation-only or non-runtime, explicitly keep runtime metadata pinned and document why.

- **Assumption:** No new stack-overflow diagnostic belongs to Phase 68A.  
  **Reason:** Stack overflow requires stack mutation operations such as `PUSH`, `CALL`, or `RET`, which remain future work. Existing checked-memory diagnostics are sufficient for explicit memory accesses.  
  **Risk:** Users may expect invalid manual writes near the stack to be reported as stack overflow.  
  **How to change later:** Add stack-specific diagnostics in the phase that implements source-level stack mutation.

- **Assumption:** Existing checked-memory diagnostics should preserve better source spans when register-indirect memory operands fail at runtime.  
  **Reason:** User testing found `invalid-address` diagnostics with line but no column/span for `[ebx]` writes, which reduced diagnostic usefulness.  
  **Risk:** The span finder is best-effort and should not become a broad parser rewrite.  
  **How to change later:** Replace the fallback span finder with richer instruction operand source mapping if a later diagnostic-precision phase introduces it.

## 6. Relevant TODO-style notes reviewed

Reviewed TODO-style notes and TODO-like wording from active docs/source/tests, including occurrences of:

- `TODO`
- `FIXME`
- `HACK`
- `TEMP`
- `DEFERRED`
- `future milestone`
- `not yet implemented`
- `later phase`
- `follow-up`

Important reviewed notes:

- README Phase 68A next-work status.
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` Phase 68A section.
- `docs/SUPPORTED_SYNTAX.md` `.stack` and deferred stack/procedure wording.
- `src/core/vm_layout.h` default stack-size request wording.
- `src/core/vm_exec.h` executor comment/Doxygen wording.
- `src/parser/parser.h` stack-size metadata comment.
- `src/parser/parser.c` `.stack` compatibility notice text.
- `src/wasm/wasm_api.c` future memory-reading opcode TODO.
- README history link to the history readme.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- README Phase 68A future-status wording was updated to current Phase 68A behavior.
- `SUPPORTED_SYNTAX.md` now distinguishes implemented `ESP` startup from deferred source-level stack instructions and frames.
- `.stack` compatibility notice text now says `.stack` contributes to ESP startup in layout-policy runs while runtime stack instructions and frames remain deferred.
- Parser/header comments now avoid implying that all stack-related runtime behavior is absent.
- `vm_layout.h` wording was narrowed so it does not contradict Phase 68A startup behavior.
- Static/test phase wording was updated from Phase 68 to Phase 68A.

### Future-owned TODO-style notes intentionally preserved

- Future `CALL`, `RET`, `PUSH`, `POP`, stack frames, `PROC USES`, `LOCAL`, `PROTO`, `INVOKE`, `ADDR`, and Irvine32 callable dispatch notes remain deferred.
- The future memory-reading opcode TODO in `src/wasm/wasm_api.c` remains preserved and outside Phase 68A scope.
- Broad roadmap references in the spec/guide remain preserved as future implementation guidance.

### Stale or contradicted TODO-style notes corrected

- README history link was corrected to `docs/history/HISTORY_README.md`.
- Broad stale “stack behavior deferred” wording in touched files was narrowed.
- Stale “current Phase 68” test/static wording was updated to Phase 68A.
- Runtime invalid-address diagnostics were improved after user testing revealed missing source context for register-indirect memory operands.

### Unresolved TODO-related risks

- Low. Remaining TODO-style notes are future-owned or roadmap-oriented. They should not be treated as current Phase 68A scope in future sessions unless the next target milestone explicitly owns them.

## 8. Design summary

Phase 68A adds a single stack-startup invariant: after memory/layout initialization and before source execution, `ESP` is initialized from the active stack memory region.

The key convention is:

```text
ESP = active_stack_region_base + active_stack_region_size
```

For the default fixed layout, this produces:

```text
ESP = 00900000h
```

The implementation keeps stack startup separate from stack mutation. It consumes existing memory-region metadata and does not introduce new stack sizing. Future `PUSH`, `CALL`, and `RET` behavior can use the documented empty-stack convention by subtracting 4 before a checked write.

Seeded startup still provides deterministic nonzero/randomized startup behavior for the registers/flags it owns, but it now preserves the stack contract by keeping or restoring `ESP` from active stack metadata.

A user-test follow-up improved invalid-address source mapping for runtime memory diagnostics. This does not add new stack semantics; it improves diagnostics for checked memory helpers already used by the VM.

## 9. Files changed

Files changed across implementation, compliance reviews, and user-test follow-up:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_layout.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_vm_layout.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

Added or strengthened tests for:

- Fixed-layout `ESP` startup from stack region limit.
- `vm_load_program()` reinitializing `ESP` from active stack metadata.
- Explicit layout-policy stack metadata driving `ESP`.
- Source-run visibility of fixed-layout startup `ESP = 00900000h`.
- Seeded startup preserving the stack-pointer contract.
- Automatic-layout `.stack 4096` startup behavior.
- Automatic-layout `.stack 4096` selected stack base usability at `008FF000h`.
- Updated `.stack` compatibility notice rendering.
- Updated startup-state notice rendering.
- Updated Phase 68A metadata/protocol expectations.
- Unsupported `CALL` remaining unsupported.
- Invalid register-indirect memory diagnostics preserving bracketed operand source span.
- Rendered invalid-address diagnostics including column/byte offset/span length.

Updated existing regression expectations for:

- Phase number/suffix/name metadata.
- Browser protocol metadata.
- Rendered diagnostic fixtures.
- Existing `.stack` tests.
- Existing source-run startup-state tests.

## 11. Commands used to test

Focused commands run during implementation and review:

```text
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command run:

```text
python3 scripts/run_tests.py --all
```

User-test follow-up commands run after invalid-address diagnostic fix:

```text
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --static
```

Final gap-check commands run:

```text
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Skipped dependency check:

- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

No subgroup or fixture-family rerun was required after the final focused and aggregate passes.

## 12. Pass/fail results

Final focused test results:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
```

Final aggregate test result:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Classification:

- Aggregate completed and passed.
- No aggregate failure remained.
- No focused group failed.
- No focused group timed out and required fixture/subgroup decomposition.
- Browser/Wasm rebuild smoke was skipped because the `emcc` dependency was unavailable in the assistant/container environment.

Earlier implementation/compliance passes had an aggregate timeout in the assistant/container wrapper, but the final gap-check aggregate completed and passed.

## 13. Manual/browser testing guidance and expected outputs

### Website testing

Website testing is applicable after rebuilding Wasm locally with Emscripten.

Rebuild and serve on Windows:

```cmd
scripts\windows\build_wasm.cmd
py -m http.server 8000 --directory web
```

Open:

```text
http://localhost:8000
```

Default editor source:

```asm
.stack 4096
.data
value DWORD 7
.code
main PROC
    mov eax, esp      ; ESP starts at the active stack region top
    mov ebx, value
main ENDP             ; normal fallthrough completes here
END main
```

Expected website-visible behavior:

- Simulator Messages include the `.stack` compatibility notice:

```text
[simulator-notice] compatibility-metadata-only line 1, column 1, byte offset 0, span length 6: .stack size is recorded as parser metadata and contributes to ESP startup in layout-policy runs; runtime stack instructions and procedure frames remain deferred.
```

- Simulator Messages include the startup-state notice:

```text
[simulator-notice] startup-state-notice: The simulator starts EAX, EBX, ECX, EDX, ESI, EDI, EBP, EIP, and modeled flags at 0, and initializes ESP to the documented empty-stack address from the active stack region. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
```

- Simulator Messages include exactly one:

```text
[info] execution-complete: Execution completed successfully.
```

- Program Console is empty.
- Final registers include:

```text
EAX = 00900000h / u: 9437184
EBX = 00000007h / u: 7
ESP = 00900000h / u: 9437184
```

If Wasm is not rebuilt, the HTML/status text may reflect Phase 68A while the browser runtime may still use stale Phase 68 backend behavior.

### Windows CMD local testing

One-time JSON formatter setup:

```cmd
set "SHOW_MASM_JSON=import json,sys;d=json.load(sys.stdin);fmt=lambda m:'[{}] {}{}: {}'.format(m.get('kind'),m.get('code'),(' line {}, column {}, byte offset {}, span length {}'.format(m.get('line'),m.get('column'),m.get('byteOffset'),m.get('spanLength')) if m.get('line') is not None else ''),m.get('message'));print('Phase: {}{} - {}'.format(d.get('phase'),d.get('phaseSuffix',''),d.get('phaseName','')));print('Status: ok={} status={}'.format(d.get('ok'),d.get('status')));ei=d.get('executedInstructionCount');ii=d.get('instructionCount');print('Instructions: {}'.format('not executed' if ei is None and ii is None else 'executed {} of {}'.format(ei,ii)));print();print('Simulator Messages:');msgs=d.get('simulatorMessages') or [];print('(none)' if not msgs else '\n'.join(fmt(m) for m in msgs));print();print('Program Console:');pc=d.get('programConsole') or '';print(pc if pc else '(empty)');print();print('Registers:');regs=d.get('registers') or {};print('(none)' if not regs else '\n'.join('{} {} / u: {}'.format(r.ljust(7),v.get('hex'),v.get('unsigned')) for r,v in regs.items()));print();print('Memory Changes:');mc=d.get('memoryChanges') or [];print('No memory changes.' if not mc else json.dumps(mc,indent=2))"
```

Run a source program:

```cmd
build\tests\diagnostic_json_producer.exe program.asm | py -c "%SHOW_MASM_JSON%"
```

Representative manual test 1:

```asm
.code
main PROC
    mov eax, esp
main ENDP
END main
```

Expected:

```text
Phase: 68A - Phase 68A - Stack Runtime Initialization and ESP Startup Contract
Status: ok=True status=ok
Instructions: executed 1 of 1
EAX     00900000h / u: 9437184
ESP     00900000h / u: 9437184
```

Representative manual test 2:

```asm
.stack 4096
.data
value DWORD 7
.code
main PROC
    mov eax, esp
    mov ebx, value
main ENDP
END main
```

Expected:

```text
Status: ok=True status=ok
Instructions: executed 2 of 2
EAX     00900000h / u: 9437184
EBX     00000007h / u: 7
ESP     00900000h / u: 9437184
```

Representative manual test 3, automatic layout:

```asm
.stack 4096
.code
main PROC
    mov eax, esp
    mov ebx, 008FF000h
    mov DWORD PTR [ebx], 456
    mov ecx, DWORD PTR [ebx]
main ENDP
END main
```

Run:

```cmd
set MASM32_DIAGNOSTIC_LAYOUT_MODE=automatic
build\tests\diagnostic_json_producer.exe program.asm | py -c "%SHOW_MASM_JSON%"
set MASM32_DIAGNOSTIC_LAYOUT_MODE=
```

Expected:

```text
Status: ok=True status=ok
Instructions: executed 4 of 4
EAX     00900000h / u: 9437184
EBX     008FF000h / u: 9433088
ECX     000001C8h / u: 456
ESP     00900000h / u: 9437184
```

Representative unsupported future behavior test:

```asm
.code
main PROC
    call helper
main ENDP
helper PROC
    mov eax, esp
helper ENDP
END main
```

Expected:

```text
Status: ok=False status=parse-error
Instructions: not executed
CALL is not supported yet.
```

Representative invalid-address diagnostic check:

```asm
.stack 4096
.code
main PROC
    mov eax, esp
    mov ebx, 008EF000h
    mov DWORD PTR [ebx], 456
    mov ecx, DWORD PTR [ebx]
main ENDP
END main
```

Expected after user-test follow-up fix:

```text
[runtime-error] invalid-address line 6, column 19, byte offset <file-dependent>, span length 5: Invalid memory write at 008EF000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

This is expected as an invalid configured-memory access, not a semantic stack-overflow diagnostic.

## 14. Compliance review summary

First compliance review found no scope violation or accidental future behavior. It corrected documentation/comment/test-description issues:

- Stale broad “stack behavior” wording.
- Stale Doxygen wording for `vm_init_with_layout_policy()`.
- A misplaced test comment near Phase 68A source-run tests.

Focused groups passed after the fixes. Aggregate was attempted but timed out during that pass, so no aggregate success was claimed at that time.

## 15. Re-review summary

Second compliance review found additional stale wording and one test-quality gap:

- Stale “current Phase 68” wording while expecting Phase 68A values.
- Static runner function name still referenced Phase 68.
- Automatic-layout source-run test observed `ESP` but did not directly prove the selected `.stack 4096` base was usable.

Fixes:

- Updated stale Phase 68 wording to Phase 68A.
- Renamed the static runner check to Phase 68A.
- Strengthened the automatic-layout test to write/read at `008FF000h` and confirm `ECX = 456`.

Focused groups passed after the fixes. Aggregate was attempted but timed out during that pass, so no aggregate success was claimed at that time.

Final gap check later completed the aggregate and passed.

## 16. User-test follow-up summary

User manual tests initially passed.

The user then observed an invalid-address diagnostic for a manual out-of-stack/out-of-configured-memory write:

```text
[runtime-error] invalid-address line 6, column None, byte offset None, span length None: Invalid memory write at 008EF000h for 4 bytes. The address is outside the simulator's configured memory regions.
```

Diagnosis:

- The invalid-address failure was expected for default fixed-layout execution.
- The diagnostic source context was weak because it had line but not column/byte/span.

Follow-up fix:

- Runtime invalid-address diagnostics now attach best-effort source span metadata for bracketed memory operands such as `[ebx]`.
- If a bracketed operand cannot be found, the full instruction span is used as fallback.
- Existing execution behavior was unchanged.

Regression coverage was added/updated for invalid register-indirect memory diagnostics and rendered invalid-address diagnostics.

The user also asked about whether `ESP` should be treated as a general-purpose register. The decision was to make no Phase 68A code change: explicit writes such as `mov esp, 1` remain legal because MASM/x86 permits them. Future stack-safety phases may add educational warnings or stack-specific errors when stack-using instructions consume an invalid `ESP` value.

## 17. Known limitations

- Wasm artifacts were not rebuilt in the assistant/container environment because `emcc` is unavailable.
- Served-browser runtime verification requires a local Emscripten rebuild before `web/dist/masm32_sim_core.wasm` reflects the updated C backend.
- `ESP` direct writes remain legal and are not warned about in Phase 68A.
- No semantic stack-overflow or stack-underflow diagnostic exists yet because source-level stack mutation instructions are not implemented.
- `CALL`, `RET`, `PUSH`, `POP`, frames, and Irvine32 callable dispatch remain future work.

## 18. Next recommended milestone

**Next recommended milestone:** Phase 69 - Direct CALL to User Procedures

Phase 69 can consume the Phase 68A stack-startup contract by writing simulator-defined return tokens below `ESP` through checked VM memory helpers, then transferring execution to direct user procedure targets.

## 19. Changed-files ZIP/package produced

Packages produced during Phase 68A work:

- `milestone_68A_implementation.zip`
- `milestone_68A_first_compliance_check.zip`
- `milestone_68A_second_compliance_check.zip`
- `milestone_68A_user_test_followup_fixes.zip`

No final-compliance ZIP was produced because no files changed during the final gap-check pass.

Recommended full repository archive name after applying all Phase 68A packages:

```text
Latest_repository_state_milestone_68A.zip
```
