# Milestone 68B Report - EIP Pseudo-Code Address Display and Source-Operand Restrictions

## 1. Milestone title and scope

**Target milestone:** Phase 68B - EIP Pseudo-Code Address Display and Source-Operand Restrictions

Phase 68B was a corrective milestone inserted after Phase 68A and before Phase 69. Its scope was to separate displayed `EIP` from ordinary source-writable register behavior, while preserving the Phase 68A stack-startup contract for `ESP`.

The milestone implemented `EIP` as derived VM control-state display:

- `EIP` remains visible in final register output and protocol output.
- `EIP` is no longer accepted as a source-readable, source-writable, address-base, address-index, declaration, label, or procedure symbol.
- Displayed `EIP` is computed from the lowered VM instruction index using a pseudo-code-address mapping.
- `ESP` remains initialized from the active stack region's empty-stack address and remains explicitly writable by supported source instructions.

No future procedure, stack instruction, or native-code execution behavior was implemented.

## 2. Source-of-truth files used

Canonical files used for implementation and review:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/history/reports/Milestone 68A report.md`
- `README.md`
- `web/index.html`

Repository/archive input:

- `Latest_repository_state_milestone_68A.zip`

The active canonical spec/guide pair was confirmed as:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

The guide identified the next canonical phase as Phase 68B, matching `TARGET_MILESTONE = 68B`.

## 3. Exact requirements implemented

Implemented requirements from Phase 68B:

1. **Displayed `EIP` is derived VM control state.**
   - Added pseudo-code-address constants:
     - `VM_CODE_BASE = 00401000h`
     - `VM_CODE_STRIDE = 4`
   - Added helper behavior mapping lowered executable instruction indexes to displayed pseudo-code addresses.
   - Added reverse validation for aligned pseudo-code addresses, intended for later procedure/control-flow work.

2. **Displayed `EIP` follows VM execution position.**
   - Ordinary fallthrough updates displayed `EIP` by instruction position.
   - Direct `jmp` updates displayed `EIP` to the target lowered instruction.
   - Conditional jump taken and not-taken paths update displayed `EIP` correctly.
   - `exit` leaves displayed `EIP` at the executed `exit` instruction.
   - Runtime error stop leaves displayed `EIP` at the failing instruction.
   - Instruction-count watchdog stop leaves displayed `EIP` at the instruction where execution stopped.
   - No-executable and empty-entry programs display base pseudo-EIP `00401000h` and succeed when no other error exists.

3. **`EIP` source operands are rejected.**
   - Added `invalid-eip-operand` diagnostics for source-level uses including:
     - `mov eip, 1`
     - `mov eax, eip`
     - `add eip, 4`
     - `sub eip, 4`
     - `cmp eip, eax`
     - `xchg eip, eax`
     - `lea eip, [eax]`
     - `mov eax, [eip]`
     - `mov eax, [eax + eip]`
     - `mov [eip], eax`
     - `nop eip`
   - Diagnostics preserve line, column, byte offset, and span length.
   - Rendered Simulator Messages explain that `EIP` is displayed VM control state, not a source-writable general-purpose register.

4. **`EIP` declarations and symbol shadowing are rejected.**
   - Rejected attempts to define `EIP` as:
     - data symbol;
     - numeric equate;
     - code label;
     - procedure name.
   - Rejected `EIP` declarations are not inserted into user-symbol metadata.

5. **`IP` was not introduced.**
   - The current parser does not recognize `IP` as a built-in instruction-pointer alias.
   - Added regression coverage proving Phase 68B did not introduce `ip` as a source operand/register alias.

6. **`ESP` Phase 68A behavior is preserved.**
   - `ESP` remains initialized to the active stack region's empty-stack address.
   - Explicit supported writes to `ESP` remain legal:
     - `mov esp, 1`
     - `mov esp, eax`
     - `add esp, 4`
     - `sub esp, 4`
   - No ordinary-register stack-pointer range validation was added.
   - `mov esp, 1` followed by no implicit stack access does not fail solely because `ESP` is outside the stack range.

7. **Protocol and web display distinguish `EIP` role.**
   - Added `registerRoles` protocol metadata.
   - `EIP` uses role `derived-control-state`.
   - `ESP` uses role `stack-pointer`.
   - Browser final-register rendering marks `EIP` as `[derived control state]`.

8. **Startup notice wording updated.**
   - `EIP` is no longer grouped with ordinary zero-start or seeded source-writable registers.
   - `ESP` is identified as the exception initialized from the active stack region.
   - Final wording after user-test follow-up:

   ```text
   The simulator starts modeled flags and all registers to 0, except ESP and EIP. ESP is set to the end of the active stack region, and EIP is displayed as a derived VM pseudo-code address for the current execution position, not as a source-writable register. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
   ```

9. **Active documentation and web UI updated.**
   - README, supported syntax, milestone history, building/development notes, protocol metadata, web banner, and default browser code were updated for Phase 68B.
   - Active docs now describe `EIP` derived display as implemented behavior, not as future work.

## 4. Explicit non-goals and future work not implemented

The following were explicitly not implemented:

- Executable `CALL` to user procedures.
- `RET`, root `RET`, `RET imm16`, or `LEAVE`.
- Source-level `PUSH` or `POP`.
- Procedure call stacks, procedure frames, frame-pointer setup, or teardown.
- `PROC USES`, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR` behavior.
- Irvine32 callable routine dispatch beyond the existing virtual `exit` behavior.
- Stack overflow or stack underflow diagnostics.
- Suspicious-stack-pointer warnings.
- Real x86 instruction byte lengths.
- PE loader/linker behavior.
- Executable code memory.
- Code-section byte reads.
- Self-modifying code.
- Treating pseudo-EIP values as VM data-memory addresses.
- Making `ESP` non-writable.
- Introducing `IP` as a register alias.

## 5. Assumptions used

- Assumption: `00401000h` is the canonical Phase 68B pseudo-code base, and `4` is the canonical pseudo-code stride.
  Reason: The Phase 68B guide made these values the milestone contract for displayed pseudo-EIP.
  Risk: Future milestones could confuse pseudo-code addresses with real PE layout or real x86 byte offsets.
  How to change later: Keep pseudo-code-address helpers isolated and revise the constants or mapping if a later layout/display milestone changes the policy.

- Assumption: Retaining internal `cpu->eip` storage is acceptable if it is treated as display/control-state storage only.
  Reason: Removing the field would have created unnecessary churn. The milestone required blocking source-level `EIP` access, not removing every internal field named `eip`.
  Risk: Future work could accidentally route source-level writes through the internal field.
  How to change later: Further split generic register storage from VM control-state storage, or add stricter internal APIs before implementing procedure calls.

- Assumption: A new diagnostic code `invalid-eip-operand` is appropriate.
  Reason: No clearly equivalent existing diagnostic described the Phase 68B source-role violation.
  Risk: New diagnostic codes require web rendering, protocol, and structured test coverage.
  How to change later: If diagnostics are later consolidated, alias or migrate this code with compatibility tests.

- Assumption: `IP` should remain unsupported rather than becoming an alias.
  Reason: The current parser did not recognize `IP` as an instruction-pointer register alias, and Phase 68B explicitly did not require introducing it.
  Risk: Users familiar with 16-bit x86 may expect `IP`, but the simulator's current educational MASM32 subset does not support it.
  How to change later: If a future phase introduces `IP`, apply the same non-source-writable control-state restrictions and add mirrored diagnostics/tests.

- Assumption: `exit` final pseudo-EIP should remain at the executed `exit` instruction.
  Reason: The simulator does not model a real OS return, CRT epilogue, or post-exit instruction. Phase 68B records the current/last completed VM instruction position.
  Risk: Some users may expect `EIP` to advance to a synthetic next address after `exit`.
  How to change later: Add an explicit terminal-control-state value or synthetic post-exit pseudo-address in a future milestone if the spec changes.

## 6. Relevant TODO-style notes reviewed

Reviewed TODO-style notes and TODO-like planning/status text included:

- `README.md` Phase 68B next-work note.
- `docs/SUPPORTED_SYNTAX.md` Phase 68A legacy EIP wording and deferred stack/procedure notes.
- `docs/MILESTONE_HISTORY.md` planned Phase 68B status text.
- `src/wasm/wasm_api.c` future memory-reading opcode TODO.
- `src/parser/parser.h` future Irvine32 routine classification note.
- Historical test comment about Phase 59 instruction-limit precedence before later Phase 61 `jmp`.
- Future/deferred documentation notes for CALL, RET, PUSH/POP, procedure frames, Irvine32 callable routines, and later data/instruction families.

## 7. TODO-style note disposition

- target-owned TODO-style notes resolved:
  - README Phase 68B next-work note was resolved by implementation/status updates.
  - `SUPPORTED_SYNTAX.md` legacy displayed-`EIP` wording was resolved.
  - `MILESTONE_HISTORY.md` Phase 68B planned-work/status wording was resolved.

- future-owned TODO-style notes intentionally preserved:
  - `src/wasm/wasm_api.c` future memory-reading opcode TODO remains for later memory-reading opcode milestones.
  - `src/parser/parser.h` future Irvine32 routine classification note remains for later Irvine32 callable routine work.
  - CALL, RET, PUSH/POP, procedure-frame, stack-runtime, and Irvine32 routine deferrals remain documented as future work.

- stale or contradicted TODO-style notes corrected:
  - Stale Phase 68A-oriented comments/assertion descriptions in tests were corrected during compliance review.
  - Documentation that described implemented Phase 68B behavior as future behavior was updated.

- unresolved TODO-related risks:
  - None blocking.
  - Remaining TODO-style notes are future-scoped and did not drive accidental future-milestone implementation.

## 8. Design summary

The implementation separates three concepts that were previously too tightly coupled:

1. **Generic source-writable registers**
   - Ordinary registers remain source-visible and source-writable.
   - `ESP` remains in this category for explicit source writes, even though its startup value is stack-derived.

2. **Displayed VM control state**
   - `EIP` is displayed as the VM execution position.
   - It is not source-writable or source-readable as a general-purpose register.
   - It is not a memory addressing base/index and cannot be defined as a user symbol.

3. **Pseudo-code-address display policy**
   - The VM maps lowered executable instruction indexes to stable educational addresses beginning at `00401000h`.
   - Each lowered executable VM instruction advances by a fixed pseudo-address stride of `4`.
   - The mapping is intentionally educational and deterministic; it is not a real x86 byte-length model.

Protocol output now carries register role metadata so the browser can label `EIP` as derived control state without removing it from final-register output.

Diagnostics are emitted during parsing/assembly validation, not during execution. Assembly errors prevent execution and produce no register state, preserving the existing separation between Program Console and Simulator Messages.

## 9. Files changed

Files changed across implementation, compliance reviews, and user-test follow-up:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_cpu.c`
- `src/core/vm_cpu.h`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_vm_cpu.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_formatters.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/formatters.js`
- `web/src/main.js`
- `web/src/protocol.js`

## 10. Tests added

Added or expanded tests cover:

### Parser and diagnostics

- Reject `mov eip, 1`.
- Reject `mov eax, eip`.
- Reject `add eip, 4`.
- Reject `sub eip, 4`.
- Reject `cmp eip, eax`.
- Reject `xchg eip, eax`.
- Reject `lea eip, [eax]`.
- Reject `mov eax, [eip]`.
- Reject `mov eax, [eax + eip]`.
- Reject `mov [eip], eax`.
- Reject `nop eip`.
- Reject `EIP` data declarations.
- Reject `EIP` numeric equates.
- Reject `EIP` labels.
- Reject `EIP PROC` procedure names.
- Verify `ip` was not introduced as a built-in register alias.
- Verify structured diagnostic fields: code, severity, line, column, byte offset, and span length.
- Verify rendered Simulator Messages wording for invalid `EIP` operands.

### CPU and VM executor

- Pseudo-EIP index-to-address mapping.
- Pseudo-EIP reverse mapping.
- Rejection of pseudo-EIP values below base.
- Rejection of non-stride-aligned pseudo-EIP values.
- Rejection of out-of-range pseudo-EIP values.
- VM display-EIP synchronization after load, fallthrough, and branch transfer.

### Source-run integration

- Fallthrough pseudo-EIP display.
- Direct `jmp` pseudo-EIP display.
- Conditional jump taken pseudo-EIP display.
- Conditional jump not-taken pseudo-EIP display.
- Runtime divide-by-zero stop pseudo-EIP display.
- Instruction-count watchdog stop pseudo-EIP display.
- Empty selected-entry / no executable instruction state.
- Explicit `ESP` writes remain legal and visible.
- Invalid `EIP` diagnostics in JSON/source-run output.

### Web/protocol/static

- `registerRoles.EIP = derived-control-state`.
- `registerRoles.ESP = stack-pointer`.
- Final-register rendering marks `EIP` as `[derived control state]`.
- Startup notice text is rendered exactly.
- Documentation/runner static expectations reflect Phase 68B.

## 11. Commands used to test

Focused commands run:

```text
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command run:

```text
python3 scripts/run_tests.py --all
```

Subgroup or fixture-family commands:

- No additional documented subgroup/fixture-family commands were required after focused groups passed.

Skipped dependency checks:

- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

## 12. Pass/fail results

Final reported results after implementation, compliance review, second review, user-test follow-up, and final gap check:

- `python3 scripts/run_tests.py --structure`: PASS
- `python3 scripts/run_tests.py --native`: PASS
- `python3 scripts/run_tests.py --source-run`: PASS
- `python3 scripts/run_tests.py --web`: PASS
- `python3 scripts/run_tests.py --diagnostics`: PASS
- `python3 scripts/run_tests.py --protocol`: PASS
- `python3 scripts/run_tests.py --static`: PASS
- `python3 scripts/run_tests.py --all`: PASS in the final gap check
- Browser/Wasm rebuild smoke: SKIP because `emcc` was unavailable

Result classifications:

- aggregate completed and passed: yes, in the final gap check.
- aggregate timed out but focused groups passed: occurred during earlier compliance passes in the assistant/container environment; not the final status.
- aggregate failed: no.
- focused group failed: no final focused failure.
- focused group timed out and was rerun by subgroup/fixture: no final focused timeout requiring subgroup rerun.
- group skipped because dependency was unavailable: Browser/Wasm rebuild smoke skipped due to unavailable `emcc`.

## 13. Manual/browser testing guidance and expected outputs

Phase 68B is browser-testable after rebuilding Wasm with Emscripten. Without `emcc`, local native/source-run tests are still valid, but served browser execution may use stale Wasm artifacts.

### Setup for browser testing

From a Windows Emscripten-enabled command prompt:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Then open the local URL printed by the serve script.

### Program 1 - pseudo-EIP display and explicit ESP write

```asm
.386
.model flat, stdcall
.stack 4096
INCLUDE Irvine32.inc

.code
main PROC
    mov eax, 1
    mov esp, 1
    mov eax, 2
    exit
main ENDP
END main
```

Expected key output:

```text
[info] execution-complete: Execution completed successfully.
EAX = 00000002h
ESP = 00000001h
EIP = 0040100Ch [derived control state]
Memory Changes: No memory changes.
Program Console: No program output.
```

### Program 2 - taken conditional jump changes derived EIP

```asm
.386
.model flat, stdcall
.stack 4096
INCLUDE Irvine32.inc

.code
main PROC
    mov eax, 0
    cmp eax, 0
    je taken
    mov ebx, 111
taken:
    mov ecx, 222
    exit
main ENDP
END main
```

Expected key output:

```text
[info] execution-complete: Execution completed successfully.
EAX = 00000000h
EBX = 00000000h
ECX = 000000DEh
EIP = 00401014h [derived control state]
```

### Program 3 - empty selected entry / no executable instruction

```asm
.386
.model flat, stdcall
.stack 4096
INCLUDE Irvine32.inc

.code
main PROC
main ENDP
END main
```

Expected key output:

```text
[info] execution-complete: Execution completed successfully.
instructionCount = 0
executedInstructionCount = 0
currentInstructionIndex = null
attemptedNextInstructionIndex = null
EIP = 00401000h [derived control state]
```

### Program 4 - illegal source write to EIP

```asm
.386
.model flat, stdcall
.stack 4096
INCLUDE Irvine32.inc

.code
main PROC
    mov eip, 1
main ENDP
END main
```

Expected key output when pasted with the blank line shown above:

```text
[assembly-error] invalid-eip-operand line 8, column 9, byte offset 84, span length 3: EIP is displayed VM control state, not a source-writable general-purpose register. Source code cannot read, write, address through, or define EIP.
Final Registers: No register state available.
Memory Changes: No memory changes.
```

### Program 5 - illegal non-reading EIP instruction operand

```asm
.386
.model flat, stdcall
.stack 4096
INCLUDE Irvine32.inc

.code
main PROC
    nop eip
main ENDP
END main
```

Expected key output when pasted with the blank line shown above:

```text
[assembly-error] invalid-eip-operand line 8, column 9, byte offset 84, span length 3: EIP is displayed VM control state, not a source-writable general-purpose register. Source code cannot read, write, address through, or define EIP.
Final Registers: No register state available.
Memory Changes: No memory changes.
```

### Windows CMD local focused tests

From the repository root:

```cmd
python scripts\run_tests.py --structure
python scripts\run_tests.py --native
python scripts\run_tests.py --source-run
python scripts\run_tests.py --web
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --protocol
python scripts\run_tests.py --static
```

Expected result for each command:

```text
Selected test groups passed.
```

If `emcc` is unavailable, this skip is expected:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Regression signs:

- `EIP` is writable, readable, addressable, or definable from MASM source.
- `EIP` displays as `00000000h` for normal execution.
- `EIP` is missing from final register output.
- `EIP` lacks `[derived control state]` in the browser renderer.
- Explicit `ESP` writes fail.
- Empty selected-entry programs fail solely because no instruction executed.
- Invalid `EIP` diagnostics lose structured line/column/byte-offset/span metadata.
- Startup notice regresses to grouping `EIP` with ordinary source-writable registers.

## 14. Compliance review summary

The first compliance review found:

- Phase 68B scope was controlled correctly; no accidental CALL/RET/PUSH/POP/procedure-frame/code-memory work was added.
- Initial test coverage was too thin for:
  - no executable lowered-instruction program;
  - conditional jump taken and not-taken pseudo-EIP behavior;
  - runtime-error pseudo-EIP behavior;
  - watchdog-stop pseudo-EIP behavior;
  - pseudo-EIP helper and reverse-mapping behavior.
- Some stale Phase 68A labels remained in comments/assertion descriptions.

Fixes applied during the first compliance review:

- Added VM executor pseudo-EIP helper tests.
- Added source-run pseudo-EIP tests for no-executable, conditional jumps, runtime error, and watchdog paths.
- Corrected stale Phase 68A wording in tests and static runner text.

Focused groups passed after the fixes. Aggregate initially timed out in that environment, so focused results were used for that review pass.

## 15. Re-review summary

The second compliance review found:

- `nop eip` was still accepted through the existing NOP register encoding-operand path.
- `IP` alias behavior needed explicit regression coverage.
- A few comments/status strings were still too Phase-68A-oriented or too narrow.
- Docs/web wording did not explicitly cover non-reading instruction operands such as `nop eip`.

Fixes applied during the second review:

- Added parser rejection for `nop eip`.
- Added parser regression for `nop eip`.
- Added parser regression proving `ip` remains unsupported as a built-in register alias/source operand.
- Updated parser/source-run/static wording and web/docs wording to include `EIP` as an instruction operand.

All focused test groups passed after the second review. Aggregate timed out in that earlier assistant/container pass, so it was rerun later during the final gap check.

## 16. User-test follow-up summary

User manual testing showed Programs 1 through 5 behaved correctly.

Observed discrepancy:

- Manual instructions expected invalid `EIP` diagnostics at line 7, byte offset 83.
- Actual output showed line 8, byte offset 84.

Diagnosis:

- This was a manual-test expectation bug, caused by the blank line before `.code` in the provided source. The implementation output was correct.

User feedback:

- The startup notice was too wordy.
- The user asked why pseudo-EIP starts at `00401000h` and whether that resembles real MASM/x86 behavior.

Fixes applied:

- Shortened `startup-state-notice` while retaining the necessary `ESP` and `EIP` distinction.
- Updated rendered-message tests for the shorter notice.

Clarification captured:

- `00401000h` is the canonical Phase 68B pseudo-code base, resembling the common 32-bit Windows PE pattern where image base `00400000h` plus code-section RVA `00001000h` yields `00401000h`.
- The simulator does not model real PE layout or variable-length x86 instructions. The fixed stride of `4` is educational pseudo-address behavior, not native byte-accurate EIP behavior.
- `exit` intentionally leaves final displayed `EIP` at the executed `exit` pseudo-address because the simulator does not model an OS/CRT return path or synthetic post-exit instruction.

Rerun after user-test follow-up:

- `python3 scripts/run_tests.py --source-run`: PASS
- `python3 scripts/run_tests.py --diagnostics`: PASS
- `python3 scripts/run_tests.py --web`: PASS
- `python3 scripts/run_tests.py --static`: PASS

## 17. Known limitations

- `emcc` was unavailable in the assistant/container environment.
- Browser/Wasm rebuild smoke was skipped.
- Served website testing of the new C/Wasm behavior requires rebuilding the Wasm artifact in an Emscripten-enabled environment.
- `web/dist` generated artifacts were not regenerated by the assistant.
- `EIP` pseudo-addresses are not real native instruction addresses and do not use real x86 instruction lengths.
- `00401000h` and stride `4` are Phase 68B display-policy constants, not PE loader/linker output.
- CALL/RET/PUSH/POP and real stack/procedure behavior remain future work.

## 18. Next recommended milestone

Next recommended milestone:

- Phase 69 - Direct CALL to User Procedures

Recommended latest full repository archive after applying all Phase 68B changes:

```text
Latest_repository_state_milestone_68B.zip
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced during this milestone:

- `milestone_68B_implementation.zip`
- `milestone_68B_first_compliance_check.zip`
- `milestone_68B_second_compliance_check.zip`
- `milestone_68B_user_test_followup.zip`

No `milestone_68B_final_compliance_check.zip` was produced because the final gap check made no project file changes.

A full latest repository archive was recommended but not produced by the assistant during the report step:

- Recommended full archive name: `Latest_repository_state_milestone_68B.zip`
