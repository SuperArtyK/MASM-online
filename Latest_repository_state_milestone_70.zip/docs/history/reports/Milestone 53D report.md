# Milestone 53D report - Compatibility No-Op and Limited-Behavior Notices

## 1. Milestone title and scope

Milestone 53D implements **Phase 53D - Compatibility No-Op and Limited-Behavior Notices** for the Online MASM32 Educational Simulator.

This milestone adds default, non-fatal informational Simulator Messages for accepted MASM compatibility constructs whose real MASM behavior is intentionally not performed by the simulator, or whose simulator behavior is limited to metadata/virtual compatibility.

Scope implemented:

- Added non-fatal `simulator-notice` diagnostics for accepted compatibility constructs.
- Added structured notice diagnostic codes:
  - `compatibility-no-op`
  - `compatibility-metadata-only`
  - `compatibility-limited`
- Added default notices for processor compatibility directives:
  - `.386`
  - `.486`
  - `.586`
  - `.686`
- Added default notices for MASM32 compatibility metadata/limited directives:
  - `.model flat, stdcall`
  - `.stack`
  - `.stack size`
- Added a default limited-compatibility notice for:
  - `INCLUDE Macros.inc`
- Added default no-op listing/documentation notices for:
  - `TITLE`
  - `SUBTITLE`
  - `PAGE`
- Preserved successful execution for programs that contain only notices and otherwise valid executable source.
- Preserved assembly-error behavior for invalid constructs that appear alongside notices.
- Preserved Program Console and Simulator Messages separation.
- Preserved exact source location metadata for notices: line, column, byte offset, and span length.
- Preserved existing behavior for active semantic constructs that must not receive generic no-op notices.
- Updated documentation, browser status text, aggregate test reporting, parser tests, source-run tests, and rendered Simulator Messages tests.
- Applied a user-test follow-up improvement so processor and listing/documentation notices name the exact directive that produced the notice.

The implementation stayed within the target milestone boundary. No future UI settings, macro expansion, listing generation, host include loading, new instructions, runtime stack behavior, or broader MASM behavior was implemented.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 53C report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_53C.zip
```

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 53D is the only target milestone for this implementation session.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- User-visible diagnostics require structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

### 3.1 Notice severity and diagnostic codes

Implemented a non-fatal notice diagnostic category rendered as:

```text
[simulator-notice]
```

Implemented structured diagnostic codes:

```text
compatibility-no-op
compatibility-metadata-only
compatibility-limited
```

Behavior:

- Notices are emitted through Simulator Messages.
- Notices are not assembly errors.
- Notices do not block parsing, loading, or execution.
- Notices do not write to Program Console.
- Notices preserve source line, column, byte offset, and span length.
- Existing warnings and errors retain their prior behavior.

### 3.2 Processor compatibility directive notices

Implemented notices for accepted processor compatibility directives:

```asm
.386
.486
.586
.686
```

Final user-test-follow-up wording names the exact directive:

```text
.386 is accepted for MASM compatibility but does not change the simulator CPU mode.
.486 is accepted for MASM compatibility but does not change the simulator CPU mode.
.586 is accepted for MASM compatibility but does not change the simulator CPU mode.
.686 is accepted for MASM compatibility but does not change the simulator CPU mode.
```

Diagnostic code:

```text
compatibility-no-op
```

### 3.3 `.model flat, stdcall` limited-behavior notice

Implemented a default limited-behavior notice for accepted MASM32 textbook model syntax:

```asm
.model flat, stdcall
```

Rendered message:

```text
.model flat, stdcall is accepted for MASM32 textbook compatibility but does not enable real object-file, linker, Windows calling-convention, or WinAPI behavior.
```

Diagnostic code:

```text
compatibility-limited
```

Unsupported `.model` forms remain assembly errors. A source containing `.686` followed by `.model small, c` now reports the `.686` notice and the `.model` assembly error, and execution remains blocked by the error.

### 3.4 `.stack` metadata-only notices

Implemented notices for:

```asm
.stack
.stack 4096
```

`.stack` without size:

```text
.stack is accepted as stack metadata, but it does not by itself execute stack instructions or create procedure frames.
```

`.stack size`:

```text
.stack size is recorded as parser metadata, but runtime stack instructions and procedure frames remain deferred.
```

Diagnostic code:

```text
compatibility-metadata-only
```

The implementation did not add stack execution, stack instructions, call frames, procedure frames, `call`, `ret`, `push`, `pop`, `leave`, `LOCAL`, `PROTO`, or `INVOKE` behavior.

### 3.5 `INCLUDE Macros.inc` limited virtual-include notice

Implemented a limited-behavior notice for:

```asm
INCLUDE Macros.inc
```

Rendered message:

```text
INCLUDE Macros.inc is accepted as a virtual compatibility include; general MASM macro expansion remains unsupported until a later macro phase.
```

Diagnostic code:

```text
compatibility-limited
```

This milestone did not add real include-file loading, macro definitions, macro expansion, macro invocation support, or host filesystem access.

### 3.6 Listing/documentation no-op notices

Implemented default no-op notices for accepted listing/documentation directives:

```asm
TITLE Notice Sample
SUBTITLE More Notices
PAGE 60, 132
```

Final user-test-follow-up wording names the exact directive:

```text
TITLE is accepted as a listing/documentation directive for MASM compatibility but does not affect VM execution.
SUBTITLE is accepted as a listing/documentation directive for MASM compatibility but does not affect VM execution.
PAGE is accepted as a listing/documentation directive for MASM compatibility but does not affect VM execution.
```

Diagnostic code:

```text
compatibility-no-op
```

The implementation did not add listing-file generation or documentation output behavior.

### 3.7 Active semantic constructs intentionally produce no generic notice

Implemented and tested that generic compatibility notices are not emitted for constructs with active simulator semantics:

```asm
INCLUDE Irvine32.inc
OPTION CASEMAP:ALL
OPTION CASEMAP:NONE
.DATA?
.CONST
.code
PROC
ENDP
END
```

`INCLUDE Irvine32.inc` continues to enable the existing virtual `exit` terminator. It is not described as a no-op. `OPTION CASEMAP` directives continue to have source-order symbol lookup semantics and are not described as no-ops. `.DATA?` and `.CONST` retain their data layout, metadata, uninitialized-origin, and read-only behaviors.

### 3.8 Error precedence preserved

Notices do not downgrade or hide assembly errors.

Example behavior:

```asm
.686
.model small, c
.code
main PROC
    mov eax, 1
main ENDP
END main
```

Expected behavior:

- Emits a `.686` `simulator-notice`.
- Emits an `assembly-error` for unsupported `.model` syntax.
- Does not execute instructions.
- Does not emit `execution-complete`.
- Does not provide final register state.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 53D:

- Phase 53E browser settings UI.
- Compatibility-notice on/off browser setting.
- New share/project-state settings.
- Macro expansion.
- Macro definitions.
- Macro invocations.
- Real host include loading.
- Listing file generation.
- Real object-file behavior.
- Real linker behavior.
- Real `.model` calling-convention behavior.
- Windows API simulation.
- WinAPI import handling.
- PE loading.
- Host filesystem behavior.
- Runtime stack instruction behavior.
- Procedure frames.
- `call`, `ret`, `push`, `pop`, `leave`, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR` behavior.
- New runtime instructions.
- Phase 54 `imul`.
- New memory validation behavior.
- New default diagnostics for section-capacity, section-image, or allocated-object validation.
- Changes to default uninitialized-read or undefined-flag-use warning policies beyond preserving the already-completed Phase 53C behavior.

## 5. Assumptions used

### Assumption 1

- **Assumption:** A distinct `simulator-notice` category should be added instead of reusing `simulator-warning`.
- **Reason:** The Phase 53D guide preferred `[simulator-notice]`, and source inspection showed the diagnostic pipeline could support it with localized parser, Wasm JSON, and formatter changes.
- **Risk:** A new category required coordinated updates across parser diagnostics, source-run JSON mapping, renderer tests, documentation, and browser formatter behavior.
- **How to change later:** If a future diagnostic unification phase changes severity names, `simulator-notice` can be mapped through a shared diagnostic severity registry while preserving old rendered-message tests or migrating them intentionally.

### Assumption 2

- **Assumption:** Notices should be emitted one per relevant source construct rather than grouped.
- **Reason:** The guide allowed one notice per construct and made grouping optional. Per-construct notices preserve precise source locations and avoid broad diagnostic architecture work.
- **Risk:** Programs with many compatibility header directives may show several notices.
- **How to change later:** A future diagnostic-polish phase can add grouping or deduplication while retaining structured per-source metadata.

### Assumption 3

- **Assumption:** Browser UI/settings controls for compatibility notices should remain deferred to Phase 53E.
- **Reason:** Phase 53E is the guide-owned settings milestone. Phase 53D only required default notices and allowed opt-out only if simple.
- **Risk:** Website users cannot disable compatibility notices from the UI until Phase 53E.
- **How to change later:** Phase 53E can add a Compatibility Notices On/Off setting and route it through the existing source-run/settings protocol.

### Assumption 4

- **Assumption:** A backend/test opt-out was not required for Phase 53D after source inspection.
- **Reason:** Adding default notices was localized; adding a full opt-out path would overlap with Phase 53E settings policy and was not needed for Phase 53D acceptance coverage.
- **Risk:** Tests validate default-on behavior only.
- **How to change later:** Phase 53E can add an explicit compatibility-notices policy to source-run and browser settings.

### Assumption 5

- **Assumption:** Numeric phase metadata remains `53` rather than encoding suffix milestone `53D` as a numeric protocol value.
- **Reason:** Earlier suffix milestones used status/documentation updates without forcing suffix values into the numeric runtime phase field.
- **Risk:** The numeric field alone does not distinguish 53A, 53B, 53C, and 53D.
- **How to change later:** A future protocol/status milestone can add an explicit string milestone field while preserving numeric compatibility.

### Assumption 6

- **Assumption:** User-test feedback requesting directive-specific notice text is within Phase 53D scope.
- **Reason:** It improves the exact user-facing compatibility notice wording without adding new behavior or future milestone scope.
- **Risk:** More directive-specific message generation required a small parser helper and additional exact-message tests.
- **How to change later:** Future diagnostics can continue to use formatted directive-specific notice helpers where a generic notice would be ambiguous.

## 6. Relevant TODO-style notes reviewed

The repository was searched for TODO-style notes before implementation, using case-insensitive terms including:

```text
TODO
FIXME
HACK
TEMP
DEFERRED
future milestone
not yet implemented
later phase
follow-up
```

Relevant notes and evidence reviewed:

1. `docs/FULL_IMPLEMENTATION_SPEC.md` Phase 53C/53D transition note.
   - Summary: Meaningful compatibility no-op notices are owned by Phase 53D and were intentionally not emitted by default in Phase 53C.
   - Classification: target-owned.

2. `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` Phase 53D section.
   - Summary: Phase 53D must add non-fatal compatibility notices for accepted no-op, metadata-only, virtual-only, and limited constructs.
   - Classification: target-owned.

3. `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` 53D opt-out decision note.
   - Summary: `compatibility_notices = off/on` may be added if simple; otherwise Phase 53E owns opt-out/settings work.
   - Classification: target-owned decision point, with settings implementation deferred.

4. `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` active-semantics no-notice note.
   - Summary: Do not emit generic no-op notices for constructs with active semantics such as `INCLUDE Irvine32.inc`, `OPTION CASEMAP`, `.DATA?`, `.CONST`, `.code`, `PROC`, `ENDP`, and `END`.
   - Classification: target-owned regression requirement.

5. `src/parser/parser.h` stack metadata note.
   - Summary: Requested stack size from `.stack size`; runtime stack behavior is deferred.
   - Classification: target-owned evidence for `.stack` notice wording.

6. `docs/SUPPORTED_SYNTAX.md` stack behavior note.
   - Summary: `.stack` and `.stack size` store parser metadata; runtime stack behavior remains deferred.
   - Classification: target-owned evidence for `.stack` notice wording.

7. `src/wasm/wasm_api.c` future memory-reading opcode TODO.
   - Summary: Future memory-reading opcodes must be added when those opcodes are implemented.
   - Classification: future-owned.

8. `src/parser/parser.c` CALL classification deferral.
   - Summary: CALL target classification remains deferred until CALL exists.
   - Classification: future-owned.

9. Phase 53E settings/UI roadmap notes.
   - Summary: Browser UI/settings exposure belongs to Phase 53E.
   - Classification: future-owned.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 53D ownership of compatibility no-op/limited-behavior notices was implemented.
- Active-semantics no-notice requirements were implemented and tested.
- `.stack` metadata-only/runtime-deferred behavior was reflected in notice wording and tests.
- User-test follow-up improved directive-specific notice wording for processor and listing/documentation directives.

### Future-owned TODO-style notes intentionally preserved

- Future memory-reading opcode TODO in `src/wasm/wasm_api.c` remains unchanged.
- CALL target classification deferral remains unchanged.
- Phase 53E browser settings/UI work remains deferred.
- Extended 32-bit/QWORD/SQWORD future deferrals remain unchanged.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style note required correction.
- A stale non-TODO documentation sentence in `docs/SUPPORTED_SYNTAX.md` was corrected during first compliance review because it described Phase 53D using Phase 53C wording.

### Unresolved TODO-related risks

- None identified. Remaining TODO-style notes are future-scoped and do not contradict the current spec/guide or Phase 53D scope.

## 8. Design summary

### Diagnostic model

A parser diagnostic notice severity was added and mapped through source-run/Wasm output to the rendered Simulator Messages category:

```text
simulator-notice
```

The notice severity is lower than warning/error. It is non-fatal and does not prevent execution.

### Parser notice emission

The parser now emits notices when it accepts compatibility constructs with limited or no runtime effect:

- processor directives;
- `.model flat, stdcall`;
- `.stack` and `.stack size`;
- `INCLUDE Macros.inc`;
- `TITLE`, `SUBTITLE`, and `PAGE`.

Notice messages are directive-specific where that improves clarity. For example, `.686` and `TITLE` are included directly in their notice text.

### Source-run behavior

Source-run JSON includes notices in `simulatorMessages` along with warnings, errors, and info messages. Valid programs with notices still execute normally and emit `execution-complete`.

### Rendered message behavior

The web/Node Simulator Messages formatter renders notices as:

```text
[simulator-notice] <code> line <line>, column <column>, byte offset <offset>, span length <span>: <message>
```

Exact rendered-message tests cover this formatting.

### Error precedence

Assembly errors remain fatal. A source file may contain notices before an error, but any assembly error still prevents execution and prevents `execution-complete`.

### Scope preservation

The implementation does not alter VM execution, memory validation, Program Console behavior, instruction semantics, default teaching warnings from Phase 53C, or browser settings.

## 9. Files changed

Final changed-files package includes these repository files:

```text
README.md
docs/SUPPORTED_SYNTAX.md
docs/TESTING_GUIDE.md
scripts/run_tests.py
src/parser/parser.c
src/parser/parser.h
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
web/index.html
```

## 10. Tests added

### Parser tests

Added/updated parser tests for:

- `compatibility-no-op` notices.
- `compatibility-metadata-only` notices.
- `compatibility-limited` notices.
- Notice severity classification.
- Source line, column, byte offset, and span length metadata.
- Processor directive notices that name `.686` and related directives.
- Listing/documentation notices that name `TITLE`, `SUBTITLE`, and `PAGE`.
- Active semantic constructs that must not receive generic compatibility notices.

### Source-run tests

Added/updated source-run tests for:

- Notice-bearing source programs that still execute successfully.
- Final register state preservation for programs that include compatibility notices.
- Program Console remaining separate and unaffected.
- Error precedence when a notice appears before an assembly error.
- No generic notice for `INCLUDE Irvine32.inc` and other active semantic constructs.
- Directive-specific notice wording after user-test follow-up.

### Rendered Simulator Messages tests

Added exact rendered-message tests for:

- `[simulator-notice] compatibility-no-op ...`
- `[simulator-notice] compatibility-metadata-only ...`
- `[simulator-notice] compatibility-limited ...`
- Successful completion following notices.
- Notice plus assembly-error output.
- User-test follow-up directive-specific wording.

### Aggregate reporting

Updated aggregate test-runner output so Phase 53D parser/source-run/rendered-message coverage is reported by the full test suite.

## 11. Commands used to test

Initial repository verification:

```bash
cd /mnt/data/repo_m53c_verify
python3 scripts/run_tests.py
```

Implementation test run:

```bash
cd /mnt/data/repo_m53c_verify
python3 scripts/run_tests.py
```

First compliance review test run:

```bash
cd /mnt/data/repo_m53c_verify
python3 scripts/run_tests.py
```

Second compliance review test run:

```bash
cd /mnt/data/repo_m53c_verify
python3 scripts/run_tests.py
```

User-test follow-up final test run:

```bash
cd /mnt/data/repo_m53d_followup
python3 scripts/run_tests.py
```

Final gap-check test run:

```bash
cd /mnt/data/repo_m53d_followup
python3 scripts/run_tests.py
```

## 12. Pass/fail results

All runs passed.

Final observed result:

```text
All implemented milestone tests passed.
```

Additional environment result:

```text
Phase 51 browser manual smoke after rebuilding Wasm: not run; emcc is unavailable in this environment.
```

Native C tests compiled with strict C99 posture:

```text
-std=c99 -Wall -Wextra -Werror -pedantic
```

Node/web protocol, formatter, and rendered Simulator Messages tests passed.

## 13. Manual/browser testing guidance and expected outputs

Phase 53D is website-testable after rebuilding Wasm in an Emscripten-capable Windows environment.

### Required setup assumptions

- Windows CMD, Visual Studio Developer Command Prompt, or equivalent shell.
- Emscripten available for browser testing.
- Python available as `py` for local aggregate tests.
- Node.js available for web/formatter tests.
- A GCC/Clang-style C compiler available for `scripts/run_tests.py`; on Windows, set `CC=clang` if needed.

### Browser build and serve commands

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

### Manual Program 1 - Main compatibility notices

```asm
.386
.486
.586
.686
.model flat, stdcall
.stack 4096
INCLUDE Macros.inc
TITLE Notice Sample
SUBTITLE More Notices
PAGE 60, 132
.code
main PROC
    mov eax, 42
main ENDP
END main
```

Expected Simulator Messages after the user-test follow-up wording improvement:

```text
[simulator-notice] compatibility-no-op line 1, column 1, byte offset 0, span length 4: .386 is accepted for MASM compatibility but does not change the simulator CPU mode.
[simulator-notice] compatibility-no-op line 2, column 1, byte offset 5, span length 4: .486 is accepted for MASM compatibility but does not change the simulator CPU mode.
[simulator-notice] compatibility-no-op line 3, column 1, byte offset 10, span length 4: .586 is accepted for MASM compatibility but does not change the simulator CPU mode.
[simulator-notice] compatibility-no-op line 4, column 1, byte offset 15, span length 4: .686 is accepted for MASM compatibility but does not change the simulator CPU mode.
[simulator-notice] compatibility-limited line 5, column 1, byte offset 20, span length 6: .model flat, stdcall is accepted for MASM32 textbook compatibility but does not enable real object-file, linker, Windows calling-convention, or WinAPI behavior.
[simulator-notice] compatibility-metadata-only line 6, column 1, byte offset 41, span length 6: .stack size is recorded as parser metadata, but runtime stack instructions and procedure frames remain deferred.
[simulator-notice] compatibility-limited line 7, column 1, byte offset 53, span length 7: INCLUDE Macros.inc is accepted as a virtual compatibility include; general MASM macro expansion remains unsupported until a later macro phase.
[simulator-notice] compatibility-no-op line 8, column 1, byte offset 72, span length 5: TITLE is accepted as a listing/documentation directive for MASM compatibility but does not affect VM execution.
[simulator-notice] compatibility-no-op line 9, column 1, byte offset 92, span length 8: SUBTITLE is accepted as a listing/documentation directive for MASM compatibility but does not affect VM execution.
[simulator-notice] compatibility-no-op line 10, column 1, byte offset 114, span length 4: PAGE is accepted as a listing/documentation directive for MASM compatibility but does not affect VM execution.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected final register excerpt:

```text
EAX    | 0000002Ah / u: 42         / s:  42
```

Expected memory changes:

```text
No memory changes.
```

### Manual Program 2 - `.stack` without size

```asm
.stack
.code
main PROC
    mov eax, 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] compatibility-metadata-only line 1, column 1, byte offset 0, span length 6: .stack is accepted as stack metadata, but it does not by itself execute stack instructions or create procedure frames.
[info] execution-complete: Execution completed successfully.
```

Expected final register excerpt:

```text
EAX    | 00000001h / u: 1          / s:  1
```

Expected Program Console:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

### Manual Program 3 - Active semantic constructs should not receive generic no-op notices

```asm
INCLUDE Irvine32.inc
OPTION CASEMAP:ALL
.DATA?
buf DWORD ?
.CONST
limit DWORD 1
.code
main PROC
    exit
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected behavior:

- No `compatibility-no-op` notice for `INCLUDE Irvine32.inc`.
- No no-op notice for `OPTION CASEMAP:ALL`.
- No no-op notice for `.DATA?`, `.CONST`, `.code`, `PROC`, `ENDP`, or `END`.
- `exit` succeeds because `INCLUDE Irvine32.inc` is active.

Expected Program Console:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

### Manual Program 4 - Notice plus assembly error

```asm
.686
.model small, c
.code
main PROC
    mov eax, 1
main ENDP
END main
```

Expected Simulator Messages after the user-test follow-up wording improvement:

```text
[simulator-notice] compatibility-no-op line 1, column 1, byte offset 0, span length 4: .686 is accepted for MASM compatibility but does not change the simulator CPU mode.
[assembly-error] unsupported-model line 2, column 1, byte offset 5, span length 6: .model form is unsupported. Use `.model flat, stdcall` in MASM32 Educational Mode.
```

Expected behavior:

- No `execution-complete` message.
- No instruction execution.
- No final register state available.
- No memory changes.

### Windows CMD local testing guidance

Run the full test suite:

```cmd
set CC=clang
py scripts\run_tests.py
```

Expected final line:

```text
All implemented milestone tests passed.
```

For local diagnostic JSON checks, save a manual program as root-level `program.asm` and run:

```cmd
build\tests\diagnostic_json_producer.exe program.asm
```

Expected JSON for valid notice-bearing programs:

```json
{
  "ok": true,
  "status": "ok"
}
```

Expected JSON for Program 4:

```json
{
  "ok": false,
  "status": "parse-error",
  "instructionCount": 0
}
```

Regression signs:

- Missing `simulator-notice` messages for accepted compatibility constructs.
- Notices rendered as warnings or errors.
- Notices written to Program Console.
- Notices blocking execution.
- Assembly errors failing to block execution.
- Generic no-op notices for active semantic constructs such as `INCLUDE Irvine32.inc` or `.CONST`.
- Directive-specific notice wording disappearing after the user-test follow-up.
- Changed source line/column/byte offset/span length metadata.

## 14. Compliance review summary

First compliance review findings:

- Scope control passed: only Phase 53D behavior was implemented.
- C99 boundary passed: no C++ core code was introduced.
- Diagnostic structure passed: notices preserve source location data and rendered-message tests exist.
- Test coverage passed for success, error, edge, regression, and rendered-message paths.
- One stale documentation sentence in `docs/SUPPORTED_SYNTAX.md` described Phase 53D using Phase 53C wording.

Fix applied:

- Corrected `docs/SUPPORTED_SYNTAX.md` so Milestone 53D describes compatibility notices, not default uninitialized-read/undefined-flag-use warnings.

Tests rerun:

```bash
python3 scripts/run_tests.py
```

Result:

```text
PASS - All implemented milestone tests passed.
```

## 15. Re-review summary

Second compliance review findings:

- One test-quality issue was found: several unrelated rendered-message assertions in `tests/web/test_diagnostic_rendering.mjs` had accidentally been relabeled with the new Phase 53D fixture name.
- The tested behavior was correct, but failure labels were misleading.

Fix applied:

- Restored unrelated rendered-message assertions to use their local `name` variable.
- Kept the actual Phase 53D rendered-message assertion labeled as `phase53d-compatibility-notices`.

Tests rerun:

```bash
python3 scripts/run_tests.py
```

Result:

```text
PASS - All implemented milestone tests passed.
```

Final re-review verdict:

- Scope complete.
- Documentation complete.
- Test coverage complete.
- TODO-style notes correctly disposed.

## 16. User-test follow-up summary

The user manually ran the provided browser programs and confirmed behavior matched expected output functionally.

User suggestion:

- The generic processor and listing/documentation notice messages should name the exact directive used, because line/column information alone is not enough to make the diagnostic self-explanatory.

Diagnosis:

- Functional behavior was correct.
- The message wording was a usability issue within Phase 53D scope.

Fix applied:

- Updated processor compatibility notices to name `.386`, `.486`, `.586`, or `.686`.
- Updated listing/documentation notices to name `TITLE`, `SUBTITLE`, or `PAGE`.
- Added a small parser formatting helper for directive-specific notice text.

Regression tests added/updated:

- Parser tests for directive-specific processor/listing notices.
- Source-run tests for directive-specific notice messages.
- Rendered Simulator Messages tests for exact final wording.

Tests rerun:

```bash
cd /mnt/data/repo_m53d_followup
python3 scripts/run_tests.py
```

Result:

```text
PASS - All implemented milestone tests passed.
```

Remaining manual verification after follow-up:

- Rebuild Wasm and rerun Program 1 and Program 4 in the browser to verify the updated directive-specific rendered messages appear in the served UI.

## 17. Known limitations

- Emscripten was unavailable in this environment, so Wasm rebuild and served-browser smoke testing could not be performed here.
- Compatibility notices are default-on, and no browser UI setting exists yet. Phase 53E owns settings/UI exposure.
- No backend/test compatibility-notice opt-out was added in Phase 53D.
- Numeric runtime phase metadata remains `53`; suffix milestone identity is represented in documentation/status text rather than as a separate numeric phase value.
- No macro expansion, listing generation, real linker behavior, real `.model` calling-convention behavior, runtime stack behavior, new instruction behavior, or Windows API behavior was implemented.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 53E - Default Teaching Diagnostics Browser Settings Panel
```

Expected Phase 53E ownership:

- Browser UI/settings exposure for default teaching diagnostics.
- Likely compatibility notice setting integration if the guide still requires it at that point.
- No Phase 54 `imul` behavior unless Phase 53E is completed or intentionally skipped by a future canonical guide change.

## 19. Changed-files ZIP/package produced

Final changed-files package:

```text
milestone_53D_user_followup_changed_files.zip
```

Earlier packages produced during review history:

```text
milestone_53D_changed_files.zip
milestone_53D_review_changed_files.zip
milestone_53D_second_review_changed_files.zip
```

Recommended package to apply/use:

```text
milestone_53D_user_followup_changed_files.zip
```

Recommended latest repository/archive name after applying the final changed-files package to the Milestone 53C base:

```text
Latest_repository_state_milestone_53D.zip
```
