# Milestone 61B report - Branch Runtime Watchdog Scope Cleanup

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 61B - Branch Runtime Watchdog Scope Cleanup
```

Repository/archive milestone after this work:

```text
Phase 61B - Branch Runtime Watchdog Scope Cleanup
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 61 - Direct JMP Runtime Execution
```

Status interpretation:

The repository/archive milestone is newer than the runtime/source-run MASM behavior phase because Phase 61B is documentation and static-check hardening for behavior already owned by Phase 61. Phase 61B does not add MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser controls, browser layout, browser interaction behavior, diagnostic codes, diagnostic JSON fields, or rendered Simulator Messages behavior. Runtime/source-run phase metadata must remain Phase 61 unless a later target phase explicitly changes runtime-visible MASM/source behavior or explicitly requires metadata advancement.

Scope implemented:

- Clarified that direct `jmp label` runtime execution is governed by the Phase 59 instruction-count watchdog.
- Clarified that Phase 61, Phase 61A, and Phase 61B do not implement active-time watchdog behavior.
- Preserved Phase 200 - Active Time Watchdog and Worker Responsiveness as the future owner for active-time watchdog behavior.
- Updated current-status documentation to distinguish repository/archive Phase 61B from runtime/source-run MASM behavior Phase 61.
- Added static documentation checks to prevent future wording from implying that active-time watchdog behavior is implemented or required by the direct-JMP phases.
- Preserved all direct-JMP runtime behavior from Phase 61 and Phase 61A.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_61B.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 61A report.md`
- `Project Audit and Milestones.txt`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_61A.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, status-surface hygiene, and broad product constraints.
- The implementation guide owns Phase 61B numbering, exact phase scope, tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or implementation guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or implementation guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

## 3. Exact requirements implemented

### 3.1 Repository/runtime status split

Implemented the Phase 61B status split:

```text
Repository/archive milestone:
Phase 61B - Branch Runtime Watchdog Scope Cleanup

Runtime/source-run MASM behavior phase:
Phase 61 - Direct JMP Runtime Execution
```

Current-status documentation and static checks preserve that split. Runtime/source-run JSON continues to report Phase 61 behavior metadata, because Phase 61B does not introduce new runtime-visible MASM/source behavior.

### 3.2 Instruction-count watchdog clarification

Updated current-status documentation to clarify that Phase 61 direct-JMP runtime execution is guarded by the Phase 59 `instructionLimit` watchdog.

The clarified behavior is:

- Direct `jmp label` transfers to the resolved VM instruction index.
- A committed direct `jmp` counts as one executed VM instruction.
- Backward direct-JMP loops are stopped by the Phase 59 instruction-count watchdog when the configured instruction limit blocks the next instruction fetch.
- The relevant diagnostic remains `instruction-limit-exceeded`.
- The blocked instruction does not execute.
- No active-time watchdog behavior is involved in this path.

### 3.3 Active-time watchdog boundary

Clarified that active-time watchdog behavior is not implemented by any of these phases:

- Phase 61 - Direct JMP Runtime Execution
- Phase 61A - Direct JMP Runtime Accounting and Status Hardening
- Phase 61B - Branch Runtime Watchdog Scope Cleanup

The future owner remains:

```text
Phase 200 - Active Time Watchdog and Worker Responsiveness
```

Phase 61B does not add:

- wall-clock timing;
- monotonic-clock checks;
- worker yielding/chunking;
- Stop-button responsiveness;
- time-limit settings;
- active-time diagnostics;
- browser UI controls for execution time.

### 3.4 Current-status documentation updates

Updated documentation to report repository/archive Phase 61B while keeping runtime/source-run MASM behavior at Phase 61.

Updated files:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`

The updated wording states that Phase 61B is documentation/static-check hardening, not a new runtime behavior phase.

### 3.5 Static checks

Added and strengthened static checks in `scripts/run_tests.py`.

The static checks now require documentation to preserve these facts:

- Repository/archive milestone is Phase 61B.
- Runtime/source-run MASM behavior phase remains Phase 61.
- Direct-JMP loop behavior is tied to the Phase 59 instruction-count watchdog.
- Active-time watchdog behavior is not part of Phase 61, Phase 61A, or Phase 61B.
- Phase 200 remains the active-time watchdog owner.
- Current-status docs must not contain contradictory wording implying that active-time watchdog behavior is already implemented or required by Phase 61B.

During the second compliance pass, negative-check coverage was widened across all changed current-status docs:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 61B:

- Active-time watchdog behavior.
- Wall-clock execution limits.
- Monotonic-clock or fake-clock logic.
- Worker yielding/chunking for responsiveness.
- Stop-button responsiveness.
- Browser UI controls for execution time or instruction limits.
- New source-run JSON fields.
- New diagnostics or rendered Simulator Messages categories.
- New Program Console behavior.
- C runtime behavior changes.
- Parser changes.
- Executor changes.
- Wasm API changes.
- Worker/protocol changes.
- Browser UI changes.
- New branch syntax.
- Conditional jumps.
- `cmp`.
- `loop`, `loope`, `loopne`, `jcxz`, or `jecxz`.
- Indirect branch execution.
- Register-target `jmp` execution.
- Memory-target `jmp` execution.
- Immediate-target `jmp` execution.
- Branch-distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Relative branch encoding or real x86 instruction encoding.
- Native x86 execution.
- Stack or procedure execution semantics.
- `call`, `ret`, `leave`, `push`, or `pop`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 routine calls beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Debugger stepping, breakpoints, current-instruction highlighting, editor source navigation, or label-click navigation.
- Reserved-word declaration diagnostics.
- `OPTION NOKEYWORD`.
- General dynamic keyword-table mutation.
- Full MASM macro expansion.

Future work intentionally preserved:

- Phase 61C - Branch Debugger Dependency Cleanup.
- Phase 61D - Source-Run Capacity Documentation and Diagnostic Hardening.
- Phase 61E - Reserved Word Symbol Diagnostics.
- Phase 62 - CMP Register and Immediate Forms.
- Later conditional jump phases.
- Later `loop` phase.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future `OPTION NOKEYWORD` keyword-control compatibility.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 61B advances repository/archive milestone status but does not advance runtime/source-run MASM behavior metadata.
- **Reason:** Phase 61B clarifies documentation and static checks only. It does not add MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser controls, browser layout, browser interaction behavior, diagnostic codes, diagnostic JSON fields, or rendered Simulator Messages behavior.
- **Risk:** Future readers may think runtime/source-run metadata is stale because repository documentation says Phase 61B.
- **How to change later:** Only update runtime/source-run metadata in a later phase that explicitly changes runtime-visible MASM/source behavior or explicitly requires metadata advancement.

### Assumption 2

- **Assumption:** Static checks are the correct test vehicle for Phase 61B.
- **Reason:** The target work is documentation/status-surface hardening. No C runtime, parser, executor, Wasm API, worker/protocol, browser UI, diagnostic, or rendered-message behavior should change.
- **Risk:** Static checks can become brittle if they require long exact prose blocks.
- **How to change later:** Keep checks focused on stable required fragments and specific forbidden contradictions rather than broad verbatim documentation snapshots.

### Assumption 3

- **Assumption:** Phase 61 direct-JMP loop execution remains governed by the Phase 59 instruction-count watchdog only.
- **Reason:** Phase 59 already owns the deterministic `instructionLimit` path. Phase 61 executes direct `jmp label`; Phase 61A hardened accounting/status coverage; Phase 61B clarifies that active-time watchdog behavior remains separate future work.
- **Risk:** Older wording about respecting watchdogs could be misread as requiring active-time watchdog support now.
- **How to change later:** Phase 200 can deliberately add active-time watchdog behavior and then update docs, runtime behavior, UI/settings, protocol, and tests as required by that phase.

### Assumption 4

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this environment.
- **Reason:** `emcc` is unavailable on PATH in the assistant/container environment, and Phase 61B does not change C/Wasm runtime files.
- **Risk:** Local served artifacts may be stale if a developer expects rebuilt Wasm after earlier runtime changes.
- **How to change later:** Run `scripts\windows\build_wasm.cmd` in an Emscripten-enabled Windows environment when C/Wasm artifacts need rebuilding.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning, implementation, compliance review, re-review, manual-test preparation, and final gap check:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61B - Branch Runtime Watchdog Scope Cleanup
- Note text or summary:
  Phase 61B owns documentation, static checks, and milestone-report wording to prevent future assistants from treating active-time watchdog behavior as part of direct-JMP execution.
- Classification:
  target-owned
- Reason:
  This is the canonical target milestone scope.
- Action for this milestone:
  Implemented through documentation/status updates and static checks.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61B required clarification
- Note text or summary:
  Any Phase 61-related wording that says or implies "Respect instruction-count and active-time watchdogs" must be interpreted as instruction-count watchdog only; active-time watchdog remains future work until Phase 200.
- Classification:
  target-owned
- Reason:
  This is the specific ambiguity Phase 61B exists to correct.
- Action for this milestone:
  Implemented through documentation clarifications and static checks tying direct-JMP loops to Phase 59 and active-time watchdog ownership to Phase 200.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 61B required tests and checks
- Note text or summary:
  Add static documentation checks or manual audit checklist entries proving early direct-branch phases refer to Phase 59, do not require active-time watchdog implementation, and keep Phase 200 as active-time watchdog owner.
- Classification:
  target-owned
- Reason:
  This directly defines the acceptance work for Phase 61B.
- Action for this milestone:
  Implemented in `scripts/run_tests.py` static checks.
```

```text
- Location:
  docs/MILESTONE_HISTORY.md, Phase 61A entry and future-work boundary text
- Note text or summary:
  Active-time watchdog behavior remains future work.
- Classification:
  future-owned
- Reason:
  Correct boundary statement. Phase 61B clarifies the boundary but does not implement active-time watchdog behavior.
- Action for this milestone:
  Preserved and clarified.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 200 - Active Time Watchdog and Worker Responsiveness
- Note text or summary:
  Active execution time watchdog behavior is assigned to Phase 200.
- Classification:
  future-owned
- Reason:
  Phase 200 remains the owner. Phase 61B must not implement active-time measurement, wall-clock limits, worker yielding, Stop-button responsiveness, or UI controls.
- Action for this milestone:
  Preserved as future owner and referenced as a boundary.
```

```text
- Location:
  src/wasm/wasm_api.c
- Note text or summary:
  TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
- Classification:
  future-owned
- Reason:
  Phase 61B adds no memory-reading opcode and does not touch runtime behavior.
- Action for this milestone:
  Left unchanged.
```

```text
- Location:
  src/core/vm_exec.h, src/core/vm_exec.c, src/wasm/wasm_api.c
- Note text or summary:
  `branch-runtime-deferred` status path remains present for accepted branch forms whose runtime behavior is explicitly deferred.
- Classification:
  future-owned
- Reason:
  Phase 61A already confirmed valid direct `jmp label` does not emit this status. Phase 61B does not remove or implement deferred branch forms.
- Action for this milestone:
  Left runtime code unchanged.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 61B watchdog-scope clarification was implemented.
- Phase 61B instruction-count versus active-time watchdog boundary was documented.
- Phase 61B static documentation checks were added and strengthened.

### Future-owned TODO-style notes intentionally preserved

- Phase 200 active-time watchdog behavior.
- Future memory-reading opcode TODO in `src/wasm/wasm_api.c`.
- Future/deferred `branch-runtime-deferred` status-path notes.
- Conditional jumps.
- `cmp`.
- `loop`.
- Indirect jumps.
- Register-target jumps.
- Memory-target jumps.
- Immediate-target jumps.
- Branch-distance/type overrides.
- `call`, `ret`, stack behavior, procedure frames, and procedure invocation.
- Debugger stepping, breakpoints, editor/source navigation, and UI label navigation.
- Irvine32 callable routines beyond the virtual `exit` terminator.
- Reserved-word declaration diagnostics.
- `OPTION NOKEYWORD` keyword-control compatibility.

### Stale or contradicted TODO-style notes corrected

- None found.

### Unresolved TODO-related risks

- None specific to Phase 61B.

## 8. Design summary

Phase 61B was implemented as a status-surface and static-check hardening layer.

Primary design choices:

1. **Do not alter runtime behavior.** Existing Phase 61 direct-JMP runtime execution and Phase 61A accounting/status tests remain the behavioral authority. Phase 61B adds no runtime semantics.

2. **Preserve runtime/source-run metadata at Phase 61.** The repository/archive milestone advances to Phase 61B, but runtime/source-run MASM behavior remains Phase 61.

3. **Clarify watchdog ownership.** Direct-JMP loop protection is described as the Phase 59 instruction-count watchdog. Active-time watchdog behavior is named as Phase 200 future work.

4. **Prefer static checks over runtime tests.** Because the milestone is documentation/static-check only, `scripts/run_tests.py --static` is the primary new verification path.

5. **Avoid broad rewrites.** Updates were limited to current-status documentation and static-check logic. No C, parser, Wasm, worker, UI, or test fixture behavior was changed.

6. **Strengthen contradiction detection.** A second compliance pass expanded static negative checks across all changed current-status docs so contradictory active-time wording is caught more broadly.

## 9. Files changed

Changed files in the final Phase 61B state:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `scripts/run_tests.py`

No C runtime/core/parser/Wasm implementation files were changed.

No browser UI source files were changed.

No source-run fixtures or rendered Simulator Messages fixtures were changed.

## 10. Tests added

Added or strengthened static tests in `scripts/run_tests.py`:

- Updated Phase 61 status checks for repository/archive Phase 61B and runtime/source-run MASM behavior Phase 61.
- Added Phase 61B watchdog-scope documentation checks requiring:
  - Phase 59 instruction-count watchdog language;
  - Phase 200 active-time watchdog ownership language;
  - explicit statement that active-time watchdog behavior is not part of Phase 61, Phase 61A, or Phase 61B.
- Strengthened negative checks to scan all changed current-status docs for contradictory active-time watchdog wording:
  - `README.md`
  - `docs/SUPPORTED_SYNTAX.md`
  - `docs/MILESTONE_HISTORY.md`
  - `docs/BUILDING_AND_DEVELOPMENT.md`

No native C tests, parser tests, source-run tests, web formatter tests, diagnostic fixtures, protocol tests, or browser fixtures were added because Phase 61B does not change those behaviors.

## 11. Commands used to test

### Pre-implementation repository verification

Aggregate command attempted:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
Timed out in the assistant/container environment.
```

Classification:

```text
aggregate timed out in assistant/container environment, focused groups passed
```

Focused commands run after aggregate timeout:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Implementation verification

Focused commands run:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
```

Aggregate command attempted:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
Timed out in the assistant/container environment.
```

Classification:

```text
aggregate timed out with focused groups passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### First compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
All focused groups passed.
```

Aggregate command attempted:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
Timed out in the assistant/container environment.
```

Classification:

```text
aggregate timed out with focused groups passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Second compliance review verification

Focused commands rerun:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Result:

```text
All focused groups passed.
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Manual-test preparation verification

Commands run by assistant before writing manual local-test instructions:

```bash
python3 scripts/run_tests.py --static --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
--static: PASS
--source-run: PASS
--all: timed out in this container pass
```

Classification:

```text
focused groups passed; aggregate timed out in assistant/container environment
```

### Final gap-check verification

Commands rerun:

```bash
python3 scripts/run_tests.py --static --quiet
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --all --quiet
```

Result:

```text
--static: PASS
--structure: PASS
--native: PASS
--source-run: PASS
--web: PASS
--diagnostics: PASS
--protocol: PASS
--all: timed out in this final container pass
```

Classification:

```text
aggregate timed out in assistant/container environment, focused groups passed
```

Dependency skip:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

## 12. Pass/fail result summary

Phase 61B verification produced these classifications:

- Pre-implementation aggregate: aggregate timed out in assistant/container environment; focused groups passed.
- Implementation aggregate: aggregate timed out with focused groups passed.
- First compliance aggregate: aggregate timed out with focused groups passed.
- Second compliance aggregate: aggregate completed and passed.
- Final gap-check aggregate: aggregate timed out in assistant/container environment; focused groups passed.
- Focused groups: passed whenever run individually.
- Focused group failures: none.
- Focused group timeouts requiring subgroup/fixture rerun: none.
- Dependency skipped: Browser/Wasm rebuild smoke skipped because `emcc` is unavailable in this environment.

Important interpretation:

- The latest successful full aggregate completion observed in this session was during the second compliance review with `python3 scripts/run_tests.py --all --quiet`.
- The final gap-check aggregate attempt timed out in the hosted assistant/container environment; this is not treated as a project failure because focused groups passed individually afterward/in that pass.
- Do not claim the final aggregate pass for an attempt that timed out. The report distinguishes the completed aggregate pass from later timeout attempts.

## 13. Manual/browser testing guidance and expected outputs

Phase 61B is not website-testable with a MASM source program. It is documentation/static-check hardening only.

```text
program.asm is not applicable
```

### Browser testing

No browser MASM program is applicable.

Expected served-site behavior:

- Same as Phase 61 / Phase 61A for direct `jmp label`.
- No visible active-time watchdog controls.
- No new Simulator Messages.
- No new Program Console behavior.
- No new register/memory/diagnostic behavior.

### Windows CMD local testing

Required setup for minimum Phase 61B verification:

- Python available as `py -3` or `python`.

Required setup for broader focused regression verification:

- Visual Studio Developer Command Prompt or an equivalent C compiler environment.
- Node.js for web/diagnostic formatter tests.
- Emscripten/`emcc` is not required for Phase 61B. If unavailable, the runner may report Browser/Wasm rebuild smoke as skipped.

Minimum command from project root:

```cmd
py -3 scripts\run_tests.py --static --quiet
```

Expected output snippets:

```text
[static] START
[static] PASS
```

```text
static       PASS     runner/documentation consistency checks passed
```

```text
Selected test groups passed.
```

Acceptable dependency skip if Emscripten is not configured:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Recommended focused regression commands:

```cmd
py -3 scripts\run_tests.py --structure --quiet
py -3 scripts\run_tests.py --native --quiet
py -3 scripts\run_tests.py --source-run --quiet
py -3 scripts\run_tests.py --web --quiet
py -3 scripts\run_tests.py --diagnostics --quiet
py -3 scripts\run_tests.py --protocol --quiet
py -3 scripts\run_tests.py --static --quiet
```

Expected result for each command:

```text
[<group>] START
[<group>] PASS
Selected test groups passed.
```

Optional aggregate command:

```cmd
py -3 scripts\run_tests.py --all --quiet
```

Expected successful output snippets:

```text
[structure] PASS
[native] PASS
[source-run] PASS
[web] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
All implemented milestone tests passed.
```

If `--all` takes too long or times out locally, run the focused commands above and treat the focused results as the useful evidence, matching the project's decomposed-runner policy.

Regression signs:

- `--static` fails.
- Static checks complain about repository/runtime milestone mismatch.
- Documentation says or implies active-time watchdog behavior is implemented in Phase 61, Phase 61A, or Phase 61B.
- Documentation no longer says active-time watchdog behavior is future-owned by Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Runtime/source-run behavior phase is changed from Phase 61 to Phase 61B.
- Direct-JMP source-run tests fail.
- Any focused group reports `FAIL`.
- `emcc` missing is not a Phase 61B regression unless explicitly testing a Wasm rebuild.

## 14. Compliance review summary

First compliance review found two minor documentation wording issues:

- `docs/BUILDING_AND_DEVELOPMENT.md` still used “in this phase” in a current-status context.
- `docs/MILESTONE_HISTORY.md` used “in this phase” in the Phase 61B entry.

Fixes applied:

- Reworded `docs/BUILDING_AND_DEVELOPMENT.md` to use current-status wording for the Phase 59 instruction-count watchdog path.
- Reworded `docs/MILESTONE_HISTORY.md` to say that no runtime/source-run behavior changes were made by Phase 61B.

Compliance result:

- No scope violations found.
- No runtime/code behavior changes found.
- Focused verification passed.
- Aggregate attempt timed out in the assistant/container environment.
- `emcc` was unavailable, so Browser/Wasm rebuild smoke was skipped.

Verdict:

```text
complete
```

## 15. Re-review summary

Second compliance review found one additional test-hardening issue:

- Static negative-check coverage for active-time watchdog contradiction was narrower than ideal. It checked primary current-status pages but not all changed current-status docs.

Fix applied:

- Strengthened `scripts/run_tests.py` so Phase 61B active-time watchdog negative checks cover all changed current-status docs:
  - `README.md`
  - `docs/SUPPORTED_SYNTAX.md`
  - `docs/MILESTONE_HISTORY.md`
  - `docs/BUILDING_AND_DEVELOPMENT.md`

Re-review results:

- Focused groups passed.
- `python3 scripts/run_tests.py --all --quiet` completed and passed during this review.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

Final re-review verdict:

```text
complete
```

## 16. User-test follow-up summary

No Prompt 8 user-test discrepancy triage was performed.

The user did not report discrepancies from manual/browser/local testing before proceeding to the final gap check. Manual testing guidance remains local-test-only because Phase 61B is not exercised by a MASM source program.

## 17. Known limitations

- Phase 61B does not add active-time watchdog behavior; that remains Phase 200 future work.
- No browser-visible runtime behavior changes are expected.
- No manual browser verification was performed because no browser-visible runtime behavior changed.
- `emcc` is unavailable in the assistant/container environment, so Browser/Wasm rebuild smoke was skipped.
- Some aggregate `--all` attempts timed out in the hosted assistant/container environment even though focused groups passed. One `--all --quiet` run completed and passed during the second compliance review.
- Build outputs generated while running tests are local artifacts and are not part of the changed-files packages.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 61C - Branch Debugger Dependency Cleanup
```

Expected archive name after accepting this milestone:

```text
Latest_repository_state_milestone_61B.zip
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the Phase 61B session:

- `milestone_61B_changed_files.zip`
- `milestone_61B_first_compliance_check.zip`
- `milestone_61B_second_compliance_check.zip`

The final complete changed-files package is:

```text
milestone_61B_second_compliance_check.zip
```

It contains:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `scripts/run_tests.py`

No final compliance ZIP was produced because the final gap check did not change any project files.
