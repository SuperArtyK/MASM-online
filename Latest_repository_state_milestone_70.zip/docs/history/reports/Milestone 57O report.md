# Milestone 57O report - Explicit-Width NOP Encoding-Operand Forms

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57O - Explicit-Width NOP Encoding-Operand Forms
```

Repository/archive milestone after this work:

```text
Phase 57O - Explicit-Width NOP Encoding-Operand Forms
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 57O - Explicit-Width NOP Encoding-Operand Forms
```

Scope implemented:

- Corrected Phase 57O to match real MASM behavior verified by user testing against `ml.exe`.
- Preserved zero-operand `nop` behavior from the prior milestone.
- Added accepted NOP encoding operands for 16-bit and 32-bit register forms.
- Added accepted NOP encoding operands for explicit 16-bit and 32-bit memory-looking forms using unsigned and signed PTR spellings.
- Preserved IR-level no-op behavior for all accepted NOP forms.
- Ensured accepted NOP encoding operands do not read registers, write registers, evaluate effective memory addresses, read memory, write memory, perform planned memory access, or produce memory-change rows.
- Added MASM-compatible diagnostics for invalid byte-sized, missing-size, immediate, two-operand, and QWORD/SQWORD NOP forms.
- Updated canonical documentation, current-status documentation, supported syntax, tests, and rendered Simulator Messages expectations.

Accepted Phase 57O source forms include:

```asm
nop
nop ax
nop eax
nop WORD PTR [eax]
nop SWORD PTR [eax]
nop DWORD PTR [eax]
nop SDWORD PTR [eax]
```

Equivalent currently-supported 16-bit and 32-bit register operands and existing memory-address grammar forms are accepted as encoding operands. The accepted memory-looking operands remain encoding operands only and do not perform runtime memory access.

Rejected forms include:

```asm
nop al
nop ah
nop BYTE PTR [eax]
nop SBYTE PTR [eax]
nop QWORD PTR [eax]
nop SQWORD PTR [eax]
nop [eax]
nop 1
nop eax, ebx
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status and verification files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57N report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_57N.zip
```

Repository archive recommended after implementation:

```text
Latest_repository_state_milestone_57O.zip
```

A full latest repository archive was not produced during this milestone-report step. Changed-files packages were produced and are listed in Section 19.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, memory safety, and status-surface hygiene.
- The incremental implementation guide owns phase numbering, target milestone scope, per-phase implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- The audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only. They do not override the canonical spec, guide, selected target milestone, real MASM behavior verified during triage, or verified repository behavior.

## 3. Exact requirements implemented

### 3.1 Real MASM-compatible NOP operand classification

Phase 57O was corrected during user triage after real MASM checks showed the initial Phase 57O interpretation was too narrow in some places and too broad in one place.

Verified real MASM behavior used during triage:

- `nop eax` compiles.
- `nop ax` is treated as the 16-bit register encoding-operand family.
- `nop DWORD PTR [eax]` compiles.
- `nop WORD PTR [eax]` compiles.
- `nop SWORD PTR [eax]` compiles.
- `nop SDWORD PTR [eax]` compiles.
- `nop [eax]` fails with a missing-size style diagnostic.
- `nop BYTE PTR [eax]` fails with invalid operand size.
- `nop SBYTE PTR [eax]` fails with invalid operand size.
- `nop QWORD PTR [eax]` fails with invalid operand size.
- `nop SQWORD PTR [eax]` remains rejected in MASM32 Educational Mode.
- `nop 1` fails because an immediate operand is not allowed.
- `nop eax, ebx` fails because NOP accepts at most one operand.

Final implemented classification:

```text
Accepted:
- zero-operand nop
- 16-bit register encoding operands
- 32-bit register encoding operands
- WORD PTR memory-looking encoding operands
- SWORD PTR memory-looking encoding operands
- DWORD PTR memory-looking encoding operands
- SDWORD PTR memory-looking encoding operands

Rejected:
- 8-bit register operands
- BYTE PTR / SBYTE PTR memory-looking operands
- QWORD PTR / SQWORD PTR memory-looking operands
- missing-size memory-looking operands
- immediate operands
- two-operand forms
```

### 3.2 IR-level no-op semantics for every accepted form

All accepted Phase 57O forms lower to the existing `VM_IR_OPCODE_NOP` no-op instruction with no executable destination operand and no executable source operand.

Accepted register-form NOP operands:

- do not read the named register;
- do not write the named register;
- do not mutate aliases or canonical parent registers;
- do not mutate modeled flags;
- do not mutate flag-validity metadata;
- do not produce NOP-specific Simulator Messages;
- count as executed instructions.

Accepted memory-looking NOP encoding operands:

- do not evaluate an effective address at runtime;
- do not read memory;
- do not write memory;
- do not call checked memory helpers;
- do not perform planned-read or planned-write validation;
- do not trigger uninitialized-read diagnostics;
- do not trigger declared-object validation diagnostics;
- do not trigger section-capacity or section-image diagnostics;
- do not trigger `.CONST` or `.code` permission diagnostics;
- do not create memory-change rows;
- count as executed instructions.

### 3.3 Diagnostics implemented

User-visible diagnostics were refined to match the final MASM-compatible classification.

Byte-sized invalid NOP operands, such as `nop al`, `nop ah`, `nop BYTE PTR [eax]`, and `nop SBYTE PTR [eax]`, produce:

```text
invalid-operand-size: NOP encoding operand size is invalid. NOP has no 8-bit encoding-operand form. Did you mean to use the ordinary, zero-operand "NOP"?
```

QWORD/SQWORD invalid NOP operands, such as `nop QWORD PTR [eax]` and `nop SQWORD PTR [eax]`, produce:

```text
invalid-operand-size: NOP encoding operand size is invalid. QWORD/SQWORD are not supported in MASM32 Educational Mode. Use zero-operand "NOP", or a "NOP" with a 16-bit/32-bit register, or WORD/SWORD/DWORD/SDWORD PTR.
```

Missing-size memory-looking NOP operands, such as `nop [eax]`, produce:

```text
ambiguous-memory-width: NOP memory encoding operand must have an explicit size. Use zero-operand "NOP", or a "NOP" with a 16-bit/32-bit register, or WORD/SWORD/DWORD/SDWORD PTR.
```

Immediate NOP operands, such as `nop 1`, produce:

```text
invalid-instruction-operands: NOP does not accept an immediate operand. Use zero-operand "NOP", or a "NOP" with a 16-bit/32-bit register, or WORD/SWORD/DWORD/SDWORD PTR.
```

Two-operand forms, such as `nop eax, ebx`, produce:

```text
invalid-instruction-operands: NOP accepts at most one operand.
```

All invalid forms remain assembly errors and prevent execution. Exact rendered Simulator Messages tests cover the final diagnostic text.

### 3.4 Documentation and status-surface updates

The following status and documentation behavior was updated:

- Repository/archive milestone advanced to Phase 57O.
- Runtime/source-run MASM behavior phase advanced to Phase 57O because accepted source syntax changed.
- README current-status text was updated.
- Supported syntax documentation was updated.
- Milestone history was updated.
- Browser static status text was updated.
- Protocol/source-run status expectations were updated.
- The guide/spec Phase 57O sections were corrected during triage to reflect real MASM behavior.

### 3.5 Regression behavior preserved

The milestone preserved prior behavior:

- Zero-operand `nop`, `NOP`, and `NoP` still parse and execute.
- Ordinary memory-capable instructions still perform checked memory access.
- Real memory reads still trigger invalid-address, uninitialized-read, declared-object, section-capacity, section-image, `.CONST`, and `.code` diagnostics as appropriate.
- NOP was not added to planned memory-read collection.
- Program Console and Simulator Messages remain separate.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57O:

- Real x86 opcode byte emission.
- Opcode `90h` emission or byte-level encoding output.
- Multi-byte NOP byte generation.
- `.code` byte-image generation.
- Source-level `.code` memory image support.
- PE `.text` layout.
- Object files.
- Linker behavior.
- Relocation behavior.
- Disassembly.
- `ALIGN` or `EVEN` behavior.
- Raw byte emission into `.code`.
- Timing, cycle, pipeline, or CPU-family behavior.
- New browser UI controls.
- Future stack, procedure, branch, Irvine32 routine, macro, high-level-flow, or debugger behavior.
- Host include path diagnostics from Phase 57P.
- INCLUDELIB diagnostics from Phase 57Q.
- New memory-addressing grammar beyond forms already supported by the parser.
- Any actual runtime memory access for NOP operands.
- Any actual register access for NOP register operands.

Future work intentionally preserved:

- Future `.code` byte-image behavior, if a reviewed future phase ever adds it.
- Future memory-reading opcode planned-read updates for instructions that actually consume memory.
- Phase 57P - Host Include Path Diagnostics.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Accepted NOP encoding operands should lower to the existing zero-operand `VM_IR_OPCODE_NOP` IR path rather than adding executable operands to IR.
- **Reason:** Phase 57O models source-level MASM compatibility for NOP encoding operands while the simulator still does not emit real x86 bytes. The stable behavior requirement is no runtime register read and no runtime memory access.
- **Risk:** Future debugger/source-display features may want to preserve the encoding operand as non-executing source metadata.
- **How to change later:** Add separate non-executing source-operand metadata while preserving executable IR as no-op and adding tests proving no memory/register access occurs.

### Assumption 2

- **Assumption:** Signed 16-bit and 32-bit PTR spellings are valid Phase 57O encoding operands after the user verified real MASM accepts `SWORD PTR` and `SDWORD PTR` NOP forms.
- **Reason:** Signed PTR names resolve to valid 16-bit and 32-bit operand sizes, and real MASM accepts them for NOP encoding operands.
- **Risk:** A different MASM version or mode could differ, though the project targets MASM32 educational behavior and the user verified the relevant MASM behavior.
- **How to change later:** If a future MASM compatibility matrix distinguishes assembler versions or modes, add mode-specific diagnostics or compatibility notes.

### Assumption 3

- **Assumption:** Byte-sized register and memory-looking NOP operands should use the byte-specific invalid-size diagnostic rather than generic unsupported syntax.
- **Reason:** Real MASM rejects those forms as invalid operand size, and a teaching diagnostic should explain that NOP has no 8-bit encoding-operand form.
- **Risk:** The diagnostic wording is more educational than MASM's native terse text and may not match exact MASM phrasing.
- **How to change later:** If the project later introduces an exact-MASM-diagnostic mode, preserve this educational wording in default mode and add exact MASM text under that mode.

### Assumption 4

- **Assumption:** `nop [eax]` should use `ambiguous-memory-width` rather than `unsupported-syntax`.
- **Reason:** Real MASM reports that the operand must have a size. This matches the project's existing memory-width diagnostic model.
- **Risk:** Some users may see `ambiguous-memory-width` as a general memory-access error rather than an encoding-operand error.
- **How to change later:** Keep the diagnostic code but refine wording further if UX feedback requires clearer NOP-specific wording.

### Assumption 5

- **Assumption:** Runtime/source-run MASM behavior metadata should advance from Phase 57M/57N to Phase 57O.
- **Reason:** Phase 57O adds newly accepted source forms; it is not only documentation, maintenance, or diagnostic wording.
- **Risk:** A status surface could be missed and still report Phase 57M or Phase 57N.
- **How to change later:** Static/status tests should catch stale status text; update current-status surfaces if any are later found.

### Assumption 6

- **Assumption:** Browser/Wasm rebuild smoke can be reported as skipped when `emcc` is unavailable in the assistant/container environment.
- **Reason:** Emscripten is not installed in the execution environment used for this milestone.
- **Risk:** Served browser artifacts may be stale until rebuilt locally or in CI.
- **How to change later:** Rebuild with Emscripten locally or in CI and perform the manual browser verification programs listed in Section 13.

## 6. Relevant TODO-style notes reviewed

Target-owned TODO-style notes and TODO-style evidence reviewed:

- Phase 57O deferral notes in `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` and completed Phase 57N context.
- Phase 57N invalid NOP operand diagnostic wording in `src/parser/parser.c` that originally pointed to Phase 57O.
- `docs/SUPPORTED_SYNTAX.md` notes that previously described NOP operand-bearing forms as rejected until Phase 57O.
- Rendered diagnostic test expectations that previously described Phase 57O as future work for NOP operands.
- README/status wording that advanced repository/archive milestone but kept explicit-width NOP operands deferred before Phase 57O.

Future-owned TODO-style notes reviewed:

- Future `.code` byte-image behavior note in the full specification.
- Future memory-reading opcode planned-read TODO in `src/wasm/wasm_api.c`.

Broad TODO-style categories reviewed and excluded as irrelevant to Phase 57O:

- future QWORD/SQWORD execution outside NOP diagnostics;
- future Irvine32 routine notes;
- future stack/procedure/debugger work;
- future macro/high-level-flow notes;
- future branch/control-flow phase notes;
- static-check strings and test fixture text not relevant to Phase 57O;
- historical report text and generated artifacts excluded from source-note authority.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 57O deferral wording for explicit NOP operands was resolved in current documentation and diagnostics.
- Parser diagnostic wording no longer says supported Phase 57O forms are deferred.
- Supported syntax now documents Phase 57O accepted and rejected NOP operand forms.
- Rendered Simulator Messages tests now assert final Phase 57O diagnostics.
- README/current-status text now reflects Phase 57O.

### Future-owned TODO-style notes intentionally preserved

- Future `.code` byte-image behavior remains preserved.
- Future memory-reading opcode planned-read TODO remains preserved in `src/wasm/wasm_api.c`; NOP was not added to planned-read collection.

### Stale or contradicted TODO-style notes corrected

- Stale documentation phrases implying `BYTE PTR` NOP forms were accepted or deferred to Phase 57O were corrected.
- Stale wording omitting `SWORD PTR` and `SDWORD PTR` from accepted Phase 57O forms was corrected.
- Stale wording that implied signed 16/32-bit PTR aliases were invalid was corrected after real MASM verification.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 57O was implemented as a narrow parser/source-compatibility milestone. It adds accepted MASM source forms while intentionally preserving no-op runtime behavior.

Primary design choices:

1. **Reuse existing NOP IR behavior.** All accepted NOP forms lower to `VM_IR_OPCODE_NOP` with no executable operands.

2. **Classify operands in the parser only.** The parser recognizes accepted encoding-operand source syntax and rejects invalid forms with structured diagnostics.

3. **Do not model real x86 byte encoding.** Register and memory-looking operands are accepted for source compatibility only. They do not produce byte streams or instruction-length metadata.

4. **Do not evaluate encoding operands at runtime.** Accepted memory-looking forms do not compute effective addresses or trigger memory diagnostics, even when the apparent address is invalid, uninitialized, `.CONST`, or `.code`.

5. **Use targeted diagnostic codes.** Missing-size memory forms use `ambiguous-memory-width`; byte and QWORD/SQWORD forms use `invalid-operand-size`; immediate and two-operand forms use `invalid-instruction-operands`.

6. **Preserve existing memory safety for real memory operations.** NOP is the only instruction path affected. Real memory-capable instructions continue using checked VM memory helpers and planned access validation.

7. **Reflect verified MASM behavior.** The final implementation accepts `SWORD PTR` and `SDWORD PTR` after user verification showed real MASM accepts those forms.

## 9. Files changed

Files changed across implementation, reviews, user triage corrections, and final gap check:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

### Parser/native tests

Added or strengthened parser coverage for accepted forms:

- zero-operand `nop` remains accepted;
- `nop`, `NOP`, and `NoP` case-insensitive regressions remain accepted;
- all 16-bit register operands are accepted as encoding operands:
  - `ax`, `bx`, `cx`, `dx`, `si`, `di`, `bp`, `sp`;
- all 32-bit register operands are accepted as encoding operands:
  - `eax`, `ebx`, `ecx`, `edx`, `esi`, `edi`, `ebp`, `esp`;
- `WORD PTR` memory-looking operands are accepted;
- `SWORD PTR` memory-looking operands are accepted;
- `DWORD PTR` memory-looking operands are accepted;
- `SDWORD PTR` memory-looking operands are accepted;
- displacement and symbol-plus-register forms are accepted where existing grammar supports them.

Parser assertions verify accepted forms lower to `VM_IR_OPCODE_NOP` and do not create executable destination/source operands.

Added or strengthened parser rejection coverage for:

- `nop al`;
- `nop ah`;
- `nop BYTE PTR [eax]`;
- `nop SBYTE PTR [eax]`;
- `nop QWORD PTR [eax]`;
- `nop SQWORD PTR [eax]`;
- `nop [eax]`;
- `nop 1`;
- `nop eax, ebx`.

Expected diagnostic codes are asserted:

- `invalid-operand-size` for byte-sized and QWORD/SQWORD invalid sizes;
- `ambiguous-memory-width` for missing-size memory-looking operands;
- `invalid-instruction-operands` for immediates and two-operand forms.

### Source-run tests

Added or strengthened source-run coverage proving:

- `nop ax` succeeds and does not mutate `EAX`/`AX`;
- `nop eax` succeeds and does not mutate `EAX`;
- accepted register-form NOP operands preserve registers;
- `nop WORD PTR [eax]` succeeds even when `EAX = 0`;
- `nop SWORD PTR [eax]` succeeds even when `EAX = 0`;
- `nop DWORD PTR [eax]` succeeds even when `EAX = 0`;
- `nop SDWORD PTR [eax]` succeeds even when `EAX = 0`;
- accepted memory-looking NOP operands do not emit invalid-address diagnostics;
- accepted memory-looking NOP operands do not emit `.CONST` permission diagnostics;
- accepted memory-looking NOP operands do not emit `.code` access diagnostics;
- accepted memory-looking NOP operands do not emit uninitialized-read diagnostics;
- accepted memory-looking NOP operands do not produce memory-change rows;
- invalid NOP forms prevent execution and omit `execution-complete`.

### Rendered Simulator Messages tests

Added or updated exact rendered-message tests for:

- `nop al`;
- `nop ah`;
- `nop BYTE PTR [eax]`;
- `nop SBYTE PTR [eax]`;
- `nop QWORD PTR [eax]`;
- `nop SQWORD PTR [eax]`;
- `nop [eax]`;
- `nop 1`;
- `nop eax, ebx`.

Exact expected messages were updated to the final wording specified during user triage.

### Static/status/protocol tests

Updated status/protocol/static checks to recognize:

- repository/archive milestone Phase 57O;
- runtime/source-run MASM behavior phase Phase 57O;
- corrected supported syntax including 16/32-bit registers and `WORD/SWORD/DWORD/SDWORD PTR`;
- absence of stale current-status wording claiming Phase 57O support still excludes signed 16/32-bit PTR aliases or accepts byte PTR forms.

## 11. Commands used to test

### Aggregate command

```bash
cd /mnt/data/repo_57N_verify
python3 scripts/run_tests.py --all
```

Observed result:

```text
Timed out in the assistant/container environment before returning final aggregate success status.
```

No aggregate-pass claim is made.

### Focused group commands

The following focused groups were run repeatedly during implementation, compliance review, user triage fixes, and final gap check:

```bash
cd /mnt/data/repo_57N_verify
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Observed focused results:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Subgroup or fixture-family commands

No subgroup or individual fixture-family commands were required. No individual focused group failed. No individual focused group required subgroup decomposition.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is a dependency skip, not a test failure. Browser-served testing requires rebuilding Wasm in an environment with Emscripten.

## 12. Pass/fail results

Final result classification:

```text
aggregate timed out in assistant/container environment, focused groups passed
```

Detailed classification:

- Aggregate command was attempted.
- Aggregate did not complete in the assistant/container environment before timeout.
- The aggregate suite is therefore not claimed as completed or passed.
- Focused groups completed and passed:
  - `--structure`
  - `--native`
  - `--source-run`
  - `--web`
  - `--diagnostics`
  - `--protocol`
  - `--static`
- No focused group failed.
- No focused group timed out.
- No focused group required subgroup or fixture-family rerun.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

## 13. Manual/browser testing guidance and expected outputs

Phase 57O is website-testable after rebuilding Wasm with Emscripten.

### Browser setup on Windows CMD

From the repository root:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open:

```text
http://localhost:8000
```

If `emcc` is unavailable, browser rebuild is expected to fail or be skipped. In that case, use local focused test commands.

### Program 1 - accepted register-form NOP operands

```asm
.code
main PROC
    mov eax, 0FFFFFFFFh
    nop ax
    nop eax
    mov ebx, 42
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key registers:

```text
EAX = FFFFFFFFh / u:4294967295 / s:-1
EBX = 0000002Ah / u:42 / s:42
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `nop ax` or `nop eax` is rejected.
- `EAX` changes from `FFFFFFFFh`.
- Program Console has output.
- Memory changes are reported.

### Program 2 - accepted WORD/SWORD/DWORD/SDWORD PTR NOP operands do not access memory

```asm
.code
main PROC
    mov eax, 0
    nop WORD PTR [eax]
    nop SWORD PTR [eax]
    nop DWORD PTR [eax]
    nop SDWORD PTR [eax]
    mov ebx, 42
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key registers:

```text
EAX = 00000000h / u:0 / s:0
EBX = 0000002Ah / u:42 / s:42
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- Invalid-memory diagnostic appears for `[eax]`.
- Any accepted `WORD/SWORD/DWORD/SDWORD PTR` form is rejected.
- `EBX` is not `42`.

### Program 3 - accepted `.CONST` address does not trigger permission diagnostics

```asm
.CONST
limit DWORD 10

.code
main PROC
    mov eax, OFFSET limit
    nop SDWORD PTR [eax]
    mov ebx, limit
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key registers:

```text
EAX = 00600000h / u:6291456 / s:6291456
EBX = 0000000Ah / u:10 / s:10
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `.CONST` permission diagnostic appears because of `nop SDWORD PTR [eax]`.
- `EBX` is not `10`.
- Memory changes are reported.

### Program 4 - accepted `.DATA?` address does not trigger uninitialized-read

```asm
.DATA?
buf DWORD ?

.code
main PROC
    mov eax, OFFSET buf
    nop DWORD PTR [eax]
    mov ebx, 7
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key registers:

```text
EAX = 00500000h / u:5242880 / s:5242880
EBX = 00000007h / u:7 / s:7
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- `uninitialized-read` appears because of `nop DWORD PTR [eax]`.
- Declared-object, section-capacity, or section-image diagnostics appear because of NOP.
- `EBX` is not `7`.

### Program 5 - reject missing-size memory operand

```asm
.code
main PROC
    nop [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] ambiguous-memory-width line 3, column 9, byte offset 24, span length 1: NOP memory encoding operand must have an explicit size. Use zero-operand "NOP", or a "NOP" with a 16-bit/32-bit register, or WORD/SWORD/DWORD/SDWORD PTR.
```

Expected Program Console:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

Regression signs:

- Program executes successfully.
- Diagnostic is `unsupported-syntax` instead of `ambiguous-memory-width`.
- `execution-complete` appears.

### Program 6 - reject byte-sized NOP operands

```asm
.code
main PROC
    nop al
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-operand-size line 3, column 9, byte offset 24, span length 2: NOP encoding operand size is invalid. NOP has no 8-bit encoding-operand form. Did you mean to use the ordinary, zero-operand "NOP"?
```

Also test:

```asm
.code
main PROC
    nop BYTE PTR [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-operand-size line 3, column 9, byte offset 24, span length 4: NOP encoding operand size is invalid. NOP has no 8-bit encoding-operand form. Did you mean to use the ordinary, zero-operand "NOP"?
```

Regression signs:

- `nop al` or `nop BYTE PTR [eax]` executes.
- Diagnostic is generic unsupported syntax.
- `execution-complete` appears.

### Program 7 - reject QWORD/SQWORD NOP operands

```asm
.code
main PROC
    nop QWORD PTR [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-operand-size line 3, column 9, byte offset 24, span length 5: NOP encoding operand size is invalid. QWORD/SQWORD are not supported in MASM32 Educational Mode. Use zero-operand "NOP", or a "NOP" with a 16-bit/32-bit register, or WORD/SWORD/DWORD/SDWORD PTR.
```

Also test:

```asm
.code
main PROC
    nop SQWORD PTR [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-operand-size line 3, column 9, byte offset 24, span length 6: NOP encoding operand size is invalid. QWORD/SQWORD are not supported in MASM32 Educational Mode. Use zero-operand "NOP", or a "NOP" with a 16-bit/32-bit register, or WORD/SWORD/DWORD/SDWORD PTR.
```

Regression signs:

- QWORD/SQWORD form executes.
- Diagnostic does not mention QWORD/SQWORD unsupported in MASM32 Educational Mode.
- `execution-complete` appears.

### Program 8 - reject immediate and two-operand forms

Immediate form:

```asm
.code
main PROC
    nop 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 3, column 9, byte offset 24, span length 1: NOP does not accept an immediate operand. Use zero-operand "NOP", or a "NOP" with a 16-bit/32-bit register, or WORD/SWORD/DWORD/SDWORD PTR.
```

Two-operand form:

```asm
.code
main PROC
    nop eax, ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-instruction-operands line 3, column 12, byte offset 27, span length 1: NOP accepts at most one operand.
```

Regression signs:

- Either invalid program executes.
- Diagnostic is generic unsupported syntax.
- `execution-complete` appears.

### Windows CMD local focused tests

From the repository root:

```cmd
python3 scripts\run_tests.py --native
python3 scripts\run_tests.py --source-run
python3 scripts\run_tests.py --web
python3 scripts\run_tests.py --diagnostics
python3 scripts\run_tests.py --protocol
python3 scripts\run_tests.py --static
python3 scripts\run_tests.py --structure
```

Expected for each selected group:

```text
PASS
Selected test groups passed.
```

Optional aggregate:

```cmd
python3 scripts\run_tests.py --all
```

Expected on a local machine with enough time:

```text
All implemented milestone tests passed.
```

If `emcc` is unavailable, this skip is expected:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

## 14. Compliance review summary

First compliance review found one scope-control gap in the initial implementation:

- Signed PTR aliases were initially accepted or rejected inconsistently relative to the then-current interpretation.
- The first correction narrowed NOP accepted forms too much by rejecting signed 16/32-bit PTR spellings.

Follow-up user testing with real MASM corrected that interpretation:

- `SWORD PTR` and `SDWORD PTR` are valid and should be accepted.
- Byte-sized and QWORD/SQWORD forms remain invalid.

The final implementation reflects the corrected MASM-compatible behavior.

Compliance checks verified:

- Scope remains limited to Phase 57O.
- No future byte-emission or `.code` image behavior was added.
- Core remains C99-oriented.
- New diagnostics are structured and rendered through Simulator Messages.
- Program Console remains separate.
- Focused tests pass.

## 15. Re-review summary

Second review and final gap check found documentation/status wording issues, then corrected them:

- Stale `Phase 57M` runtime/source-run status wording was corrected to Phase 57O.
- Stale wording implying `BYTE PTR` NOP forms were accepted or deferred was corrected.
- Supported syntax summary was updated to include `SWORD PTR` and `SDWORD PTR`.
- Phase 57N historical/current transition wording was clarified where needed without rewriting historical evidence incorrectly.

No remaining implementation gaps were found.

## 16. User-test follow-up summary

User testing with real MASM materially improved the milestone:

- The user verified `nop [eax]` is invalid and MASM reports that the operand must have a size.
- The user verified `nop DWORD PTR [eax]` compiles.
- The user verified `nop eax` compiles.
- The user verified `nop 1` is rejected as immediate operand not allowed.
- The user verified `nop eax, ebx` is rejected.
- The user verified `nop QWORD PTR [eax]` is rejected as invalid operand size.
- The user verified `nop BYTE PTR [eax]` and `nop SBYTE PTR [eax]` are rejected as invalid operand size.
- The user later verified `nop SWORD PTR [eax]` and `nop SDWORD PTR [eax]` compile.

Corrections made from that follow-up:

- accepted `nop ax`/`nop eax` and all 16/32-bit register forms;
- accepted `SWORD PTR` and `SDWORD PTR` memory-looking forms;
- rejected byte-sized NOP forms;
- refined missing-size, invalid-size, immediate, and two-operand diagnostics;
- updated tests and docs accordingly.

The user then ran manual tests and reported that all worked before the final diagnostic wording and signed-PTR refinements were completed. The final manual test guidance in Section 13 reflects the finished behavior.

## 17. Known limitations

- The aggregate `--all` command timed out in the assistant/container environment, so aggregate completion is not claimed.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.
- Browser-served validation requires rebuilding Wasm locally or in CI with Emscripten.
- No real x86 instruction bytes are emitted.
- No instruction-length display exists.
- No `.code` byte image exists.
- NOP encoding operands are source-level compatibility syntax only.
- Exact MASM native diagnostic text is not copied verbatim; the simulator uses educational diagnostic wording.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57P - Host Include Path Diagnostics
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

- `milestone_57O_changed_files.zip`
- `milestone_57O_compliance_changed_files.zip`
- `milestone_57O_second_review_changed_files.zip`
- `milestone_57O_docs_triage_task1_changed_files.zip`
- `milestone_57O_impl_triage_task2_changed_files.zip`
- `milestone_57O_tests_triage_task3_changed_files.zip`
- `milestone_57O_signed_ptr_correction_changed_files.zip`
- `milestone_57O_diagnostic_wording_update_changed_files.zip`
- `milestone_57O_final_gap_changed_files.zip`

Recommended final changed-files package:

```text
milestone_57O_final_gap_changed_files.zip
```

This package preserves repository structure and contains the final changed files after implementation, reviews, user triage corrections, and final gap check.

