# Milestone 69C report

## 1. Milestone title and scope

Milestone: `69C`

Title: **Phase 69C - Wasm Output-Contract Compatibility and Test Runner Decomposition**

Scope completed in this milestone:

- Added a separate source-run output-contract identifier so the browser/UI can detect stale or missing browser/Wasm output-contract artifacts without advancing the runtime/source-run MASM behavior phase.
- Preserved the runtime/source-run MASM behavior phase as **Phase 69 - Direct CALL to User Procedures**.
- Kept the existing broad focused test-runner groups as the supported timeout-safe decomposition.
- Updated active status documentation and the web page status text to identify repository/archive status as Phase 69C while preserving runtime behavior Phase 69.
- Added C, protocol, rendered-message, and static coverage for the output-contract metadata and stale-artifact warning path.

Phase 69C is an artifact/protocol/test-infrastructure cleanup milestone only. It is not a MASM syntax milestone, parser milestone, VM semantics milestone, Program Console milestone, register/memory milestone, or source-level diagnostic milestone.

## 2. Source-of-truth files used

Canonical active source-of-truth files:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`

Supporting status, build, testing, and history files reviewed or updated:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/TESTING_GUIDE.md`
- `docs/history/reports/Milestone 69B report.md`
- `web/index.html`
- `scripts/run_tests.py`

Archive/source evidence used at the start of the milestone:

- `Latest_repository_state_milestone_69B.zip`

Audit/handoff note:

- `docs/history/PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_69B.md` was requested by the prompt sequence but was not present in the inspected archive.
- Older audit/handoff reports were present for earlier milestones only and were treated as historical navigation, not active source of truth.

## 3. Exact requirements implemented

Implemented requirements from the Phase 69C guide section:

1. **Preserve runtime/source-run behavior metadata.**
   - `phase` remains `69`.
   - `phaseSuffix` remains the empty string.
   - `phaseName` remains `Phase 69 - Direct CALL to User Procedures`.
   - Runtime/source-run MASM behavior was not advanced to 69C.

2. **Add a separate output-contract identifier.**
   - Added C source-run JSON field:
     - `sourceRunOutputContract`
   - Added contract value:
     - `phase-69c-source-run-output-contract-v1`
   - The field is separate from runtime/source-run phase metadata.

3. **Detect stale browser/Wasm output-contract artifacts separately from stale runtime phase artifacts.**
   - Browser protocol logic now checks the source-run output contract independently.
   - Missing, non-string, or mismatched output-contract metadata produces a distinct warning.
   - Stale runtime phase metadata and stale output-contract metadata are reported as separate artifact-status conditions.

4. **Render user-visible stale-output-contract artifact warning.**
   - Added rendered Simulator Messages coverage for:
     - `stale-wasm-output-contract`
   - The warning text explains that the loaded Wasm artifact does not report the Phase 69C source-run output-contract identifier and instructs rebuilding `web/dist` with the Emscripten build script.

5. **Keep existing decomposed runner groups valid.**
   - Preserved these broad focused flags:
     - `--structure`
     - `--native`
     - `--source-run`
     - `--web`
     - `--diagnostics`
     - `--protocol`
     - `--static`
     - `--all`
   - Did not add subgroup flags because all existing focused groups passed independently and the guide allowed subgroup work to remain future guidance unless needed and exposed by `--help`.
   - Updated runner help and static checks so stale subgroup wording does not reappear.

6. **Update active docs and status text.**
   - Updated repository/archive status to Phase 69C.
   - Added or clarified artifact/test-infrastructure cleanup status.
   - Preserved Phase 69 as the current runtime/source-run MASM behavior phase.
   - Preserved Phase 70 as the next runtime implementation milestone.

7. **Update web status display.**
   - Corrected `web/index.html` after user testing so the top-page status is concise:
     - `Milestone 69C: Wasm Output-Contract Compatibility and Test Runner Decomposition.`
   - Added a static check to prevent the long old `Repository status:` paragraph from returning.

8. **Add required test coverage.**
   - Added C source-run JSON assertions.
   - Added protocol success/error/edge-case tests.
   - Added rendered Simulator Messages test coverage.
   - Added static documentation/runner/status consistency checks.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 69C:

- `RET` execution.
- Root `RET` behavior.
- `RET imm16`.
- `LEAVE`.
- Source-level `PUSH` or `POP`.
- Stack frames.
- Active call frame tracking.
- Call-depth diagnostics.
- Procedure frame teardown.
- `PROC USES`.
- `LOCAL`.
- `PROTO`.
- `INVOKE`.
- `ADDR`.
- Irvine32 callable routine dispatch beyond already-completed behavior.
- New CALL target forms.
- New MASM syntax acceptance or rejection behavior.
- Parser behavior changes.
- VM instruction semantic changes.
- Register semantic changes.
- Memory semantic changes.
- Memory-change row semantic changes.
- Program Console output changes.
- Source-level diagnostic code, severity, line, column, byte-offset, or span changes.
- Browser/Wasm rebuild output generation in this environment, because `emcc` was unavailable.

Phase 70 remains the next recommended runtime implementation milestone: **Phase 70 - RET Execution and Return Address Validation**.

## 5. Assumptions used

- Assumption: Phase 69C should use the preferred separate output-contract identifier strategy rather than relying only on milestone reports or release checklist text.
  - Reason: The guide explicitly identified a blind spot where output-only C/Wasm-facing changes could be missed if runtime/source-run behavior phase metadata remained unchanged.
  - Risk: A new protocol-visible JSON field adds a small compatibility surface that must remain documented and tested.
  - How to change later: A later infrastructure phase can rename or migrate the field only by updating C source-run output, browser protocol handling, rendered-message tests, docs, and static checks together.

- Assumption: The output-contract identifier should be a separate string field named `sourceRunOutputContract` rather than a suffix on the runtime phase fields.
  - Reason: Runtime phase fields describe MASM behavior and VM semantics. Phase 69C is not a runtime behavior phase.
  - Risk: Maintainers could accidentally treat artifact compatibility as runtime behavior if docs/tests are not explicit.
  - How to change later: Add a compatibility migration that accepts both old and new names temporarily, then retire the old name in a later maintenance milestone.

- Assumption: Existing broad focused runner groups are sufficient for Phase 69C.
  - Reason: The aggregate command timed out in the assistant/container environment, but every documented focused group passed independently.
  - Risk: Future growth of `--native`, `--diagnostics`, or `--all` may make more granular subgroup flags necessary.
  - How to change later: Add subgroup flags as real `scripts/run_tests.py --help` entries, document them, and preserve all existing broad flags.

- Assumption: Browser-visible stale output-contract warnings are artifact-status messages, not MASM source diagnostics.
  - Reason: The warning is about stale or mismatched browser/Wasm artifacts, not source-program validity.
  - Risk: Users might confuse an artifact warning with a MASM diagnostic if the text is not explicit.
  - How to change later: Keep artifact warnings clearly named and documented separately from source diagnostics, and keep rendered-message tests for exact wording.

- Assumption: `web/dist` should not be regenerated in this assistant/container environment.
  - Reason: `emcc` was unavailable.
  - Risk: Served browser runs using stale Phase 69B Wasm artifacts will show `stale-wasm-output-contract` until `web/dist` is rebuilt externally.
  - How to change later: Run the Emscripten build script in a configured Emscripten environment and then rerun browser smoke verification.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and milestone-status notes reviewed during planning and compliance:

- Location: `docs/BUILDING_AND_DEVELOPMENT.md`, current-status section.
  - Note text or summary: Listed Phase 69C as the next repository/archive corrective milestone.
  - Classification: target-owned.
  - Reason: Directly named `TARGET_MILESTONE`.
  - Action: Resolved by updating the document to identify Phase 69C as the current artifact/test-infrastructure cleanup milestone and preserving Phase 70 as the next runtime milestone.

- Location: `docs/MILESTONE_HISTORY.md`, current-status section.
  - Note text or summary: Stated that Phase 69C was inserted after Phase 69B and before Phase 70 as artifact/test-infrastructure cleanup.
  - Classification: target-owned.
  - Reason: Directly described the target phase and its non-runtime scope.
  - Action: Resolved by updating milestone history/current status to reflect Phase 69C completion.

- Location: `docs/TESTING_GUIDE.md` around the runner decomposition guidance.
  - Note text or summary: Phase 69C might add smaller runner subgroups for timeout-safe verification.
  - Classification: target-owned.
  - Reason: The target milestone required evaluating test-runner decomposition.
  - Action: Resolved by documenting that Phase 69C keeps broad focused groups as the supported decomposition and does not add subgroup flags. Static checks and runner help now match that decision.

- Location: `src/wasm/wasm_api.c`, future memory-reading opcode TODO.
  - Note text or summary: Future instruction milestones should add future memory-reading opcodes when those opcodes are implemented.
  - Classification: future-owned.
  - Reason: Phase 69C does not implement instruction semantics or memory-reading opcodes.
  - Action: Preserved unchanged.

- Location: `scripts/run_tests.py --help`, stale wording discovered during second compliance review.
  - Note text or summary: Help text still said source-run and diagnostic subgroups were not split in Phase 56A.
  - Classification: stale-or-contradicted.
  - Reason: Current Phase 69C guidance superseded that wording.
  - Action: Corrected during the second compliance pass and guarded by static checks.

No new TODO-style notes were added.

## 7. TODO-style note disposition

Target-owned TODO-style notes resolved:

- Phase 69C status/navigation note in `docs/BUILDING_AND_DEVELOPMENT.md`.
- Phase 69C status/navigation note in `docs/MILESTONE_HISTORY.md`.
- Phase 69C runner-decomposition guidance in `docs/TESTING_GUIDE.md`.

Future-owned TODO-style notes intentionally preserved:

- Future memory-reading opcode TODO in `src/wasm/wasm_api.c`.
- Future runtime features documented as deferred, including `RET`, root procedure termination, source-level stack instructions, procedure frames, `LOCAL`, `USES`, `PROTO`, `INVOKE`, `ADDR`, and Irvine32 callable routine dispatch.

Stale or contradicted TODO-style notes corrected:

- Stale Phase 56A runner-help wording was corrected during the second compliance pass.
- A static regression guard now rejects the stale Phase 56A subgroup-help wording.

Unresolved TODO-related risks:

- None blocking.

## 8. Design summary

Phase 69C separates runtime behavior compatibility from output-contract/artifact compatibility.

The C source-run JSON path now emits:

```json
"sourceRunOutputContract": "phase-69c-source-run-output-contract-v1"
```

The browser protocol expects that exact value. If the field is absent, non-string, or mismatched, the protocol adds a distinct artifact-status warning:

```text
stale-wasm-output-contract
```

This check is separate from existing runtime phase checks. A Wasm artifact can therefore be:

- runtime-compatible and output-contract-compatible;
- runtime-compatible but output-contract-stale;
- runtime-stale but output-contract-compatible;
- stale in both ways.

The warning is routed to Simulator Messages. It is not Program Console output and is not a MASM source diagnostic. It does not affect source acceptance, source rejection, VM execution, register values, memory values, memory-change rows, source line/column/byte-offset/span metadata, or runtime/source-run behavior phase metadata.

The test runner design decision was conservative. Phase 69C did not add subgroup flags because the existing broad focused groups were sufficient and already passed independently. Runner help and docs now explicitly say that no subgroup flags were added in Phase 69C and that documentation must not list future subgroup flags until the runner exposes them.

## 9. Files changed

Files changed during implementation and compliance passes:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `scripts/run_tests.py`
- `src/wasm/wasm_api.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

Compliance-pass-only changes:

- First compliance pass:
  - `tests/web/test_protocol.mjs`
- Second compliance pass:
  - `scripts/run_tests.py`
- User-test follow-up HTML status fix:
  - `web/index.html`
  - `scripts/run_tests.py`

No files were changed during the final gap-check pass.

## 10. Tests added

C/source-run tests:

- Assert source-run JSON includes `sourceRunOutputContract`.
- Assert invalid-setting JSON paths include the output-contract metadata where protocol-visible.
- Assert runtime/source-run metadata remains Phase 69.

Protocol tests:

- Matching runtime metadata and matching output-contract metadata.
- Missing output-contract metadata.
- Stale output-contract metadata.
- Non-string output-contract metadata treated as missing/stale.
- Non-array `simulatorMessages` handled safely.
- Non-object runtime results left unchanged.
- Stale runtime metadata plus stale output-contract metadata reported distinctly.

Rendered-message tests:

- Rendered Simulator Messages coverage for `stale-wasm-output-contract`.

Static tests:

- Active docs and web status identify repository/archive status as Phase 69C.
- Runtime/source-run behavior phase remains Phase 69.
- Output-contract identifier is documented.
- Protocol/rendered-message coverage for stale output-contract exists.
- Runner help reflects Phase 69C broad-group decomposition.
- Stale Phase 56A subgroup-help wording is rejected.
- The long `Repository status:` paragraph in `web/index.html` is rejected so the concise top-page status remains in the requested form.

## 11. Commands used to test

Aggregate command attempted:

```sh
python3 scripts/run_tests.py --all
```

Focused commands run:

```sh
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Additional targeted reruns during compliance and user-test follow-up:

```sh
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --static
```

Subgroup or fixture-family commands:

- None. Phase 69C did not add subgroup flags.
- Existing broad focused groups remain the supported decomposition.

Skipped dependency checks:

- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.
- `web/dist` was not rebuilt by the assistant for the same reason.

## 12. Pass/fail results

Aggregate result:

- `python3 scripts/run_tests.py --all`
  - Result: timed out in the assistant/container environment.
  - Classification: aggregate timed out but focused groups passed.
  - No final aggregate success status was claimed.

Focused group results:

- `python3 scripts/run_tests.py --structure`
  - Result: PASS.
  - Classification: focused group passed.

- `python3 scripts/run_tests.py --native`
  - Result: PASS.
  - Classification: focused group passed.

- `python3 scripts/run_tests.py --source-run`
  - Result: PASS.
  - Classification: focused group passed.

- `python3 scripts/run_tests.py --web`
  - Result: PASS.
  - Classification: focused group passed.

- `python3 scripts/run_tests.py --diagnostics`
  - Result: PASS.
  - Classification: focused group passed.

- `python3 scripts/run_tests.py --protocol`
  - Result: PASS.
  - Classification: focused group passed.

- `python3 scripts/run_tests.py --static`
  - Result: PASS.
  - Classification: focused group passed.

Dependency skip result:

- Browser/Wasm rebuild smoke:
  - Result: SKIP.
  - Classification: group skipped because a dependency was unavailable.
  - Reason: `emcc` unavailable.

No focused group failed.

No focused group timeout required subgroup or fixture-family reruns.

## 13. Manual/browser testing guidance and expected outputs

Phase 69C is partly website-testable and partly local-test-only.

### Browser testing

Browser testing is useful for the stale-artifact warning path. It is not a MASM source-semantics feature.

Run the site on Windows CMD:

```cmd
scripts\windows\serve_web.cmd
```

Open:

```text
http://localhost:8000
```

Paste this smoke program, or use the default page-load program if equivalent:

```asm
.stack 4096
.data
value DWORD 7
.code
main PROC
    call Helper       ; Writes pseudo-EIP return token at ESP - 4
    mov eax, value    ; Not reached until RET exists in a later phase
main ENDP

Helper PROC
    mov ebx, value
Helper ENDP
END main
```

Expected when `web/dist` still contains an old Phase 69B Wasm artifact:

```text
[internal-simulator-error] stale-wasm-output-contract: The loaded Wasm artifact does not report the Phase 69C source-run output-contract identifier required by the current UI/source files. Rebuild web/dist with the Emscripten build script.
```

Expected Program Console:

```text

```

It should be empty.

Expected final registers for the smoke program:

```text
EAX = 00000000h
EBX = 00000007h
ECX = 00000000h
EDX = 00000000h
ESI = 00000000h
EDI = 00000000h
EBP = 00000000h
ESP = 008FFFFCh
EIP = 00401008h
EFLAGS = 00000000h
```

Expected memory changes:

```text
None
```

After a successful Emscripten rebuild, the same smoke run should not show `stale-wasm-output-contract`.

Rebuild command on Windows CMD when Emscripten is available:

```cmd
scripts\windows\build_wasm.cmd
```

Expected success line:

```text
Built "<repo>\web\dist\masm32_sim_core.js".
```

If `emcc` is unavailable, expected failure text:

```text
ERROR: emcc was not found.
Set EMSDK_ROOT to the emsdk directory or run this from an Emscripten command prompt.
```

That `emcc` failure is not a Phase 69C project failure; it only prevents browser no-warning verification until Emscripten is configured.

Stop the server:

```cmd
scripts\windows\stop_web.cmd
```

### Windows CMD local testing

`program.asm` is not applicable for local Phase 69C acceptance. The milestone is validated by runner/protocol/source-run/static tests rather than by a manually supplied MASM source file.

Recommended Windows CMD commands:

```cmd
py scripts\run_tests.py --protocol
py scripts\run_tests.py --web
py scripts\run_tests.py --static
py scripts\run_tests.py --structure
py scripts\run_tests.py --native
py scripts\run_tests.py --source-run
py scripts\run_tests.py --diagnostics
```

Expected snippets:

```text
[protocol] START
[protocol] PASS - protocol tests passed independently
```

```text
[web] START
[web] PASS - browser-side Node module tests passed
```

```text
[static] START
[static] PASS - runner/documentation consistency checks passed
```

```text
[source-run] START
[source-run] PASS - source-run integration binary passed independently
```

```text
[diagnostics] START
[diagnostics] PASS - native diagnostic producer and rendered messages passed
```

```text
[native] START
[native] PASS - native C non-source-run tests passed
```

```text
[structure] START
[structure] PASS - repository structure and metadata checks passed
```

Regression signs:

- Any `FAIL` line.
- Any `Traceback`.
- Any `AssertionError`.
- Missing `sourceRunOutputContract` in source-run JSON.
- Runtime phase changing away from Phase 69.
- `stale-wasm-output-contract` missing when testing old/unrebuilt `web/dist`.
- `stale-wasm-output-contract` still appearing after a successful Emscripten rebuild.
- `RET` execution or other Phase 70 behavior appearing.
- Program Console output changes for the smoke program.
- Final registers differing from the expected smoke-program values.

## 14. Compliance review summary

First compliance review:

- Found one test-coverage gap.
- Added protocol edge-case tests for:
  - non-string output-contract metadata;
  - non-array `simulatorMessages`;
  - non-object runtime results.
- Reran focused tests.
- Result: focused groups passed; aggregate timed out; `emcc` unavailable.

Second compliance review:

- Found stale runner-help wording referring to Phase 56A.
- Updated runner help to Phase 69C wording.
- Added static guard against the stale Phase 56A wording.
- Reran focused tests.
- Result: focused groups passed; aggregate timed out; `emcc` unavailable.

Final gap check:

- No additional missing work found.
- No files changed.
- Reconfirmed Phase 69C scope, docs, tests, TODO disposition, archive recommendation, and web status text.

## 15. Re-review summary

The second review re-read the target milestone section, relevant spec guidance, changed source files, changed docs, tests, and TODO-style notes. It confirmed:

- Phase 69C stayed in scope.
- Runtime/source-run behavior remains Phase 69.
- No future runtime features were added.
- Docs do not promise future behavior.
- User-visible warning text is exact and covered by rendered-message tests.
- Active runner help and docs agree on broad focused groups and absence of subgroup flags.
- Future-owned TODO notes remain scoped to future runtime work.

The one stale documentation/help issue found during re-review was corrected.

## 16. User-test follow-up summary

User reported a regression in `web/index.html`:

- The top page showed `Repository status:` followed by a long description.
- The desired format was a concise line:
  - `Milestone <# and prefix if given>: <brief description or copied guide name>`

Fix applied:

- Updated top-page status to:

```text
Milestone 69C: Wasm Output-Contract Compatibility and Test Runner Decomposition.
```

- Added a static check to prevent the long `Repository status:` paragraph from returning.

Tests rerun after the fix:

```sh
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
```

Results:

- `--static`: PASS.
- `--web`: PASS.
- `--protocol`: PASS.
- Browser/Wasm rebuild smoke skipped because `emcc` unavailable.

Package produced for this follow-up:

- `milestone_69C_html_status_fix.zip`

## Post-report artifact-status correction

A post-report audit of the current Phase 69C repository archive found that the checked-in `web/dist/masm32_sim_core.wasm` artifact contains the Phase 69C output-contract evidence:

```text
sourceRunOutputContract
phase-69c-source-run-output-contract-v1
```

This corrects the artifact-status interpretation for the current archive only. The assistant/container environment still could not run an Emscripten rebuild because `emcc` was unavailable, so rebuild reproducibility was not independently verified in that environment.

Use the following distinction for future audits:

- `emcc` unavailable means the assistant could not rebuild `web/dist` locally.
- A checked-in Wasm artifact containing the current output-contract string is evidence that the archive's artifact content is not obviously stale for that contract.
- A checked-in artifact-content check is not the same as a successful Emscripten rebuild.
- Browser/Wasm smoke without `stale-wasm-output-contract` is still the best served-artifact verification when a browser/Wasm test environment is available.

Future reports must not state that `web/dist` is stale solely because `emcc` is unavailable. They must separately report local rebuild status, checked-in artifact-content status, and browser/Wasm smoke status.

## 17. Known limitations

- `web/dist/masm32_sim_core.js` and `.wasm` were not rebuilt in the assistant/container environment.
- Browser no-warning verification requires Emscripten outside this environment.
- The aggregate `--all` command timed out in the assistant/container environment, so aggregate completion is not claimed.
- Existing broad focused groups passed and are the supported verification path for this environment.
- If served with old Phase 69B Wasm artifacts, the browser is expected to show `stale-wasm-output-contract` until `web/dist` is rebuilt.

## 18. Next recommended milestone

Next recommended milestone:

- **Phase 70 - RET Execution and Return Address Validation**

Archive recommendation after integrating all Phase 69C changes:

```text
Latest_repository_state_milestone_69C.zip
```

## 19. Changed-files ZIP/packages produced

Packages produced during the milestone sequence:

- `milestone_69C_implementation.zip`
  - Initial Phase 69C implementation package.

- `milestone_69C_first_compliance_check.zip`
  - First compliance pass fixes.

- `milestone_69C_second_compliance_check.zip`
  - Second compliance pass fixes.

- `milestone_69C_html_status_fix.zip`
  - User-test follow-up fix for concise `web/index.html` milestone status.

No final compliance package was produced because the final gap-check pass found no missing work and changed no files.

The latest full repository/archive ZIP was not created by the assistant in this milestone-report step. The recommended final archive name after applying all packages is:

```text
Latest_repository_state_milestone_69C.zip
```

## Milestone report completed

- Report file: `Milestone 69C report.md`
- Latest repository/archive recommendation: `Latest_repository_state_milestone_69C.zip`
- Latest repository/archive produced, if created: not created during this report step
- Next milestone: `Phase 70 - RET Execution and Return Address Validation`
