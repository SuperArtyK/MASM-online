# Milestone 57M report - MASM Segment and Group Symbol Diagnostics

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57M - MASM Segment and Group Symbol Diagnostics
```

Repository/archive milestone after this work:

```text
Phase 57M - MASM Segment and Group Symbol Diagnostics
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 57M - MASM Segment and Group Symbol Diagnostics
```

Status interpretation:

Phase 57M is a runtime/source-run behavior milestone. It changes source-visible parser/source-run behavior by adding targeted diagnostics for recognized MASM/object/linker segment and group names. Therefore both the repository/archive milestone and runtime/source-run MASM behavior phase advance to Phase 57M.

Scope implemented:

- Added targeted `unsupported-segment-symbol` diagnostics for recognized MASM segment and group names when they are used as addressable symbols, data/equate-like user names where applicable, or segment/group definition forms.
- Covered the required recognized names: `_TEXT`, `_DATA`, `_BSS`, `CONST`, `STACK`, `DGROUP`, and `FLAT`.
- Rejected addressable references such as `OFFSET _TEXT`, `OFFSET _DATA`, `OFFSET _BSS`, `OFFSET CONST`, `OFFSET STACK`, `OFFSET DGROUP`, `OFFSET FLAT`, and bracketed memory forms such as `DWORD PTR [_TEXT]` and `DWORD PTR [_DATA]`.
- Rejected segment/group definition forms such as `_TEXT SEGMENT`, `_TEXT ENDS`, `_DATA SEGMENT`, `_DATA ENDS`, `_BSS SEGMENT`, `STACK SEGMENT`, and `DGROUP GROUP _DATA, _BSS`.
- Preserved CASEMAP behavior: default and `OPTION CASEMAP:ALL` recognize case variants of these segment/group names; `OPTION CASEMAP:NONE` diagnoses exact recognized spellings but permits different-case ordinary user symbols when they do not exactly match the reserved diagnostic-only spelling.
- Updated source-run/protocol/status metadata to Phase 57M.
- Updated documentation and static checks to describe Phase 57M as current behavior, not future behavior.
- Preserved Phase 57L `.code` memory-access diagnostics and all prior `.CONST`, diagnostic-policy, startup-state, display, and source-run behavior.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status and verification files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `Milestone 57L report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_57L.zip
```

Repository archive recommended after implementation:

```text
Latest_repository_state_milestone_57M.zip
```

No full latest repository archive was produced during this milestone-report step. Changed-files packages were produced and are listed in Section 19.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, memory safety, and status-surface hygiene.
- The incremental implementation guide owns phase numbering, target milestone scope, per-phase implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical spec/guide.
- The audit/handoff report is a navigation and stale-assumption-prevention aid, not a replacement for the canonical spec/guide.
- TODO-style notes are implementation-risk evidence only. They do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

## 3. Exact requirements implemented

### 3.1 Targeted `unsupported-segment-symbol` diagnostics

Implemented the diagnostic family:

```text
unsupported-segment-symbol
```

Recognized names implemented:

```text
_TEXT
_DATA
_BSS
CONST
STACK
DGROUP
FLAT
```

The parser reports `unsupported-segment-symbol` when these names are used as addressable MASM/object/linker symbols or as segment/group definitions.

### 3.2 Addressable symbol references rejected

Implemented targeted diagnostics for addressable forms including:

```asm
mov eax, OFFSET _TEXT
mov eax, OFFSET _DATA
mov eax, OFFSET _BSS
mov eax, OFFSET CONST
mov eax, OFFSET STACK
mov eax, OFFSET DGROUP
mov eax, OFFSET FLAT

mov eax, DWORD PTR [_TEXT]
mov eax, DWORD PTR [_DATA]
mov eax, DWORD PTR [_BSS]
mov eax, DWORD PTR [CONST]
```

These diagnostics are assembly/parser diagnostics. Source-run refuses execution after the diagnostic, emits no Program Console output, and does not emit `execution-complete`.

### 3.3 Segment and group definition forms rejected

Implemented targeted diagnostics for forms including:

```asm
_TEXT SEGMENT
_TEXT ENDS
_DATA SEGMENT
_DATA ENDS
_BSS SEGMENT
_BSS ENDS
CONST SEGMENT
CONST ENDS
STACK SEGMENT
STACK ENDS
DGROUP GROUP _DATA, _BSS
```

Rejected segment/group definitions do not create ordinary user symbols, segment metadata, group metadata, linker metadata, object-file metadata, relocation metadata, or aliases for simulator memory regions.

### 3.4 Diagnostic wording and source locations

Implemented user-facing messages that explain the stable reason for rejection. Examples:

```text
`_TEXT` is a conventional MASM/OBJ/COFF segment or section name for code, often associated with the linker `.text` section. It is not a variable or address label in this simulator. Use labels declared in `.code` only as procedure/branch targets when those features are supported; do not write `OFFSET _TEXT`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

```text
`_DATA` is a conventional MASM/OBJ/COFF segment or section name for initialized data. It is not a variable or address label in this simulator. Define your own variable in `.data`, for example `value DWORD 1`, then use `OFFSET value`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

```text
`DGROUP` is a MASM GROUP name, a linker grouping of data-related segments used by some memory models. It is not a variable or address label in this simulator. Use an actual variable label such as `value` with `OFFSET value` instead of `OFFSET DGROUP`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Diagnostics preserve line, column, byte offset, and span length for the recognized name token.

### 3.5 CASEMAP behavior implemented

Default and `OPTION CASEMAP:ALL` behavior:

- Exact and case-variant uses of recognized names diagnose as `unsupported-segment-symbol`.
- Examples: `_TEXT`, `_text`, `_Text`, `_DATA`, `_data`, `dgroup`, and `Flat` diagnose when used as recognized segment/group symbols.
- A user-defined symbol that collides with a recognized segment/group name under case-insensitive lookup is not allowed to silently replace the diagnostic-only classification.

`OPTION CASEMAP:NONE` behavior:

- Exact recognized spellings such as `_TEXT`, `_DATA`, `CONST`, `STACK`, `DGROUP`, and `FLAT` still diagnose.
- Different-case spellings may be used as ordinary user symbols when they do not exactly match the recognized unsupported spelling.
- This preserves the exact-case symbol policy while still reserving exact conventional segment/group names for targeted diagnostics.

### 3.6 Status-surface updates

Updated current-status surfaces to Phase 57M where runtime/source-run behavior is reported:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `web/index.html`
- `web/src/protocol.js`
- `src/wasm/wasm_api.c`
- protocol tests
- static documentation/status checks in `scripts/run_tests.py`

### 3.7 Previous behavior preserved

Preserved and regression-tested:

- Phase 57L `.code` memory-access diagnostics remain active.
- `_TEXT` is not an alias for `.code`.
- `.code` read/write denial remains `unsupported-code-memory-access` or `region-boundary-crossing` where appropriate.
- `_DATA`, `_BSS`, `CONST`, `STACK`, `DGROUP`, and `FLAT` do not expose simulator internal regions.
- `.model flat, stdcall` remains accepted as a MASM compatibility directive and is not misdiagnosed as `unsupported-segment-symbol`.
- Ordinary declared data labels such as `value` continue to work with `OFFSET value`.
- Program Console remains separate from Simulator Messages.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57M:

- Segment registers.
- Segment override syntax or behavior.
- `ASSUME` behavior.
- OMF segment modeling.
- COFF section modeling.
- PE section layout or loader behavior.
- Object-file generation or object-file parsing.
- Linker behavior.
- Linker groups as metadata.
- Relocation records.
- `_TEXT` as an alias for `.code`.
- `_DATA` as an alias for `.data`.
- `_BSS` as an alias for `.DATA?`.
- `CONST` as an alias for `.CONST`.
- `STACK` as an alias for the VM stack region.
- `DGROUP` or `FLAT` as addressable symbols.
- Host filesystem include behavior.
- New instruction opcode behavior.
- New memory-addressing syntax.
- Browser UI controls for this diagnostic.
- Future Phase 57N behavior.

Future work intentionally preserved:

- Future stack/procedure/control-flow/debugger/Irvine32 routine phases remain out of scope.
- Future memory-reading opcode planned-read TODO remains deferred to the relevant future opcode phases.
- Future segment-register or segment-override behavior remains out of v1 scope unless the canonical spec/guide is deliberately changed.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Use one diagnostic code, `unsupported-segment-symbol`, for both recognized segment names and recognized group/memory-model names.
- **Reason:** The guide names this as the expected diagnostic family and allows documented equivalents only when distinctions are tested.
- **Risk:** Future diagnostics might want finer-grained taxonomy for segment names versus group names.
- **How to change later:** A future diagnostic-taxonomy phase can split this into documented subcodes while updating structured tests, rendered-message tests, docs, and migration checks.

### Assumption 2

- **Assumption:** Under `OPTION CASEMAP:NONE`, exact recognized unsupported spellings are reserved/diagnosed, while different-case spellings may be ordinary user symbols.
- **Reason:** This is the simplest behavior consistent with exact-case user-symbol lookup and the guide requirement that ordinary user symbols should not be blocked merely because they resemble a segment name under exact-case policy.
- **Risk:** Users could be surprised that `_text` works as a user symbol under `CASEMAP:NONE` while `_TEXT` is rejected.
- **How to change later:** A future compatibility policy phase can reserve all case variants even under `CASEMAP:NONE`, but it must update the spec, supported-syntax docs, parser tests, source-run tests, and rendered-message tests.

### Assumption 3

- **Assumption:** Phase 57M advances both repository/archive milestone and runtime/source-run MASM behavior phase.
- **Reason:** The phase changes source-visible parser/source-run diagnostics and status metadata.
- **Risk:** A missed status surface could leave Phase 57L text in current documentation, protocol tests, or UI strings.
- **How to change later:** Future status-surface checks should continue to assert the repository/archive phase and runtime/source-run MASM behavior phase explicitly.

### Assumption 4

- **Assumption:** Segment/group definition forms should be rejected at parser level before any symbol-table insertion.
- **Reason:** Phase 57M requires no ordinary symbols and no segment/linker metadata for these names.
- **Risk:** Parser recovery could produce cascaded diagnostics for adjacent lines.
- **How to change later:** If future parser recovery changes these forms, keep the primary `unsupported-segment-symbol` diagnostic and add targeted tests for diagnostic ordering and cascade suppression.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can be reported as skipped when `emcc` is unavailable in the assistant/container environment.
- **Reason:** The aggregate test runner reports this dependency skip explicitly and the environment lacks Emscripten.
- **Risk:** Browser users need rebuilt Wasm artifacts to observe the updated behavior on the served site.
- **How to change later:** Rebuild with Emscripten locally or in CI and perform the served-browser manual verification steps.

## 6. Relevant TODO-style notes reviewed

Target-owned TODO-style notes reviewed:

- `docs/FULL_IMPLEMENTATION_SPEC.md`: Phase 57K/57M policy note stating that Phase 57M owns parser/source-run implementation of `unsupported-segment-symbol` diagnostics for recognized segment/group names.
- `docs/SUPPORTED_SYNTAX.md`: current-status note that `_TEXT`, `_DATA`, `_BSS`, `CONST`, `STACK`, `DGROUP`, and `FLAT` were unsupported addressable symbols for later Phase 57M targeted diagnostics.

Future-owned TODO-style notes reviewed:

- `src/wasm/wasm_api.c`: future memory-reading opcode planned-read TODO. This remains future-owned because Phase 57M adds parser/source-run diagnostics, not a memory-reading opcode.

Broad TODO-style categories reviewed and excluded as irrelevant to Phase 57M:

- future QWORD/SQWORD execution notes;
- future Irvine32 routine notes;
- future stack/procedure/debugger work;
- future macro/high-level-flow notes;
- future branch/control-flow phase notes;
- parser diagnostics for unrelated unsupported constructs;
- static-check strings and test fixture text;
- historical report text and generated artifacts excluded from source-note authority.

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- The Phase 57M segment/group diagnostic policy note in `docs/FULL_IMPLEMENTATION_SPEC.md` was resolved by implementing the parser/source-run diagnostic behavior and updating the spec wording so Phase 57M is current behavior.
- The `docs/SUPPORTED_SYNTAX.md` future-Phase-57M note was resolved by documenting current `unsupported-segment-symbol` behavior and adding status/static checks.

### Future-owned TODO-style notes intentionally preserved

- `src/wasm/wasm_api.c` future memory-reading opcode planned-read TODO remains unchanged. Phase 57M did not add a new opcode or memory-reading instruction family.

### Stale or contradicted TODO-style notes corrected

- No stale repository TODO-style notes remained after review.
- A stale milestone-history sentence that still described Phase 57M as future work was corrected during the second compliance review. It was not a TODO-style note, but it was stale current documentation.

### Unresolved TODO-related risks

- None identified.

## 8. Design summary

Phase 57M was implemented as a narrow parser/source-run diagnostic milestone.

Primary design choices:

1. **Parser-side classification.** Recognized MASM segment/group names are classified in the parser before they can fall through to generic `unknown-symbol` behavior or ordinary symbol insertion.

2. **Diagnostic-only compatibility names.** `_TEXT`, `_DATA`, `_BSS`, `CONST`, `STACK`, `DGROUP`, and `FLAT` are recognized only to produce targeted diagnostics. They are not region aliases and do not create segment/group/linker metadata.

3. **CASEMAP-aware classification.** The classifier follows the active user-symbol CASEMAP policy. Default/`CASEMAP:ALL` uses case-insensitive recognition; `CASEMAP:NONE` reserves exact recognized spellings while allowing different-case ordinary user symbols.

4. **No runtime memory-path change.** Phase 57M does not alter checked VM memory helpers or memory access semantics. Phase 57L `.code` access denial remains the runtime authority for numeric/computed memory ranges overlapping `.code`.

5. **Stable, user-facing diagnostic copy.** Diagnostics explain why each conventional name is rejected and point the user toward declared labels such as `value`, `buf`, or `limit` where appropriate.

6. **Exact rendered-message coverage.** Each user-visible diagnostic family added by the milestone has structured JSON/source-run tests and exact rendered Simulator Messages tests.

7. **Status-surface consistency.** Runtime/source-run phase metadata, protocol status, README, supported syntax, milestone history, and static checks were advanced to Phase 57M because this milestone changes source-visible diagnostics.

## 9. Files changed

Files changed across implementation, compliance review, re-review, user-follow-up/manual-output corrections, and final status/documentation work:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/parser.c`
- `src/parser/parser.h`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

Added or updated test coverage includes:

### Parser/native tests

- `OFFSET _TEXT`, `OFFSET _DATA`, `OFFSET _BSS`, `OFFSET CONST`, `OFFSET STACK`, `OFFSET DGROUP`, and `OFFSET FLAT` report `unsupported-segment-symbol`.
- Bracketed memory references such as `DWORD PTR [_TEXT]` and `DWORD PTR [_DATA]` report `unsupported-segment-symbol` instead of `unknown-symbol`.
- Segment/group definition forms such as `_TEXT SEGMENT`, `_TEXT ENDS`, `_DATA SEGMENT`, `_DATA ENDS`, `_BSS SEGMENT`, `STACK SEGMENT`, and `DGROUP GROUP _DATA, _BSS` report targeted diagnostics.
- Rejected segment/group definitions do not create ordinary data symbols.
- Default/`CASEMAP:ALL` case variants diagnose.
- `CASEMAP:NONE` exact recognized spellings diagnose.
- `CASEMAP:NONE` different-case ordinary labels may work when they do not exactly match reserved unsupported spellings.
- `.model flat, stdcall` remains accepted and is not misdiagnosed as `unsupported-segment-symbol`.

### Source-run tests

- Source with `OFFSET _TEXT` refuses execution.
- Source with `_TEXT SEGMENT` refuses execution.
- Source with `DGROUP GROUP _DATA, _BSS` refuses execution.
- Failure cases emit no Program Console output.
- Failure cases do not emit `execution-complete`.
- Ordinary data-label programs using `OFFSET value` still execute.
- Source-run metadata/status advances to Phase 57M.

### Rendered Simulator Messages tests

Exact rendered-message coverage for:

- `_TEXT` `OFFSET` diagnostic.
- `_DATA` `OFFSET` diagnostic.
- `_BSS` `OFFSET` diagnostic.
- `CONST` `OFFSET` diagnostic.
- `STACK` `OFFSET` diagnostic.
- `FLAT` `OFFSET` diagnostic.
- `DGROUP` `OFFSET` diagnostic.
- `_TEXT SEGMENT` definition diagnostic.

### Protocol/static/status tests

- Protocol phase metadata reports Phase 57M.
- Stale artifacts without Phase 57M suffix are detected.
- README and docs report Phase 57M repository/runtime status.
- Supported-syntax documentation reports current `unsupported-segment-symbol` behavior.
- Static checks preserve Phase 57L `.code` policy wording while advancing Phase 57M status.
- Static checks prevent stale future-only Phase 57M wording in current docs.

## 11. Commands used to test

### Aggregate command

```bash
cd /mnt/data/repo_57L_verify
python3 scripts/run_tests.py --all
```

Observed final result:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

### Focused group commands

Focused groups run during implementation, compliance review, re-review, and final gap check:

```bash
cd /mnt/data/repo_57L_verify
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Combined focused command forms also used:

```bash
cd /mnt/data/repo_57L_verify
python3 scripts/run_tests.py --diagnostics --web --protocol
```

Observed focused results:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

### Subgroup or fixture-family commands

No subgroup or individual fixture-family commands were required. No focused group timed out.

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.

This is an expected dependency skip, not a test failure. Website testing requires rebuilding Wasm in an environment with Emscripten.

## 12. Pass/fail results

Final result classification:

```text
aggregate completed and passed
```

Detailed classification:

- Aggregate completed and passed.
- Focused groups completed and passed.
- No aggregate timeout occurred.
- No aggregate failure occurred.
- No focused group failed.
- No focused group timed out.
- No subgroup/fixture-family rerun was required.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

Final aggregate output ended with:

```text
All implemented milestone tests passed.
```

## 13. Manual/browser testing guidance and expected outputs

Phase 57M is website-testable after rebuilding Wasm with Emscripten.

### Browser setup on Windows CMD

From the repository root:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Open:

```text
http://localhost:8000
```

If Emscripten is unavailable, browser/Wasm rebuild is expected to be skipped. In that case, use the local test-suite commands in Section 11.

### Program 1 - `_TEXT` must not be an alias for `.code`

```asm
.code
main PROC
    mov eax, OFFSET _TEXT
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-segment-symbol line 3, column 21, byte offset 36, span length 5: `_TEXT` is a conventional MASM/OBJ/COFF segment or section name for code, often associated with the linker `.text` section. It is not a variable or address label in this simulator. Use labels declared in `.code` only as procedure/branch targets when those features are supported; do not write `OFFSET _TEXT`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Expected Program Console:

```text
(empty)
```

Expected key behavior:

- Program does not execute.
- No `execution-complete` message.
- `_TEXT` is not resolved to `00400000h` or any `.code` address.

### Program 2 - `_DATA` must not be an alias for `.data`

```asm
.code
main PROC
    mov eax, OFFSET _DATA
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-segment-symbol line 3, column 21, byte offset 36, span length 5: `_DATA` is a conventional MASM/OBJ/COFF segment or section name for initialized data. It is not a variable or address label in this simulator. Define your own variable in `.data`, for example `value DWORD 1`, then use `OFFSET value`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Expected Program Console:

```text
(empty)
```

### Program 3 - `_BSS` must not be an alias for `.DATA?`

```asm
.code
main PROC
    mov eax, OFFSET _BSS
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-segment-symbol line 3, column 21, byte offset 36, span length 4: `_BSS` is a conventional MASM/OBJ/COFF segment or section name for uninitialized data, also called a BSS section. It is not a variable or address label in this simulator. Define your own variable in `.DATA?`, for example `buf BYTE 16 DUP(?)`, then use `OFFSET buf`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Expected Program Console:

```text
(empty)
```

### Program 4 - `CONST` must not be an alias for `.CONST`

```asm
.code
main PROC
    mov eax, OFFSET CONST
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-segment-symbol line 3, column 21, byte offset 36, span length 5: `CONST` is a conventional MASM segment name for constant or read-only data. It is not a constant variable or address label in this simulator. Define your own symbol in `.CONST`, for example `limit DWORD 10`, then use `OFFSET limit`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Expected Program Console:

```text
(empty)
```

### Program 5 - `STACK` must not expose simulator stack memory

```asm
.code
main PROC
    mov eax, OFFSET STACK
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-segment-symbol line 3, column 21, byte offset 36, span length 5: `STACK` is a conventional MASM segment name for stack storage in object-file layouts. `OFFSET STACK` asks for that linker segment name as an address symbol, so it is rejected. This diagnostic is only about the literal symbol name `STACK`; it is not a statement about ordinary stack instructions or checked stack memory access in phases that implement them. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Expected Program Console:

```text
(empty)
```

### Program 6 - `DGROUP` must not expose a linker group

```asm
.code
main PROC
    mov eax, OFFSET DGROUP
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-segment-symbol line 3, column 21, byte offset 36, span length 6: `DGROUP` is a MASM GROUP name, a linker grouping of data-related segments used by some memory models. It is not a variable or address label in this simulator. Use an actual variable label such as `value` with `OFFSET value` instead of `OFFSET DGROUP`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Expected Program Console:

```text
(empty)
```

### Program 7 - `FLAT` must not expose a linker group

```asm
.code
main PROC
    mov eax, OFFSET FLAT
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-segment-symbol line 3, column 21, byte offset 36, span length 4: `FLAT` is a MASM memory-model name and GROUP-style linker concept used in directives such as `.model flat, stdcall`. It is not a variable or address label in this simulator, so `OFFSET FLAT` is rejected. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Expected Program Console:

```text
(empty)
```

### Program 8 - segment definition form must be rejected

```asm
_TEXT SEGMENT
_TEXT ENDS
.code
main PROC
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-segment-symbol line 1, column 1, byte offset 0, span length 5: `_TEXT` is a conventional MASM/OBJ/COFF segment or section name for code, often associated with the linker `.text` section. It is not a variable or address label in this simulator. Use labels declared in `.code` only as procedure/branch targets when those features are supported; do not write `OFFSET _TEXT`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Expected Program Console:

```text
(empty)
```

### Program 9 - ordinary data labels must still work

```asm
.data
value DWORD 123

.code
main PROC
    mov eax, OFFSET value
    mov ebx, value
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key registers under default fixed layout:

```text
EAX = 00500000h / 5242880
EBX = 0000007Bh / 123
```

### Program 10 - `CASEMAP:NONE` exact reserved spelling still diagnoses

```asm
OPTION CASEMAP:NONE

.code
main PROC
    mov eax, OFFSET _TEXT
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-segment-symbol line 5, column 21, byte offset 58, span length 5: `_TEXT` is a conventional MASM/OBJ/COFF segment or section name for code, often associated with the linker `.text` section. It is not a variable or address label in this simulator. Use labels declared in `.code` only as procedure/branch targets when those features are supported; do not write `OFFSET _TEXT`. Recognized unsupported segment/GROUP names: _TEXT, _DATA, _BSS, CONST, STACK, DGROUP, FLAT.
```

Expected Program Console:

```text
(empty)
```

### Program 11 - `CASEMAP:NONE` different-case ordinary label may work

```asm
OPTION CASEMAP:NONE

.data
_text DWORD 77

.code
main PROC
    mov eax, OFFSET _text
    mov ebx, _text
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected key registers under default fixed layout:

```text
EAX = 00500000h / 5242880
EBX = 0000004Dh / 77
```

### Regression signs during manual testing

The following indicate regressions:

- A recognized segment/group name reports `unknown-symbol` instead of `unsupported-segment-symbol`.
- A program using `_TEXT`, `_DATA`, `_BSS`, `CONST`, `STACK`, `DGROUP`, or `FLAT` as an addressable symbol executes successfully.
- Any recognized name resolves to an internal VM address.
- `_TEXT` becomes an alias for `.code` or `_DATA` becomes an alias for `.data`.
- Program Console receives output on a diagnostic-only failure.
- `execution-complete` appears after an assembly diagnostic.
- Source location fields are missing or incorrect.
- Current docs still describe Phase 57M diagnostics as future work.

## 14. Compliance review summary

First compliance review results:

- Scope remained limited to Phase 57M.
- Core remained C99-only.
- No future milestone behavior was implemented.
- No non-goal behavior was added.
- Structured diagnostics preserved line, column, byte offset, and span length.
- Rendered Simulator Messages tests existed for target diagnostics.
- One coverage hardening gap was found: structured/parser tests covered all required recognized names, but exact rendered-message coverage did not yet include `STACK` and `FLAT`.

Fixes applied during first compliance review:

- Added parser regression coverage for `_BSS SEGMENT` and `STACK SEGMENT`.
- Added source-run coverage for `OFFSET STACK` and `OFFSET FLAT`.
- Added exact rendered Simulator Messages tests for `STACK` and `FLAT`.

Tests rerun after first compliance review:

- `python3 scripts/run_tests.py --native`
- `python3 scripts/run_tests.py --source-run`
- `python3 scripts/run_tests.py --diagnostics --web --protocol`
- `python3 scripts/run_tests.py --static`
- `python3 scripts/run_tests.py --all`

All completed and passed. Browser/Wasm rebuild smoke remained skipped because `emcc` was unavailable.

## 15. Re-review summary

Second compliance review results:

- Re-read the target guide/spec sections.
- Compared implementation behavior against the target tasks and acceptance criteria.
- Inspected changed code, tests, and docs for stale comments, hidden assumptions, and incomplete Doxygen/file-header issues.
- Re-scanned TODO-style notes in changed files and nearby modules.
- Inspected tests for quality and exact rendered-message coverage.
- Rechecked docs for stale future-only wording.

Additional issues found during second review:

- `docs/MILESTONE_HISTORY.md` still had one stale sentence saying Phase 57M would later implement the segment/group diagnostics.
- Phase 57M source-run tests did not explicitly assert that failure cases produce no Program Console output.
- Two static-check helper names in `scripts/run_tests.py` still referenced Phase 57L even though they now verified Phase 57M status plus retained Phase 57L `.code` policy.

Fixes applied during second review:

- Updated `docs/MILESTONE_HISTORY.md` to describe Phase 57M as current implemented behavior.
- Added source-run assertions that `OFFSET _TEXT`, `_TEXT SEGMENT`, and `DGROUP GROUP _DATA, _BSS` do not create Program Console output.
- Renamed stale static-check helper names to Phase 57M-oriented names.

Tests rerun after second review:

- `python3 scripts/run_tests.py --native`
- `python3 scripts/run_tests.py --source-run`
- `python3 scripts/run_tests.py --diagnostics --web --protocol`
- `python3 scripts/run_tests.py --static`
- `python3 scripts/run_tests.py --all`

All completed and passed. Browser/Wasm rebuild smoke remained skipped because `emcc` was unavailable.

## 16. User-test follow-up summary

The user did not provide a failing manual/browser test result requiring repository fixes in this visible Prompt 8 path.

The final gap check found a non-repository issue in the earlier manual-testing instructions: several expected rendered messages in the manual instructions were stale compared with the repository's exact rendered-message tests. No repository implementation change was required for that finding. This report includes corrected manual expected outputs in Section 13.

If the served website is rebuilt with Emscripten and the user observes a mismatch from the Section 13 expectations, the next step should be targeted triage against the current `tests/web/test_diagnostic_rendering.mjs` expected strings and the loaded Wasm artifact version.

## 17. Known limitations

Known limitations after Phase 57M:

- No segment registers or segment overrides are implemented.
- `ASSUME` remains unsupported.
- MASM/OMF/COFF/PE segment, section, group, relocation, object-file, and linker behavior remain outside this milestone.
- `_TEXT`, `_DATA`, `_BSS`, `CONST`, `STACK`, `DGROUP`, and `FLAT` are diagnostic-only recognized names, not addressable symbols.
- `.code` remains inaccessible as source-level memory through Phase 57L diagnostics.
- `.CONST` write protection and declaration/read diagnostics remain governed by prior phases.
- Browser/Wasm rebuild smoke could not run in the assistant/container environment because `emcc` was unavailable.
- Served-browser verification requires rebuilding Wasm in a local/CI environment with Emscripten.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57N - Zero-Operand NOP Audit, Repair, and Regression Hardening
```

Implementation guidance for the next milestone:

- Start from the completed Phase 57M repository state.
- Use `Latest_repository_state_milestone_57M.zip` as the recommended next archive name if a full repository archive is created.
- Re-run repository verification before implementing Phase 57N.
- Do not infer Phase 57N requirements from stale TODO-style notes; read the canonical guide section.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone process include:

- `phase57m_changed_files.zip`
- `phase57m_compliance_review_changed_files.zip`
- `phase57m_second_review_changed_files.zip`
- `phase57m_final_changed_files.zip`

The final changed-files package created for this report is:

```text
phase57m_final_changed_files.zip
```

It preserves repository structure for the final changed files relative to the Phase 57L base archive.

No full latest repository archive was produced during this milestone-report step.

Recommended full archive name if the user packages the repository after applying these changes:

```text
Latest_repository_state_milestone_57M.zip
```
