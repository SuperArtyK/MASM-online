# Milestone 50A report - Undefined Modeled Flag Validity Metadata

## 1. Milestone title and scope

Milestone 50A implements **Phase 50A - Undefined Modeled Flag Validity Metadata** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added internal validity metadata for each currently modeled flag:
  - `CF`
  - `ZF`
  - `SF`
  - `OF`
- Preserved existing deterministic EFLAGS bit behavior for all supported programs.
- Tracked whether each modeled flag's current deterministic value is architecturally valid.
- Tracked undefined-origin metadata for flags made invalid by undefined producer behavior:
  - diagnostic code, such as `undefined-shift-flag` or `undefined-modeled-flag`;
  - producer mnemonic, such as `shl`, `shr`, `sar`, `rol`, or `ror`;
  - producer source line;
  - producer source column;
  - producer byte offset;
  - producer span length.
- Initialized all modeled flag metadata as valid on CPU reset/load.
- Marked modeled flags valid whenever an instruction or helper architecturally defines, sets, clears, or writes the flag.
- Preserved flag validity metadata whenever an instruction architecturally preserves a modeled flag.
- Marked only the architecturally undefined modeled flags invalid for existing shift and rotate undefined-flag producer cases.
- Preserved no-partial-mutation guarantees by restoring flag validity metadata on failed memory writes and runtime permission failures.
- Preserved all existing visible source-run, rendered diagnostic, Program Console, register, memory, and final EFLAGS behavior.

This milestone is backend/internal metadata infrastructure. It does not add new MASM syntax and does not add new website-visible flag-validity display.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 50 report.md`

Repository archive used as the implementation base:

- `Latest_repository_state_milestone_50.zip`

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.
- Phase 50A is the only target milestone for this work session.

## 3. Exact requirements implemented

Phase 50A required internal metadata that distinguishes deterministic simulator flag values from architecturally valid flag values after instructions with undefined modeled flag behavior.

Implemented metadata behavior:

- `VmCpu` now stores `VmFlagValidityMetadata` for every modeled flag.
- Each metadata entry records:
  - `is_valid`;
  - `undefined_code`;
  - `producer_mnemonic`;
  - `producer_source_line`;
  - `producer_source_column`;
  - `producer_byte_offset`;
  - `producer_span_length`.
- CPU initialization marks all modeled flags valid and clears undefined-origin metadata.
- Raw EFLAGS writes mark all modeled flags valid.
- Normal flag helper writes mark the affected modeled flag valid and clear undefined-origin metadata.
- Undefined-flag producer paths preserve the deterministic EFLAGS bit while marking only the affected modeled flag metadata invalid.
- Flag-preserving instructions preserve both the flag bit and the metadata.

Implemented shift/rotate metadata cases:

- `shl eax, 2` marks `OF` invalid while leaving `CF`, `ZF`, and `SF` valid.
- `shl al, 8` marks `CF` and `OF` invalid while leaving `ZF` and `SF` valid.
- `shr al, 8` marks `CF` and `OF` invalid while leaving `ZF` and `SF` valid.
- `sar al, 8` marks `CF` and `OF` invalid while leaving `ZF` and `SF` valid.
- `rol eax, 2` marks `OF` invalid, marks `CF` valid, and preserves `ZF`/`SF` validity metadata.
- `ror eax, 2` marks `OF` invalid, marks `CF` valid, and preserves `ZF`/`SF` validity metadata.
- `rol eax, 1` and `ror eax, 1` mark `CF` and `OF` valid.
- `rol eax, 32` and `ror eax, 32` preserve all flag values and validity metadata because the effective count is zero.

Implemented rollback/no-partial-mutation behavior:

- Failed memory reads preserve existing flag values and validity metadata.
- Failed memory writes restore previous CPU/flag state, including validity metadata.
- Runtime `.CONST` permission failures restore previous CPU/flag state, including validity metadata.
- Failed validation paths do not commit flag-validity mutation.

Implemented diagnostics behavior:

- Existing producer warnings are preserved:
  - `undefined-shift-flag`
  - `undefined-modeled-flag`
- Existing rendered Simulator Messages remain unchanged.
- No new default source-level diagnostics are emitted in Phase 50A.
- No `undefined-flag-use` consumer diagnostic was implemented.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 50A:

- `PF`, `AF`, or `DF` metadata.
- New runtime instructions.
- `cmp`.
- Labels, `jmp`, conditional jumps, or `loop`.
- `SETcc` or `CMOVcc`.
- Flag-consumer source-level diagnostics such as `undefined-flag-use`.
- Smart flag-consumer validation in normal source execution.
- Browser UI for flag-validity metadata.
- Browser settings for strict flag-validity behavior.
- New default Simulator Messages output.
- Changed Program Console behavior.
- Changed final EFLAGS bit values.
- Strict producer errors for rotate instructions.
- Carry rotates.
- Stack, procedure, Irvine32 expansion, QWORD/SQWORD execution, scaled-index addressing, WinAPI, PE, linker, macro, or filesystem behavior.

Next flag-validity work is expected to be a future consumer-diagnostics milestone, not part of Phase 50A.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Flag-validity metadata should live in `VmCpu` rather than in a separate executor-only table.
- **Reason:** Validity is part of the modeled CPU/flag state and must be preserved or restored alongside flag values across instruction execution, no-op cases, and rollback paths.
- **Risk:** CPU-state snapshots and helper call sites must account for the added metadata.
- **How to change later:** A future refactor can move metadata into a named sub-struct within `VmCpu`, while preserving the public helper API.

### Assumption 2

- **Assumption:** Normal source-run JSON should not expose flag-validity metadata in Phase 50A.
- **Reason:** The phase is backend/internal metadata infrastructure, and exposing new JSON fields could destabilize browser/protocol output before a UI/debugger milestone defines display behavior.
- **Risk:** Website users cannot directly inspect the new metadata yet.
- **How to change later:** Add a structured debugger/status payload in a later UI or flag-consumer diagnostics phase, with protocol and rendered-output tests.

### Assumption 3

- **Assumption:** Existing numeric source-run/browser phase metadata should remain `50` instead of forcing a string-like `50A` into existing numeric fields.
- **Reason:** The repository metadata path has historically used numeric phase values, and Phase 50A is internal infrastructure with no new user-visible MASM behavior.
- **Risk:** The normal UI does not visibly advertise Phase 50A as a separate implemented capability.
- **How to change later:** Introduce a separate feature/capability field such as `implementedMilestoneLabel` if a later protocol milestone requires suffix milestones in UI metadata.

### Assumption 4

- **Assumption:** Existing producer warning diagnostics should remain unchanged.
- **Reason:** Phase 50A adds metadata behind existing warnings; it does not redefine user-facing diagnostic wording.
- **Risk:** Users cannot see validity metadata in Simulator Messages.
- **How to change later:** A later consumer-diagnostics phase can add explicit `undefined-flag-use` messages without changing Phase 50A producer behavior.

### Assumption 5

- **Assumption:** Producer column, byte offset, and span length can be stored in the metadata model even when current executor call sites only have complete line data and use zero placeholders for the remaining fields.
- **Reason:** The guide requires the metadata model to be able to retain source-span information. Current IR/executor paths do not expose every source coordinate at the helper call sites used for shift/rotate metadata.
- **Risk:** Metadata source spans are not yet fully populated for all producer paths.
- **How to change later:** Thread full source-span fields through IR or executor helper inputs in a later diagnostics/debugger refinement without changing the metadata structure.

## 6. Design summary

### CPU model changes

The CPU state now owns modeled-flag validity metadata:

```text
VmCpu
  eflags deterministic bit values
  flag_validity[VM_FLAG_COUNT]
```

Each `VmFlagValidityMetadata` entry records whether the modeled flag value is architecturally valid and, if not, where the invalid value originated.

New/updated helper behavior:

- `vm_cpu_get_flag_validity` retrieves metadata for a modeled flag.
- `vm_cpu_mark_flag_valid` marks a modeled flag valid and clears undefined-origin metadata.
- `vm_cpu_mark_flag_undefined` marks a modeled flag invalid and records producer metadata.
- Existing flag writes and raw EFLAGS writes mark affected modeled flags valid.

### Executor changes

The executor now differentiates three flag-state cases:

1. **Defined flag:** update deterministic bit, mark metadata valid.
2. **Architecturally preserved flag:** preserve bit and preserve metadata.
3. **Architecturally undefined modeled flag:** preserve deterministic fallback bit, mark metadata invalid, and store producer origin.

Shift and rotate helpers apply this rule to existing undefined flag cases without changing visible results.

Rollback uses the existing CPU state snapshot approach. Because validity metadata is now part of `VmCpu`, restoring the CPU snapshot restores both EFLAGS bits and metadata.

### Documentation/status changes

Documentation was updated to state that Phase 50A is implemented as internal metadata infrastructure. The documentation does not claim that flag-validity metadata is displayed in the browser or that future consumer diagnostics are implemented.

## 7. Files changed

Final Phase 50A changed files:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_cpu.c
src/core/vm_cpu.h
src/core/vm_exec.c
tests/core/test_vm_cpu.c
tests/core/test_vm_exec.c
```

Changed-files packages produced:

```text
/mnt/data/milestone50a_changed_files.zip
/mnt/data/milestone50a_compliance_review_changed_files.zip
/mnt/data/milestone50a_second_review_changed_files.zip
```

The latest verified package is:

```text
/mnt/data/milestone50a_second_review_changed_files.zip
```

## 8. Tests added

### CPU/flag metadata tests

Added or expanded coverage for:

- CPU initialization marks all modeled flags valid.
- Marking a flag undefined stores:
  - invalid state;
  - undefined diagnostic code;
  - producer mnemonic;
  - source line;
  - source column;
  - byte offset;
  - span length.
- Normal modeled flag writes clear undefined metadata and mark the flag valid.
- Raw EFLAGS writes mark modeled flags valid.
- Invalid helper inputs fail safely without mutation.

### Executor metadata tests

Added or expanded coverage for:

- `shl` multi-bit invalid `OF` metadata.
- `shl`, `shr`, and `sar` counts greater than or equal to operand width invalidating `CF`/`OF` while preserving valid `ZF`/`SF` metadata.
- `rol` and `ror` multi-bit invalid `OF` metadata.
- `rol` and `ror` one-bit counts marking `CF`/`OF` valid.
- effective-count-zero rotate paths preserving flag values and validity metadata.
- `inc` preserving invalid `CF` metadata.
- `mov` preserving invalid `OF`/`CF` metadata.
- `not` preserving invalid `OF`/`CF` metadata.
- `clc` marking `CF` valid while preserving unrelated invalid `OF` metadata.
- `test eax, eax` marking `CF`, `ZF`, `SF`, and `OF` valid.
- invalid memory reads preserving flag validity metadata.
- runtime `.CONST` write failures restoring flag validity metadata.

### Static compliance checks

Updated `scripts/run_tests.py` to require Phase 50A artifacts, including:

- `VmFlagValidityMetadata`
- `vm_cpu_get_flag_validity`
- `vm_cpu_mark_flag_valid`
- `vm_cpu_mark_flag_undefined`
- source-span metadata fields
- Phase 50A executor tests for undefined, defined, preserved, and rollback cases
- documentation/status references for Phase 50A

### Rendered message regression coverage

No new rendered diagnostic was added because Phase 50A intentionally does not introduce a new user-visible diagnostic path. Existing rendered warning tests for shift and rotate producer warnings continued to pass unchanged.

## 9. Commands used to test

Primary aggregate test command:

```sh
cd /mnt/data/review_m50a
CC=clang python3 -u scripts/run_tests.py
```

Wasm rebuild check command:

```sh
cd /mnt/data/review_m50a
bash scripts/build_wasm.sh
```

Additional verification performed during earlier repository setup:

```sh
cd /mnt/data/repo_verify_m50
CC=clang python3 -u scripts/run_tests.py
```

## 10. Pass/fail results

Primary aggregate test result:

```text
All implemented milestone tests passed.
```

The aggregate runner covered native C tests, static milestone/compliance checks, the native diagnostic JSON producer build, and Node web/protocol/formatter/rendered-message tests.

Wasm rebuild result in this container:

```text
emcc: command not found
```

This is an environment limitation. Emscripten is not installed in the container, so `web/dist` could not be rebuilt here. Native C and Node tests passed.

## 11. Manual/browser testing guidance and expected outputs

### Website-testable status

The actual Phase 50A metadata is not directly website-testable because the browser UI does not display flag-validity metadata yet.

Browser testing is still useful as a regression check that existing visible shift/rotate behavior did not change.

### Browser regression Program A - ROL undefined modeled flag warning

Program:

```asm
.code
main PROC
    mov eax, 1
    rol eax, 2
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-warning] undefined-modeled-flag line 4, column 5, byte offset 35, span length 10: ROL count 2 has effective count 2 and rotate amount 2 for a 32-bit destination. CF was updated from the least significant bit of the rotated result. ZF and SF were preserved because ROL does not define them. OF is architecturally undefined because the effective count is not 1. The simulator preserved OF deterministically.
[info] execution-complete: Execution completed successfully.
```

Expected final registers:

```text
EAX    00000004h / 4
EFLAGS 00000000h / 0
```

Expected Program Console:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

### Browser regression Program B - effective-count-zero ROR preserves visible flags

Program:

```asm
.code
main PROC
    mov eax, 80000001h
    stc
    ror eax, 32
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected final registers:

```text
EAX    80000001h / 2147483649
EFLAGS 00000001h / 1
```

Expected Program Console:

```text
(empty)
```

Expected memory changes:

```text
No memory changes.
```

### Windows CMD local test commands

From the project root in a Visual Studio Developer Command Prompt or equivalent environment:

```cmd
set CC=clang
py scripts\run_tests.py
```

Expected final output:

```text
All implemented milestone tests passed.
```

Direct Phase 50A-relevant native tests after aggregate build:

```cmd
build\tests\test_vm_cpu.exe
```

Expected output:

```text
CPU register and flag metadata tests passed.
```

```cmd
build\tests\test_vm_exec.exe
```

Expected output:

```text
Executor tests through Milestone 50A passed.
```

### Windows CMD source-run regression Program A

Create `program.asm` at the project root:

```asm
.code
main PROC
    mov eax, 1
    rol eax, 2
main ENDP
END main
```

Run:

```cmd
build\tests\diagnostic_json_producer.exe program.asm
```

Expected JSON facts:

```text
"ok": true
"status": "ok"
"phase": 50
"hex": "00000004h" under EAX
"hex": "00000000h" under EFLAGS
"code": "undefined-modeled-flag"
"code": "execution-complete"
"memoryChanges": []
```

### Windows CMD source-run regression Program B

Create `program.asm` at the project root:

```asm
.code
main PROC
    mov eax, 80000001h
    stc
    ror eax, 32
main ENDP
END main
```

Run:

```cmd
build\tests\diagnostic_json_producer.exe program.asm
```

Expected JSON facts:

```text
"ok": true
"status": "ok"
"phase": 50
"hex": "80000001h" under EAX
"hex": "00000001h" under EFLAGS
"code": "execution-complete"
"memoryChanges": []
```

Expected absent strings:

```text
undefined-modeled-flag
undefined-shift-flag
undefined-flag-use
```

Regression signs:

- Native Phase 50A tests fail.
- Existing warning text changes unexpectedly.
- Final EAX/EFLAGS differ from expected values.
- A new `undefined-flag-use` message appears.
- Program Console output appears for these programs.
- Memory changes appear for these programs.
- Website behavior differs after a successful Wasm rebuild.

## 12. Compliance review summary

The first compliance review found two issues and fixed them:

1. The metadata model did not yet store source column, byte offset, and span length.
2. A Doxygen comment in `src/core/vm_exec.c` was malformed after adding the undefined-flag helper documentation.

Fixes applied:

- Added `producer_source_column`, `producer_byte_offset`, and `producer_span_length` to `VmFlagValidityMetadata`.
- Updated `vm_cpu_mark_flag_undefined` and executor call sites to pass the expanded metadata.
- Fixed malformed Doxygen/comment placement in `vm_exec.c`.
- Added tests for source-span metadata storage.
- Updated static checks to require the new fields.

Compliance review result:

```text
All implemented milestone tests passed.
```

## 13. Re-review summary

The second review found one test coverage gap:

- Dedicated Phase 50A tests did not explicitly verify the guide-required behavior that `mov` and `not` preserve flag validity metadata, and that `clc`/flag-setting instructions mark flags valid.

Fixes applied:

- Added `test_phase50a_defined_and_preserved_flag_validity_metadata`.
- Verified:
  - `mov` preserves invalid `OF`/`CF` metadata.
  - `not` preserves invalid `OF`/`CF` metadata.
  - `clc` marks `CF` valid while preserving unrelated invalid `OF` metadata.
  - `test eax, eax` marks `CF`, `ZF`, `SF`, and `OF` valid.
- Updated static checks to require the new test.

Re-review result:

```text
All implemented milestone tests passed.
```

Final gap check result:

- No missing work found.
- No further fixes applied.
- Latest changed-files ZIP inspected and retained.

## 14. User-test follow-up summary

Manual testing instructions were prepared for the user.

Key guidance:

- The actual Phase 50A metadata is local-test-only because the website does not display it.
- Browser tests are regression checks for unchanged visible behavior.
- Windows CMD instructions use `program.asm` at the project root.
- Expected outputs were provided for:
  - direct native Phase 50A tests;
  - source-run JSON regression checks;
  - website visible behavior for representative `rol` and `ror` programs.

No user-reported follow-up defects were raised before this milestone report.

## 15. Known limitations

- Phase 50A metadata is not exposed in normal source-run JSON or displayed by the website.
- Existing numeric phase metadata remains `50`; Phase 50A is documented as internal infrastructure.
- Producer column, byte offset, and span length are supported in metadata, but current executor call sites pass zero placeholders where the current IR does not provide complete source-span fields.
- No `undefined-flag-use` diagnostics are implemented; that is future work.
- Wasm/browser rebuild could not be verified in this container because Emscripten is missing.

## 16. Next recommended milestone

Next recommended milestone:

```text
Phase 50B - Undefined Flag Use Diagnostics for Flag Consumers
```

This next phase should consume the Phase 50A metadata only where a supported flag-consuming instruction exists or is introduced by the guide. It should not be backported into Phase 50A.

## 17. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

```text
/mnt/data/milestone50a_changed_files.zip
/mnt/data/milestone50a_compliance_review_changed_files.zip
/mnt/data/milestone50a_second_review_changed_files.zip
```

Latest verified changed-files package:

```text
/mnt/data/milestone50a_second_review_changed_files.zip
```

Recommended next full repository archive name after applying the latest changed-files package:

```text
Latest_repository_state_milestone_50A.zip
```
