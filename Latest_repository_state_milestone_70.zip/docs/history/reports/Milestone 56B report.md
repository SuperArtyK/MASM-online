# Milestone 56B report - User-Facing Diagnostic Wording Cleanup

## 1. Milestone title and scope

Milestone 56B implements **Phase 56B - User-Facing Diagnostic Wording Cleanup** for the Online MASM32 Educational Simulator.

This milestone is a wording, current-status, protocol-message, documentation, and test-maintenance milestone. It does not add MASM syntax, parser acceptance behavior, VM behavior, executor behavior, Wasm API behavior, browser controls, browser layout, browser interaction behavior, diagnostic codes, diagnostic JSON fields, diagnostic policies, severity categories, or rendered Simulator Messages categories.

Scope implemented:

- Audited live user-facing diagnostics and current-status text for milestone-relative wording such as:
  - `current milestone`;
  - `this milestone`;
  - `unsupported by the current milestone`;
  - `not implemented in this milestone`;
  - `not supported in this milestone`;
  - `unsupported in this milestone`;
  - `implemented through the current milestone`;
  - `current milestone metadata`.
- Replaced live milestone-relative diagnostic wording with stable, behavior-specific wording.
- Tightened the changed diagnostics after user feedback so the messages are actionable rather than merely saying to use a "supported" form.
- Updated current-status documentation to explicitly distinguish:
  - repository/archive milestone; and
  - runtime/source-run MASM behavior phase.
- Preserved the runtime/source-run MASM behavior phase as **Phase 56 - Unsigned DIV**.
- Updated stale test assertion descriptions that referred to "current milestone metadata".
- Updated a stale worker/protocol `ui-error` message that referred to stale Wasm phase metadata as "Milestone" metadata.
- Added exact rendered Simulator Messages coverage for changed parser diagnostic wording.
- Added exact protocol coverage for the stale-Wasm worker message wording.
- Added static audit coverage to prevent live milestone-relative wording from returning in current source, web source, tests, README, and supported-syntax documentation.
- Preserved all completed Milestone 56A behavior and all runtime behavior through Phase 56 - Unsigned DIV.

Repository/archive milestone:

```text
Phase 56B - User-Facing Diagnostic Wording Cleanup
```

Runtime/source-run MASM behavior phase:

```text
Phase 56 - Unsigned DIV
```

Status interpretation:

The repository/archive milestone is newer than the runtime/source-run MASM behavior phase because this target phase did not add MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser controls, browser layout, browser interaction behavior, diagnostic codes, diagnostic JSON fields, or rendered Simulator Messages wording categories. Do not update runtime/source-run phase metadata, supported-syntax runtime wording, or tests that assert runtime phase values unless a later target phase explicitly owns that change.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 56A report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_56A.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 56B is the only target milestone for this implementation session.
- Phase 56B is inserted after Phase 56A and before Phase 57. It does not renumber Phase 57.
- Phase 56B advances repository/archive status but does not advance runtime/source-run MASM behavior metadata.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source remains `.c` and `.h` for C components.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- User-visible diagnostics still have structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

### 3.1 Live diagnostic wording cleanup

Implemented stable wording for touched parser diagnostics. The cleanup removed milestone-relative phrasing and replaced it with wording that describes the actual accepted syntax or simulator boundary.

Updated diagnostic families include:

- unsupported `TYPE` expression forms;
- unsupported `LENGTHOF` expression forms;
- unsupported `SIZEOF` expression forms;
- unsupported destination widths;
- generic unsupported instruction diagnostics;
- unsupported/repeated/out-of-order section directive diagnostics;
- text `EQU` / `TEXTEQU` diagnostics;
- known but unsupported Irvine32 routine diagnostics where live wording needed stable deferral language.

After user feedback, the changed diagnostics were tightened so they do not merely say "use the supported form." They now state the accepted syntax shape and provide examples where useful.

Representative final wording:

```text
Unsupported TYPE expression. Write TYPE followed by exactly one declared data symbol, for example TYPE nums. Arithmetic, bracketed operands, and nested expressions are not accepted in TYPE operands.
```

```text
Unsupported LENGTHOF expression. Write LENGTHOF followed by exactly one declared data symbol, for example LENGTHOF nums. Arithmetic, bracketed operands, and nested expressions are not accepted in LENGTHOF operands.
```

```text
Unsupported SIZEOF expression. Write SIZEOF followed by exactly one declared data symbol, for example SIZEOF nums. Arithmetic, bracketed operands, and nested expressions are not accepted in SIZEOF operands.
```

```text
Unsupported instruction. This mnemonic has no executable behavior in MASM32 Educational Mode; use an implemented instruction listed in docs/SUPPORTED_SYNTAX.md.
```

```text
Text EQU constants are not accepted. Define numeric equates with NAME EQU constant-expression, for example COUNT EQU 4; text substitution forms such as NAME EQU <text> and TEXTEQU are not implemented.
```

Preserved for all changed diagnostics:

- existing diagnostic codes;
- existing diagnostic severities/kinds;
- source line;
- source column;
- byte offset;
- span length;
- JSON field names;
- assembly-error blocking behavior where already blocking;
- non-execution for parse-error/assembly-error programs.

### 3.2 Current-status documentation cleanup

Updated current-status documentation to use explicit labels instead of vague current-milestone phrasing.

Updated `README.md` and `docs/SUPPORTED_SYNTAX.md` to state:

```text
Repository/archive milestone:
Phase 56B - User-Facing Diagnostic Wording Cleanup

Runtime/source-run MASM behavior phase:
Phase 56 - Unsigned DIV
```

Also clarified that Phase 56B is wording/current-status/test-maintenance work only and does not add MASM syntax or runtime behavior.

### 3.3 Runtime metadata wording cleanup

Updated test assertion descriptions that said "current milestone metadata" so they now say "runtime/source-run MASM behavior phase metadata."

Preserved actual runtime/source-run phase metadata value:

```text
"phase":56
```

No runtime metadata was advanced to 56B.

### 3.4 Worker/protocol stale-Wasm wording cleanup

Updated the worker/protocol stale-Wasm `ui-error` wording from milestone-relative wording to runtime/source-run behavior-phase wording.

The protocol test now asserts the exact changed stale-Wasm wording.

### 3.5 Static audit coverage

Added a static audit under `scripts/run_tests.py --static` that scans live surfaces for forbidden milestone-relative wording.

The audit scans:

- `src/`
- `web/src/`
- `web/index.html`
- `tests/`
- `README.md`
- `docs/SUPPORTED_SYNTAX.md`

The audit intentionally allows negative assertions that prove forbidden phrases are absent from user-facing output, such as test helper calls named `expect_json_not_contains` or `assert_text_not_contains`.

Historical reports, archives, generated artifacts, and explanatory guide text are not treated as live current-status surfaces by this check.

### 3.6 Test expectation updates

Updated exact expected strings in:

- source-run tests;
- parser-related source-run assertions;
- exact rendered Simulator Messages tests;
- protocol tests;
- data-section diagnostic tests where text `EQU` wording changed;
- structure/static checks that referenced old supported-syntax status wording.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 56B:

- `idiv` or any signed division behavior;
- any new runtime instruction;
- any new MASM syntax;
- parser acceptance changes;
- executor behavior changes;
- VM behavior changes;
- memory model changes;
- Wasm API behavior changes;
- browser controls;
- browser layout changes;
- browser interaction changes;
- new diagnostic codes;
- new diagnostic JSON fields;
- new diagnostic policies;
- new diagnostic severities;
- new rendered Simulator Messages categories;
- labels, jumps, conditional jumps, `cmp`, or `loop`;
- stack behavior;
- procedure behavior;
- Irvine32 routine expansion;
- macro expansion;
- WinAPI behavior;
- PE loading;
- object linking;
- host include loading;
- Extended 32-bit Mode behavior;
- executable QWORD/SQWORD memory operations.

The next planned runtime behavior milestone remains Phase 57 - Signed IDIV.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 56B may update diagnostic message text but must preserve diagnostic codes, severity/kind, source locations, span metadata, and JSON field names.
- **Reason:** The guide defines Phase 56B as wording cleanup and test maintenance, not diagnostic-schema work.
- **Risk:** A wording audit can reveal a deeper diagnostic classification issue that would be tempting to fix immediately.
- **How to change later:** If a diagnostic code or schema field is truly wrong, handle that in a later explicitly scoped diagnostic-correction phase or obtain explicit user approval before changing schema behavior.

### Assumption 2

- **Assumption:** Runtime/source-run MASM behavior phase remains Phase 56 after Phase 56B.
- **Reason:** Phase 56B does not add MASM syntax, parser acceptance, VM execution, executor behavior, Wasm behavior, or diagnostic categories.
- **Risk:** Documentation or tests may appear "behind" the repository milestone unless they clearly distinguish repository/archive milestone from runtime/source-run MASM behavior phase.
- **How to change later:** Phase 57 - Signed IDIV should intentionally advance runtime/source-run MASM behavior metadata when it implements runtime behavior.

### Assumption 3

- **Assumption:** Static audit coverage belongs under `scripts/run_tests.py --static`.
- **Reason:** Phase 56A decomposed test groups and established `--static` as the home for runner/documentation consistency and self-checks.
- **Risk:** Static wording checks can become noisy if they scan historical documents or examples explaining forbidden wording.
- **How to change later:** Keep the scanned live-surface set explicit and add narrow allow rules for legitimate negative assertions or historical contexts.

### Assumption 4

- **Assumption:** Stable deferral wording may name a future phase or feature when it is concrete and not milestone-relative.
- **Reason:** The guide allows stable planned-future wording and forbids vague phrases such as "current milestone" or "this milestone."
- **Risk:** A future assistant could overcorrect and delete useful future-owner information.
- **How to change later:** Keep future references precise, such as "Phase 57 - Signed IDIV" or "Extended 32-bit Mode," and avoid saying merely "future milestone" unless it is inside guide/historical text.

### Assumption 5

- **Assumption:** The Prompt 7 manual browser diagnostics needed later correction after user feedback changed the implemented messages.
- **Reason:** The user correctly identified that the first cleaned diagnostics were stable but too vague. The implementation and tests were then updated.
- **Risk:** A user following the earlier Prompt 7 strings would see correct current behavior but think the output mismatched.
- **How to change later:** Use the final report's manual/browser testing guidance, not the earlier Prompt 7 expected strings, for Phase 56B verification.

## 6. Relevant TODO-style notes reviewed

### Target-owned seed findings

- **Location:** `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, Phase 56B seed findings.
- **Note text or summary:** Phase 56A follow-up audit identified milestone-relative or assistant-confusing wording in parser diagnostics, README current-scope wording, supported-syntax wording, and test assertion descriptions.
- **Classification:** target-owned.
- **Reason:** These findings directly define Phase 56B work.
- **Action for this milestone:** Resolved through diagnostic wording cleanup, documentation status-label cleanup, assertion wording updates, rendered-message tests, protocol tests, and static audit coverage.

### Future memory-reading opcode TODO

- **Location:** `src/wasm/wasm_api.c`.
- **Note text or summary:** A future instruction-milestone TODO says each future memory-reading opcode should be added to planned-read handling when implemented.
- **Classification:** future-owned.
- **Reason:** Phase 56B is not an instruction or memory-reading opcode milestone. Phase 57 - Signed IDIV is the next likely owner if it adds memory-source signed division.
- **Action for this milestone:** Preserved unchanged.

### Deferred-feature references

- **Location:** README, supported-syntax docs, tests, and existing diagnostic wording.
- **Note text or summary:** Deferred references remain for Extended 32-bit Mode, QWORD/SQWORD executable memory operations, stack/procedure behavior, Irvine32 routine bodies, and other future systems.
- **Classification:** future-owned or irrelevant-to-target depending on exact occurrence.
- **Reason:** Stable deferred-feature wording is allowed when it describes a concrete future feature or simulator boundary.
- **Action for this milestone:** Preserved when accurate; corrected only milestone-relative live wording.

## 7. TODO-style note disposition

Target-owned TODO-style notes resolved:

- Phase 56B guide seed findings were resolved.
- Live parser diagnostics no longer use the forbidden current-milestone wording.
- README and supported-syntax docs now distinguish repository/archive and runtime/source-run behavior phases.
- Source-run test assertion descriptions no longer say "current milestone metadata."
- Static audit coverage was added to prevent recurrence.

Future-owned TODO-style notes intentionally preserved:

- `src/wasm/wasm_api.c` future memory-reading opcode TODO remains in place.
- Deferred feature references for stack, procedures, Irvine32 routines, macros, linker/WinAPI non-goals, and Extended 32-bit Mode remain where accurate.

Stale or contradicted TODO-style notes corrected:

- None found in changed files or nearby modules during final review.

Unresolved TODO-related risks:

- None blocking.

No new TODO-style notes were added.

## 8. Design summary

The implementation used a narrow wording-and-test-maintenance approach:

- Parser diagnostic text changed at the existing diagnostic call sites.
- No diagnostic enum values, JSON field names, parser acceptance paths, or runtime behavior paths were changed.
- Test assertion wording was updated to distinguish repository/archive milestone from runtime/source-run behavior phase.
- Documentation current-status text was made explicit and stable.
- Worker stale-Wasm wording was updated to describe the relevant status field as runtime/source-run MASM behavior phase metadata.
- Static audit coverage was added to the existing Phase 56A `--static` group.
- User feedback was incorporated by making diagnostics more actionable, including exact accepted forms and examples.

The key design rule was that Phase 56B must improve text without changing simulator semantics.

## 9. Files changed

Changed repository files:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/parser/parser.c`
- `tests/core/test_data_section.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/src/protocol.js`

No core header files were changed.

No new public C API, struct, enum, or module-level API was added.

No source/header file lost its file-level block comment.

## 10. Tests added

Added or updated test coverage includes:

- Exact rendered Simulator Messages fixture for unsupported `TYPE` expression wording.
- Exact rendered Simulator Messages fixture for unsupported `LENGTHOF` expression wording.
- Exact rendered Simulator Messages fixture for unsupported `SIZEOF` expression wording.
- Exact rendered Simulator Messages fixture for unsupported instruction wording.
- Exact rendered Simulator Messages fixture for post-code/out-of-order section diagnostic wording.
- Exact rendered Simulator Messages fixture for text `EQU` diagnostic wording.
- Source-run assertions for changed diagnostic text.
- Data-section diagnostic expectation for text `EQU` wording.
- Protocol assertion for stale-Wasm runtime/source-run behavior phase wording.
- Static audit check for forbidden live milestone-relative wording.
- Static documentation label check requiring repository/archive and runtime/source-run phase labels in README and supported syntax.

The tests preserve exact assertions for rendered output; they were not weakened to broad substring-only coverage for user-facing diagnostics.

## 11. Commands used to test

Focused group commands run during implementation and reviews:

```text
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command attempted:

```text
python3 scripts/run_tests.py --all
```

Subgroup or fixture-family commands:

- No additional documented subgroup or individual fixture-family command was needed. Focused groups were sufficient after aggregate timeout.

Skipped dependency checks:

- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.
- Website testing of C parser diagnostic wording requires a local Wasm rebuild with Emscripten before browser-visible C diagnostic text changes appear.

## 12. Pass/fail results

Focused group results:

```text
python3 scripts/run_tests.py --structure    PASS
python3 scripts/run_tests.py --native       PASS
python3 scripts/run_tests.py --source-run   PASS
python3 scripts/run_tests.py --web          PASS
python3 scripts/run_tests.py --diagnostics  PASS
python3 scripts/run_tests.py --protocol     PASS
python3 scripts/run_tests.py --static       PASS
```

Aggregate result:

```text
python3 scripts/run_tests.py --all          timed out in the assistant/container environment
```

Result classification:

```text
aggregate timed out but focused groups passed
```

The aggregate command did not complete in this assistant/container environment, so aggregate success is not claimed.

No focused group failed.

No focused group timed out and required fixture reruns.

Dependency skipped:

```text
emcc unavailable; browser/Wasm rebuild smoke skipped
```

## 13. Manual/browser testing guidance and expected outputs

Phase 56B can be tested locally through the decomposed test runner. It can also be tested on the served website after applying the changed files and rebuilding Wasm.

### 13.1 Windows CMD local tests

Use a Visual Studio Developer Command Prompt or another shell where Python, Node.js, and a GCC/Clang-compatible C compiler are available. If using Clang:

```cmd
set CC=clang
```

Run:

```cmd
py scripts\run_tests.py --diagnostics
py scripts\run_tests.py --protocol
py scripts\run_tests.py --static
py scripts\run_tests.py --source-run
```

Expected snippets:

```text
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
[source-run] PASS - source-run integration binary passed independently
Selected test groups passed.
```

Optional aggregate:

```cmd
py scripts\run_tests.py --all
```

Expected only if it completes locally:

```text
All implemented milestone tests passed.
```

### 13.2 Browser setup

Website/browser testing requires a Wasm rebuild because the changed parser diagnostics live in C source.

From Windows CMD with Emscripten available:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8080
```

Open:

```text
http://localhost:8080
```

Paste each source into the web editor with no leading blank line and click Run.

Stop server afterward:

```cmd
scripts\windows\stop_web.cmd
```

### 13.3 Browser manual program 1 - unsupported TYPE expression

Program:

```asm
.data
x DWORD 0
.code
main PROC
    mov eax, TYPE x + 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-type-expression line 5, column 21, byte offset 52, span length 1: Unsupported TYPE expression. Write TYPE followed by exactly one declared data symbol, for example TYPE nums. Arithmetic, bracketed operands, and nested expressions are not accepted in TYPE operands.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message appears.

### 13.4 Browser manual program 2 - unsupported LENGTHOF expression

Program:

```asm
.data
x DWORD 0
.code
main PROC
    mov eax, LENGTHOF x + 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-lengthof-expression line 5, column 25, byte offset 56, span length 1: Unsupported LENGTHOF expression. Write LENGTHOF followed by exactly one declared data symbol, for example LENGTHOF nums. Arithmetic, bracketed operands, and nested expressions are not accepted in LENGTHOF operands.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message appears.

### 13.5 Browser manual program 3 - unsupported SIZEOF expression

Program:

```asm
.data
x DWORD 0
.code
main PROC
    mov eax, SIZEOF x + 1
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-sizeof-expression line 5, column 23, byte offset 54, span length 1: Unsupported SIZEOF expression. Write SIZEOF followed by exactly one declared data symbol, for example SIZEOF nums. Arithmetic, bracketed operands, and nested expressions are not accepted in SIZEOF operands.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message appears.

### 13.6 Browser manual program 4 - unsupported instruction wording

Program:

```asm
.code
main PROC
    idiv ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-instruction line 3, column 5, byte offset 20, span length 4: Unsupported instruction. This mnemonic has no executable behavior in MASM32 Educational Mode; use an implemented instruction listed in docs/SUPPORTED_SYNTAX.md.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message appears.
- Message must not say "current milestone," "this milestone," "unsupported by the current milestone," or "not implemented in this milestone."

### 13.7 Browser manual program 5 - text EQU wording

Program:

```asm
NAME EQU <text>
.code
main PROC
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-equate line 1, column 10, byte offset 9, span length 1: Text EQU constants are not accepted. Define numeric equates with NAME EQU constant-expression, for example COUNT EQU 4; text substitution forms such as NAME EQU <text> and TEXTEQU are not implemented.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

- Program does not execute.
- No `execution-complete` message appears.

### 13.8 Regression signs during manual testing

Regression signs:

- Any local focused command prints `FAIL`.
- Browser diagnostic says "current milestone," "this milestone," "unsupported by the current milestone," or "not implemented in this milestone."
- Runtime/source-run metadata advances to Phase 56B. It should remain Phase 56 - Unsigned DIV.
- Parse-error programs produce Program Console output.
- Parse-error programs show `execution-complete`.
- Website tests still show old wording after rebuilding Wasm.

## 14. Compliance review summary

First compliance review found that README and supported-syntax current-status text did not fully use the explicit repository/archive and runtime/source-run label form required by Phase 56B.

Fixes applied:

- Updated `README.md` with the explicit status labels.
- Updated `docs/SUPPORTED_SYNTAX.md` with the explicit status labels.
- Added static checks requiring those labels.
- Updated a structure self-check that still expected the old `through Milestone 56` wording.

Focused tests rerun and passed.

Aggregate `--all` timed out in the assistant/container environment; focused groups passed.

## 15. Re-review summary

Second compliance review found one additional live worker/protocol wording issue:

- `web/src/protocol.js` stale-Wasm `ui-error` wording still said the module "reports Milestone" and the UI "expects Milestone."

Fixes applied:

- Updated the stale-Wasm message to use `runtime/source-run MASM behavior phase` wording.
- Updated `tests/web/test_protocol.mjs` to assert the exact new stale-Wasm message.
- Extended the static wording audit to include `web/index.html`.

Focused tests rerun and passed.

Aggregate `--all` timed out in the assistant/container environment; focused groups passed.

## 16. User-test follow-up summary

The user reported that the first cleaned diagnostics were still too vague because they said to use the "supported" form without explaining what is actually supported.

Follow-up fixes applied:

- Rewrote touched `TYPE`, `LENGTHOF`, and `SIZEOF` diagnostics to name the exact accepted shape and give concrete examples.
- Rewrote text `EQU` wording to explain numeric equates and text substitution forms.
- Tightened unsupported-instruction wording to explain that the mnemonic has no executable behavior in MASM32 Educational Mode and points to `docs/SUPPORTED_SYNTAX.md`.
- Updated exact rendered-message tests, source-run assertions, native tests, and manual expected outputs accordingly.

Focused tests rerun and passed:

- `--diagnostics`
- `--source-run`
- `--native`
- `--web`
- `--protocol`
- `--static`
- `--structure`

A combined multi-group run timed out after several groups had already passed, so remaining focused groups were rerun individually. Aggregate success was not claimed.

## 17. Known limitations

- Aggregate `python3 scripts/run_tests.py --all` timed out in the assistant/container environment. This is an environment limitation, not a demonstrated project failure. Focused groups passed.
- `emcc` is unavailable in the assistant/container environment, so browser/Wasm rebuild smoke was skipped.
- Browser-visible C parser diagnostic wording requires rebuilding the Wasm artifact locally before the served website shows the new messages.
- Phase 56B does not implement `idiv`; unsupported-instruction behavior for `idiv` remains an assembly diagnostic until Phase 57 - Signed IDIV is implemented.
- No latest repository archive was produced during the implementation prompts. A final repository archive should be produced separately by packaging the updated repository state.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57 - Signed IDIV
```

Phase 57 should implement signed division if the canonical guide still names it as the next runtime behavior phase after Phase 56B.

When Phase 57 is implemented, it should intentionally advance runtime/source-run MASM behavior metadata from Phase 56 to Phase 57 and should update the future-owned memory-reading opcode TODO where applicable.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the session:

- `milestone_56B_changed_files.zip`
- `milestone_56B_compliance_review_changed_files.zip`
- `milestone_56B_second_review_changed_files.zip`
- `milestone_56B_user_feedback_diagnostics_changed_files.zip`
- `milestone_56B_final_gap_check_changed_files.zip`

The recommended final changed-files package is:

```text
milestone_56B_final_gap_check_changed_files.zip
```

A latest full repository/archive package was not produced during the milestone prompts. If produced, it should be named:

```text
Latest_repository_state_milestone_56B.zip
```

## 20. Final status

Milestone 56B is complete.

Final status:

- Target milestone implemented: yes.
- Future milestone behavior avoided: yes.
- Runtime/source-run MASM behavior metadata preserved at Phase 56: yes.
- User-visible diagnostic wording improved and tested: yes.
- README and supported-syntax current-status labels corrected: yes.
- Static audit added and passing: yes.
- Protocol stale-Wasm wording corrected and tested: yes.
- Target-owned TODO-style findings resolved: yes.
- Future-owned TODO-style notes preserved: yes.
- Aggregate test result: timed out in assistant/container environment.
- Focused group result: all relevant focused groups passed.
