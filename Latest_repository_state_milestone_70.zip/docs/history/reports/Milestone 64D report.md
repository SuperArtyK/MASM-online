# Milestone 64D report - Memory Change Source Attribution Display

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 64D - Memory Change Source Attribution Display
```

Repository/archive milestone after this work:

```text
Phase 64D - Memory Change Source Attribution Display
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 64A - Planned-Read Coverage Correction for Existing Memory-Reading Instructions
```

Status interpretation:

Phase 64D changes source-run result metadata and browser-rendered memory-change display only. It does not add MASM syntax, parser behavior, VM instruction behavior, executor semantics, new diagnostics, new diagnostic-policy families, new memory-validation policy behavior, or new memory-write semantics. Runtime/source-run MASM behavior phase metadata therefore remains Phase 64A.

Scope implemented:

- Successful source-run memory-change rows now carry source attribution when the write came from a parsed source instruction.
- Memory-change JSON entries include `sourceLine` when source line metadata is available.
- Memory-change JSON entries include `sourceText` when preserved original instruction text is available.
- Browser memory-change display renders non-compact attribution with the exact preserved source line text, for example:

  ```text
  a DWORD | line 10: inc a
  ```

- Attribution identifies the instruction that caused the write, not an earlier address setup instruction.
- Direct memory writes, read-modify-write memory destinations, indirect writes, symbol-offset writes, repeated writes on different lines, and existing `xchg reg, mem` writes are covered.
- Failed writes continue to produce no successful memory-change rows.
- Read-only/no-write instructions continue to produce no memory-change rows.
- Existing memory-value formatting, symbol/offset display, Program Console behavior, Simulator Messages behavior, and Phase 64B message grouping/order are preserved.
- `web/index.html` was updated to reflect Phase 64D and its default page-load program now demonstrates memory-change source attribution.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_64D.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, audit, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 64C report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_64C.zip
```

Changed-files packages produced during implementation and review:

```text
milestone_64D_implementation.zip
milestone_64D_second_compliance_check.zip
milestone_64D_final_compliance_check.zip
```

No `milestone_64D_first_compliance_check.zip` was produced because the first compliance pass found no project-file changes to apply.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, UI stream separation, current-status surface hygiene, stable display/source-run behavior expectations, and future/non-goal distinctions.
- The incremental implementation guide owns Phase 64D numbering, scope, tasks, required tests, acceptance criteria, status wording, and milestone-report obligations.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or guide.
- TODO-style notes are implementation-risk evidence only and do not override the target milestone, canonical guide, or canonical specification.

## 3. Exact requirements implemented

### 3.1 Source attribution in memory-change JSON

Successful source-run memory-change entries now include source attribution fields where the write-producing instruction has source metadata:

```json
"sourceLine": 10,
"sourceText": "inc a"
```

`sourceLine` uses the existing 1-based user-facing line-number convention used by diagnostics. `sourceText` is the preserved original instruction text from the parsed source instruction. The implementation does not reconstruct source text from opcode or operand metadata.

### 3.2 Non-compact rendered memory-change attribution

The browser formatter now renders memory-change source attribution in the memory-change label line when source metadata exists:

```text
a DWORD | line 10: inc a
```

When `sourceText` is unavailable but `sourceLine` exists, the formatter can render a line-only attribution. When source attribution is unavailable, the formatter does not invent a fake line number or fake source text.

### 3.3 Correct write-producing instruction attribution

Attribution identifies the instruction that actually caused the memory mutation.

Implemented and tested examples include:

```asm
mov a, 1
inc a
mov eax, OFFSET a
mov DWORD PTR [eax], 20
xchg ebx, a
mov nums[8], 100
```

For an indirect write, attribution points to the write instruction:

```asm
mov DWORD PTR [eax], 20
```

It does not point to the earlier address setup instruction:

```asm
mov eax, OFFSET a
```

### 3.4 Existing memory-change behavior preserved

Phase 64D does not change when a memory-change row is created. It only adds source attribution to rows that already exist or should exist for existing successful memory writes.

Preserved behavior includes:

- failed writes produce no memory-change row;
- read-only/no-write instructions produce no memory-change row;
- old/new value display remains unchanged;
- signed/unsigned memory display from Phase 52A remains unchanged;
- symbol-offset display remains unchanged;
- `byte offset` and `element index` info rows remain unchanged;
- `.CONST` write protection remains mandatory;
- Program Console and Simulator Messages remain separate streams.

### 3.5 `xchg reg, mem` correction from second compliance pass

The second compliance review found that the first implementation did not surface source-attributed memory-change rows for `xchg reg, mem`, where the written memory operand is the source operand in instruction syntax.

The final implementation updates symbolic memory-change collection to inspect either instruction operand where appropriate and attribute the memory-change row to the write-producing instruction.

Example covered:

```asm
xchg eax, a
```

Expected rendered memory-change label shape:

```text
a DWORD | line N: xchg eax, a
```

### 3.6 Default page-load program updated

`web/index.html` status text reflects Phase 64D. The default editor source was also updated during the final gap check so the default page-load program demonstrates Phase 64D memory-change source attribution while preserving an equality-conditional-jump smoke path.

### 3.7 Current-status metadata preserved correctly

Repository/archive current-status surfaces were advanced to Phase 64D.

Runtime/source-run MASM behavior phase metadata remains Phase 64A because Phase 64D changes source-run result metadata and display formatting only.

Updated status/static surfaces include:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `web/index.html`

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 64D:

- New MASM syntax.
- New parser behavior.
- New VM instruction behavior.
- New executor semantics.
- New memory operand forms.
- New memory-validation policies.
- New planned-read or planned-write behavior.
- New diagnostic codes.
- New diagnostic-policy families.
- New rendered Simulator Messages diagnostic categories.
- Changes to `.CONST` write protection.
- Changes to uninitialized-read behavior.
- Changes to undefined-flag-use behavior.
- Changes to same-value-write row-creation semantics.
- Changes to Program Console behavior.
- Changes to Simulator Messages ordering or grouping.
- Clickable source links.
- Hover text for memory-change rows.
- Expandable memory-change rows.
- CodeMirror gutter behavior.
- Source highlighting.
- Debugger stepping behavior.
- Branch or jump behavior.
- Signed relational conditional jumps.
- Unsigned relational conditional jumps.
- `loop` or loop-family instructions.
- Indirect/register/memory/immediate jump targets.
- Stack instructions such as `push`, `pop`, `call`, `ret`, or `leave`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 callable routines beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Macro expansion.
- `OPTION NOKEYWORD` behavior or dynamic keyword-table mutation.
- Active-time watchdog behavior.
- Worker yielding/chunking for responsiveness.

Future work intentionally preserved:

- Phase 65 - Signed Relational Conditional Jumps.
- Later unsigned relational conditional jumps.
- Later `loop` runtime behavior.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future UI affordances for memory-change attribution such as hover text, expandable rows, clickable links, and source highlighting.
- Future Irvine32 routine expansion.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- Future memory-reading opcode planned-access additions when those future opcodes are implemented.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Non-compact rendering should show both line number and exact preserved source instruction text when available.
- **Reason:** The user explicitly requested non-compact rendering showing the exact line of code that caused the mutation.
- **Risk:** Long source lines may make memory-change rows wider than before.
- **How to change later:** A later UI/display phase may add truncation, wrapping, hover text, expandable details, or editor navigation. Those behaviors were not added in Phase 64D.

### Assumption 2

- **Assumption:** `sourceText` should be carried from existing preserved instruction text, not reconstructed from internal IR.
- **Reason:** The Phase 64D requirement is source attribution, and the user requested the exact line of code. Reconstructing source text from opcode/operand metadata could produce non-original formatting and would be more error-prone.
- **Risk:** If a future source-less or synthesized runtime write exists, no exact user source text may be available.
- **How to change later:** Add a documented nullable/fallback representation for source-less writes. The current implementation avoids fabricated source text.

### Assumption 3

- **Assumption:** Existing memory-change row creation semantics must remain unchanged.
- **Reason:** Phase 64D is a metadata/display milestone. It must not change executor semantics, memory-write semantics, or same-value-write policy.
- **Risk:** Some users may expect every syntactic write, including same-value writes, to appear as a memory-change row.
- **How to change later:** A future explicit-write display policy phase could revisit row creation semantics. Phase 64D only attributes rows that are produced by current behavior.

### Assumption 4

- **Assumption:** Runtime/source-run MASM behavior metadata remains Phase 64A.
- **Reason:** Phase 64D does not add MASM syntax or execution semantics. It changes source-run result metadata and rendered memory-change display.
- **Risk:** Users may see repository/archive Phase 64D while runtime/source-run metadata remains Phase 64A and misread it as stale.
- **How to change later:** Continue using explicit dual-status wording in current documentation, status summaries, and milestone reports.

### Assumption 5

- **Assumption:** No new rendered Simulator Messages diagnostics are required because Phase 64D does not add diagnostic paths.
- **Reason:** Phase 64D affects memory-change result JSON and browser memory-change display. It does not add or alter warning/error diagnostics.
- **Risk:** Diagnostic-rendering fixtures might still need regression coverage when they display memory changes alongside existing Simulator Messages.
- **How to change later:** Keep memory-change display coverage in web formatter and native/Node diagnostic-rendering integration tests, as implemented.

### Assumption 6

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in the assistant/container environment.
- **Risk:** A locally served browser could show stale behavior if Wasm artifacts are not rebuilt after applying C source changes.
- **How to change later:** On Windows, activate Emscripten with `call C:\_CPP_TOOLS\emsdk\emsdk_env.bat`, run `scripts\windows\build_wasm.cmd`, then serve the site.

## 6. Relevant TODO-style notes reviewed

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 64D section
- Note text or summary:
  The listed memory-destination forms are current-behavior reminders only and are not permission to implement future instruction forms early.
- Classification:
  target-owned
- Reason:
  This note directly constrains Phase 64D implementation scope. Phase 64D may add source attribution to existing memory-change rows but must not add missing/future instruction forms.
- Action for this milestone:
  Respected. The implementation adds attribution only for existing successful memory-write behavior. It does not add future instruction forms.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 64D section
- Note text or summary:
  If source attribution is unavailable for a future source-less or synthesized runtime write, the implementation must not invent a fake source line.
- Classification:
  target-owned
- Reason:
  This note directly controls the source-attribution data model.
- Action for this milestone:
  Respected. Source attribution is emitted only from existing instruction source metadata. No fake source line or fake source text is fabricated.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 64D section
- Note text or summary:
  Later UI/debugger phases may add hover text, expandable rows, click-to-source navigation, source highlighting, or editor integration.
- Classification:
  future-owned
- Reason:
  These are explicitly future UI/debugger features outside Phase 64D.
- Action for this milestone:
  Preserved the deferral. Phase 64D renders plain non-clickable source attribution only.
```

```text
- Location:
  src/wasm/wasm_api.c near planned-read collection
- Note text or summary:
  Future memory-reading opcodes must be added to planned-read collection when their owning instruction milestones implement them.
- Classification:
  future-owned
- Reason:
  Phase 64D does not add memory-reading opcodes, new instruction behavior, or planned-read behavior.
- Action for this milestone:
  Left unchanged.
```

```text
- Location:
  README.md, docs/SUPPORTED_SYNTAX.md, docs/BUILDING_AND_DEVELOPMENT.md, docs/MILESTONE_HISTORY.md, and related deferred-feature notes
- Note text or summary:
  Signed relational jumps, unsigned relational jumps, loop, stack/procedure behavior, debugger/editor behavior, active-time watchdog behavior, and related branch/call features remain deferred.
- Classification:
  future-owned
- Reason:
  Phase 64D changes only memory-change source attribution display and source-run result metadata.
- Action for this milestone:
  Preserved these deferrals.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 64D current-behavior-only reminder was resolved by implementation discipline and regression coverage. Existing memory-write forms were attributed; future instruction forms were not implemented.
- Phase 64D no-fake-source-location rule was resolved by using existing instruction metadata and avoiding fabricated line numbers/source text.

### Future-owned TODO-style notes intentionally preserved

- Future UI/debugger source navigation, hover text, expandable rows, CodeMirror integration, and source highlighting remain deferred.
- Future memory-reading opcode planned-read TODO in `src/wasm/wasm_api.c` remains valid.
- Future signed/unsigned relational jumps, `loop`, stack/procedure, Irvine32 callable routines, macro behavior, and active-time watchdog work remain deferred.

### Stale or contradicted TODO-style notes corrected

- None found for Phase 64D.

### Unresolved TODO-related risks

- None specific to Phase 64D.

### New TODO-style notes added

- None.

## 8. Design summary

Phase 64D was implemented as a focused source-run metadata and display enhancement.

Primary design choices:

1. **Use preserved source metadata.** Memory-change attribution uses the executing instruction's preserved source line and source text.

2. **Avoid reconstruction.** The implementation does not reconstruct source text from internal opcode/operand formatting. This preserves user spelling, spacing, and instruction text as already stored by the parser/source-run path.

3. **Attach attribution during memory-change JSON collection.** The source-run JSON producer adds `sourceLine` and `sourceText` to each successful memory-change entry where available.

4. **Support either written operand.** The second compliance pass corrected `xchg reg, mem` by allowing symbolic memory-change collection to inspect either operand where the existing instruction can write memory through the source operand.

5. **Formatter-side rendering.** The browser formatter renders attribution in the memory-change label line. Existing old/new value rows and info rows remain unchanged.

6. **Plain display only.** No clickable links, editor integration, hover UI, or debugger/source navigation behavior was added.

7. **Strict scope.** No syntax, executor semantics, diagnostics, policies, or future milestone behavior were implemented.

8. **Status-surface hygiene.** Documentation and `web/index.html` identify repository/archive Phase 64D while preserving runtime/source-run MASM behavior Phase 64A.

## 9. Files changed

Changed project files in the final Phase 64D state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/wasm/wasm_api.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_formatters.mjs`
- `web/index.html`
- `web/src/formatters.js`

Generated/native build artifacts may have been created or updated by local test runs under build directories. They are not treated as source changes for milestone design purposes.

## 10. Tests added

### 10.1 Source-run JSON tests

Added source-run tests covering:

- direct symbol write attribution;
- read-modify-write memory-destination attribution;
- indirect write attribution pointing to the write instruction rather than the address setup instruction;
- repeated writes to the same symbol on different lines;
- `xchg reg, mem` attribution where the memory write is through the source operand;
- same-value write regression preserving existing no-row behavior where applicable;
- failed `.CONST` write producing no memory-change row;
- read-only/no-write instruction producing no memory-change row;
- source line and source text fields in JSON.

### 10.2 Browser formatter tests

Added or updated formatter tests covering:

- non-compact `line N: <source text>` attribution rendering;
- line-only fallback when source text is unavailable;
- absence of fabricated source attribution when no source line exists;
- preservation of existing old/new value formatting;
- preservation of symbol-offset display;
- preservation of `byte offset` and `element index` info rows.

### 10.3 Native/Node diagnostic-rendering integration tests

Added or updated diagnostic-rendering integration tests covering:

- direct and read-modify-write memory attribution display;
- indirect write attribution display;
- `xchg reg, mem` memory-change attribution display;
- signed memory-display regression with attribution;
- unchanged Simulator Messages behavior for successful and failing programs where relevant.

### 10.4 Static/status tests

Updated static/status checks to verify:

- repository/archive milestone text is Phase 64D;
- runtime/source-run MASM behavior phase remains Phase 64A;
- documentation describes Phase 64D as source-run result metadata and rendered memory-change display only;
- documentation does not claim Phase 64D adds MASM syntax, VM semantics, or new diagnostics;
- `web/index.html` reflects Phase 64D;
- default page-load source demonstrates Phase 64D memory-change source attribution.

### 10.5 Regression tests preserved

Retained and reran regression coverage for:

- Phase 64A planned-read behavior;
- Phase 64B Simulator Messages grouping/order;
- Phase 64C expanded EFLAGS display;
- Program Console and Simulator Messages stream separation;
- `.CONST` write failure behavior;
- existing memory-change old/new value formatting;
- source-run and web formatter behavior.

## 11. Commands used to test

### 11.1 Initial implementation test pass

The initial implementation pass ran focused groups and the aggregate suite.

Commands reported:

```text
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Initial implementation result:

```text
Focused groups: PASS
Aggregate: PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

### 11.2 First compliance review test pass

Commands rerun:

```text
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --all
```

First compliance result:

```text
Focused groups: PASS
Aggregate: timed out in assistant/container environment before final aggregate status
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

A combined command that chained native/source-run/web also timed out during the web portion, but `--web` passed when rerun separately.

### 11.3 Second compliance review test pass

Commands rerun:

```text
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Second compliance result:

```text
Focused groups: PASS
Aggregate: timed out in assistant/container environment before final aggregate status
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

### 11.4 Final gap-check test pass

Commands rerun after the final `web/index.html` default-program/status-check fix:

```text
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --all
```

Final gap-check result:

```text
Focused groups rerun after final fix: PASS
Aggregate: timed out in assistant/container environment before final aggregate status
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

## 12. Pass/fail results and classifications

Final authoritative verification classification after all Phase 64D fixes:

```text
Focused groups passed.
Aggregate timed out in the assistant/container environment after final changes.
Browser/Wasm rebuild smoke skipped because emcc was unavailable.
```

Detailed classifications:

- `python3 scripts/run_tests.py --structure`: focused group passed.
- `python3 scripts/run_tests.py --native`: focused group passed.
- `python3 scripts/run_tests.py --source-run`: focused group passed.
- `python3 scripts/run_tests.py --web`: focused group passed.
- `python3 scripts/run_tests.py --diagnostics`: focused group passed.
- `python3 scripts/run_tests.py --protocol`: focused group passed.
- `python3 scripts/run_tests.py --static`: focused group passed.
- `python3 scripts/run_tests.py --all`: aggregate timed out in the assistant/container environment during compliance/final passes and was not claimed as a final aggregate success after the final gap-check change.
- Browser/Wasm rebuild smoke: dependency skipped because `emcc` was unavailable.

No focused group failed. No focused group required fixture-family reruns after individual focused execution. The only timeouts were aggregate or combined-command environment/tool timeouts, not reproducible focused-group failures.

## 13. Manual/browser testing guidance and expected outputs

Phase 64D is website-testable after applying the changed files and rebuilding Wasm. The C/Wasm source-run JSON producer changed, so browser testing requires an Emscripten rebuild.

Windows CMD setup for browser testing:

```bat
call C:\_CPP_TOOLS\emsdk\emsdk_env.bat
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Then open the local URL printed by the serve script.

### Manual browser test 1 - direct write and read-modify-write attribution

Program:

```asm
.data
a DWORD 0

.code
main PROC
    mov a, 1
    inc a
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Expected relevant Memory Changes:

```text
a DWORD | line 6: mov a, 1
  old | 00000000h / u: 0          / s:  0
  new | 00000001h / u: 1          / s:  1

a DWORD | line 7: inc a
  old | 00000001h / u: 1          / s:  1
  new | 00000002h / u: 2          / s:  2
```

Regression signs:

- missing `line N: source text` in memory changes;
- `inc a` row points to the wrong line;
- Program Console contains diagnostics;
- `execution-complete` is missing.

### Manual browser test 2 - indirect write, `xchg reg, mem`, and symbol-offset attribution

Program:

```asm
.data
a DWORD 10
nums DWORD 4 DUP(0)

.code
main PROC
    mov eax, OFFSET a
    mov DWORD PTR [eax], 20
    mov ebx, 33
    xchg ebx, a
    mov nums[8], 100
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Expected relevant Registers:

```text
EAX = 00500000h
EBX = 00000014h
```

Expected relevant Memory Changes:

```text
a DWORD | line 8: mov DWORD PTR [eax], 20
  old | 0000000Ah / u: 10         / s:  10
  new | 00000014h / u: 20         / s:  20

a DWORD | line 10: xchg ebx, a
  old | 00000014h / u: 20         / s:  20
  new | 00000021h / u: 33         / s:  33

nums + 8 DWORD | line 11: mov nums[8], 100
  old | 00000000h / u: 0          / s:  0
  new | 00000064h / u: 100        / s:  100
  info| byte offset +8, element index 2
```

Regression signs:

- indirect write row points to `mov eax, OFFSET a` instead of `mov DWORD PTR [eax], 20`;
- `xchg ebx, a` row is missing;
- `nums + 8 DWORD` loses the `byte offset` / `element index` info row;
- line numbers are absent or wrong.

### Manual browser test 3 - failed `.CONST` write must not create a memory-change row

Program:

```asm
.CONST
limit DWORD 10

.code
main PROC
    mov eax, OFFSET limit
    mov DWORD PTR [eax], 20
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[runtime-error] permission-denied line 7: Memory write at 00600000h for 4 bytes is not permitted in .const.
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

Regression signs:

- a memory-change row appears for the failed `.CONST` write;
- `execution-complete` appears after the runtime error;
- the runtime error points to line 6 instead of line 7.

### Windows CMD local test-suite guidance

From the project root after applying the final Phase 64D changed-files package:

```bat
python scripts\run_tests.py --source-run
python scripts\run_tests.py --web
python scripts\run_tests.py --diagnostics
```

Expected snippets:

```text
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
```

Recommended broader verification:

```bat
python scripts\run_tests.py --structure
python scripts\run_tests.py --native
python scripts\run_tests.py --protocol
python scripts\run_tests.py --static
```

Expected snippets:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
```

Optional aggregate command:

```bat
python scripts\run_tests.py --all
```

Expected final output in a local environment where the aggregate completes:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

If Emscripten is available and the build smoke is enabled by the test runner, the browser/Wasm smoke should build rather than skip.

## 14. Compliance review summary

### First compliance review

Result:

```text
Verdict: complete
```

Findings:

- No implementation compliance defects found.
- No project files changed during the first compliance pass.
- Focused verification passed for all available groups.
- Aggregate timed out in the assistant/container environment before final aggregate status.
- Browser/Wasm rebuild smoke remained skipped because `emcc` was unavailable.

TODO review:

- Target-owned TODO-style notes were satisfied by implementation behavior and tests.
- Future-owned TODO-style notes were preserved.
- No stale TODO-style notes were found.
- No new TODO-style notes were added.

### Second compliance review

Result:

```text
Verdict: complete after fix
```

Issue found and fixed:

- `xchg reg, mem` is an existing implemented memory-writing instruction form named in the Phase 64D guide's read-modify-write attribution reminder.
- The first implementation did not surface a source-attributed memory-change row when the written memory operand was the source operand, as in `xchg eax, a`.
- `src/wasm/wasm_api.c` was updated so symbolic memory-change collection can inspect either instruction operand where appropriate.
- Source-run JSON and diagnostic-rendering tests were added for `xchg reg, mem`.

Verification:

- All focused groups passed.
- Aggregate timed out in the assistant/container environment before final aggregate status.
- Browser/Wasm rebuild smoke remained skipped because `emcc` was unavailable.

## 15. Re-review summary

Final gap check result:

```text
Verdict: complete after final default-program/status-check fix
```

Issue found and fixed:

- `web/index.html` had correct Phase 64D milestone text, but the default editor program still demonstrated equality-conditional-jump behavior only.
- Because the final checklist explicitly called out default code, the default program was updated to also produce Phase 64D memory-change source attribution.
- Static checks were updated to verify the default page-load program contains the Phase 64D memory-write lines.

Verification after final fix:

- Relevant focused tests passed:
  - `--static`
  - `--web`
  - `--structure`
  - `--source-run`
- Aggregate timed out in the assistant/container environment before final aggregate status.

## 16. User-test follow-up summary

Prompt 8 was not run. The user reported that everything appeared to pass and proceeded directly to the final gap check.

No user-test discrepancies were provided, so no user-test triage fixes were required.

## 17. Known limitations

- Final aggregate verification was not completed after the final gap-check change in the assistant/container environment because `python3 scripts/run_tests.py --all` timed out before final aggregate status.
- Focused test groups relevant to the changed areas passed after final changes.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.
- Browser testing requires a local Emscripten rebuild because `src/wasm/wasm_api.c` changed.
- Phase 64D plain display does not add clickable source links, hover text, expandable rows, CodeMirror integration, source highlighting, or debugger/editor behavior.
- Source attribution is emitted only when source metadata exists. The implementation does not fabricate source lines for source-less or synthesized future writes.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 65 - Signed Relational Conditional Jumps
```

Phase 65 should begin only after accepting the Phase 64D final state and archiving it as:

```text
Latest_repository_state_milestone_64D.zip
```

## 19. Changed-files ZIP/package produced

Produced packages:

```text
milestone_64D_implementation.zip
milestone_64D_second_compliance_check.zip
milestone_64D_final_compliance_check.zip
```

No first-compliance package was produced because no files changed during the first compliance pass.

The final compliance package contains the final gap-check changes:

```text
milestone_64D_final_compliance_check.zip
```

Recommended final repository archive name:

```text
Latest_repository_state_milestone_64D.zip
```
