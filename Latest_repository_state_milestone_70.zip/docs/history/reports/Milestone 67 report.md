# Milestone 67 report - Arithmetic, Branch, and Watchdog Integration Harness

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 67 - Arithmetic, Branch, and Watchdog Integration Harness
```

Repository/archive milestone after this work:

```text
Phase 67 - Arithmetic, Branch, and Watchdog Integration Harness
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 66 - Unsigned Relational Conditional Jumps
```

Status interpretation:

Phase 67 is a validation-only integration-harness milestone. It does not add MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser controls, browser interaction behavior, diagnostic codes, diagnostic JSON fields, or new rendered Simulator Messages categories. The repository/archive milestone advances to Phase 67 because new tests, documentation/status text, and default-source orientation were added. The runtime/source-run MASM behavior phase intentionally remains Phase 66 because the latest runtime-visible MASM behavior remains the unsigned relational conditional jump work completed in Phase 66.

Scope implemented:

- Native executor harness coverage for arithmetic fault no-partial-mutation behavior.
- Native executor harness coverage for malformed branch-runtime metadata failure behavior that ordinary source cannot reach.
- Source-run integration harness coverage combining `cmp`, equality Jcc, signed relational Jcc, unsigned relational Jcc, and `jmp` in one program.
- Source-run harness coverage proving selected existing arithmetic and branch instructions produce no successful memory-change rows in a no-write fixture.
- Source-run and rendered-message coverage for instruction-count watchdog behavior using already-implemented `cmp`, Jcc, and `jmp`.
- Rendered Simulator Messages coverage for one branch-target classifier diagnostic, one division runtime diagnostic, and one instruction-limit diagnostic.
- Runner/static/status updates so Phase 67 is part of normal verification.
- `web/index.html` status/default-source update to identify Milestone 67 while preserving runtime MASM support as Phase 66.

This milestone intentionally did not implement new runtime behavior. It is test coverage and status/documentation work for already-implemented features.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_67.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, audit, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 66 report.md`
- latest repository archive derived from `LATEST_COMPLETED_MILESTONE = 66A`:

```text
Latest_repository_state_milestone_66A.zip
```

Changed-files packages produced during implementation and review:

```text
milestone_67_implementation.zip
milestone_67_first_compliance_check.zip
```

No second-compliance or final-compliance changed-files package was produced because no files changed during those passes.

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, UI stream separation, C99 core policy, diagnostic policy, memory-safety policy, reserved-word policy, and current-status surface hygiene.
- The incremental implementation guide owns Phase 67 numbering, scope, tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or guide.
- TODO-style notes are implementation-risk evidence only and do not override the target milestone, canonical guide, or canonical specification.

## 3. Exact requirements implemented

### 3.1 Combined arithmetic and branch integration harness

Implemented source-run integration coverage for a single MASM program that combines:

- `cmp`;
- equality conditional jump behavior;
- signed relational conditional jump behavior;
- unsigned relational conditional jump behavior;
- direct `jmp` behavior.

The fixture verifies that these already-implemented instruction families compose correctly in one source-run program and reach the expected register state without relying on future branch forms.

### 3.2 Shared direct branch target classification coverage

Implemented Phase 67 branch-target diagnostic coverage showing that implemented branch families use the existing direct branch target classifier. The rendered diagnostic fixture uses ordinary MASM source and verifies a rejected branch target with exact final Simulator Messages text.

A native executor metadata fixture also covers the runtime/internal malformed branch-target path that normal source validation should prevent. This keeps the internal runtime failure path covered without making invalid branch metadata reachable from user source.

### 3.3 Instruction-count watchdog integration coverage

Implemented coverage for instruction-count watchdog behavior using a small loop built from already-supported instructions:

- `cmp`;
- Jcc;
- `jmp`.

The fixture verifies that an instruction-limit diagnostic is emitted and that `execution-complete` is absent after the fatal watchdog diagnostic.

No active-time or wall-clock watchdog behavior was added.

### 3.4 Arithmetic fault no-partial-mutation harness

Implemented native executor coverage for arithmetic fault paths:

- `mul` invalid memory-read failure;
- `imul` invalid memory-read failure;
- `div` divide-by-zero failure;
- `idiv` divide-by-zero failure.

The harness verifies no-partial-mutation behavior, including preservation of relevant registers, seeded flag values where applicable, memory state, and absence of successful memory-change rows after fatal arithmetic errors.

The first compliance pass strengthened this coverage by adding explicit `div`/`idiv` divisor register preservation checks and flag preservation checks, plus a register preservation check for malformed conditional-branch runtime metadata.

### 3.5 No successful memory-change rows for selected instructions

Implemented source-run coverage proving that the following already-supported instructions produce no successful memory-change rows in a no-write fixture:

- `lea`;
- `cmp`;
- `mul`;
- `imul`;
- `div`;
- `idiv`;
- `jmp`;
- Jcc.

The fixture avoids setup writes so the memory-change assertion is meaningful for the tested instruction sequence.

### 3.6 Rendered Simulator Messages coverage

Added exact rendered Simulator Messages tests for:

- a branch-target classifier diagnostic reachable from ordinary source;
- a division runtime diagnostic;
- an instruction-limit diagnostic from a small branch loop.

These tests use the existing rendered-message harness and do not add new diagnostic categories.

### 3.7 Runner and static/status integration

Updated test runner/status expectations so Phase 67 coverage is part of normal verification.

Updated current-status surfaces to identify the repository/archive milestone as Phase 67 while preserving runtime/source-run MASM behavior as Phase 66.

Updated `web/index.html` to:

- identify Milestone 67;
- describe it as integration-test coverage;
- preserve runtime MASM support as Phase 66;
- provide a default source program that demonstrates existing `cmp`, equality Jcc, signed Jcc, unsigned Jcc, and `jmp` behavior.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 67:

- New MASM syntax.
- New parser behavior.
- New VM/executor behavior.
- New Wasm API behavior.
- New browser controls or browser interaction behavior.
- New worker protocol behavior.
- New diagnostic codes.
- New diagnostic JSON fields.
- New rendered diagnostic categories.
- `loop` or loop-family instructions.
- Indirect branch targets.
- Register-target branches.
- Memory-target branches.
- Immediate or numeric-address branch targets.
- Branch distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Anonymous labels.
- `call`, `ret`, `leave`, stack execution, stack frames, procedure invocation, arguments, locals, `USES`, `PROTO`, or `INVOKE` behavior.
- Irvine32 callable routines beyond already-existing virtual behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Macro expansion.
- Debugger/editor branch behavior, including breakpoints, current-instruction highlighting, source navigation, CodeMirror gutter behavior, or branch-target highlighting.
- Active-time or wall-clock watchdog behavior.
- New memory operand behavior.
- New memory-validation policy behavior.
- New Program Console behavior.
- Executable QWORD/SQWORD memory operations in MASM32 Educational Mode.
- `OPTION NOKEYWORD` keyword-control behavior.

Future work intentionally preserved:

- Phase 68 - Call Target Classification and Procedure Entry Metadata.
- Later `loop` runtime behavior.
- Later indirect/register/memory/immediate branch target phases.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future Irvine32 routine expansion.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- Future executable QWORD/SQWORD memory operation support only if a later explicit phase enables it.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 67 is a test-harness and documentation/status milestone only.
- **Reason:** The Phase 67 guide section describes an integration harness and explicitly does not require new runtime features.
- **Risk:** A test added for the harness could expose a real pre-existing implementation defect, which might require a narrowly scoped fix during a validation milestone.
- **How to change later:** If a defect is proven by the Phase 67 harness, fix only the existing behavior that violates the spec/guide and document why the fix remains within Phase 67 validation scope.

### Assumption 2

- **Assumption:** Runtime/source-run MASM behavior metadata remains Phase 66 after Phase 67.
- **Reason:** Phase 67 adds no runtime-visible MASM/source behavior. It adds integration coverage and status/documentation updates.
- **Risk:** Users or future assistants may confuse the repository/archive milestone with runtime/source-run behavior if a status surface says only "Phase 67".
- **How to change later:** Continue using explicit dual labels: repository/archive milestone Phase 67 and runtime/source-run MASM behavior phase Phase 66. Advance runtime/source-run metadata only when a later phase changes runtime-visible MASM/source behavior.

### Assumption 3

- **Assumption:** Existing diagnostic wording is stable enough for exact rendered-message assertions.
- **Reason:** Phase 67 requires rendered Simulator Messages coverage for branch-target, division, and instruction-limit diagnostics.
- **Risk:** If a diagnostic wording discrepancy existed, exact tests could require wording cleanup that might appear larger than a harness-only change.
- **How to change later:** Keep exact rendered-message tests as the authority for current wording. If wording cleanup is needed later, treat it as an explicit diagnostic-wording milestone or a narrowly scoped corrective change.

### Assumption 4

- **Assumption:** The existing runner structure can include Phase 67 coverage without adding a new test group.
- **Reason:** Native, source-run, diagnostics, web, protocol, static, and structure groups already exist and cover the required layers.
- **Risk:** A new Phase 67 fixture could be added but not executed by aggregate or focused groups if placed incorrectly.
- **How to change later:** Keep the harness in existing invoked binaries and Node tests, and verify both focused groups and aggregate runner where practical.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in the assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in the assistant/container environment, and Phase 67 does not change runtime C/Wasm behavior.
- **Risk:** A locally served browser could show stale `index.html` or stale Wasm artifacts if the user has not copied the changed web files or rebuilt artifacts when needed.
- **How to change later:** On Windows, activate Emscripten with the local `emsdk_env.bat`, run `scripts\windows\build_wasm.cmd`, then serve the site with `scripts\windows\serve_web.cmd`.

## 6. Relevant TODO-style notes reviewed

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 67 - Arithmetic, Branch, and Watchdog Integration Harness
- Note text or summary:
  Phase 67 requires validation-only integration coverage for combined cmp/Jcc behavior, shared branch target classification, instruction-count watchdog behavior, arithmetic fault no-partial-mutation behavior, no memory-change rows, rendered branch-target diagnostics, rendered division diagnostics, and rendered instruction-limit diagnostics.
- Classification:
  target-owned
- Reason:
  This is the canonical target milestone scope and acceptance contract.
- Action for this milestone:
  Resolved by adding native executor, source-run, rendered-message, runner, and status/documentation coverage without adding runtime behavior.
```

```text
- Location:
  src/wasm/wasm_api.c planned-read/planned-write future instruction reminder
- Note text or summary:
  Future memory-reading opcodes must be added to planned-read collection when implemented.
- Classification:
  future-owned
- Reason:
  Phase 67 adds no new opcode and does not change simulated memory access behavior.
- Action for this milestone:
  Preserved. No planned-read/planned-write implementation path was changed.
```

```text
- Location:
  src/core/vm_exec.h, src/core/vm_exec.c, src/wasm/wasm_api.c, and related tests
- Note text or summary:
  `VM_EXEC_STATUS_BRANCH_RUNTIME_DEFERRED` and `branch-runtime-deferred` describe accepted branch forms whose runtime behavior remains deferred.
- Classification:
  future-owned for genuinely deferred forms; regression evidence for Phase 67 tests.
- Reason:
  Phase 67 validates implemented direct branch forms but does not remove the deferred path for future metadata-only/deferred branch behavior.
- Action for this milestone:
  Preserved. Phase 67 coverage verifies implemented branch behavior without enabling future branch forms.
```

```text
- Location:
  src/parser/parser.c and branch target diagnostic tests
- Note text or summary:
  Branch distance/type overrides, memory targets, register targets, and immediate targets are deferred to later branch phases.
- Classification:
  future-owned
- Reason:
  Phase 67 requires diagnostic coverage for existing branch target classification, not implementation of deferred branch targets.
- Action for this milestone:
  Preserved. No deferred branch target form was implemented.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md deferred systems list
- Note text or summary:
  Deferred systems include `loop`, indirect/register/memory/immediate jumps, branch-distance/type overrides, stack initialization, `push`, `pop`, `call`, `ret`, Irvine32 routines beyond virtual `exit`, debugger stepping, breakpoints, scaled-index addressing, carry rotates, macro expansion, Windows API modeling, and full MASM expression compatibility.
- Classification:
  future-owned
- Reason:
  Phase 67 uses already implemented `cmp`, Jcc, and `jmp` to validate instruction-count watchdog behavior. It does not implement those deferred systems.
- Action for this milestone:
  Preserved. Documentation continues to identify these as future work.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md static phase-reference audit denylist
- Note text or summary:
  The string `Phase 67 ReadString completion` appears as a known stale phrase that static checks should flag if it appears in active roadmap text.
- Classification:
  irrelevant-to-target
- Reason:
  This is a static-check denylist example, not an instruction to implement ReadString.
- Action for this milestone:
  No implementation action.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 67 guide-owned validation harness requirements were resolved by implementation and tests.
- Phase 67 status/documentation requirements were resolved without advancing runtime/source-run MASM behavior metadata.

### Future-owned TODO-style notes intentionally preserved

- Future memory-reading opcode planned-access TODO.
- Deferred branch-runtime path for genuinely deferred future branch forms.
- Deferred indirect/register/memory/immediate/distance branch target forms.
- Future loop-family instruction behavior.
- Future stack/procedure/call/return behavior.
- Future Irvine32 routine expansion.
- Future debugger/editor behavior.
- Future active-time watchdog behavior.
- Future macro, WinAPI, PE/linker, and host-filesystem behavior.
- Future executable QWORD/SQWORD memory operations.
- Future `OPTION NOKEYWORD` keyword-control behavior.

### Stale or contradicted TODO-style notes corrected

- None found during implementation, first compliance review, second compliance review, or final gap check.

### Unresolved TODO-related risks

- None identified for Phase 67.

### New TODO-style notes added

- None.

## 8. Design summary

Phase 67 was implemented as a focused validation harness.

Primary design choices:

1. **No runtime semantics changed.** The milestone adds tests and status/documentation updates only. Existing parser, VM, executor, Wasm API, and protocol behavior remain unchanged.

2. **Use source-run integration for user-reachable behavior.** Combined `cmp`/Jcc/`jmp`, no-memory-change behavior, division runtime diagnostics, and instruction-limit diagnostics are exercised through normal source-run paths where possible.

3. **Use native executor tests for internal-only paths.** Malformed branch-runtime metadata is not reachable from valid source because parser/lowering validation rejects invalid targets earlier. Native executor coverage tests that internal path without weakening source validation.

4. **Keep exact rendered diagnostics stable.** Branch-target, division, and instruction-limit diagnostic fixtures use exact rendered Simulator Messages tests.

5. **Preserve current-status hygiene.** Repository/archive status advances to Phase 67. Runtime/source-run MASM behavior remains Phase 66. Documentation and `index.html` state both concepts clearly.

6. **Avoid future feature leakage.** The watchdog fixture uses already implemented `cmp`, Jcc, and `jmp`; it does not implement `loop` or active-time watchdog behavior. Branch diagnostic tests reuse existing rejected direct-target behavior; they do not enable indirect/register/memory/immediate branches or branch-distance overrides.

## 9. Branch/control-flow status

- Branch forms executable in this phase:
  - No new branch forms were made executable in Phase 67.
  - Existing executable forms validated by the harness include direct `jmp label`, equality Jcc, signed relational Jcc, and unsigned relational Jcc.
- Branch forms parsed/lowered but not executable:
  - No new metadata-only branch forms were added.
- Branch forms rejected:
  - Existing rejected target categories remain rejected, including data-symbol targets, unknown targets, register targets, memory targets, immediate/numeric targets, and distance/type override forms where applicable.
- Branch forms still future work:
  - `loop` family, indirect branches, register/memory/immediate branch targets, branch distance/type overrides, call/return/procedure transfer, and debugger/editor branch navigation.
- Instruction-count watchdog behavior:
  - Existing instruction-count watchdog behavior is validated by a small branch loop fixture.
- Active-time watchdog behavior:
  - Not implemented. Remains future work.
- Debugger/editor branch behavior:
  - Not implemented. Remains future work.
- Runtime/source-run MASM behavior phase advanced:
  - No. It remains Phase 66.

Reserved-word and keyword status:

- New branch/control-flow mnemonics added in this phase:
  - None.
- Case-insensitive mnemonic recognition verified:
  - Existing branch families remain covered by prior tests and Phase 67 integration tests.
- New mnemonics rejected as user-defined symbols:
  - Not applicable; no new mnemonics were added.
- `OPTION CASEMAP:NONE` does not make new mnemonics available as user symbols:
  - Not applicable; no new mnemonics were added.
- `OPTION NOKEYWORD` remains unsupported unless this phase explicitly implements it:
  - Yes; Phase 67 does not implement it.

Deferred-runtime path status:

- Valid branch/control-flow forms implemented in this phase use executable runtime behavior:
  - Not applicable; no new valid branch/control-flow forms were implemented.
- Valid branch/control-flow forms implemented in this phase avoid deferred-runtime diagnostics such as `branch-runtime-deferred`:
  - Not applicable for new forms; the harness preserves the existing expectation that implemented direct branch forms execute normally and do not use deferred-runtime behavior.
- Metadata-only or deferred branch/control-flow forms intentionally preserved, if any:
  - Existing future-owned deferred path remains preserved for future branch/control-flow forms.

## 10. Planned-read/planned-write coverage

Phase 67 did not add, change, correct, or reclassify simulated memory access behavior. It did not add a memory-capable opcode, runtime routine, debugger action, stack feature, call/return feature, string/buffer feature, or memory-validation policy path.

Applicable review result:

- Newly added simulated memory reads:
  - None.
- Newly added simulated memory writes:
  - None.
- Changed simulated memory reads:
  - None.
- Changed simulated memory writes:
  - None.
- Read-modify-write forms added or changed:
  - None.
- Implicit memory accesses added or changed:
  - None.
- Planned-read collection updated:
  - No; not applicable.
- Planned-write collection updated:
  - No; not applicable.
- Object/declared-bounds planned-access collection updated:
  - No; not applicable.
- Section-capacity planned-access collection updated:
  - No; not applicable.
- Section-image planned-access collection updated:
  - No; not applicable.
- Uninitialized-read policy coverage applies:
  - No new policy coverage required by Phase 67. Existing policy behavior remains unchanged.
- `.CONST` or protected-region write protection can apply:
  - No new write behavior was added.
- Cross-region protected-region diagnostics can apply:
  - No new memory access behavior was added.
- Source line, column, byte offset, and span length preservation:
  - Existing diagnostics used by rendered-message fixtures preserve these fields.

The Phase 67 no-memory-change fixture is validation coverage only. It does not change planned-access behavior.

## 11. Current-status documentation disposition

Current-status documentation disposition:

- README changed:
  - Yes.
- README current-status block replaced rather than appended:
  - Yes.
- README current-scope block remains concise:
  - Yes.
- SUPPORTED_SYNTAX opening status block replaced rather than appended:
  - Yes.
- BUILDING_AND_DEVELOPMENT avoided feature-history accumulation:
  - Yes.
- MILESTONE_HISTORY updated for historical detail:
  - Yes.
- Browser/protocol/source-run status text changed:
  - Browser `web/index.html` visible text/default source changed. Protocol/source-run runtime metadata did not change.
- Runtime/source-run metadata advanced:
  - No.
- Reason runtime/source-run metadata did or did not advance:
  - Phase 67 did not add runtime-visible MASM/source behavior; runtime/source-run MASM behavior remains Phase 66.
- Static documentation checks added or updated:
  - Updated to account for Phase 67 current-status surfaces and documentation expectations.
- Manual documentation checks performed, if static checks were skipped:
  - Static checks were run and passed; manual checks also confirmed `index.html` and status docs do not promise new runtime behavior.
- Clutter risk remaining:
  - Low. Current-status wording remains concise and explicitly separates repository/archive milestone from runtime/source-run MASM behavior.

## 12. Files changed

Changed project files in the final Phase 67 state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `web/index.html`

No core runtime implementation files were changed for Phase 67.

Generated/native build artifacts may have been created or updated by local test runs under build directories. They are not treated as source changes for milestone design purposes.

## 13. Tests added

### 13.1 Native executor tests

Added or updated:

- `test_phase67_arithmetic_fault_no_partial_mutation_harness`
- `test_phase67_conditional_branch_invalid_metadata_harness`

Coverage includes:

- `mul` invalid memory-read failure preserving visible state and avoiding memory-change rows;
- `imul` invalid memory-read failure preserving visible state and avoiding memory-change rows;
- `div` divide-by-zero preserving quotient/remainder registers, divisor register, seeded flag state, memory, and memory-change rows;
- `idiv` divide-by-zero preserving quotient/remainder registers, divisor register, seeded flag state, memory, and memory-change rows;
- malformed conditional-branch runtime metadata preserving instruction pointer, instruction count, seeded general-purpose registers, flags, memory, and memory-change rows.

### 13.2 Source-run integration tests

Added or updated:

- `test_phase67_arithmetic_branch_watchdog_source_run_harness`

Coverage includes:

- one integrated source program combining `cmp`, equality Jcc, signed relational Jcc, unsigned relational Jcc, and direct `jmp`;
- a no-memory-change fixture for `lea`, `cmp`, `mul`, `imul`, `div`, `idiv`, `jmp`, and Jcc;
- a branch-loop instruction-count watchdog fixture using existing `cmp`, Jcc, and `jmp` behavior;
- absence of `execution-complete` after fatal instruction-limit diagnostics.

### 13.3 Rendered Simulator Messages tests

Added or updated fixtures in `tests/web/test_diagnostic_rendering.mjs`:

- exact rendered Phase 67 branch-target classifier diagnostic;
- exact rendered Phase 67 division runtime diagnostic;
- exact rendered Phase 67 branch-loop instruction-limit diagnostic.

### 13.4 Static/status tests

Updated static/status expectations for:

- repository/archive Phase 67;
- runtime/source-run MASM behavior Phase 66 preservation;
- `index.html` visible milestone text and default source;
- runner/status inventory references.

## 14. Commands used to test

### Pre-implementation repository verification

Aggregate command attempted:

```bash
python3 scripts/run_tests.py --all
```

Observed result:

```text
The runner printed all focused group PASS lines and "All implemented milestone tests passed", but the container command timed out at the tool boundary. Not counted as aggregate completed.
```

Focused fallback commands run and passed:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Focused result classification:

```text
aggregate timed out with focused groups passed
```

### Implementation testing

Focused commands run and passed:

```bash
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command run:

```bash
python3 scripts/run_tests.py --all
```

Observed implementation result:

```text
PASS, final line reported "All implemented milestone tests passed."
```

Result classification:

```text
aggregate completed and passed
```

### First compliance review testing

Focused commands rerun and passed:

```bash
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Aggregate command rerun:

```bash
python3 scripts/run_tests.py --all
```

Observed result:

```text
timed out in the assistant/container environment; aggregate completion not claimed for that pass
```

Result classification:

```text
aggregate timed out but focused groups passed
```

### Second compliance review testing

Commands rerun:

```bash
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Observed results:

```text
--native: PASS
--source-run: PASS
--diagnostics: PASS
--structure: PASS
--web: PASS
--protocol: PASS
--static: PASS
--all: PASS, final line reported "All implemented milestone tests passed."
```

Result classification:

```text
aggregate completed and passed
```

### Final gap-check testing

Commands rerun:

```bash
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Observed results:

```text
--native: PASS
--source-run: PASS
--diagnostics: PASS
--structure: PASS
--web: PASS
--protocol: PASS
--static: PASS
--all: timed out in the assistant/container environment during the final pass; aggregate completion not claimed for that pass
```

Result classification for final gap check:

```text
aggregate timed out but focused groups passed
```

### Skipped dependency checks

Browser/Wasm rebuild smoke:

```text
Skipped because emcc is unavailable in the assistant/container environment.
```

Expected local behavior if Emscripten is not installed or not activated:

```text
emcc not found
```

This is an environment limitation, not a Phase 67 regression.

## 15. Pass/fail result summary

- Aggregate completed and passed:
  - Yes, during implementation testing.
  - Yes, during second compliance review testing.
- Aggregate timed out but focused groups passed:
  - Yes, during pre-implementation verification.
  - Yes, during first compliance review.
  - Yes, during final gap check.
- Aggregate failed:
  - No.
- Focused group failed:
  - No.
- Focused group timed out and was rerun by subgroup/fixture:
  - No.
- Group skipped because dependency was unavailable:
  - Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

## 16. Manual/browser testing guidance and expected outputs

### 16.1 Website-testable status

Phase 67 is partially website-testable. It is primarily a validation-harness milestone, so the complete verification is local test-suite based. The served website can still test the visible existing MASM behavior that Phase 67 validates and can verify `index.html` milestone/status/default-source updates.

Required browser setup:

```bat
scripts\windows\serve_web.cmd
```

Open the URL shown by the script.

### 16.2 Browser test 1 - default page-load program

The default editor program tests the main visible Phase 67 integration path: `cmp`, equality Jcc, signed Jcc, unsigned Jcc, and `jmp` in one source program.

Expected page text near the top:

```text
Milestone 67: Integration tests cover existing arithmetic, branch, and instruction-limit behavior; runtime MASM support remains Phase 66.
```

Expected Simulator Messages after Run:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected registers:

```text
EAX = FFFFFFFFh / 4294967295
EBX = 00000001h / 1
ECX = 00000002h / 2
EDX = 00000003h / 3
```

Expected memory changes:

```text
none / empty
```

Regression signs:

```text
EBX is not 1
ECX is not 2
EDX is not 3
branch-runtime-deferred appears
execution-complete is missing
memory changes appear
runtime/source-run phase is shown as Phase 67 instead of Phase 66
```

### 16.3 Browser test 2 - no-memory-change arithmetic/branch fixture

Program:

```asm
.code
main PROC
    mov ebx, 8
    lea eax, [ebx + 4]
    cmp eax, 12
    mul ebx
    mov eax, 100
    mov edx, 0
    div ebx
    mov eax, -12
    cdq
    mov ebx, 3
    idiv ebx
    mov eax, -2
    imul ebx
    cmp eax, 0FFFFFFFAh
    je equal_done
    mov esi, 99
equal_done:
    jb unsigned_done
    jl signed_done
signed_done:
    jmp final_done
unsigned_done:
    mov edi, 99
final_done:
    nop
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected registers:

```text
EAX = FFFFFFFAh / 4294967290
EBX = 00000003h / 3
EDX = FFFFFFFFh / 4294967295
ESI = 00000000h / 0
EDI = 00000000h / 0
```

Expected memory changes:

```text
none / empty
```

Regression signs:

```text
memory changes appear
EAX is not FFFFFFFAh
ESI becomes 99
EDI becomes 99
branch-runtime-deferred appears
execution-complete is missing
```

### 16.4 Browser test 3 - branch-target diagnostic

Program:

```asm
.data
value DWORD 1
.code
main PROC
    ja value
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-branch-target line 5, column 8, byte offset 43, span length 5: JA target cannot be a data symbol. Direct conditional jumps accept only code labels with executable instruction targets.
```

Expected Program Console:

```text
(empty)
```

Expected execution behavior:

```text
Program does not execute.
No execution-complete message appears.
No memory changes appear.
```

Regression signs:

```text
program executes
execution-complete appears
diagnostic is not invalid-branch-target
line/column/byte offset/span length differ
JA to a data symbol is accepted
```

### 16.5 Browser test 4 - division runtime diagnostic

Program:

```asm
.code
main PROC
    mov eax, 100
    mov edx, 2
    mov ebx, 0
    div ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[runtime-error] divide-by-zero line 6, column 5, byte offset 67, span length 7: DIV divisor operand EBX evaluated to zero. Division by zero is not allowed. Execution stopped before updating the quotient register EAX and remainder register EDX.
```

Expected Program Console:

```text
(empty)
```

Expected registers after stop:

```text
EAX = 00000064h / 100
EBX = 00000000h / 0
EDX = 00000002h / 2
```

Expected memory changes:

```text
none / empty
```

Regression signs:

```text
EAX or EDX is changed by the failed DIV
execution-complete appears
diagnostic is not divide-by-zero
memory changes appear
```

### 16.6 Windows CMD local testing guidance

From the project root, run:

```bat
py scripts\run_tests.py --native --source-run --diagnostics --structure --web --protocol --static
```

Expected output snippets:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
Selected test groups passed.
```

Then run:

```bat
py scripts\run_tests.py --all
```

Expected successful ending:

```text
All implemented milestone tests passed.
```

If the aggregate command times out or truncates in a constrained environment, that alone is not a project failure. The focused command above is the expected fallback, and all focused groups should pass.

Optional instruction-limit diagnostic verification:

```bat
py scripts\run_tests.py --diagnostics
```

Expected output:

```text
[diagnostics] PASS - native diagnostic producer and rendered messages passed
Selected test groups passed.
```

This includes exact rendered instruction-limit coverage for the Phase 67 branch-loop fixture.

## 17. Compliance review summary

### First compliance review

Issues found:

- The Phase 67 native arithmetic-fault harness checked register preservation and memory-change rows, but did not explicitly verify flag preservation for `div`/`idiv` divide-by-zero faults.
- The malformed conditional-branch metadata harness checked instruction pointer, instruction count, flags, and memory-change rows, but did not explicitly verify preservation of a seeded general-purpose register.

Fixes applied:

- Strengthened `tests/core/test_vm_exec.c`.
- Added `EBX` divisor-register preservation checks for `div` and `idiv` divide-by-zero paths.
- Added flag preservation checks:
  - `DIV` divide-by-zero preserves seeded `CF`.
  - `IDIV` divide-by-zero preserves seeded `SF`.
- Added `EAX` preservation check for malformed conditional-branch runtime target metadata.

Files changed during first compliance review:

- `tests/core/test_vm_exec.c`

Result:

- Focused verification passed.
- Aggregate command timed out in the assistant/container environment for that pass, so aggregate completion was not claimed.
- Browser/Wasm rebuild smoke skipped because `emcc` was unavailable.

Verdict:

```text
complete
```

## 18. Re-review summary

### Second compliance review

Additional issues found:

- None.

Additional fixes applied:

- None.

Verification:

- Re-read Phase 67 guide requirements.
- Re-checked relevant spec rules.
- Inspected changed files for stale comments, incomplete Doxygen concerns, hidden assumptions, and accidental future behavior.
- Re-scanned TODO-style notes in changed files and nearby modules.
- Re-checked test quality, exact diagnostics, and status documentation.
- Re-ran focused groups and aggregate runner.

Result:

- Focused groups passed.
- Aggregate completed and passed during this review.

Verdict:

```text
complete
```

### Final gap check

Missing work found:

- None.

Verification:

- Re-checked target milestone requirements and acceptance criteria.
- Re-checked changed code and docs.
- Re-checked implementation assumptions.
- Re-checked tests and manual testing instructions.
- Re-checked accidental future work risk.
- Re-checked TODO-style notes.
- Re-checked package/archive naming.
- Re-checked `index.html` and displayed status/default code.

Result:

- Focused groups passed.
- Aggregate command timed out during this final pass, so aggregate completion was not claimed for that pass.

Verdict:

```text
complete
```

## 19. User-test follow-up summary

Prompt 8 was not provided because the user did not report discrepancies from the manual/browser/local tests. No user-test fixes were required. No discrepancies were invented.

## 20. Known limitations

- Browser/Wasm rebuild smoke was skipped in the assistant/container environment because `emcc` is unavailable.
- Phase 67 does not add runtime MASM behavior; it validates existing behavior.
- Runtime/source-run MASM behavior remains Phase 66.
- Active-time and wall-clock watchdog behavior remain future work.
- Future branch families, stack/procedure transfer, Irvine32 routine expansion, debugger/editor behavior, QWORD/SQWORD executable memory operations, macros, WinAPI, PE/linker, host-filesystem behavior, and `OPTION NOKEYWORD` remain unimplemented.
- In constrained assistant/container environments, `python3 scripts/run_tests.py --all` may time out even when focused groups pass. The report distinguishes those cases by pass.

## 21. Next recommended milestone

Next canonical milestone:

```text
Phase 68 - Call Target Classification and Procedure Entry Metadata
```

Phase 68 should be implemented only after accepting and archiving the Phase 67 repository state.

Recommended latest repository/archive name after Phase 67 acceptance:

```text
Latest_repository_state_milestone_67.zip
```

## 22. Changed-files ZIP/package produced

Produced changed-files packages:

```text
milestone_67_implementation.zip
milestone_67_first_compliance_check.zip
```

No package was produced for the second compliance review because no files changed during that pass.

No package was produced for the final compliance check because no files changed during that pass.

