# Milestone 52 report - LEA

## 1. Milestone title and scope

Milestone 52 implements **Phase 52 - LEA** for the Online MASM32 Educational Simulator.

Scope implemented:

- Added executable runtime support for `lea`.
- Supported 32-bit register destinations only.
- Supported effective-address source forms that reuse the currently supported address-expression subset:
  - `lea reg32, symbol`
  - `lea reg32, symbol[offset]`
  - `lea reg32, [symbol + constant]`
  - `lea reg32, [reg32]`
  - `lea reg32, [reg32 + constant]`
  - `lea reg32, [reg32 - constant]`
  - `lea reg32, symbol[reg32]`
  - `lea reg32, [symbol + reg32]`
- Implemented LEA as address computation only. It does not read from or write to the effective address.
- Implemented modulo-32-bit effective-address arithmetic for register-derived address expressions.
- Preserved all modeled flags across LEA.
- Preserved Program Console output; LEA emits no console text.
- Ensured LEA produces no memory-change rows.
- Ensured LEA source operands do not trigger memory-read diagnostics, unaligned diagnostics, object-bound diagnostics, uninitialized-read diagnostics, `.CONST` permission diagnostics, or executable QWORD/SQWORD memory-operation diagnostics merely because an address is computed.
- Added structured diagnostics and rendered Simulator Messages tests for LEA-specific invalid source and destination forms.
- Preserved rejection for unsupported scaled-index addressing.
- Updated source-run and browser metadata to report phase `52`.
- Updated documentation and browser sample/status text for the new user-visible LEA behavior.

The implementation stayed within the milestone boundary. No future scaled-index addressing, control flow, stack behavior, procedure behavior, multiplication/division, QWORD/SQWORD execution, broader Irvine32 behavior, macro behavior, Windows API behavior, PE loading, linking, or browser settings UI was implemented.

## 2. Source-of-truth files used

Canonical repository files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 51 report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_51.zip
```

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording are audit history only unless explicitly reclassified as canonical.
- Phase 52 is the only target milestone for this implementation session.

## 3. Exact requirements implemented

Phase 52 required `lea` as an address-computation instruction that computes an effective address without dereferencing memory.

Accepted syntax implemented:

```asm
lea reg32, symbol
lea reg32, symbol[offset]
lea reg32, [symbol + constant]
lea reg32, [reg32]
lea reg32, [reg32 + constant]
lea reg32, [reg32 - constant]
lea reg32, symbol[reg32]
lea reg32, [symbol + reg32]
```

Supported destination registers:

```text
EAX, EBX, ECX, EDX, ESI, EDI, EBP, ESP
```

Rejected syntax verified:

```asm
lea mem, symbol
lea eax, ebx
lea eax, 123
lea eax, OFFSET symbol
lea ax, symbol
lea al, symbol
lea eax, [eax * 4]
lea eax, [base + index * 4]
lea eax
lea eax, symbol, ebx
```

Runtime semantics implemented:

- LEA computes the effective address of the source expression.
- The computed effective address is written to the 32-bit destination register.
- Register-derived arithmetic wraps modulo `2^32`.
- The computed address is not required to be mapped, aligned, readable, writable, or inside a declared object.
- The source effective address is not dereferenced.
- No memory read occurs.
- No memory write occurs.
- No memory-change row is emitted.
- Program Console output is unchanged.
- `CF`, `ZF`, `SF`, and `OF` are preserved exactly, including their deterministic values and validity metadata.

Diagnostics implemented or verified:

- `invalid-effective-address-expression` for LEA sources that are not effective-address expressions, such as registers, immediates, and `OFFSET symbol`.
- `invalid-instruction-operands` for invalid LEA destination width or destination class.
- Existing `unsupported-scaled-index` diagnostics for scaled-index address expressions.
- Existing unknown-symbol diagnostics for unknown data symbols used in LEA expressions.
- Static displacement-overflow diagnostics for LEA symbol-offset forms that cannot be represented by the supported parser expression shape.
- Diagnostic source location data remains preserved: line, column, byte offset, and span length where applicable.

Acceptance behavior:

```asm
.data
nums DWORD 10 DUP(0)
.code
main PROC
    mov ebx, OFFSET nums
    lea eax, nums[8]
    lea ecx, [ebx + 4]
main ENDP
END main
```

Expected final state under the fixed educational layout:

```text
EAX = 00500008h / 5242888
EBX = 00500000h / 5242880
ECX = 00500004h / 5242884
EFLAGS = 00000000h / 0
```

Expected messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected memory behavior:

```text
No memory changes.
```

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 52:

- Scaled-index addressing.
- `base + index * scale` address expressions.
- New multiplication, division, or scaled-address arithmetic instructions.
- `cmp`.
- Labels as executable branch targets.
- `jmp`, conditional jumps, `loop`, `SETcc`, or `CMOVcc`.
- `push`, `pop`, `call`, `ret`, `leave`, stack behavior, or stack-frame behavior.
- Procedure metadata, `LOCAL`, `PROTO`, `INVOKE`, `USES`, or `ADDR`.
- Irvine32 routine bodies beyond the existing `exit` virtual terminator.
- Program Console input/output routines.
- Executable QWORD/SQWORD memory operations.
- PF, AF, DF, or broader flag model expansion.
- Carry rotates.
- Macro expansion.
- Windows API simulation.
- PE loading.
- Object linking.
- Host include-file loading or filesystem behavior.
- Browser settings UI for LEA, memory diagnostics, layout policies, or flag diagnostics.

## 5. Assumptions used

### Assumption 1

- **Assumption:** `lea` should be represented as a dedicated IR opcode.
- **Reason:** LEA has instruction identity that should remain visible to diagnostics, tests, metadata, and future debugger display. It also computes runtime register-derived addresses, so it cannot be safely treated as a static `OFFSET` alias.
- **Risk:** Adds another parser, IR, executor, and test path.
- **How to change later:** A future internal lowering or address-computation helper can share implementation details while preserving `VM_IR_OPCODE_LEA` as the public IR identity.

### Assumption 2

- **Assumption:** LEA source operands should reuse existing memory-address operand shapes but execute through an address-only path.
- **Reason:** The guide requires LEA to accept currently supported address-expression forms while not performing a memory access.
- **Risk:** Reusing memory operand structures can accidentally inherit memory-width, permission, uninitialized, object-bound, or executable-QWORD validation.
- **How to change later:** Introduce a distinct effective-address-only IR operand kind if future address-expression support becomes broad enough to justify separation.

### Assumption 3

- **Assumption:** Effective-address arithmetic should use explicit unsigned 32-bit wrap semantics.
- **Reason:** The guide requires modulo `2^32` behavior, and C signed overflow must be avoided.
- **Risk:** Future addressing forms may need a more general helper that models displacement, base, index, and scale fields in one place.
- **How to change later:** Centralize all effective-address arithmetic in a documented helper when scaled-index addressing is implemented in its own future milestone.

### Assumption 4

- **Assumption:** LEA should not reject or diagnose address expressions merely because the final address is unmapped or points into `.CONST`, `.DATA?`, an object boundary, or QWORD/SQWORD storage.
- **Reason:** LEA computes an address only and does not dereference the address.
- **Risk:** Some existing memory validation helpers cannot be reused directly because they perform dereference-oriented checks.
- **How to change later:** Keep LEA tests that prove no memory diagnostic is emitted for address-only computation; refactor helpers only if the tests remain stable.

### Assumption 5

- **Assumption:** Phase metadata should advance to numeric `52`.
- **Reason:** Unlike Milestones 50A, 50B, and 51, Phase 52 adds new user-visible MASM runtime syntax and behavior.
- **Risk:** Metadata updates touch browser protocol and UI tests even though the main behavior is parser/executor code.
- **How to change later:** If the project later separates feature labels from numeric runtime phase, update protocol metadata and tests together.

### Assumption 6

- **Assumption:** Existing scaled-index diagnostics should remain the diagnostic path for unsupported scaled-index syntax.
- **Reason:** Scaled-index rejection already existed as a stable future-feature diagnostic. Phase 52 must not implement scaled-index support.
- **Risk:** The diagnostic code is not LEA-specific, but it accurately classifies the unsupported future feature.
- **How to change later:** If the project introduces a diagnostic catalog consolidation phase, update rendered-message golden tests together with the diagnostic code or wording.

## 6. Design summary

### IR design

A new opcode was added:

```text
VM_IR_OPCODE_LEA
```

The opcode-name helper reports:

```text
lea
```

### Parser design

The parser recognizes `lea` as a two-operand instruction with strict LEA-specific validation.

Parser behavior:

- Requires a destination operand.
- Requires exactly one source operand.
- Requires the destination to be a 32-bit register.
- Rejects 8-bit and 16-bit destination registers.
- Rejects memory destinations.
- Rejects immediate sources.
- Rejects register sources.
- Rejects `OFFSET symbol` sources because LEA expects an effective-address expression, not an immediate OFFSET operator.
- Accepts existing supported symbol, symbol-offset, register-indirect, register-displacement, and symbol-plus-register effective-address forms.
- Uses LEA-specific address-only paths for symbol-plus-register forms so QWORD/SQWORD symbol metadata does not trigger executable-memory-width rejection.
- Preserves existing scaled-index rejection behavior.
- Preserves source location metadata for diagnostics.

### Executor design

The executor handles LEA through a dedicated address-computation path.

Execution algorithm:

1. Validate that the destination is a 32-bit register.
2. Resolve the source effective address without reading memory.
3. Compute any register-derived displacement using `uint32_t` modulo arithmetic.
4. Write the computed address to the destination register.
5. Preserve modeled flags and flag-validity metadata.
6. Do not touch memory.
7. Do not emit memory-change rows.
8. Do not write to Program Console.

### Wasm/source-run behavior

The source-run JSON path now reports phase `52`. LEA source operands are not reported as planned memory reads because LEA does not dereference its source expression.

### UI/documentation behavior

The browser sample and status text were updated to demonstrate LEA. Supported syntax documentation and README status were updated to reflect current behavior rather than future behavior.

## 7. Files changed

Final reviewed changed files:

```text
README.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/core/vm_exec.c
src/core/vm_exec.h
src/core/vm_ir.c
src/core/vm_ir.h
src/parser/parser.c
src/parser/parser.h
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_vm_exec.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
tests/web/test_protocol.mjs
web/index.html
web/src/protocol.js
```

Changed-files packages produced:

```text
/mnt/data/milestone52_changed_files.zip
/mnt/data/milestone52_compliance_review_changed_files.zip
/mnt/data/milestone52_second_review_changed_files.zip
```

The latest reviewed package is:

```text
/mnt/data/milestone52_second_review_changed_files.zip
```

## 8. Tests added

### Unit and executor tests

Added or updated coverage for:

- `VM_IR_OPCODE_LEA` opcode naming.
- LEA absolute symbol address computation.
- LEA symbol-offset computation.
- LEA register-indirect address computation.
- LEA register-displacement computation.
- LEA symbol-plus-register computation.
- LEA modulo-32-bit wraparound, for example `FFFFFFFFh + 4 -> 00000003h`.
- LEA preserving `CF`, `ZF`, `SF`, and `OF`.
- LEA producing no memory-change rows.
- LEA avoiding memory reads and writes.

### Parser tests

Added or updated coverage for accepted forms:

```asm
lea eax, nums
lea eax, nums[8]
lea eax, [nums + 8]
lea eax, [ebx]
lea eax, [ebx + 4]
lea eax, [ebx - 4]
lea eax, nums[esi]
lea eax, [nums + esi]
```

Added or updated coverage for rejected forms:

```asm
lea value, nums
lea eax, ebx
lea eax, 123
lea eax, OFFSET nums
lea ax, nums
lea al, nums
lea eax, [eax * 4]
lea eax, [nums + esi * 4]
lea eax
lea eax, nums, ebx
```

Added regression coverage for:

- Mixed-case `LeA` mnemonic recognition.
- `OPTION CASEMAP:NONE` preserving user-symbol case policy while instruction mnemonics remain case-insensitive.
- Unknown symbols in LEA expressions.
- LEA symbol-plus-register forms over QWORD/SQWORD declarations.

### Source-run tests

Added or updated coverage for:

- Successful LEA execution from source.
- Source-run phase metadata `52`.
- `.DATA?` and `.CONST` addresses computed without memory diagnostics.
- QWORD/SQWORD symbol addresses computed without executable QWORD/SQWORD rejection.
- LEA on unmapped final addresses without invalid-address diagnostics.
- LEA with object-bound validation enabled without object-bound diagnostics.
- LEA with uninitialized-read diagnostics enabled without uninitialized-read diagnostics.
- No memory-change rows for LEA.
- `OFFSET` source rejection.
- Register source rejection.
- Narrow destination rejection.
- Scaled-index rejection.
- Static displacement overflow diagnostic.

### Rendered Simulator Messages tests

Added exact rendered-message coverage for:

- LEA `OFFSET` source rejection.
- LEA narrow destination rejection.
- LEA scaled-index rejection.
- LEA register-source rejection.
- LEA displacement-overflow rejection.

### Protocol/web tests

Updated protocol metadata tests for implemented phase `52`.

### Aggregate runner reporting

Updated the aggregate test runner so the native and Node suites include Phase 52 LEA coverage in the standard command.

## 9. Commands used to test

Baseline verification before implementation:

```bash
cd /mnt/data/repo_m51_verify_prompt2 && python3 scripts/run_tests.py
```

Implementation test run:

```bash
cd /mnt/data/repo_m52_work && python3 scripts/run_tests.py
```

Compliance review test run:

```bash
cd /mnt/data/repo_m52_work && python3 scripts/run_tests.py
```

Second review test run:

```bash
cd /mnt/data/repo_m52_work && python3 scripts/run_tests.py
```

Final gap-check test run:

```bash
cd /mnt/data/repo_m52_gapcheck && python3 scripts/run_tests.py
```

Report-generation verification run:

```bash
cd /mnt/data/repo_m52_gapcheck && python3 scripts/run_tests.py
```

Representative commands executed by the aggregate runner include native C99 builds with:

```bash
cc -std=c99 -Wall -Wextra -Werror -pedantic
```

and Node-based web/formatter tests:

```bash
node tests/web/test_protocol.mjs
node tests/web/test_formatters.mjs
node tests/web/test_diagnostic_rendering.mjs
```

## 10. Pass/fail results

All aggregate test runs passed after implementation and after both reviews.

Final observed result:

```text
All implemented milestone tests passed.
```

The final run included:

- Phase 0 C tests.
- CPU/register/flag metadata tests.
- Memory and layout tests.
- Executor tests through Milestone 52.
- Lexer tests.
- Parser tests.
- Source execution tests through Phase 52 LEA coverage.
- Data section and expression tests through earlier milestones.
- Object map tests.
- Web protocol tests.
- Web formatter tests.
- Native diagnostic JSON plus rendered Simulator Messages tests.
- Milestone structure tests.

## 11. Manual/browser testing guidance and expected outputs

Milestone 52 is website-testable after rebuilding Wasm with Emscripten. It is also local-testable through the native/Node aggregate test suite.

### Browser setup on Windows

Use an Emscripten-enabled command prompt:

```cmd
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd 8000
```

Open:

```text
http://localhost:8000
```

### Manual program 1 - default LEA success

```asm
.data
nums DWORD 10 DUP(0)
.code
main PROC
    mov ebx, OFFSET nums
    lea eax, nums[8]
    lea ecx, [ebx + 4]
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected fixed-layout registers:

```text
EAX    00500008h / 5242888
EBX    00500000h / 5242880
ECX    00500004h / 5242884
EFLAGS 00000000h / 0
```

Expected Program Console:

```text
(empty)
```

Expected Memory Changes:

```text
No memory changes.
```

### Manual program 2 - wraparound and flag preservation

```asm
.code
main PROC
    mov ebx, 0FFFFFFFFh
    stc
    test eax, eax
    lea eax, [ebx + 4]
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected registers:

```text
EAX    00000003h / 3
EBX    FFFFFFFFh / 4294967295
EFLAGS 00000040h / 64
```

Expected Memory Changes:

```text
No memory changes.
```

Regression sign: `EFLAGS` changes during LEA or an invalid-address diagnostic is emitted for `[ebx + 4]`.

### Manual program 3 - `.DATA?`, `.CONST`, and QWORD address-only behavior

```asm
.DATA?
buf DWORD ?
.CONST
limit QWORD 10
.code
main PROC
    mov ebx, 0
    lea eax, [ebx + 4]
    lea ecx, limit
    lea edx, [limit + 4]
    lea esi, buf
    lea edi, limit[ebx]
    lea ebp, [limit + ebx]
main ENDP
END main
```

Expected Simulator Messages:

```text
[info] execution-complete: Execution completed successfully.
```

Expected fixed-layout registers:

```text
EAX    00000004h / 4
EBX    00000000h / 0
ECX    00600000h / 6291456
EDX    00600004h / 6291460
ESI    00500000h / 5242880
EDI    00600000h / 6291456
EBP    00600000h / 6291456
EFLAGS 00000000h / 0
```

Expected Memory Changes:

```text
No memory changes.
```

Regression sign: any `.CONST` permission, uninitialized-read, invalid-address, object-bound, or QWORD/SQWORD executable-width diagnostic appears.

### Manual program 4 - invalid OFFSET source

```asm
.data
nums DWORD 0
.code
main PROC
    lea eax, OFFSET nums
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-effective-address-expression line 5, column 14, byte offset 48, span length 6: LEA source must be an effective-address expression, not OFFSET symbol.
```

Expected behavior:

```text
No execution. No register state. No memory changes. Program Console empty.
```

### Manual program 5 - scaled-index remains unsupported

```asm
.code
main PROC
    lea eax, [eax * 4]
main ENDP
END main
```

Expected Simulator Messages:

```text
[unsupported-feature] unsupported-scaled-index line 3, column 19, byte offset 34, span length 1: Scaled-index memory operands are not supported yet.
```

Expected behavior:

```text
No execution. No register state. No memory changes. Program Console empty.
```

### Manual program 6 - register source is invalid

```asm
.code
main PROC
    lea eax, ebx
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-effective-address-expression line 3, column 14, byte offset 29, span length 3: LEA source must be a supported effective-address expression.
```

Expected behavior:

```text
No execution. No register state. No memory changes. Program Console empty.
```

### Windows CMD local testing

From the repository root in a Visual Studio Developer Command Prompt or equivalent C99-capable environment:

```cmd
set CC=clang
py scripts\run_tests.py
```

Expected final output:

```text
All implemented milestone tests passed.
```

To inspect one manual program through the native diagnostic producer, save it as:

```text
program.asm
```

Then run:

```cmd
build\tests\diagnostic_json_producer.exe program.asm > program.json
type program.json
```

Expected success-program JSON includes:

```text
"phase":52
"ok":true
"status":"ok"
"code":"execution-complete"
"memoryChanges":[]
```

## 12. Compliance review summary

First compliance review checked:

- Scope control.
- Guide/spec alignment.
- Non-goal exclusion.
- Completeness against Phase 52 tasks.
- C99 core policy.
- Doxygen/file-header expectations.
- Diagnostic source locations.
- Structured and rendered diagnostic coverage.
- Test quality and aggregate runner integration.
- Documentation accuracy.

Issues found during first review:

- LEA `symbol[reg32]` and `[symbol + reg32]` initially reused a normal memory-operand builder that could apply executable memory-width restrictions to QWORD/SQWORD symbols even though LEA is address-only.
- LEA bracketed displacement overflow for `[symbol + constant]` needed explicit rendered-message coverage.

Fixes applied:

- Added LEA-specific symbol-plus-register address parsing/building that resolves symbol addresses without memory-width, executable QWORD/SQWORD, object-bound, alignment, or permission checks.
- Added LEA-specific bracketed symbol-offset parsing so static displacement overflow reports `invalid-effective-address-expression`.
- Added parser/source-run coverage for QWORD `.CONST` symbol-plus-register LEA forms.
- Added parser/source-run/rendered Simulator Messages coverage for static LEA displacement overflow.

Result:

```text
All implemented milestone tests passed.
```

Compliance verdict:

```text
complete
```

## 13. Re-review summary

Second compliance review rechecked:

- Phase 52 guide requirements.
- Relevant full-spec behavior.
- Changed source files.
- Changed docs.
- Test coverage quality.
- Diagnostic wording and source spans.
- Future-feature exclusion.
- Changed-files package freshness.

Additional issues found:

```text
None.
```

Additional fixes applied:

```text
None.
```

Result:

```text
All implemented milestone tests passed.
```

Final scope verdict:

```text
Complete. Implementation remains limited to Phase 52 - LEA.
```

Final documentation verdict:

```text
Complete. README and docs/SUPPORTED_SYNTAX.md describe current LEA behavior and do not promise future behavior.
```

Final test coverage verdict:

```text
Complete. Coverage includes parser success/error cases, executor/source-run behavior, no-memory-diagnostic behavior, flag preservation, modulo wraparound, .CONST/.DATA? address computation, rendered Simulator Messages, protocol metadata, and prior regression suites.
```

## 14. User-test follow-up summary, if any

No post-manual-user-test defect report was provided after the manual testing instructions.

Manual testing instructions were prepared for:

- Website testing after a Wasm rebuild.
- Windows CMD local aggregate tests.
- Native diagnostic JSON inspection through `program.asm`.
- Exact expected outputs for LEA success, wraparound, flag preservation, address-only `.CONST`/`.DATA?` behavior, invalid `OFFSET` source, scaled-index rejection, and invalid register source.

No additional implementation changes were requested after those instructions.

## 15. Known limitations

- Emscripten was unavailable in the execution environment, so `web/dist` could not be rebuilt here.
- Served-browser manual smoke testing was not run in this environment.
- The browser-visible milestone is testable after rebuilding Wasm in an Emscripten-capable environment.
- Scaled-index addressing remains intentionally unsupported.
- LEA does not implement future addressing forms beyond the currently supported effective-address subset.
- LEA does not add labels, jumps, stack behavior, procedure behavior, multiplication/division, QWORD/SQWORD execution, new Irvine32 routines, macro behavior, linker behavior, Windows API behavior, PE loading, or browser settings.

## 16. Next recommended milestone

The next recommended milestone is:

```text
Phase 53 - Unsigned MUL
```

The next session should begin from the latest Milestone 52 repository/archive and verify the guide's Phase 53 section before implementation. It should not implement Phase 54 or later behavior.

## 17. Changed-files ZIP/package produced

Changed-files packages produced:

```text
/mnt/data/milestone52_changed_files.zip
/mnt/data/milestone52_compliance_review_changed_files.zip
/mnt/data/milestone52_second_review_changed_files.zip
```

Latest reviewed changed-files package:

```text
/mnt/data/milestone52_second_review_changed_files.zip
```

Recommended next full repository archive name:

```text
Latest_repository_state_milestone_52.zip
```

This report file:

```text
Milestone 52 report.md
```
