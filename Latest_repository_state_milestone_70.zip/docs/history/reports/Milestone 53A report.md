# Milestone 53A report - Memory Validation Policy Clarification and Symbol-Offset Runtime Correction

## 1. Milestone title and scope

Milestone 53A implements **Phase 53A - Memory Validation Policy Clarification and Symbol-Offset Runtime Correction** for the Online MASM32 Educational Simulator.

This milestone is a corrective memory-validation and diagnostics-policy milestone. It clarifies the simulator's memory validation layers and fixes parser/static handling of valid MASM-style symbol-offset memory operands so those operands are not rejected merely because their final access spans a declared object, section image, section capacity, or fixed-layout slack.

Scope implemented:

- Formalized the memory validation policy terminology in implementation and documentation:
  - **Level 1 - region-only validation:** mandatory, always-on checked VM memory validation.
  - **Level 2 - section-capacity validation:** future Phase 53B work.
  - **Level 3 - section-image validation:** future Phase 53B work.
  - **Level 4 - declared-object validation:** already implemented allocated-object warning/strict modes.
- Corrected parser/static symbol-offset validation so valid memory operands are accepted when the address expression is representable, even if the inferred access width crosses a declared object or section-image boundary.
- Preserved final runtime byte-range enforcement through checked VM memory helpers.
- Preserved mandatory `.CONST` runtime write protection and its diagnostic precedence.
- Preserved allocated-object warning/strict behavior as opt-in Level 4 declared-object validation.
- Preserved uninitialized-read warning/strict behavior as a separate orthogonal read-origin policy.
- Added planned access checks in the source-run/Wasm path so strict allocated-object validation can stop before instruction mutation when the access passes mandatory Level 1 validation.
- Added parser, source-run, rendered Simulator Messages, and regression tests for the corrected behavior.
- Updated documentation and test-runner reporting to describe current Phase 53A behavior.

The implementation stayed within the milestone boundary. No new MASM syntax, no new instruction behavior, no section-capacity validation, no section-image validation, no browser settings UI, and no Phase 54 signed `imul` behavior were implemented.

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 53 report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_53.zip
```

Interpretation rules used:

- The full implementation specification owns product boundaries and stable behavior.
- The incremental implementation guide owns phase numbering, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 53A is the only target milestone for this implementation session.

Relevant stable project constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- All mandatory memory safety remains routed through checked memory helpers.
- User-visible diagnostics require structured tests and rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, or WinAPI simulator.

## 3. Exact requirements implemented

### 3.1 Memory validation levels documented and preserved

Phase 53A required a clear split between mandatory runtime memory safety and optional educational validation modes.

Implemented documentation and behavior identify these levels:

```text
Level 1 - Region-only validation
  Always enforced. Validates final effective address, byte range, region containment, permissions, .CONST read-only protection, and address overflow through checked VM memory helpers.

Level 2 - Section-capacity validation
  Future Phase 53B. Not implemented in Phase 53A.

Level 3 - Section-image validation
  Future Phase 53B. Not implemented in Phase 53A.

Level 4 - Declared-object validation
  Existing allocated-object warning/strict behavior. Optional diagnostic policy only.
```

Default source execution remains Level 1 region-only. Default mode does not emit object-bound diagnostics merely because a valid access crosses a declared object.

### 3.2 Symbol-offset parser/static correction

Before Phase 53A, parser/static checks could reject operands such as:

```asm
.DATA?
x DWORD ?

.code
main PROC
    mov eax, 10
    mul [x+1]
main ENDP
END main
```

The rejection was too early because it treated object/section-image boundary crossing as a parser error. Phase 53A corrected this. The parser now rejects only address expressions that cannot be represented in the simulator's 32-bit address space. Final access validity is left to runtime Level 1 checks and opt-in policies.

Implemented behavior:

- `mul [x+1]` with `x DWORD ?` is accepted as a valid memory operand when the inferred address is representable.
- `mov eax, DWORD PTR [x+1]` is accepted in default mode when the final range is region-contained.
- The corrected behavior applies through the shared symbol-offset memory operand path, not only to `mul`.
- True malformed, unsupported, or unrepresentable operands remain rejected.

### 3.3 Runtime validation and diagnostic precedence

Mandatory Level 1 checked memory validation remains authoritative.

Preserved precedence:

1. Invalid address/range/region/permission failures are runtime errors.
2. `.CONST` runtime write protection remains a permission/read-only runtime error.
3. Allocated-object warning/strict diagnostics occur only when mandatory Level 1 validation succeeds.
4. Uninitialized-read warnings/errors remain a separate read-origin policy.
5. Unaligned-access warnings remain warning-only when reached.

Strict allocated-object validation now stops before instruction mutation for planned reads/writes that pass Level 1 checks but violate declared-object boundaries.

### 3.4 Allocated-object validation preserved as Level 4

Existing allocated-object modes were preserved and clarified:

```text
MASM32_DIAGNOSTIC_MEMORY_VALIDATION=allocated-object-warnings
MASM32_DIAGNOSTIC_MEMORY_VALIDATION=allocated-object-strict
```

Behavior:

- Warning mode emits `object-bounds-warning` and continues execution.
- Strict mode emits `object-bounds-violation` and stops before instruction mutation.
- Default mode emits neither object-bound warning nor object-bound violation.

### 3.5 Uninitialized-read validation remains orthogonal

Existing uninitialized-read modes were preserved:

```text
MASM32_DIAGNOSTIC_MEMORY_VALIDATION=uninitialized-read-warnings
MASM32_DIAGNOSTIC_MEMORY_VALIDATION=uninitialized-read-strict
```

Behavior:

- Default mode does not emit `uninitialized-read`.
- Warning mode emits `uninitialized-read` and continues when no earlier fatal diagnostic stops execution.
- Strict mode emits `uninitialized-read` and stops before mutation when the read is reached.
- Object-bound policy and uninitialized-origin policy remain separate.

### 3.6 Documentation and runner reporting updated

Documentation updates included:

- `README.md`: status text and stale uninitialized-read wording corrected.
- `docs/FULL_IMPLEMENTATION_SPEC.md`: validation-layer behavior clarified.
- `docs/SUPPORTED_SYNTAX.md`: supported behavior and current validation modes clarified.
- `scripts/run_tests.py`: aggregate runner output updated to report Phase 53A coverage.

## 4. Explicit non-goals and future work not implemented

Not implemented in Milestone 53A:

- Phase 53B section-capacity validation.
- Phase 53B section-image validation.
- Phase 54 one-operand signed `imul`.
- New runtime instructions.
- New MASM syntax.
- Scaled-index addressing.
- Executable QWORD/SQWORD memory operations.
- Browser UI controls or settings for validation policies.
- New provenance validation semantics.
- New default diagnostics for allocated-object or uninitialized-read validation.
- New Program Console behavior.
- New raw JSON protocol fields.
- Signed multiplication behavior.
- Division behavior.
- Labels, jumps, conditional jumps, `loop`, `SETcc`, or `CMOVcc`.
- Stack, procedure, `call`, `ret`, `leave`, `LOCAL`, `PROTO`, `INVOKE`, or `ADDR` behavior.
- Irvine32 routine expansion beyond existing behavior.
- Macro expansion.
- Windows API simulation.
- PE loading.
- Object linking.
- Host filesystem behavior.

Next validation work is expected to be Phase 53B. Next arithmetic work after the validation split remains Phase 54 - One-Operand Signed IMUL.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 53A should change parser/static validation and documentation/tests first; executor arithmetic behavior for `mul` should remain unchanged unless source inspection proves the parser correction cannot be made without touching shared memory operand lowering.
- **Reason:** The target correction is about valid memory operands reaching runtime validation, not about changing multiplication semantics.
- **Risk:** Shared parser helpers may affect multiple memory-capable instructions, not only `mul`.
- **How to change later:** If a later audit finds instruction-specific behavior should differ, factor a documented helper with instruction-specific policy hooks and add per-instruction regression tests.

### Assumption 2

- **Assumption:** `symbol-offset-out-of-range` may remain valid only for expression/address representability failures, not for runtime object/section boundary crossing.
- **Reason:** Phase 53A requires parser/static diagnostics not to enforce runtime object, section-image, or section-capacity policy.
- **Risk:** Existing tests that expected parser-level section-image rejection had to be revised, which could obscure a real address overflow case if tests are not precise.
- **How to change later:** Keep separate representability/overflow tests for true out-of-model addresses and separate runtime-policy tests for boundary crossing.

### Assumption 3

- **Assumption:** The current runtime layout should be documented as `.data` and `.DATA?` sharing the writable `.data` VM region while `.CONST` is in a separate read-only `.const` VM region.
- **Reason:** Source inspection and tests showed this was the current implemented representation.
- **Risk:** If a future layout refactor separates `.DATA?` into its own runtime region or adds section-capacity/image layers, docs and tests will need updates.
- **How to change later:** Phase 53B can add explicit section-capacity and section-image policy metadata without changing the Level 1 checked-region contract.

### Assumption 4

- **Assumption:** Documentation updates should be canonical in spec/guide where possible, with shorter summaries in README and supported-syntax docs.
- **Reason:** The full spec and implementation guide own behavior and phase tasks; README/supported syntax should summarize current user-facing behavior.
- **Risk:** Duplicated wording across docs can drift.
- **How to change later:** Centralize future detailed validation terminology in the canonical docs and keep README/status docs concise.

### Assumption 5

- **Assumption:** Strict allocated-object validation should use a planned-access check before instruction mutation, rather than changing core VM memory helpers to enforce declared-object policy globally.
- **Reason:** Declared-object validation is optional educational policy, while VM memory helpers must remain mandatory Level 1 region/permission checks.
- **Risk:** Future memory-capable opcodes must keep planned-access collectors updated.
- **How to change later:** A future diagnostics infrastructure phase could centralize planned access collection behind a documented executor API, while preserving the mandatory/optional policy split.

## 6. Relevant TODO-style notes reviewed

The milestone review included a practical repository TODO-style search with these case-insensitive terms:

```text
TODO
FIXME
HACK
TEMP
DEFERRED
future milestone
not yet implemented
later phase
follow-up
```

Relevant notes reviewed:

```text
- Location: src/wasm/wasm_api.c:1385
- Note text or summary: TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
- Classification: future-owned
- Reason: Phase 53A does not add a new memory-reading opcode. Phase 53 already added `mul`; Phase 53A only corrects validation policy and symbol-offset handling.
- Action for this milestone: Leave in place. Verify that Phase 53A does not bypass existing memory-read planning for current opcodes.
```

```text
- Location: docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md:3441
- Note text or summary: Later section-capacity or section-image validation must add a new policy layer and tests rather than rewriting Phase 37 history.
- Classification: future-owned
- Reason: This matches Phase 53A's split between current Level 4 object validation and future Level 2/Level 3 validation.
- Action for this milestone: Preserve. Do not implement Phase 53B modes early.
```

```text
- Location: docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md:3536
- Note text or summary: A later phase may add section-capacity and section-image strict modes, separate from object validation.
- Classification: future-owned
- Reason: Phase 53A documents the split; Phase 53B owns implementation.
- Action for this milestone: Preserve. Do not implement section-capacity or section-image validation in Phase 53A.
```

## 7. TODO-style note disposition

Target-owned TODO-style notes resolved:

- None. No TODO-style notes were directly owned by Phase 53A.

Future-owned TODO-style notes intentionally preserved:

- `src/wasm/wasm_api.c` future opcode collector reminder.
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` notes about future section-capacity validation.
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` notes about future section-image validation.

Stale or contradicted TODO-style notes corrected:

- None in the TODO-style-note set.

Related stale comments/documentation corrected during reviews:

- `src/wasm/wasm_api.c`: comment adjusted from planned memory read to planned memory access because Phase 53A uses the helper for both read and write access checks.
- `src/parser/parser.c`: stale helper comment corrected to describe `.DATA?` as supported.
- `README.md`: stale wording corrected so uninitialized-read diagnostics are no longer described as deferred; only provenance diagnostics and UI controls remain deferred.

Unresolved TODO-related risks:

- Future memory-capable opcodes must update planned-read/object-access collection in their owning milestones.
- Future Phase 53B work must keep Level 2/Level 3 section validation separate from Level 4 object validation.

New TODO-style notes added:

- None.

## 8. Design summary

### Parser changes

The parser's symbol-offset validation was narrowed so it no longer treats object or section crossing as an assembly error. It now accepts representable symbol-offset memory operands and preserves normal diagnostics for truly invalid or unsupported forms.

Preserved parser diagnostics include:

- malformed syntax;
- unknown symbols;
- ambiguous memory width;
- unsupported addressing modes;
- unsupported executable width;
- constant-expression failures;
- address representability failures;
- obvious static `.CONST` direct writes.

### Source-run/Wasm validation changes

The source-run layer gained or refined planned-access handling for optional allocated-object validation. This allows strict allocated-object mode to detect object-bound violations before `vm_step` mutates result registers, flags, memory, Program Console output, or memory-change rows.

The planned-access validation is deliberately policy-level behavior, not a replacement for checked VM memory helpers.

### Runtime memory policy

Mandatory runtime memory safety remains centralized in checked VM memory helpers. Phase 53A does not make object validation part of mandatory memory safety.

Diagnostic order is intentionally conservative:

1. Level 1 region/permission checks remain mandatory and authoritative.
2. Optional Level 4 object validation is applied only after Level 1 success.
3. Orthogonal uninitialized-origin validation is applied separately.
4. Unaligned-access warning behavior remains existing warning behavior.

### Documentation design

Documentation was updated to prevent future confusion between:

- mandatory region validation;
- future section-capacity/section-image validation;
- existing declared-object validation;
- uninitialized-origin diagnostics.

## 9. Files changed

Final changed files:

```text
README.md
docs/FULL_IMPLEMENTATION_SPEC.md
docs/SUPPORTED_SYNTAX.md
scripts/run_tests.py
src/parser/parser.c
src/wasm/wasm_api.c
tests/core/test_data_section.c
tests/core/test_parser.c
tests/core/test_wasm_source_run.c
tests/web/test_diagnostic_rendering.mjs
```

## 10. Tests added

### Parser tests

Added or updated parser coverage for:

- `mul [x+1]` crossing a declared object while preserving inferred width.
- Symbol-offset memory operands that should no longer fail parser/static validation solely because an inferred access range crosses a declared object or section image.
- Older parser expectations that previously expected section-image parser rejection were updated to Phase 53A behavior.

### Source-run tests

Added source-run coverage for:

- Default `mul [x+1]` no longer failing assembly with `symbol-offset-out-of-range`.
- Default region-only behavior for object-spanning reads.
- Allocated-object warning mode continuing execution.
- Allocated-object strict mode stopping before mutation.
- Invalid-region diagnostics taking precedence over object validation.
- `.CONST` permission diagnostics taking precedence over object validation.
- Uninitialized-read warning/strict interaction with symbol-offset reads.

### Rendered Simulator Messages tests

Added or updated rendered-message coverage for:

- Default object-spanning read success with unaligned warning.
- Object-bound warning mode.
- Strict object-bound failure.
- Uninitialized-read warning/strict interaction.
- `.CONST` permission precedence where relevant.

### Regression tests

Regression coverage preserved and extended for:

- Phase 53 `mul` behavior.
- Memory-source reads through checked helpers.
- No memory-change rows for memory-source reads.
- Phase 37/38 allocated-object policy behavior.
- Phase 40 uninitialized-origin diagnostics.
- `.CONST` static and runtime protection.
- Existing aggregate native C and Node rendered-message tests.

## 11. Commands used to test

Primary test command:

```bash
python3 scripts/run_tests.py
```

This aggregate runner covers native C tests and Node web tests, including:

```text
node tests/web/test_protocol.mjs
node tests/web/test_formatters.mjs
node tests/web/test_diagnostic_rendering.mjs
```

The native test build uses the C99 compiler posture:

```text
cc -std=c99 -Wall -Wextra -Werror -pedantic
```

Review and final-gap passes reran the same aggregate test command after fixes.

## 12. Pass/fail results

Baseline verification before implementation:

```text
python3 scripts/run_tests.py
Result: pass
Final line: All implemented milestone tests passed.
```

Implementation test run:

```text
python3 scripts/run_tests.py
Result: pass
Final line: All implemented milestone tests passed.
```

First compliance review test run:

```text
python3 scripts/run_tests.py
Result: pass
Final line: All implemented milestone tests passed.
```

Second compliance review test run:

```text
python3 scripts/run_tests.py
Result: pass
Final line: All implemented milestone tests passed.
```

Final gap-check test run:

```text
python3 scripts/run_tests.py
Result: pass
Final line: All implemented milestone tests passed.
```

Wasm/browser rebuild result:

```text
Not run in this environment because emcc is unavailable.
```

## 13. Manual/browser testing guidance and expected outputs

### Browser testing status

Website-testable: **yes**, after rebuilding Wasm in an Emscripten-capable environment.

The default page-load program does not exhaustively test Phase 53A. Manual paste tests are recommended.

Required setup on Windows:

```bat
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Then open the served page, paste each program, and click **Run**.

### Browser test 1 - `mul [x+1]` must not fail assembly

Program:

```asm
.DATA?
x DWORD ?

.code
main PROC
    mov eax, 10
    mul [x+1]
main ENDP
END main
```

Expected Program Console:

```text

```

Expected Simulator Messages:

```text
[simulator-warning] unaligned-memory-access line 7: Unaligned DWORD memory access at 00500001h.
[info] execution-complete: Execution completed successfully.
```

Expected final key registers:

```text
EAX = 00000000h
EDX = 00000000h
EFLAGS = 00000000h
```

Expected memory changes:

```text
None
```

Regression signs:

- `symbol-offset-out-of-range` appears.
- `object-bounds-warning` appears in default mode.
- `object-bounds-violation` appears in default mode.
- `uninitialized-read` appears in default mode.
- The program fails assembly.

### Browser test 2 - default region-only object-spanning read

Program:

```asm
.data
x DWORD 0
y DWORD 0

.code
main PROC
    mov eax, DWORD PTR [x+1]
main ENDP
END main
```

Expected Program Console:

```text

```

Expected Simulator Messages:

```text
[simulator-warning] unaligned-memory-access line 7: Unaligned DWORD memory access at 00500001h.
[info] execution-complete: Execution completed successfully.
```

Expected final key register:

```text
EAX = 00000000h
```

Expected memory changes:

```text
None
```

Regression signs:

- `object-bounds-warning` in default mode.
- `object-bounds-violation` in default mode.
- `symbol-offset-out-of-range`.
- Execution stops before completion.

### Browser test 3 - `.CONST` runtime write protection precedence

Program:

```asm
.CONST
c DWORD 123

.code
main PROC
    mov eax, OFFSET c
    mov DWORD PTR [eax], 456
main ENDP
END main
```

Expected Program Console:

```text

```

Expected Simulator Messages:

```text
[runtime-error] permission-denied line 7: Memory write at 00600000h for 4 bytes is not permitted in .const.
```

Expected final key register:

```text
EAX = 00600000h
```

Expected memory changes:

```text
None
```

Regression signs:

- The write succeeds.
- `object-bounds-violation` replaces `permission-denied`.
- A memory-change row appears.
- `execution-complete` appears after the runtime error.

### Windows CMD local testing setup

Use a Visual Studio Developer Command Prompt from the project root.

Run the aggregate tests:

```bat
py scripts\run_tests.py
```

Expected final line:

```text
All implemented milestone tests passed.
```

The aggregate run builds:

```text
build\tests\diagnostic_json_producer.exe
```

Use `program.asm` at the repository root for manual local tests.

### Local test - allocated-object warning mode

Program:

```asm
.data
x DWORD 0
y DWORD 0

.code
main PROC
    mov eax, DWORD PTR [x+1]
main ENDP
END main
```

Run:

```bat
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=allocated-object-warnings
build\tests\diagnostic_json_producer.exe program.asm
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=
```

Expected JSON facts:

```text
"ok":true
"status":"ok"
"instructionCount":1
"code":"object-bounds-warning"
"message":"Memory read range 00500001h..00500004h spans multiple declared data objects (spans-objects)."
"code":"unaligned-memory-access"
"message":"Unaligned DWORD memory access at 00500001h."
"code":"execution-complete"
```

### Local test - allocated-object strict mode

Program:

```asm
.data
x DWORD 01020304h
y DWORD 05060708h

.code
main PROC
    mov eax, 777
    mov eax, DWORD PTR [x+1]
main ENDP
END main
```

Run:

```bat
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=allocated-object-strict
build\tests\diagnostic_json_producer.exe program.asm
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=
```

Expected JSON facts:

```text
"ok":false
"status":"execution-error"
"instructionCount":1
"EAX":{"hex":"00000309h","unsigned":777}
"code":"object-bounds-violation"
"message":"Memory read range 00500001h..00500004h spans multiple declared data objects (spans-objects)."
"line":8
"column":24
"byteOffset":99
"spanLength":5
```

Expected absent strings:

```text
execution-complete
08010203h
```

### Local test - uninitialized-read warning/strict interaction

Program:

```asm
.DATA?
x DWORD ?
y DWORD ?

.code
main PROC
    mov eax, DWORD PTR [x+1]
main ENDP
END main
```

Default run:

```bat
build\tests\diagnostic_json_producer.exe program.asm
```

Expected default JSON facts:

```text
"ok":true
"status":"ok"
"code":"unaligned-memory-access"
"code":"execution-complete"
```

Expected default absent string:

```text
uninitialized-read
```

Warning mode:

```bat
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=uninitialized-read-warnings
build\tests\diagnostic_json_producer.exe program.asm
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=
```

Expected warning-mode JSON facts:

```text
"ok":true
"status":"ok"
"code":"uninitialized-read"
"message":"Memory read range 00500001h..00500004h reads 4 bytes from x + 1; 4 of those bytes still originated from uninitialized storage."
"line":7
"column":24
"byteOffset":67
"spanLength":5
"code":"unaligned-memory-access"
"code":"execution-complete"
```

Strict mode:

```bat
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=uninitialized-read-strict
build\tests\diagnostic_json_producer.exe program.asm
set MASM32_DIAGNOSTIC_MEMORY_VALIDATION=
```

Expected strict-mode JSON facts:

```text
"ok":false
"status":"execution-error"
"instructionCount":0
"code":"uninitialized-read"
"message":"Memory read range 00500001h..00500004h reads 4 bytes from x + 1; 4 of those bytes still originated from uninitialized storage."
"line":7
"column":24
"byteOffset":67
"spanLength":5
```

Expected strict-mode absent strings:

```text
execution-complete
unaligned-memory-access
```

## 14. Compliance review summary

First compliance review checked:

- Scope control.
- Completion against the guide section.
- C99 core boundary.
- Documentation comments and stale comments.
- Diagnostic structure and rendered-message coverage.
- Test coverage and aggregate runner behavior.
- TODO-style note disposition.

Issue found:

- One stale internal comment in `src/wasm/wasm_api.c` still described only a planned memory read even though the helper was now used for planned memory access checks.

Fix applied:

- Updated the comment to describe planned memory access generally.

Test result after fix:

```text
python3 scripts/run_tests.py
Result: pass
Final line: All implemented milestone tests passed.
```

Verdict:

```text
complete
```

## 15. Re-review summary

Second review checked:

- Target guide requirements.
- Relevant full-spec sections.
- Changed code and docs.
- Stale comments/documentation.
- TODO-style notes in changed and nearby files.
- Test quality.
- Exact diagnostics and rendered Simulator Messages.
- Accidental future milestone behavior.

Additional issues found:

- `README.md` still said uninitialized-read diagnostics were deferred in the Milestone 38 summary, contradicting completed Milestone 40 opt-in uninitialized-read validation modes.
- `src/parser/parser.c` had a stale helper comment describing `.DATA?` as deferred even though `.DATA?` is implemented.

Fixes applied:

- Corrected README wording to state that provenance diagnostics and UI controls remain deferred, while uninitialized-read diagnostics are covered by Milestone 40 opt-in validation modes.
- Corrected parser helper comment to describe `.DATA?` as supported.

Test result after fixes:

```text
python3 scripts/run_tests.py
Result: pass
Final line: All implemented milestone tests passed.
```

Final re-review verdict:

```text
complete
```

## 16. User-test follow-up summary, if any

No user-reported manual test failure was received after the manual testing package was prepared.

Manual testing instructions were prepared for:

- Served-browser default behavior after Wasm rebuild.
- Local CMD aggregate test run.
- Local diagnostic JSON producer tests for default behavior, allocated-object warning mode, allocated-object strict mode, and uninitialized-read warning/strict interaction.

## 17. Known limitations

- `emcc` is unavailable in the implementation environment, so a fresh Emscripten/Wasm rebuild and served-browser smoke test could not be run here.
- Browser default behavior is testable only after rebuilding Wasm in an Emscripten-capable environment.
- Validation policy toggles remain local/test API behavior; no browser settings UI was added.
- Level 2 section-capacity validation remains unimplemented by design.
- Level 3 section-image validation remains unimplemented by design.
- Future memory-capable opcodes must continue to update planned access/object-validation collection in their owning milestones.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 53B - Section Capacity and Section Image Validation Modes
```

This is the natural continuation of the Phase 53A validation-policy split.

If the roadmap proceeds to arithmetic after validation cleanup, the next arithmetic milestone remains:

```text
Phase 54 - One-Operand Signed IMUL
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced during the milestone:

```text
milestone53a_changed_files.zip
milestone53a_compliance_changed_files.zip
milestone53a_second_review_changed_files.zip
milestone53a_final_gap_changed_files.zip
```

Recommended final changed-files package:

```text
milestone53a_final_gap_changed_files.zip
```

Recommended next full repository archive name after applying the changed files:

```text
Latest_repository_state_milestone_53A.zip
```
