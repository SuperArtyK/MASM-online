# Milestone 64 report - Equality Conditional Jumps

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 64 - Equality Conditional Jumps
```

Repository/archive milestone after this work:

```text
Phase 64 - Equality Conditional Jumps
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 64 - Equality Conditional Jumps
```

Scope implemented:

- Added executable direct-label equality conditional jumps:
  - `je label`
  - `jz label`
  - `jne label`
  - `jnz label`
- Implemented `JE` / `JZ` as branch-if-`ZF = 1`.
- Implemented `JNE` / `JNZ` as branch-if-`ZF = 0`.
- Reused the existing direct branch target classification and fixup model where practical.
- Preserved existing direct `jmp label` behavior.
- Preserved Phase 62 CMP register/immediate behavior and Phase 63 CMP memory-operand behavior.
- Added source-run consumed-flag routing so equality conditional jumps consume `ZF` through the existing `undefined-flag-use` policy path.
- Preserved register, memory, modeled-flag, Program Console, and memory-change behavior for conditional branches.
- Confirmed taken and not-taken conditional jumps each count as one executed instruction.
- Confirmed conditional branch loops are stopped by the existing instruction-count watchdog.
- Advanced runtime/source-run metadata and browser/protocol status surfaces to Phase 64.
- Updated user-facing documentation and the default `web/index.html` sample to reflect Phase 64.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_64.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 63 report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_63.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, source-run/status hygiene, and broad product constraints.
- The implementation guide owns Phase 64 numbering, exact phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or implementation guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or implementation guide.
- TODO-style notes are implementation-risk evidence only and do not override the selected target milestone or canonical docs.

## 3. Exact requirements implemented

### 3.1 Accepted equality conditional jump syntax

Implemented parser and runtime support for:

```asm
je label
jz label
jne label
jnz label
```

Example now accepted:

```asm
.code
main PROC
    mov eax, 5
    cmp eax, 5
    je equal
    mov ebx, 1
    jmp done
equal:
    mov ebx, 2
done:
    nop
main ENDP
END main
```

Expected final state includes:

```text
EAX = 00000005h / 5
EBX = 00000002h / 2
```

### 3.2 Condition semantics

Implemented condition behavior:

```text
JE/JZ:   branch when ZF is 1
JNE/JNZ: branch when ZF is 0
```

The implementation treats `jz` as an alias of `je` behavior and `jnz` as an alias of `jne` behavior while preserving distinct opcodes and mnemonic names for diagnostics/status clarity.

### 3.3 Direct branch target resolution

Implemented conditional jump parsing through the existing direct-branch target model. Supported targets are executable code labels and procedure-entry labels where the existing branch target classifier allows them.

Rejected target categories include:

- missing target;
- unknown target;
- data symbol target;
- Irvine32 or external target such as `exit`;
- register target such as `je eax`;
- memory target such as `jz [eax]`;
- immediate target such as `jne 1234h`.

Diagnostics preserve source line, column, byte offset, and span length.

### 3.4 Execution behavior

Implemented executor behavior for Phase 64 opcodes:

- Taken conditional branches set the next instruction index to the resolved target.
- Not-taken conditional branches fall through to the next instruction.
- Taken and not-taken branches each count as one executed instruction.
- Conditional jumps do not modify registers.
- Conditional jumps do not modify memory.
- Conditional jumps do not modify modeled flags.
- Conditional jumps do not create memory-change rows.
- Conditional jumps do not write Program Console output.

### 3.5 Undefined-flag-use policy integration

Phase 64 equality conditional jumps consume `ZF`. The source-run/Wasm validation path now classifies `JE`, `JZ`, `JNE`, and `JNZ` as `ZF` consumers.

Required behavior preserved:

- In `off` mode, execution uses the deterministic preserved `ZF` value without a diagnostic.
- In default warning mode, source-run emits `undefined-flag-use` and continues using the deterministic preserved `ZF` value.
- In error/strict mode, source-run emits `undefined-flag-use` and stops before the branch decision.

Native executor tests also verify that direct VM execution uses the deterministic `ZF` bit and preserves existing flag-validity metadata, because source-run policy validation is intentionally external to raw native `vm_step` execution.

### 3.6 Instruction-count watchdog behavior

Conditional branch loops participate in the existing instruction-count watchdog. A backward conditional branch loop with a true condition stops with `instruction-limit-exceeded` once the configured limit is reached.

No active-time or wall-clock watchdog behavior was added.

### 3.7 Runtime/source-run metadata advancement

Because Phase 64 changes accepted executable MASM/source behavior, runtime/source-run metadata was advanced to:

```json
{
  "phase": 64,
  "phaseSuffix": "",
  "phaseName": "Phase 64 - Equality Conditional Jumps"
}
```

Updated status surfaces include:

- source-run JSON;
- Wasm/source-run phase name constants;
- worker/protocol expected phase data;
- browser-facing protocol metadata;
- README/current status text;
- supported-syntax status text;
- milestone history;
- build/development verification docs;
- static status checks;
- default `web/index.html` sample and title/status text.

### 3.8 Browser page default sample update

`web/index.html` was updated so the page header/sample reflects Phase 64. The default editor program demonstrates:

- `cmp` setting `ZF`;
- taken `je`;
- skipped fall-through code;
- direct `jmp` to a done label;
- final `nop` target.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 64:

- Signed relational conditional jumps:
  - `jl`
  - `jle`
  - `jg`
  - `jge`
  - `jnge`
  - `jng`
  - `jnle`
  - `jnl`
- Unsigned relational conditional jumps:
  - `ja`
  - `jae`
  - `jb`
  - `jbe`
  - `jnbe`
  - `jnb`
  - `jnae`
  - `jna`
- Loop-family instructions:
  - `loop`
  - `loope`
  - `loopne`
  - `jcxz`
  - `jecxz`
- Indirect jumps.
- Register-target, memory-target, or immediate-target branch execution.
- Branch-distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Relative branch encoding or native x86 instruction encoding.
- Native x86 execution.
- Stack or procedure execution semantics.
- `call`, `ret`, `leave`, `push`, or `pop`.
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 callable routines beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Active-time watchdog behavior.
- Wall-clock execution limits.
- Worker yielding/chunking for responsiveness.
- Browser UI controls for execution time or capacity limits.
- Macro expansion.
- Debugger stepping, breakpoints, breakpoint binding, editor source navigation, current-instruction highlighting, CodeMirror gutter behavior, or branch-target editor highlighting.
- PF/AF flag storage or display.
- Executable QWORD/SQWORD memory operations in MASM32 Educational Mode.
- New scaled-index addressing forms.
- `OPTION NOKEYWORD` behavior or dynamic keyword-table mutation.

Future work intentionally preserved:

- Phase 65 - Signed Relational Conditional Jumps.
- Later unsigned relational conditional jumps.
- Later `loop` runtime behavior.
- Later indirect branch behavior, if scheduled.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future Irvine32 routine expansion.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- Future memory-reading opcode planned-access work noted in `src/wasm/wasm_api.c`.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 64 should reuse the existing direct branch target classifier and fixup model where practical.
- **Reason:** Direct `jmp label` was already implemented and tested, and the guide's branch phases are designed around a shared branch target classification path.
- **Risk:** Existing diagnostic wording could be too `JMP`-specific if reused directly.
- **How to change later:** Generalize the shared branch diagnostic helper to accept a mnemonic/context parameter while preserving diagnostic codes, source spans, and existing `jmp` behavior.

### Assumption 2

- **Assumption:** Distinct IR opcodes for `JE`, `JZ`, `JNE`, and `JNZ` are acceptable for Phase 64.
- **Reason:** Distinct opcodes make opcode naming, diagnostics, and source-run consumed-flag classification explicit and fit the existing enum/opcode-name style.
- **Risk:** Later conditional jump phases may add many related opcodes and could make dispatch repetitive.
- **How to change later:** Refactor to a generic conditional-branch opcode plus condition-code metadata if future branch phases justify the abstraction, preserving external behavior and tests.

### Assumption 3

- **Assumption:** The source-run pre-step undefined-flag-use validation path is the correct policy integration point for Phase 64.
- **Reason:** Existing flag consumers already route through `masm32_sim_wasm_validate_flag_use_before_step`, while the raw native executor intentionally does not own source-run diagnostic policy.
- **Risk:** A future native-executor-only API could consume invalid flag metadata without emitting teaching diagnostics.
- **How to change later:** Add a policy-aware executor wrapper or executor-level diagnostic policy only if the canonical design changes to require native `vm_step` diagnostics outside the source-run/Wasm path.

### Assumption 4

- **Assumption:** Runtime/source-run phase metadata should advance from Phase 63 to Phase 64.
- **Reason:** Phase 64 adds accepted executable MASM/source behavior.
- **Risk:** Missing a status surface would leave stale Phase 63 status text or failing protocol/static tests.
- **How to change later:** Continue using the standard status-surface update checklist whenever a runtime-visible milestone advances.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH in this environment.
- **Risk:** Locally served browser artifacts may remain stale until a developer rebuilds Wasm with Emscripten configured.
- **How to change later:** Run the Windows Emscripten build script in an environment where `emcc` is available, such as after running the emsdk activation script or setting `EMSDK_ROOT` correctly.

## 6. Relevant TODO-style notes reviewed

Relevant TODO-style notes and roadmap notes reviewed during planning, implementation, compliance review, second review, manual-test preparation, and final gap check:

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 64 - Equality Conditional Jumps
- Note text or summary:
  Phase 64 implements `je`, `jz`, `jne`, and `jnz`; jumps consume ZF, branch to label targets when appropriate, preserve registers/memory/flags, count as executed instructions, and respect instruction-limit enforcement.
- Classification:
  target-owned
- Reason:
  This is the selected TARGET_MILESTONE.
- Action for this milestone:
  Implemented equality conditional jump parser, IR, executor, source-run metadata, diagnostics, docs, and tests.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, standing flag-consumer rule and later conditional jump notes
- Note text or summary:
  Later conditional jump phases must call the Phase 50B undefined-flag-use helper before evaluating branch conditions.
- Classification:
  target-owned
- Reason:
  Phase 64 equality conditional jumps consume ZF.
- Action for this milestone:
  Added `JE`, `JZ`, `JNE`, and `JNZ` to the source-run consumed-flag classifier for ZF and added policy-path tests.
```

```text
- Location:
  README.md, current branch/control-flow status text
- Note text or summary:
  Phase 64 remains the next CMP-driven control-flow milestone; conditional jumps and other branch/procedure/debugger features remain future work.
- Classification:
  target-owned for equality conditional jumps; future-owned for `loop`, indirect jumps, stack/procedure behavior, debugger/editor behavior, and active-time watchdog behavior.
- Reason:
  Equality conditional jumps become implemented in Phase 64; the rest remains outside this milestone.
- Action for this milestone:
  Updated current-status text to say equality conditional jumps are implemented while preserving future-scope exclusions.
```

```text
- Location:
  docs/SUPPORTED_SYNTAX.md, branch/control-flow status text
- Note text or summary:
  Conditional jumps remain future work while direct `jmp label` is executable.
- Classification:
  target-owned for `je`/`jz`/`jne`/`jnz`; future-owned for other conditional and branch families.
- Reason:
  Phase 64 moves equality conditional jumps into implemented syntax without implementing broader control flow.
- Action for this milestone:
  Updated supported syntax to list equality conditional jumps as implemented and to keep later branch families future-owned.
```

```text
- Location:
  docs/MILESTONE_HISTORY.md
- Note text or summary:
  Phase 64 - Equality Conditional Jumps remains future work after Phase 63.
- Classification:
  target-owned
- Reason:
  Phase 64 is now implemented.
- Action for this milestone:
  Updated milestone history to record Phase 64 completion and preserve future branch scopes.
```

```text
- Location:
  src/wasm/wasm_api.c, consumed-flag / undefined-flag-use routing
- Note text or summary:
  Existing undefined-flag-use routing names current flag consumers; Phase 64 adds new flag consumers.
- Classification:
  target-owned
- Reason:
  `je`, `jz`, `jne`, and `jnz` consume ZF.
- Action for this milestone:
  Added equality conditional jump opcodes to the consumed-flag classifier for ZF.
```

```text
- Location:
  src/wasm/wasm_api.c: TODO(Phase-owned future instruction milestones): add each future memory-reading opcode here when that opcode is implemented.
- Note text or summary:
  Future memory-reading opcodes must be added to planned-read collection when implemented.
- Classification:
  irrelevant-to-target
- Reason:
  Phase 64 conditional jumps consume a flag and branch; they do not read memory.
- Action for this milestone:
  Left unchanged.
```

```text
- Location:
  src/core/vm_exec.c / src/core/vm_exec.h, `branch-runtime-deferred` status path
- Note text or summary:
  Transitional branch-deferred status remains in the executor/status enum.
- Classification:
  unclear during planning; resolved as future-owned/compatibility scaffolding during review
- Reason:
  Phase 64 valid equality jumps must execute and must not emit `branch-runtime-deferred`, but the status path can remain valid for future metadata-only branch forms.
- Action for this milestone:
  Left the status path in place; added/confirmed tests that valid equality jumps execute rather than defer.
```

```text
- Location:
  scripts/run_tests.py and docs, active-time watchdog references
- Note text or summary:
  Active-time watchdog behavior remains deferred to Phase 200.
- Classification:
  future-owned
- Reason:
  Phase 64 requires instruction-count watchdog behavior only.
- Action for this milestone:
  Left unchanged and did not implement active-time watchdog behavior.
```

```text
- Location:
  docs/FULL_IMPLEMENTATION_SPEC.md and docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, `OPTION NOKEYWORD` notes
- Note text or summary:
  `OPTION NOKEYWORD` remains unsupported until a later explicit keyword-control phase.
- Classification:
  future-owned
- Reason:
  Phase 64 adds equality conditional jumps, not keyword-control behavior.
- Action for this milestone:
  Left unchanged.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- Phase 64 equality conditional jump behavior was implemented.
- `JE`, `JZ`, `JNE`, and `JNZ` were added to the ZF consumed-flag routing path.
- Current-status text in README, supported syntax, milestone history, build/development docs, protocol metadata, static checks, and `index.html` was advanced to Phase 64.
- Valid Phase 64 equality jumps execute and do not emit `branch-runtime-deferred`.
- User-visible target diagnostics for equality conditional jumps have structured and rendered-message test coverage.

### Future-owned TODO-style notes intentionally preserved

- Signed relational conditional jumps remain future-owned.
- Unsigned relational conditional jumps remain future-owned.
- `loop` and loop-family instructions remain future-owned.
- Indirect branches and branch-size/type overrides remain future-owned.
- Stack/procedure/call/return behavior remains future-owned.
- Debugger/editor branch behavior remains future-owned.
- Active-time watchdog behavior remains future-owned.
- Irvine32 routine expansion remains future-owned.
- Macro/linker/WinAPI behavior remains future-owned.
- `OPTION NOKEYWORD` keyword-control compatibility remains future-owned.
- Future memory-reading opcode planned-access TODO remains future-owned and irrelevant to Phase 64.

### Stale or contradicted TODO-style notes corrected

- No stale TODO-style source notes were found.
- Stale non-TODO assertion wording that still referenced Phase 63 runtime metadata was corrected during compliance review.

### Unresolved TODO-related risks

- None specific to Phase 64.

## 8. Design summary

Phase 64 was implemented as a focused parser/executor/source-run policy/status milestone.

Primary design choices:

1. **Direct branch reuse.** Equality conditional jumps reuse the existing direct branch target model and target fixup flow where practical. This avoids creating a second label-resolution path.

2. **Distinct opcodes.** `JE`, `JZ`, `JNE`, and `JNZ` were added as distinct VM IR opcodes. This keeps opcode names, diagnostics, tests, and source-run consumed-flag classification explicit.

3. **Read-only branch semantics.** Equality conditional jumps only affect instruction flow and execution accounting. They do not mutate registers, memory, flags, Program Console output, or memory-change rows.

4. **Policy outside raw VM stepping.** The source-run/Wasm layer validates undefined flag consumption before stepping. The raw native executor uses deterministic flag bits and preserves validity metadata, consistent with the existing architecture.

5. **Instruction-limit integration.** Conditional backward loops use existing instruction-count enforcement. No wall-clock or active-time watchdog behavior was added.

6. **Current-status hygiene.** Because Phase 64 changes runtime-visible MASM/source behavior, source-run metadata and status surfaces were advanced to Phase 64.

7. **Future-scope protection.** Later branch families, loop behavior, stack/procedure semantics, debugger/editor behavior, and active-time watchdog behavior were not implemented.

## 9. Files changed

Changed files in the final Phase 64 state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `src/core/vm_exec.c`
- `src/core/vm_exec.h`
- `src/core/vm_ir.c`
- `src/core/vm_ir.h`
- `src/parser/parser.c`
- `src/wasm/wasm_api.c`
- `tests/core/test_data_section.c`
- `tests/core/test_parser.c`
- `tests/core/test_vm_exec.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `web/index.html`
- `web/src/protocol.js`

## 10. Tests added

Added or strengthened tests/checks:

- Parser tests for accepted equality conditional jumps:
  - `je label`
  - `jz label`
  - `jne label`
  - `jnz label`
  - forward labels;
  - backward labels;
  - procedure-entry-compatible direct targets where applicable.

- Parser/source-run tests for rejected equality conditional jump targets:
  - unknown target;
  - data symbol target;
  - Irvine32/`exit` target;
  - register target;
  - memory target;
  - immediate target;
  - missing/malformed target where applicable.

- Executor tests for equality conditional jumps:
  - `JE` taken when ZF is set;
  - `JE` not taken when ZF is clear;
  - `JNE` taken when ZF is clear;
  - `JNE` not taken when ZF is set;
  - `JZ` alias behavior;
  - `JNZ` alias behavior;
  - instruction-count accounting;
  - register preservation;
  - memory preservation;
  - flag-bit preservation;
  - flag-validity metadata preservation;
  - no memory-change rows.

- Source-run tests for:
  - Phase 64 metadata;
  - taken and not-taken conditional jumps;
  - CMP memory operand feeding conditional branch behavior;
  - conditional backward loop reaching `instruction-limit-exceeded`;
  - no `branch-runtime-deferred` for valid equality jumps;
  - invalid target diagnostics;
  - source-run status and JSON shape stability.

- Rendered Simulator Messages tests for:
  - equality conditional jump success;
  - unknown Jcc target;
  - data-symbol Jcc target;
  - Irvine32/`exit` Jcc target;
  - register Jcc target;
  - memory Jcc target;
  - immediate Jcc target.

- Protocol/static/status tests for:
  - Phase 64 phase number;
  - Phase 64 phase name;
  - current-status text updated from Phase 63 to Phase 64;
  - supported-syntax future-work wording that does not overclaim broader control flow.

- Regression coverage for:
  - direct `jmp label` still executes;
  - direct `jmp` loops still hit instruction limit;
  - CMP register/immediate still updates flags correctly;
  - CMP memory operand forms still update flags correctly;
  - Program Console and Simulator Messages remain separated;
  - branch-only programs create no memory-change rows.

## 11. Commands used to test

### Initial repository verification before implementation

Aggregate attempted:

```bash
cd /mnt/data/repo_m63_verify
python3 scripts/run_tests.py --all
```

Result:

```text
Timed out in the assistant/container environment before returning final success status.
```

Focused verification run after aggregate timeout:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Result:

```text
--structure    PASS
--native       PASS
--source-run   PASS
--web          PASS
--diagnostics  PASS
--protocol     PASS
--static       PASS
```

### Post-implementation focused verification

Focused groups run:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --static
```

Result:

```text
--structure    PASS
--native       PASS
--source-run   PASS
--diagnostics  PASS
--protocol     PASS
--web          PASS
--static       PASS
```

Aggregate attempted:

```bash
python3 scripts/run_tests.py --all
```

Result:

```text
Timed out in the assistant/container environment before returning a final aggregate status.
```

### First compliance review reruns

Commands:

```bash
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
python3 scripts/run_tests.py --all
```

Results:

```text
--native       PASS
--source-run   PASS
--diagnostics  PASS
--web          PASS
--structure    PASS
--protocol     PASS
--static       PASS
--all          timed out in assistant/container environment before final aggregate status
```

### Second compliance review reruns

Commands:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
python3 scripts/run_tests.py --native --quiet
```

Results:

```text
--structure    PASS
--source-run   PASS
--diagnostics  PASS
--web          PASS
--protocol     PASS
--static       PASS
--native       timed out in assistant/container environment before final group status
```

Targeted native executables rerun after the native-group timeout:

```bash
./build/tests/test_vm_exec
./build/tests/test_parser
./build/tests/test_data_section
./build/tests/test_object_map
```

Result:

```text
PASS
```

### Final gap-check reruns

Commands:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Results:

```text
--structure    PASS
--native       PASS
--source-run   PASS
--diagnostics  PASS
--web          PASS
--protocol     PASS
--static       PASS
```

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped in this assistant/container environment because `emcc` is unavailable.

This is a dependency skip, not a project test failure.

## 12. Pass/fail result distinction

Result classification:

- Aggregate completed and passed:
  - Not claimed. The aggregate `--all` command did not complete in this environment after implementation/compliance passes.

- Aggregate timed out but focused groups passed:
  - Yes. The aggregate command timed out in the assistant/container environment, and focused groups passed.

- Aggregate failed:
  - No real aggregate failure was observed. The aggregate did not return a final failure; it timed out.

- Focused group failed:
  - No focused group failure remained after implementation and compliance fixes.

- Focused group timed out and was rerun by subgroup/fixture:
  - During the second compliance review, `--native --quiet` timed out in this environment. Phase 64-relevant native executables were rerun directly and passed. Final gap-check `--native --quiet` later completed and passed.

- Group skipped because a dependency was unavailable:
  - Browser/Wasm rebuild smoke skipped because `emcc` is unavailable.

## 13. Manual/browser testing guidance and expected outputs

### Browser setup

From the project root on Windows CMD:

```cmd
set EMSDK_ROOT=C:\_CPP_TOOLS\emsdk
scripts\windows\build_wasm.cmd
scripts\windows\serve_web.cmd
```

Then open:

```text
http://localhost:8000
```

Wasm rebuild is required for website testing unless the browser artifacts have already been rebuilt after applying Phase 64.

### Browser Program 1 - taken `JE`

```asm
.code
main PROC
    mov eax, 5
    cmp eax, 5
    je equal
    mov ebx, 1
    jmp done
equal:
    mov ebx, 2
done:
    nop
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected important final registers:

```text
EAX = 00000005h / u: 5 / s: 5
EBX = 00000002h / u: 2 / s: 2
EFLAGS = 00000040h / 64
```

Expected Memory Changes:

```text
No memory changes.
```

### Browser Program 2 - `JZ` not taken, `JNZ` taken

```asm
.code
main PROC
    mov eax, 5
    cmp eax, 6
    jz equal
    mov ebx, 1
    jnz notequal
    mov ebx, 2
    jmp done
equal:
    mov ebx, 99
    jmp done
notequal:
    mov ebx, 3
done:
    nop
main ENDP
END main
```

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text
(empty)
```

Expected important final registers:

```text
EAX = 00000005h / u: 5 / s: 5
EBX = 00000003h / u: 3 / s: 3
EFLAGS = 00000081h / 129
```

Expected Memory Changes:

```text
No memory changes.
```

### Browser Program 3 - invalid data-symbol target

```asm
.data
value DWORD 1
.code
main PROC
    cmp eax, eax
    je value
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] invalid-branch-target line 6, column 8, byte offset 60, span length 5: JE target cannot be a data symbol. Direct conditional jumps accept only code labels with executable instruction targets.
```

Expected Program Console:

```text
(empty)
```

Expected final register display:

```text
No register state available.
```

Expected Memory Changes:

```text
No memory changes.
```

### Browser Program 4 - invalid memory target

```asm
.code
main PROC
    cmp eax, eax
    jz [eax]
main ENDP
END main
```

Expected Simulator Messages:

```text
[assembly-error] unsupported-branch-target-form line 4, column 8, byte offset 40, span length 1: JZ memory targets are not supported. Indirect branch behavior is deferred to a later branch phase.
```

Expected Program Console:

```text
(empty)
```

Expected final register display:

```text
No register state available.
```

Expected Memory Changes:

```text
No memory changes.
```

### Windows CMD focused local tests

```cmd
python scripts\run_tests.py --source-run
python scripts\run_tests.py --diagnostics
python scripts\run_tests.py --protocol
python scripts\run_tests.py --static
```

Expected snippets:

```text
[source-run] PASS
[diagnostics] PASS
[protocol] PASS
[static] PASS
Selected test groups passed.
```

If `emcc` is unavailable, this skip is acceptable for local native verification:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

### Windows CMD manual `program.asm` test

Create `program.asm` at project root:

```cmd
(
echo .code
echo main PROC
echo     mov eax, 5
echo     cmp eax, 5
echo     je equal
echo     mov ebx, 1
echo     jmp done
echo equal:
echo     mov ebx, 2
echo done:
echo     nop
echo main ENDP
echo END main
) > program.asm
```

Build the diagnostic producer if needed:

```cmd
python scripts\run_tests.py --diagnostics
```

Run:

```cmd
build\tests\diagnostic_json_producer.exe program.asm
```

Expected JSON snippets:

```json
"phase":64
"phaseName":"Phase 64 - Equality Conditional Jumps"
"ok":true
"status":"ok"
"executedInstructionCount":5
"EBX":{"hex":"00000002h","unsigned":2}
"memoryChanges":[]
"code":"execution-complete"
```

Regression signs:

- Phase still reports 63.
- `JE`, `JZ`, `JNE`, or `JNZ` are rejected as unsupported.
- Valid equality jumps emit `branch-runtime-deferred`.
- Invalid targets execute.
- Diagnostics lack source spans.
- Program Console receives diagnostics.
- Memory Changes appears for branch-only programs.
- `emcc` rebuild fails when website testing is expected.

## 14. Compliance review summary

First compliance review found no scope creep or future milestone implementation. It identified additional test coverage gaps and stale assertion wording.

Fixes applied during first compliance review:

- Added source-run checks for `jz [eax]` and `jne 1234h` invalid target diagnostics.
- Added exact rendered Simulator Messages tests for:
  - unknown Jcc target;
  - Irvine32/`exit` Jcc target;
  - memory Jcc target;
  - immediate Jcc target.
- Added native executor test proving `JNE` uses deterministic ZF for native VM callers and preserves existing invalid ZF metadata.
- Corrected stale Phase 63 wording in test assertion messages that now validate Phase 64 runtime metadata.

Compliance review verdict:

```text
complete
```

## 15. Re-review summary

Second compliance review found no additional issues in Phase 64 implementation, docs, status surfaces, diagnostics, or tests.

Confirmed during re-review:

- No accidental future-milestone behavior.
- `web/index.html` correctly reflects Phase 64 and uses a `je`/`jmp` sample.
- Remaining `branch-runtime-deferred` paths are accurate future/compatibility scaffolding and do not apply to valid Phase 64 equality conditional jumps.
- Target-owned TODO-style notes are resolved.
- Future-owned TODO-style notes remain scoped and accurate.
- No new TODO-style notes were added.

Re-review verdict:

```text
complete
```

## 16. User-test follow-up summary

Prompt 8 was skipped because the user reported that everything appeared to pass and provided no discrepancies from manual/browser/local testing.

No targeted user-test fixes were required after Prompt 7.

## 17. Known limitations

- Browser/Wasm artifacts were not rebuilt in this assistant/container environment because `emcc` is unavailable.
- The aggregate `--all` runner timed out in this assistant/container environment; focused groups passed.
- Website testing requires a local Emscripten rebuild after applying Phase 64 changes.
- Equality conditional jumps are implemented only for direct code-label targets.
- Signed and unsigned relational jumps remain future work.
- `loop` and loop-family instructions remain future work.
- Indirect branches remain future work.
- Branch-distance/type overrides remain future work.
- Debugger/editor branch visualization remains future work.
- Active-time watchdog behavior remains future work.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 65 - Signed Relational Conditional Jumps
```

Expected high-level scope for the next milestone:

- Add signed relational conditional jumps that consume modeled flags according to the guide.
- Preserve the same flag-consumer undefined-flag-use policy discipline.
- Do not implement unsigned relational jumps, loop behavior, stack/procedure behavior, debugger/editor behavior, or active-time watchdog behavior unless the guide explicitly requires them.

## 19. Changed-files ZIP/package produced

Changed-files packages produced during this milestone session:

- `phase64_changed_files.zip`
- `milestone_64_first_compliance_check.zip`

No second-compliance or final-compliance changed-files package was produced because no project files changed during those passes.

Recommended latest repository archive name after acceptance:

```text
Latest_repository_state_milestone_64.zip
```
