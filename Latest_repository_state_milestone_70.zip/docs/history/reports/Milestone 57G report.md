# Milestone 57G report - Seeded Random Uninitialized Storage Mode

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 57G - Seeded Random Uninitialized Storage Mode
```

Repository/archive milestone:

```text
Phase 57G - Seeded Random Uninitialized Storage Mode
```

Runtime/source-run MASM behavior phase:

```text
Phase 57G - Seeded Random Uninitialized Storage Mode
```

Status interpretation:

Phase 57G is a runtime/source-run behavior milestone because it adds a source-run/test/protocol-facing startup setting that can change runtime-visible memory bytes when a non-default setting is selected. It intentionally advances runtime/source-run metadata from Phase 57F - Seeded Random Register and Flag Startup Mode to Phase 57G while preserving Phase 57 as the latest MASM instruction/syntax behavior phase.

Scope implemented:

- Added an independent startup setting for visible bytes in uninitialized-origin storage:

  ```text
  uninitialized_storage_visible_byte_mode = zero | seeded-random
  ```

- Preserved the Phase 57F register/flag startup setting as a separate axis:

  ```text
  startup_register_flag_mode = zero | seeded-random
  ```

- Continued to use the shared deterministic unsigned 32-bit seed setting:

  ```text
  startup_state_seed = <u32>
  ```

- Preserved default behavior: registers, modeled flags, and visible bytes for uninitialized-origin storage start at zero unless a non-default startup mode is selected.
- Implemented opt-in seeded visible bytes only for storage bytes that carry uninitialized-origin metadata.
- Covered currently supported uninitialized-origin storage forms:
  - `.DATA?` storage;
  - scalar `?` declarations;
  - `DUP(?)` declarations.
- Preserved uninitialized-origin metadata after seeding visible bytes, so uninitialized-read warnings and strict stops continue to diagnose reads of those bytes.
- Preserved initialized `.data` and initialized `.CONST` bytes.
- Preserved Program Console behavior. Startup notices continue to be emitted through Simulator Messages only.
- Added Phase 57G source-run/runtime metadata.
- Added Phase 57G startup notice wording for seeded uninitialized-storage mode and for combined seeded register/flag plus seeded uninitialized-storage mode.
- Added structured and rendered setting diagnostics for invalid `uninitialized_storage_visible_byte_mode` values.
- Added worker/protocol/settings support for the new startup setting.
- Added a Phase 57G-specific Wasm export and stale-Wasm detection while preserving the Phase 57F compatibility export.
- Updated documentation, status surfaces, tests, browser landing text, static checks, and manual testing guidance for Phase 57G.
- Fixed a user-discovered Windows CRLF test expectation issue in the rendered diagnostic test harness.
- Corrected final documentation hygiene in `docs/MILESTONE_HISTORY.md` so Phase 57F appears before Phase 57G and so Phase 57G wording says no browser UI controls were added.

The implementation stayed within the Phase 57G boundary. No new MASM syntax, parser acceptance behavior, instruction semantics, browser UI controls, `.CONST ?` acceptance, `.CONST DUP(?)` acceptance, display-marker behavior, stack behavior, control flow, procedure behavior, Irvine32 expansion, WinAPI behavior, PE/linker behavior, host include behavior, or macro behavior was implemented.

## 2. Source-of-truth files used

Canonical repository files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 57F report.md`

Repository archive used as the implementation base:

```text
Latest_repository_state_milestone_57F.zip
```

Changed-files packages produced during the milestone:

```text
milestone_57G_changed_files.zip
milestone_57G_compliance_review_changed_files.zip
milestone_57G_second_review_changed_files.zip
milestone_57G_user_followup_changed_files.zip
milestone_57G_final_gap_check_changed_files.zip
```

No full latest repository archive was produced during this milestone-report step. The recommended full archive name after accepting and applying the latest Phase 57G changed-files package is:

```text
Latest_repository_state_milestone_57G.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, current/future/non-goal distinctions, diagnostic policy, current-status surface hygiene, and the stable rule that visible byte value and uninitialized-origin metadata are separate concepts.
- The implementation guide owns phase numbering, phase scope, implementation tasks, required tests, and acceptance criteria.
- Milestone reports and audit/handoff reports are implementation history and evidence, not replacements for the canonical spec/guide.
- Older drafts and older roadmap wording remain audit history unless explicitly reclassified as canonical.
- Phase 57G is the only target milestone for this implementation session.
- TODO-style notes are implementation-risk evidence only and do not override the canonical spec, guide, selected target milestone, or verified repository behavior.

Relevant stable constraints followed:

- Core VM, parser, executor, memory model, Irvine32 runtime, and Wasm-facing API remain C99.
- Core source uses `.c` and `.h` files.
- No C++ core code, C++ standard library use, exceptions, RTTI, classes, templates, or `extern "C"` wrappers were introduced.
- Program Console and Simulator Messages remain separate streams.
- Startup notices remain Simulator Messages only.
- User-visible diagnostics have structured tests and exact rendered Simulator Messages tests.
- MASM32 Educational Mode remains a MASM-like parser plus internal VM, not a full MASM compiler, full x86 emulator, Windows emulator, PE loader/linker, WinAPI simulator, host include loader, or macro assembler.

## 3. Exact requirements implemented

### 3.1 Independent uninitialized-storage visible-byte startup setting

Implemented a new startup setting for uninitialized-origin storage visible bytes:

```text
uninitialized_storage_visible_byte_mode = zero | seeded-random
```

Behavior:

- `zero`: preserves existing deterministic startup behavior. Visible bytes for uninitialized-origin storage start as zero-filled bytes, while uninitialized-origin metadata remains present for diagnostics.
- `seeded-random`: initializes visible bytes for uninitialized-origin storage from `startup_state_seed`, while preserving uninitialized-origin metadata.

The setting is independent from the existing Phase 57F register/flag setting:

```text
startup_register_flag_mode = zero | seeded-random
```

The implementation deliberately does not merge register/flag startup and uninitialized-storage startup into a single enum. All four combinations are supported and tested:

```text
startup_register_flag_mode = zero          + uninitialized_storage_visible_byte_mode = zero
startup_register_flag_mode = seeded-random + uninitialized_storage_visible_byte_mode = zero
startup_register_flag_mode = zero          + uninitialized_storage_visible_byte_mode = seeded-random
startup_register_flag_mode = seeded-random + uninitialized_storage_visible_byte_mode = seeded-random
```

### 3.2 Shared deterministic seed

The existing Phase 57F seed setting remains the shared deterministic seed for startup randomization:

```text
startup_state_seed = <u32>
```

The implementation preserves deterministic behavior:

- the same source, same settings, and same seed produce the same visible startup bytes;
- different seeds produce different visible bytes for suitable uninitialized-origin storage fixtures;
- no host CPU state, process memory, wall-clock time, browser nondeterminism, `rand()`, or OS randomness is used.

### 3.3 Storage forms covered

Seeded visible-byte initialization applies to currently supported storage that carries uninitialized-origin metadata:

```asm
.DATA?
value DWORD ?
buf BYTE 4 DUP(?)
```

The implementation preserves metadata for all covered forms. Reads of randomized bytes still emit `uninitialized-read` diagnostics according to the active uninitialized-read policy.

### 3.4 Initialized storage preservation

The implementation does not randomize initialized storage:

- initialized `.data` bytes are preserved exactly;
- initialized `.CONST` bytes are preserved exactly;
- `.CONST` write protection remains unchanged;
- region permissions and mandatory checked memory helpers remain unchanged.

### 3.5 Startup notices

Updated startup-state notice wording so Simulator Messages can distinguish:

- default zero startup for registers, flags, and uninitialized storage;
- seeded register/flag startup from Phase 57F;
- seeded uninitialized-storage visible-byte startup from Phase 57G;
- combined seeded register/flag and seeded uninitialized-storage startup.

Startup notices remain non-fatal and do not write to Program Console.

Representative seeded uninitialized-storage notice:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Visible bytes for uninitialized storage were initialized from the configured deterministic seed, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
```

Representative combined seeded notice:

```text
[simulator-notice] startup-state-notice: The simulator started general-purpose registers, modeled flags, and visible bytes for uninitialized storage from the configured deterministic seed. Uninitialized-origin metadata is preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
```

### 3.6 Structured setting diagnostics

Added structured and rendered diagnostics for invalid `uninitialized_storage_visible_byte_mode` values.

Rendered message form:

```text
[ui-error] invalid-startup-setting: Invalid startup setting 'uninitializedStorageVisibleByteMode'. Accepted values: zero, seeded-random.
```

A user-test follow-up corrected the Node rendered diagnostic test harness so native process stderr output is line-ending tolerant on Windows while preserving exact semantic text.

### 3.7 Worker/protocol/Wasm API support

Implemented browser-side and worker/protocol plumbing for the new setting:

- default diagnostic settings include `uninitializedStorageVisibleByteMode`;
- setting normalization validates `zero` and `seeded-random`;
- backend setting mapping carries the mode to the Wasm/source-run API;
- protocol tests cover Phase 57G settings dispatch;
- stale-Wasm detection distinguishes pre-57G artifacts from Phase 57G-capable artifacts;
- build scripts export the new Phase 57G Wasm API while preserving the Phase 57F export for compatibility.

### 3.8 Documentation and current-status updates

Updated current-status surfaces for Phase 57G, including:

- `README.md`;
- `docs/FULL_IMPLEMENTATION_SPEC.md`;
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`;
- `docs/SUPPORTED_SYNTAX.md`;
- `docs/MILESTONE_HISTORY.md`;
- `docs/BUILDING_AND_DEVELOPMENT.md`;
- `web/index.html`;
- `scripts/run_tests.py` static/status checks.

The documentation now states that Phase 57G adds source-run/test/protocol-facing seeded visible bytes for uninitialized-origin storage and does not add browser UI controls.

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 57G:

- No browser UI controls for the new setting.
- No new MASM syntax.
- No parser acceptance changes.
- No instruction semantic changes.
- No memory randomization for initialized `.data`.
- No memory randomization for initialized `.CONST`.
- No `.CONST ?` support.
- No `.CONST DUP(?)` support.
- No Phase 57H startup-state display markers for unchanged randomized values.
- No Phase 57I `.CONST` uninitialized storage acceptance.
- No Phase 57J policy controls for `.CONST` uninitialized storage.
- No stack behavior.
- No procedure behavior.
- No labels/control-flow behavior beyond already implemented behavior.
- No broader Irvine32 routine expansion.
- No `.code` memory-access-denial changes.
- No new memory validation policy.
- No host randomness, wall-clock randomness, browser-global nondeterminism, process-memory randomness, or `rand()` use.
- No C++ core code.
- No weakening of uninitialized-read diagnostics.
- No change to Program Console behavior.

Future work intentionally preserved:

- Phase 57H - Startup-State Display Markers for Unchanged Randomized Values.
- Phase 57I - `.CONST` Uninitialized Storage Acceptance.
- Phase 57J - `.CONST` Uninitialized Storage Policy Controls.
- Future `.code` protected-region diagnostics.
- Future memory-reading opcode planned-access integration for future instruction milestones.

## 5. Assumptions used

### Assumption 1

- **Assumption:** Phase 57G randomizes visible bytes only for currently accepted uninitialized-origin storage forms: `.DATA?`, scalar `?`, and `DUP(?)`.
- **Reason:** The guide explicitly excludes `.CONST ?` until Phase 57I.
- **Risk:** A future `.CONST ?` implementation must ensure it also participates in the seeded visible-byte initializer.
- **How to change later:** In Phase 57I, route accepted `.CONST ?` and `.CONST DUP(?)` storage through the same uninitialized-origin visible-byte initialization path while preserving `.CONST` read-only behavior.

### Assumption 2

- **Assumption:** Seeded visible-byte initialization should occur during program load/startup preparation, before VM execution, and should not be represented as simulated program writes.
- **Reason:** Startup randomization is an initial state configuration, not source-program behavior.
- **Risk:** If later debugger/display features want to show startup-origin changes, they need a distinct startup-state display path rather than memory-change rows.
- **How to change later:** Phase 57H or a later display milestone can add startup-origin display markers without treating startup initialization as program memory mutation.

### Assumption 3

- **Assumption:** The exact pseudo-random byte sequence is an implementation detail, while same-seed repeatability and different-seed divergence are stable behavior.
- **Reason:** The canonical guide requires deterministic seeded behavior but does not prescribe a PRNG algorithm.
- **Risk:** Tests that assert exact values can become implementation-specific regression fixtures.
- **How to change later:** If a later phase standardizes the PRNG algorithm, document it explicitly and update fixture expectations through an intentional compatibility decision.

### Assumption 4

- **Assumption:** Invalid `uninitialized_storage_visible_byte_mode` values should use the existing startup-setting diagnostic family and rendered `ui-error` path.
- **Reason:** Phase 57F already established structured/rendered diagnostics for invalid startup settings, and Phase 57G introduces another startup setting.
- **Risk:** If a future settings registry is centralized further, this compatibility layer may need to move.
- **How to change later:** Migrate validation to the centralized settings validator while preserving the existing diagnostic code and user-facing wording unless a later phase intentionally changes it.

### Assumption 5

- **Assumption:** Startup-state notices should remain under the existing `startup-state-notice` family.
- **Reason:** Phase 57E/57F already use that family for startup explanations, and Phase 57G extends startup-state behavior.
- **Risk:** A future UI may want separate toggles for register/flag startup notices and memory-startup notices.
- **How to change later:** Add a later diagnostic-policy family only if a future guide phase explicitly requires separate control.

### Assumption 6

- **Assumption:** Browser UI controls remain out of scope for Phase 57G.
- **Reason:** The guide lists no UI controls as a non-goal for this phase.
- **Risk:** Manual browser testing cannot exercise seeded uninitialized-storage mode through ordinary visible controls.
- **How to change later:** A later browser settings phase can expose the already-tested backend/protocol setting.

## 6. Relevant TODO-style notes reviewed

### Target-owned notes

```text
- Location:
  docs/SUPPORTED_SYNTAX.md:26 in the Phase 57F baseline
- Note text or summary:
  Phase 57F does not randomize memory; .DATA?, ?, and DUP(?) visible bytes remain zero-filled; visible-byte randomization for uninitialized storage is deferred to Phase 57G.
- Classification:
  target-owned
- Reason:
  The note directly identifies Phase 57G behavior.
- Action for this milestone:
  Resolved by implementing seeded visible bytes for uninitialized-origin storage and updating supported-syntax/current-status text.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md around the Phase 57F carry-forward note
- Note text or summary:
  uninitialized_storage_visible_byte_mode is not implemented by Phase 57F and is owned by Phase 57G; Phase 57G must add an independent setting and must not merge it into startup_register_flag_mode.
- Classification:
  target-owned
- Reason:
  This is a direct guide carry-forward requirement for Phase 57G.
- Action for this milestone:
  Resolved by adding an independent setting axis and preserving startup_register_flag_mode as register/flag-only.
```

### Future-owned notes

```text
- Location:
  src/wasm/wasm_api.c:2008 in the Phase 57F baseline
- Note text or summary:
  Future instruction milestones should add future memory-reading opcodes to planned-read collection when those opcodes are implemented.
- Classification:
  future-owned
- Reason:
  Phase 57G adds startup memory initialization configuration, not a new memory-reading instruction.
- Action for this milestone:
  Left unchanged.
```

```text
- Location:
  src/core/vm_memory.c:211 and matching guide/spec notes in the Phase 57F baseline
- Note text or summary:
  Future `.code` protected-region diagnostics should reuse `region-boundary-crossing` diagnostic shape when `.code` becomes protected for relevant memory access kinds.
- Classification:
  future-owned
- Reason:
  Phase 57G does not implement `.code` memory-access denial.
- Action for this milestone:
  Left unchanged.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md around Phase 57H planning text
- Note text or summary:
  Phase 57H may add a future TODO if register unchanged display markers cannot use write-tracking.
- Classification:
  future-owned
- Reason:
  Phase 57H is display formatting; Phase 57G is startup uninitialized-storage initialization.
- Action for this milestone:
  Left unchanged.
```

## 7. TODO-style note disposition

- **Target-owned TODO-style notes resolved:**
  - The Phase 57F supported-syntax deferral note for seeded uninitialized-storage visible bytes was updated to current Phase 57G behavior.
  - The guide carry-forward requirement to implement independent `uninitialized_storage_visible_byte_mode` was satisfied.

- **Future-owned TODO-style notes intentionally preserved:**
  - Future memory-reading opcode planned-access note.
  - Future `.code` protected-region diagnostic note.
  - Future Phase 57H display-marker note.

- **Stale or contradicted TODO-style notes corrected:**
  - None found.

- **Unresolved TODO-related risks:**
  - None blocking Phase 57G.

- **New TODO-style notes added:**
  - None.

## 8. Design summary

Phase 57G separates startup state into independent axes:

```text
startup_register_flag_mode
uninitialized_storage_visible_byte_mode
startup_state_seed
```

The design keeps visible byte values and uninitialized-origin metadata separate:

- visible byte values may be zero or deterministic seeded bytes;
- uninitialized-origin metadata remains present until program behavior overwrites the byte through existing memory-write paths;
- uninitialized-read diagnostics continue to report reads from uninitialized-origin bytes even when their visible byte values are nonzero due to seeded startup.

Implementation strategy:

1. Parse and lay out source as before.
2. Apply startup configuration before VM execution and before source-run final-state collection.
3. If `uninitialized_storage_visible_byte_mode` is `zero`, preserve prior zero visible-byte initialization.
4. If it is `seeded-random`, fill only bytes still marked as uninitialized-origin with deterministic bytes derived from `startup_state_seed`.
5. Do not alter initialized `.data` or `.CONST` bytes.
6. Do not create memory-change rows for startup initialization.
7. Preserve all memory checks and permissions for runtime execution.
8. Preserve uninitialized-origin diagnostics and strict stops.
9. Emit a startup-state notice through Simulator Messages when the notice policy is active.

The worker/protocol layer validates the new setting before dispatching to the runtime. Invalid settings produce renderable `ui-error` diagnostics. The browser worker now checks for a Phase 57G-capable Wasm export when non-default uninitialized-storage startup settings are used, so stale artifacts are reported clearly instead of silently ignoring the setting.

The implementation is intentionally source-run/test/protocol-facing only. No visible browser control was added in this phase.

## 9. Files changed

Files changed across implementation, compliance review, second review, user follow-up, and final gap check:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/build_wasm.sh`
- `scripts/run_tests.py`
- `scripts/windows/build_wasm.cmd`
- `src/wasm/wasm_api.c`
- `src/wasm/wasm_api.h`
- `tests/core/diagnostic_json_producer.c`
- `tests/core/test_wasm_source_run.c`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_protocol.mjs`
- `tests/web/test_settings.mjs`
- `web/index.html`
- `web/src/protocol.js`
- `web/src/settings.js`
- `web/src/worker.js`

## 10. Tests added

### Source-run/native integration tests

Added or updated Phase 57G coverage in `tests/core/test_wasm_source_run.c` for:

- Phase 57G metadata reporting.
- Default zero uninitialized-storage visible bytes.
- Seeded uninitialized-storage visible bytes.
- Same-seed repeatability.
- Different-seed divergence.
- Independence of `startup_register_flag_mode` and `uninitialized_storage_visible_byte_mode`.
- Combined seeded register/flag startup and seeded uninitialized-storage startup.
- Preservation of initialized `.data`.
- Preservation of initialized `.CONST`.
- Preservation of uninitialized-origin metadata for `.DATA?`, scalar `?`, and `DUP(?)`.
- Uninitialized-read warnings for seeded visible bytes.
- Strict uninitialized-read stop with seeded visible bytes.
- No memory-change rows caused by startup initialization.
- Startup notice wording for seeded uninitialized storage.
- Startup notice wording for combined seeded register/storage mode.
- Invalid uninitialized-storage visible-byte mode diagnostics.

### Diagnostic JSON producer tests

Updated `tests/core/diagnostic_json_producer.c` for:

- `MASM32_DIAGNOSTIC_UNINITIALIZED_STORAGE_VISIBLE_BYTE_MODE=zero`
- `MASM32_DIAGNOSTIC_UNINITIALIZED_STORAGE_VISIBLE_BYTE_MODE=seeded-random`
- invalid uninitialized-storage visible-byte mode reporting;
- preserving Windows-compatible seed parsing behavior.

### Browser/Node tests

Updated `tests/web/test_settings.mjs` for:

- Phase 57G defaults;
- Phase 57G backend enum mapping;
- invalid Phase 57G startup setting diagnostics.

Updated `tests/web/test_protocol.mjs` for:

- Phase 57G ready metadata;
- Phase 57G startup setting dispatch;
- invalid startup setting diagnostics;
- stale Wasm artifact detection for missing Phase 57G export/suffix.

Updated `tests/web/test_diagnostic_rendering.mjs` for exact rendered Simulator Messages coverage:

- seeded uninitialized-storage startup notice;
- combined seeded register/flag and uninitialized-storage startup notice;
- invalid Phase 57G uninitialized-storage startup setting `ui-error`.

User follow-up added test harness line-ending normalization so native process stderr assertions are robust on Windows while preserving exact semantic message text.

### Static/status tests

Updated `scripts/run_tests.py` static/status checks for:

- Phase 57G current-status surfaces;
- source-run coverage markers;
- documentation consistency;
- manual testing guidance consistency.

## 11. Commands used to test

### Pre-implementation verification

Command:

```text
python3 scripts/run_tests.py --all
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

Dependency note:

```text
Browser/Wasm rebuild smoke skipped because emcc was unavailable.
```

### Implementation test run

Focused command:

```text
python3 scripts/run_tests.py --structure --native --source-run --web --diagnostics --protocol --static
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
Selected test groups passed.
```

Classification:

```text
focused group passed
```

Aggregate command:

```text
python3 scripts/run_tests.py --all
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

### First compliance review test run

Focused command:

```text
python3 scripts/run_tests.py --source-run
```

Result:

```text
source-run PASS
Selected test groups passed.
```

Focused command:

```text
python3 scripts/run_tests.py --structure --native --source-run --web --diagnostics --protocol --static
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
Selected test groups passed.
```

Aggregate command:

```text
python3 scripts/run_tests.py --all
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

### Second compliance review test run

Focused command:

```text
python3 scripts/run_tests.py --diagnostics --web
```

Result:

```text
diagnostics PASS
web PASS
Selected test groups passed.
```

Focused command:

```text
python3 scripts/run_tests.py --structure --native --source-run --web --diagnostics --protocol --static
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
Selected test groups passed.
```

Aggregate command:

```text
python3 scripts/run_tests.py --all
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

### User-test follow-up test run

Focused command:

```text
python3 scripts/run_tests.py --diagnostics
```

Result:

```text
diagnostics PASS
Selected test groups passed.
```

Focused command:

```text
python3 scripts/run_tests.py --structure --native --source-run --web --diagnostics --protocol --static
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Selected test groups passed.
```

Aggregate command:

```text
python3 scripts/run_tests.py --all
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

### Final gap-check test run

Focused command:

```text
python3 scripts/run_tests.py --static
```

Result:

```text
static PASS
Selected test groups passed.
```

Aggregate command:

```text
python3 scripts/run_tests.py --all
```

Result:

```text
structure PASS
native PASS
source-run PASS
web PASS
diagnostics PASS
protocol PASS
static PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Classification:

```text
aggregate completed and passed
```

### Skipped dependency checks

Browser/Wasm rebuild smoke was skipped in this assistant/container environment because `emcc` was unavailable:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

This was a dependency skip, not a test failure. Manual browser runtime testing after a Wasm rebuild still requires an Emscripten environment.

## 12. Pass/fail result distinction

Final status:

```text
aggregate completed and passed
```

No aggregate timeout occurred.

No aggregate failure remained after the user-test follow-up.

No focused group failure remained after the user-test follow-up.

No focused group timeout occurred.

Dependency skipped:

```text
Browser/Wasm rebuild smoke skipped because emcc was unavailable.
```

## 13. Manual/browser testing guidance and expected outputs

### Required setup assumptions

Windows CMD or Visual Studio Developer Command Prompt with:

- Python 3 available as `python3` or `py -3`;
- Node.js available on `PATH`;
- a C compiler available on `PATH`, such as `clang` or MSVC-compatible tooling configured for the runner;
- Phase 57G changed files applied;
- Emscripten only if rebuilding browser Wasm.

If `python3` is not recognized on Windows, use `py -3`.

### Browser testing

Website-testable: partly.

Phase 57G does not add a visible browser UI control. The served website can test default behavior and status text. Full seeded Phase 57G behavior is source-run/test/protocol-facing unless a developer manually exercises worker/protocol settings.

If Emscripten is available, rebuild Wasm:

```cmd
scripts\windows\build_wasm.cmd
```

If `emcc` is unavailable, skipping browser Wasm rebuild is expected.

Serve the website:

```cmd
python3 -m http.server 8000 --directory web
```

Open:

```text
http://localhost:8000
```

The page/status text should mention Phase 57G and should not show a new browser UI control for the seeded uninitialized-storage mode.

Paste this program into the web editor:

```asm
.data
known DWORD 12345678h
x DWORD ?
buf BYTE 4 DUP(?)
.code
main PROC
    mov eax, x
    mov ebx, known
    mov cl, buf
main ENDP
END main
```

Expected default browser behavior:

```text
Program Console:
(empty)
```

```text
Memory Changes:
No memory changes.
```

Expected key final registers:

```text
EAX = 00000000h
EBX = 12345678h
ECX = 00000000h
EFLAGS = 00000000h
```

Expected Simulator Messages include:

```text
[simulator-warning] uninitialized-read line 7: Memory read range 00500004h..00500007h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
[simulator-warning] uninitialized-read line 9: Memory read range 00500008h..00500008h reads 1 byte from buf + 0; 1 of those byte still originated from uninitialized storage.
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

### Local command-line manual test program

Create `program.asm` at the repository root:

```asm
.data
known DWORD 12345678h
x DWORD ?
buf BYTE 4 DUP(?)
.code
main PROC
    mov eax, x
    mov ebx, known
    mov cl, buf
main ENDP
END main
```

First build the diagnostic producer and rendered-message tests:

```cmd
python3 scripts\run_tests.py --diagnostics
```

Expected:

```text
[diagnostics] PASS
Selected test groups passed.
```

#### Test A - default zero visible bytes

Command:

```cmd
set MASM32_DIAGNOSTIC_STARTUP_REGISTER_FLAG_MODE=
set MASM32_DIAGNOSTIC_UNINITIALIZED_STORAGE_VISIBLE_BYTE_MODE=
set MASM32_DIAGNOSTIC_STARTUP_STATE_SEED=
build\tests\diagnostic_json_producer.exe program.asm > out_default.json
python3 -c "import json; j=json.load(open('out_default.json')); print('phase', j['phaseSuffix'], j['phaseName']); print('registers', j['registers']['EAX']['hex'], j['registers']['EBX']['hex'], j['registers']['ECX']['hex'], j['registers']['EDX']['hex'], j['registers']['EFLAGS']['hex']); print('memoryChanges', j['memoryChanges']); print('messages'); [print('[{}] {}{}: {}'.format(m['kind'], m['code'], (' line {}'.format(m['line'])) if m.get('line') else '', m['message'])) for m in j['simulatorMessages']]"
```

Expected output:

```text
phase G Phase 57G - Seeded Random Uninitialized Storage Mode
registers 00000000h 12345678h 00000000h 00000000h 00000000h
memoryChanges []
messages
[simulator-warning] uninitialized-read line 7: Memory read range 00500004h..00500007h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
[simulator-warning] uninitialized-read line 9: Memory read range 00500008h..00500008h reads 1 byte from buf + 0; 1 of those byte still originated from uninitialized storage.
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

#### Test B - seeded uninitialized-storage visible bytes only

Command:

```cmd
set MASM32_DIAGNOSTIC_STARTUP_REGISTER_FLAG_MODE=
set MASM32_DIAGNOSTIC_UNINITIALIZED_STORAGE_VISIBLE_BYTE_MODE=seeded-random
set MASM32_DIAGNOSTIC_STARTUP_STATE_SEED=12345
build\tests\diagnostic_json_producer.exe program.asm > out_seeded_storage.json
python3 -c "import json; j=json.load(open('out_seeded_storage.json')); print('phase', j['phaseSuffix'], j['phaseName']); print('registers', j['registers']['EAX']['hex'], j['registers']['EBX']['hex'], j['registers']['ECX']['hex'], j['registers']['EDX']['hex'], j['registers']['EFLAGS']['hex']); print('memoryChanges', j['memoryChanges']); print('messages'); [print('[{}] {}{}: {}'.format(m['kind'], m['code'], (' line {}'.format(m['line'])) if m.get('line') else '', m['message'])) for m in j['simulatorMessages']]"
```

Expected output:

```text
phase G Phase 57G - Seeded Random Uninitialized Storage Mode
registers 479199B4h 12345678h 000000D5h 00000000h 00000000h
memoryChanges []
messages
[simulator-warning] uninitialized-read line 7: Memory read range 00500004h..00500007h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
[simulator-warning] uninitialized-read line 9: Memory read range 00500008h..00500008h reads 1 byte from buf + 0; 1 of those byte still originated from uninitialized storage.
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Visible bytes for uninitialized storage were initialized from the configured deterministic seed, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

#### Test C - seeded register/flag startup and seeded uninitialized-storage startup together

Command:

```cmd
set MASM32_DIAGNOSTIC_STARTUP_REGISTER_FLAG_MODE=seeded-random
set MASM32_DIAGNOSTIC_UNINITIALIZED_STORAGE_VISIBLE_BYTE_MODE=seeded-random
set MASM32_DIAGNOSTIC_STARTUP_STATE_SEED=12345
build\tests\diagnostic_json_producer.exe program.asm > out_seeded_both.json
python3 -c "import json; j=json.load(open('out_seeded_both.json')); print('phase', j['phaseSuffix'], j['phaseName']); print('registers', j['registers']['EAX']['hex'], j['registers']['EBX']['hex'], j['registers']['ECX']['hex'], j['registers']['EDX']['hex'], j['registers']['EFLAGS']['hex']); print('memoryChanges', j['memoryChanges']); print('messages'); [print('[{}] {}{}: {}'.format(m['kind'], m['code'], (' line {}'.format(m['line'])) if m.get('line') else '', m['message'])) for m in j['simulatorMessages']]"
```

Expected output:

```text
phase G Phase 57G - Seeded Random Uninitialized Storage Mode
registers 479199B4h 12345678h 3B5FD9D5h 8EE55794h 000000C0h
memoryChanges []
messages
[simulator-warning] uninitialized-read line 7: Memory read range 00500004h..00500007h reads 4 bytes from x + 0; 4 of those bytes still originated from uninitialized storage.
[simulator-warning] uninitialized-read line 9: Memory read range 00500008h..00500008h reads 1 byte from buf + 0; 1 of those byte still originated from uninitialized storage.
[simulator-notice] startup-state-notice: The simulator started general-purpose registers, modeled flags, and visible bytes for uninitialized storage from the configured deterministic seed. Uninitialized-origin metadata is preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.
[info] execution-complete: Execution completed successfully.
```

Regression signs:

- Phase output is not `phase G Phase 57G - Seeded Random Uninitialized Storage Mode`.
- Test A does not keep `EAX`, `ECX`, `EDX`, and `EFLAGS` at zero.
- Test B does not produce:

  ```text
  registers 479199B4h 12345678h 000000D5h 00000000h 00000000h
  ```

- Test C does not produce:

  ```text
  registers 479199B4h 12345678h 3B5FD9D5h 8EE55794h 000000C0h
  ```

- `memoryChanges` is anything other than `[]`.
- Uninitialized-read warnings disappear in seeded mode.
- Initialized `known` changes from `12345678h`.
- Program Console shows output for these programs.
- Any focused or aggregate test group reports `FAIL`.

## 14. Compliance review summary

The first compliance review checked scope control, completeness, code quality, diagnostics, tests, documentation, and TODO-style note disposition.

Issues found:

- Test completeness gap: all four startup-setting combinations were not directly asserted as changing both relevant runtime state categories in one execution.
- Test completeness gap: metadata preservation was covered generically, but not explicitly for all currently supported uninitialized-origin forms.

Fixes applied:

- Added source-run regression coverage proving seeded uninitialized-storage mode preserves uninitialized-origin diagnostics for:
  - `.DATA?`;
  - scalar `?`;
  - `DUP(?)`.
- Added source-run regression coverage proving combined seeded startup axes affect both:
  - an untouched seeded register;
  - a seeded uninitialized-storage value loaded from memory.

Verdict after first compliance review:

```text
complete
```

## 15. Re-review summary

The second compliance review re-read the guide and relevant spec sections, inspected changed files and nearby TODOs, reviewed tests for quality, checked documentation for accidental future promises, and reran relevant tests.

Issue found:

- Invalid Phase 57G startup-setting diagnostics were structured-tested but lacked exact rendered Simulator Messages coverage.

Fix applied:

- Added exact rendered Simulator Messages coverage for:

  ```text
  [ui-error] invalid-startup-setting: Invalid startup setting 'uninitializedStorageVisibleByteMode'. Accepted values: zero, seeded-random.
  ```

Final review verdicts:

- Scope verdict: complete.
- Documentation verdict: complete.
- Test coverage verdict: complete after rendered-message fix.
- TODO-style note verdict: complete.

## 16. User-test follow-up summary

A user ran Windows local tests and reported that web tests passed but diagnostics failed on Windows because the test expected Unix LF line endings in native process stderr:

```text
actual:   diagnostic_json_producer: invalid unsigned environment value\r\n
expected: diagnostic_json_producer: invalid unsigned environment value\n
```

Diagnosis:

```text
test expectation bug
```

The native diagnostic producer emitted the correct text. Windows produced CRLF line endings on stderr, while the Node test asserted LF exactly.

Fix applied:

- Updated `tests/web/test_diagnostic_rendering.mjs` to normalize native process output line endings before comparing exact semantic text.
- Added a documented helper:

  ```text
  normalizeProcessOutput(text)
  ```

Regression coverage:

- The existing diagnostic rendering test now covers this Windows CRLF case while preserving exact semantic output.

Tests rerun after user follow-up:

```text
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --structure --native --source-run --web --diagnostics --protocol --static
python3 scripts/run_tests.py --all
```

All passed after the fix.

## 17. Known limitations

- Browser/Wasm rebuild smoke testing could not be run in this assistant/container environment because `emcc` is unavailable.
- Phase 57G adds no visible browser UI control. Full seeded uninitialized-storage behavior is testable through source-run/test/protocol settings and through browser runtime only after a Wasm rebuild and settings injection path.
- The exact seeded byte stream is implementation-defined. Tests assert repeatability, divergence, and selected regression fixture outputs, but the canonical behavior is deterministic seeded operation rather than a published PRNG contract.
- `.CONST ?` and `.CONST DUP(?)` remain unsupported until Phase 57I.
- Startup randomization is not represented as a memory-change row. This is by design because startup state is not simulated program mutation.

## 18. Next recommended milestone

Next recommended milestone:

```text
Phase 57H - Startup-State Display Markers for Unchanged Randomized Values
```

Phase 57H should remain display-focused. It should not add new startup randomization modes, `.CONST ?` acceptance, parser syntax, or instruction semantics unless its guide section explicitly requires that behavior.

## 19. Changed-files ZIP/package produced

Packages produced during Phase 57G:

```text
milestone_57G_changed_files.zip
milestone_57G_compliance_review_changed_files.zip
milestone_57G_second_review_changed_files.zip
milestone_57G_user_followup_changed_files.zip
milestone_57G_final_gap_check_changed_files.zip
```

Recommended application order if applying incremental changed-file packages to a Phase 57F baseline:

1. `milestone_57G_changed_files.zip`
2. `milestone_57G_compliance_review_changed_files.zip`
3. `milestone_57G_second_review_changed_files.zip`
4. `milestone_57G_user_followup_changed_files.zip`
5. `milestone_57G_final_gap_check_changed_files.zip`

Alternatively, use a full final archive if one is produced later with this exact recommended name:

```text
Latest_repository_state_milestone_57G.zip
```
