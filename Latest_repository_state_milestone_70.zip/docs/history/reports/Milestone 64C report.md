# Milestone 64C report - Expanded EFLAGS Flag Display

## 1. Milestone title and scope

Milestone implemented:

```text
Phase 64C - Expanded EFLAGS Flag Display
```

Repository/archive milestone after this work:

```text
Phase 64C - Expanded EFLAGS Flag Display
```

Runtime/source-run MASM behavior phase after this work:

```text
Phase 64A - Planned-Read Coverage Correction for Existing Memory-Reading Instructions
```

Status interpretation:

Phase 64C changes final-state display formatting by showing modeled flag child rows under EFLAGS. It does not add MASM syntax, parser behavior, VM instruction behavior, executor behavior, new modeled flags, new flag semantics, or new diagnostics. Do not update supported-syntax runtime wording to say new MASM behavior was added.

Scope implemented:

- Kept the existing canonical `EFLAGS` final-register parent row.
- Added visually subordinate final-register child rows under `EFLAGS` for the currently modeled flags:
  - `CF`
  - `ZF`
  - `SF`
  - `OF`
- Displayed each modeled flag child row as `0` or `1` only.
- Derived modeled flag child values from the existing `EFLAGS` value already present in source-run/register display payloads.
- Preserved `EFLAGS` parent-row formatting as hex plus unsigned decimal.
- Preserved runtime/source-run MASM behavior phase metadata at Phase 64A.
- Preserved Phase 64B Simulator Messages grouping/order behavior.
- Updated `web/index.html` to reflect Phase 64C.
- Updated repository/archive current-status documentation to Phase 64C while preserving runtime/source-run MASM behavior Phase 64A.

Recommended repository archive after acceptance:

```text
Latest_repository_state_milestone_64C.zip
```

## 2. Source-of-truth files used

Canonical source-of-truth files used:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Supporting current-status, syntax, testing, and history files used:

- `README.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/TESTING_GUIDE.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`
- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 64B report.md`

Repository archive used as implementation base:

```text
Latest_repository_state_milestone_64B.zip
```

Changed-files packages produced during implementation and compliance review:

```text
milestone_64C_implementation.zip
milestone_64C_first_compliance_check.zip
milestone_64C_final_compliance_check.zip
```

Source-of-truth interpretation used:

- The full implementation specification owns product boundaries, stable behavior, display/source-run behavior expectations, current-status surface hygiene, Program Console versus Simulator Messages separation, and future/non-goal distinctions.
- The incremental implementation guide owns Phase 64C numbering, scope, tasks, required tests, acceptance criteria, status wording, and milestone-report obligations.
- Milestone reports are implementation history and evidence, not replacements for the canonical specification or guide.
- Audit/handoff reports are navigation and stale-assumption-prevention aids, not replacements for the canonical specification or guide.
- TODO-style notes are implementation-risk evidence only and do not override the target milestone, canonical guide, or canonical specification.

## 3. Exact requirements implemented

### 3.1 EFLAGS parent row preservation

The final-register display still includes the canonical `EFLAGS` row.

The parent row remains formatted as a 32-bit register-style row using the existing hex/unsigned display shape, for example:

```text
EFLAGS | 00000040h / 64
```

Phase 64C did not change the parent row into a flag-only row and did not remove existing EFLAGS display data.

### 3.2 Modeled flag child rows

Implemented subordinate child rows immediately after `EFLAGS` for the currently modeled flags:

```text
  CF   | 0
  ZF   | 1
  SF   | 0
  OF   | 0
```

The row order is:

1. `CF`
2. `ZF`
3. `SF`
4. `OF`

The child rows are visually subordinate through indentation and are placed under the `EFLAGS` row in the final-register display.

### 3.3 Display values

Each child flag row displays exactly one bit value:

```text
0
```

or:

```text
1
```

The implementation does not show hexadecimal, unsigned decimal, signed decimal, or validity annotation text for individual flag child rows.

### 3.4 Existing modeled state used as source of truth

The displayed child values are derived from the same modeled `EFLAGS` value used by execution and diagnostics.

Implemented bit positions:

```text
CF = EFLAGS bit 0
ZF = EFLAGS bit 6
SF = EFLAGS bit 7
OF = EFLAGS bit 11
```

The first compliance review replaced embedded numeric bit positions in row descriptors with documented constants:

```text
EFLAGS_CF_BIT
EFLAGS_ZF_BIT
EFLAGS_SF_BIT
EFLAGS_OF_BIT
```

The formatter first uses the structured `EFLAGS.unsigned` value. It also supports a safe hexadecimal fallback when `EFLAGS.hex` is present but `EFLAGS.unsigned` is absent.

### 3.5 Child rows are display-only

The new child rows are not treated as register aliases.

They do not receive alias write markers or `[unchanged]` markers.

They do not imply that `CF`, `ZF`, `SF`, or `OF` are independently writable user registers.

They are display rows derived from the canonical `EFLAGS` value.

### 3.6 Unmodeled flags remain absent

The implementation does not display or invent values for unmodeled x86 flags, including:

- `PF`
- `AF`
- `DF`
- `IF`
- `TF`

No future full-x86 flag display was added.

### 3.7 Flag-validity annotations remain deferred

Phase 64C displays modeled flag bit values only. Flag-validity annotations remain future display work.

The implementation does not add validity annotation text such as:

```text
[undefined]
```

or:

```text
[architecturally undefined; deterministic preserved value]
```

It also does not add new undefined-flag diagnostics and does not change the existing `undefined-flag-use` policy.

### 3.8 Source-run JSON unchanged

No source-run JSON schema change was required.

The existing final-register display payload already provides enough `EFLAGS` data for the browser formatter to derive the currently modeled flag child rows.

The implementation did not remove or rename existing `EFLAGS` fields.

### 3.9 Current-status and metadata preserved correctly

Repository/archive current-status surfaces were advanced to Phase 64C.

Runtime/source-run MASM behavior phase metadata remains Phase 64A because Phase 64C is display-only and does not add MASM runtime/source behavior.

Updated status surfaces include:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py` static status checks
- `web/index.html`

## 4. Explicit non-goals and future work not implemented

Not implemented in Phase 64C:

- New MASM syntax.
- New parser behavior.
- New VM instruction behavior.
- New executor behavior.
- New source-run JSON fields.
- New diagnostic codes.
- New diagnostic-policy families.
- New modeled flags.
- Full x86 flag display.
- Display for `PF`, `AF`, `DF`, `IF`, `TF`, or other unmodeled flags.
- Flag-validity annotations.
- New undefined-flag diagnostics.
- Changes to `undefined-flag-use` warning/error policy.
- Changes to arithmetic, logical, shift, rotate, compare, branch, or flag-control semantics.
- Changes to startup-state notice ordering.
- Changes to Phase 64B Simulator Messages grouping.
- Program Console changes.
- Memory-change semantic changes.
- EFLAGS user-edit controls.
- Debugger/editor behavior.
- Signed relational conditional jumps:
  - `jl`
  - `jle`
  - `jg`
  - `jge`
  - `jnge`
  - `jng`
  - `jnle`
  - `jnl`
- Unsigned relational conditional jumps:
  - `ja`
  - `jae`
  - `jb`
  - `jbe`
  - `jnbe`
  - `jnb`
  - `jnae`
  - `jna`
- `loop` or loop-family instructions.
- Indirect/register/memory/immediate jump targets.
- Branch-distance/type overrides such as `SHORT`, `NEAR PTR`, or `FAR PTR`.
- Stack instructions:
  - `push`
  - `pop`
  - `call`
  - `ret`
  - `leave`
- Procedure frames, arguments, locals, `USES`, `PROTO`, `INVOKE`, or calling conventions.
- Irvine32 callable routines beyond already-existing virtual `exit` terminator behavior.
- Windows API execution.
- PE loading/linking, object-file linkage, import libraries, or host include-file loading.
- Macro expansion.
- `OPTION NOKEYWORD` behavior or dynamic keyword-table mutation.
- Active-time watchdog behavior.
- Worker yielding/chunking for responsiveness.

Future work intentionally preserved:

- Phase 64D - Memory Change Source Attribution Display.
- Phase 65 - Signed Relational Conditional Jumps.
- Later unsigned relational conditional jumps.
- Later `loop` runtime behavior.
- Later stack/procedure/call/return phases.
- Later debugger/source-map/editor navigation phases.
- Phase 200 - Active Time Watchdog and Worker Responsiveness.
- Future full or expanded flag display, if a later phase explicitly implements additional flags.
- Future flag-validity display annotations, if a later phase explicitly implements them.
- Future Irvine32 routine expansion.
- Future `OPTION NOKEYWORD` keyword-control compatibility.
- Future memory-reading opcode planned-access additions when those future opcodes are implemented.

## 5. Assumptions used

### Assumption 1

- **Assumption:** The existing `EFLAGS.unsigned` field is sufficient for formatter-derived flag child rows.
- **Reason:** Source-run/register display payloads already include canonical `EFLAGS` register data. Phase 64C permits a formatter-only implementation when existing data is sufficient.
- **Risk:** A source-run or test path could provide only `EFLAGS.hex` and omit `EFLAGS.unsigned`.
- **How to change later:** Add a display-only structured modeled-flags field to source-run JSON if needed, keeping it backward-compatible and tested. The implemented formatter also includes a safe hex fallback, reducing this risk.

### Assumption 2

- **Assumption:** Phase 64C should remain entirely display-layer work and should not touch C core, Wasm API, parser, executor, or diagnostic schema.
- **Reason:** The target guide section defines Phase 64C as final-state display/browser/source-run formatting only, with no MASM behavior change.
- **Risk:** If a future UI rendering path cannot derive flag values from final-register data, display consistency could require a structured data path.
- **How to change later:** Introduce a narrowly scoped, display-only source-run field in a future display/data-shape phase, with no runtime semantic change.

### Assumption 3

- **Assumption:** Repository/archive status surfaces should advance to Phase 64C, while runtime/source-run MASM behavior metadata should remain Phase 64A.
- **Reason:** The guide explicitly says Phase 64C changes final-state display formatting only and does not add accepted MASM syntax or runtime/source-run behavior.
- **Risk:** Users may see Phase 64C on documentation/browser status while source-run JSON reports Phase 64A and misread that as stale metadata.
- **How to change later:** Continue using explicit dual-status wording in docs and reports whenever repository/archive status differs from runtime/source-run behavior phase.

### Assumption 4

- **Assumption:** New rendered Simulator Messages tests are not required for Phase 64C because it adds no diagnostic code, warning, runtime error, or Simulator Messages behavior.
- **Reason:** Phase 64C changes final-register display only. Existing diagnostics and Phase 64B message grouping should remain covered by regression tests.
- **Risk:** If formatter code shared between final-register display and Simulator Messages were accidentally coupled, message grouping could regress.
- **How to change later:** Existing web and diagnostics tests already cover Simulator Messages grouping; add explicit cross-tests only if a future change touches both systems.

### Assumption 5

- **Assumption:** Browser/Wasm rebuild smoke can remain dependency-skipped in this assistant/container environment.
- **Reason:** `emcc` is unavailable on PATH, and Phase 64C did not change C/Wasm sources.
- **Risk:** Locally served browser artifacts may be stale if a developer serves cached files or does not refresh/rebuild static assets as needed.
- **How to change later:** Run local browser/static serving and, if needed, rebuild with Emscripten after activating the emsdk environment, for example with `call C:\_CPP_TOOLS\emsdk\emsdk_env.bat` before the Windows build script.

## 6. Relevant TODO-style notes reviewed

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md, Phase 64C section
- Note text or summary:
  Phase 64C displays modeled flag bit values only. Flag-validity annotations remain future display work. Do not add `[undefined]` or architecture-validity annotations in this phase.
- Classification:
  future-owned
- Reason:
  This note directly constrains Phase 64C by excluding validity annotation display. It belongs to a later display/diagnostic presentation phase, not to Phase 64C.
- Action for this milestone:
  Preserved the deferral and added tests proving validity annotation text is absent from flag child rows.
```

```text
- Location:
  docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md and docs/FULL_IMPLEMENTATION_SPEC.md, modeled/unmodeled flag display guidance
- Note text or summary:
  Do not display or invent values for unmodeled x86 flags such as PF, AF, DF, IF, or TF unless a later phase explicitly implements them.
- Classification:
  future-owned
- Reason:
  Phase 64C owns only display of currently modeled CF, ZF, SF, and OF bits.
- Action for this milestone:
  Preserved the limitation and added tests proving unmodeled flags are not displayed.
```

```text
- Location:
  src/wasm/wasm_api.c near planned-read collection
- Note text or summary:
  Future memory-reading opcodes must be added to planned-read collection when their owning instruction milestones implement them.
- Classification:
  future-owned
- Reason:
  Phase 64C is display-only and adds no opcode, memory read, memory write, planned-read path, or memory-policy behavior.
- Action for this milestone:
  Left unchanged.
```

```text
- Location:
  README.md, docs/SUPPORTED_SYNTAX.md, docs/BUILDING_AND_DEVELOPMENT.md, docs/MILESTONE_HISTORY.md, and related deferred-feature notes
- Note text or summary:
  Signed relational jumps, unsigned relational jumps, loop, stack/procedure behavior, debugger/editor behavior, active-time watchdog behavior, and related branch/call features remain deferred.
- Classification:
  future-owned
- Reason:
  Phase 64C changes only final-register EFLAGS child display.
- Action for this milestone:
  Preserved these deferrals. During final gap check, corrected one stale broad supported-syntax phrase so that remaining deferred control-flow work is named precisely without implying already-implemented equality conditional jumps are future work.
```

## 7. TODO-style note disposition

### Target-owned TODO-style notes resolved

- None. No target-owned repository TODO-style note was identified for Phase 64C.

### Future-owned TODO-style notes intentionally preserved

- Flag-validity annotations remain future display work.
- Unmodeled x86 flags such as `PF`, `AF`, `DF`, `IF`, and `TF` remain future work.
- Future memory-reading opcode planned-read TODO in `src/wasm/wasm_api.c` remains valid for later memory-capable instruction milestones.
- Later branch/control-flow/debugger/watchdog deferrals remain valid.
- Future `OPTION NOKEYWORD` behavior remains deferred.

### Stale or contradicted TODO-style notes corrected

- `docs/SUPPORTED_SYNTAX.md` had one stale broad phrase describing “conditional control flow” as deferred. This contradicted already-implemented direct equality conditional jumps. During the final gap check, the wording was corrected to name the remaining future branch/control-flow systems precisely and explicitly acknowledge that `je`, `jz`, `jne`, and `jnz` direct executable targets are already implemented.

### Unresolved TODO-related risks

- None specific to Phase 64C.

### New TODO-style notes added

- None.

## 8. Design summary

Phase 64C was implemented as a focused formatter/display enhancement.

Primary design choices:

1. **Formatter-side derivation.** The browser formatter derives `CF`, `ZF`, `SF`, and `OF` from the existing canonical `EFLAGS` final-register payload. No C/Wasm/source-run JSON schema change was required.

2. **Parent row preserved.** The existing `EFLAGS` row remains the canonical parent row and keeps its hex/unsigned formatting.

3. **Child display rows only.** `CF`, `ZF`, `SF`, and `OF` are display rows. They are not register aliases, do not receive alias write markers, and do not imply independent writability.

4. **Documented bit constants.** The first compliance review replaced embedded bit numbers with documented constants for the modeled flags.

5. **Safe fallback behavior.** The formatter can derive flag bits from `EFLAGS.unsigned` and has a hex fallback for display payloads that contain `EFLAGS.hex` but not `EFLAGS.unsigned`.

6. **Strict scope.** No unmodeled flags, validity annotations, diagnostics, parser behavior, executor behavior, source-run metadata changes, or future milestone behavior were implemented.

7. **Status-surface hygiene.** Documentation and `web/index.html` identify repository/archive Phase 64C while preserving runtime/source-run MASM behavior Phase 64A.

## 9. Files changed

Changed project files in the final Phase 64C state:

- `README.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/SUPPORTED_SYNTAX.md`
- `scripts/run_tests.py`
- `tests/web/test_diagnostic_rendering.mjs`
- `tests/web/test_formatters.mjs`
- `web/index.html`
- `web/src/formatters.js`

Generated/native build artifacts were created or updated by test runs under build directories, but they are not treated as source changes for milestone design purposes.

## 10. Tests added

### 10.1 Formatter tests

Added or updated browser-side Node formatter tests covering:

- `EFLAGS` parent row remains present.
- `CF`, `ZF`, `SF`, and `OF` child rows appear under `EFLAGS`.
- Child flag rows display `0` or `1` only.
- Child flag rows derive correct bit values from `EFLAGS.unsigned`.
- Child flag rows derive correct bit values from `EFLAGS.hex` fallback when `unsigned` is unavailable.
- Child flag rows do not receive `[unchanged]` markers even when the parent `EFLAGS` row does.
- Child flag rows are not synthesized when `EFLAGS` is unavailable.
- Unmodeled flags are not displayed.
- Flag-validity annotation text is not displayed.
- Parent `EFLAGS` row formatting remains compatible with existing tests.

### 10.2 Source-run-to-formatter tests

Added or updated source-run-driven formatter tests covering:

- `xor eax, eax` final display with `ZF=1`.
- `mov al, 0FFh` followed by `add al, 1` final display with `CF=1` and `ZF=1`.
- `mov al, 7Fh` followed by `add al, 1` final display with `SF=1` and `OF=1`.
- `stc`, `clc`, and `cmc` final display proving `CF` tracks flag-control instructions.
- `test` final display proving `CF=0`, `OF=0`, and appropriate `ZF`/`SF` values.
- A Phase 64 equality conditional jump regression proving branch behavior remains unchanged while final modeled flags display correctly.

### 10.3 Static/status tests

Updated static status checks to verify:

- Repository/archive milestone text is Phase 64C.
- Runtime/source-run MASM behavior phase remains Phase 64A.
- Documentation describes Phase 64C as final-register display formatting only.
- Documentation does not claim Phase 64C adds MASM syntax or new flag semantics.

### 10.4 Regression tests preserved

Retained and reran previous coverage for:

- Phase 52A signed register display behavior.
- Phase 57H unchanged marker behavior.
- Phase 64 equality conditional jumps.
- Phase 64A planned-read behavior.
- Phase 64B Simulator Messages grouping.
- Existing diagnostic rendering.
- Program Console and Simulator Messages separation.
- Protocol status and source-run metadata status.

## 11. Commands used to test

### 11.1 Pre-implementation verification

Initial repository verification before implementation attempted the aggregate command:

```bash
python3 scripts/run_tests.py --all
```

Observed result:

```text
Timed out in the assistant/container environment; no usable partial output was captured.
```

Focused verification was then run. Results from repository verification:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Observed result summary:

```text
--structure: PASS
--native: timed out as a focused group in the verification environment, then native subtests were rerun individually and passed
--source-run: PASS
--web: PASS
--diagnostics: PASS
--protocol: PASS
--static: PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

Native subtests rerun during repository verification:

```text
test_milestone_zero: PASS
test_vm_cpu: PASS
test_vm_flags: PASS
test_diagnostic_policy: PASS
test_vm_memory: PASS
test_vm_layout: PASS
test_vm_exec: PASS
test_lexer: PASS
test_parser: PASS
test_data_section: PASS
test_object_map: PASS after compiling the Linux native executable directly from the same runner-listed sources
```

Classification:

```text
aggregate timed out in assistant/container environment, focused groups/subtests passed; emcc dependency skipped
```

### 11.2 Implementation verification

Aggregate command attempted after implementation:

```bash
python3 scripts/run_tests.py --all --quiet
```

Observed result:

```text
timed out in the assistant/container environment
```

Focused commands run after implementation:

```bash
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
```

Observed results:

```text
--structure: PASS
--native: PASS
--source-run: PASS
--web: PASS
--diagnostics: PASS
--protocol: PASS
--static: PASS
```

Classification:

```text
aggregate timed out in assistant/container environment, focused groups passed
```

Skipped dependency check:

```text
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

### 11.3 First compliance review verification

Commands rerun after first compliance fixes:

```bash
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
python3 scripts/run_tests.py --all --quiet
```

Observed results:

```text
--web: PASS
--structure: PASS
--native: PASS
--source-run: PASS
--diagnostics: PASS
--protocol: PASS
--static: PASS
--all: timed out in the assistant/container environment
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

Classification:

```text
aggregate timed out in assistant/container environment, focused groups passed; dependency skipped
```

### 11.4 Second compliance review verification

Commands rerun during second compliance review:

```bash
python3 scripts/run_tests.py --web --quiet
python3 scripts/run_tests.py --structure --quiet
python3 scripts/run_tests.py --native --quiet
python3 scripts/run_tests.py --source-run --quiet
python3 scripts/run_tests.py --diagnostics --quiet
python3 scripts/run_tests.py --protocol --quiet
python3 scripts/run_tests.py --static --quiet
python3 scripts/run_tests.py --all --quiet
```

Observed results:

```text
--web: PASS
--structure: PASS
--native: PASS
--source-run: PASS
--diagnostics: PASS
--protocol: PASS
--static: PASS
--all: timed out in the assistant/container environment
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

Classification:

```text
aggregate timed out in assistant/container environment, focused groups passed; dependency skipped
```

### 11.5 Final gap-check verification

Commands rerun after the final supported-syntax documentation wording fix:

```bash
python3 scripts/run_tests.py --static --quiet
python3 scripts/run_tests.py --web --quiet
```

Observed results:

```text
--static: PASS
--web: PASS
Browser/Wasm rebuild smoke: SKIP - emcc unavailable
```

Classification:

```text
focused groups passed; dependency skipped
```

## 12. Pass/fail results summary

- Aggregate command was run.
- Aggregate command did not complete in the assistant/container environment.
- The milestone report does not claim aggregate completed and passed.
- Focused groups passed after implementation and compliance review.
- Native focused group passed after implementation and compliance review.
- During initial repository verification only, native focused verification timed out and was rerun by individual native subtests/fixture-family binaries; those passed.
- No focused group failed after implementation.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable.

Result classification for final implementation state:

```text
aggregate timed out but focused groups passed
```

Dependency classification:

```text
group skipped because dependency was unavailable: browser/Wasm rebuild smoke skipped because emcc was unavailable
```

## 13. Manual/browser testing guidance and expected outputs

Phase 64C is website-testable. It changes the Final Registers panel only.

Setup assumptions:

- Apply the Phase 64C changed files.
- Serve the project normally.
- A Wasm rebuild is optional for Phase 64C because no C/Wasm source changed. A hard browser refresh is enough unless local served files are stale.

### Browser test 1 - default page-load program

Click Run without changing the default editor source.

Expected Simulator Messages:

```text
[simulator-notice] startup-state-notice: The simulator starts registers and modeled flags at 0. Uninitialized storage bytes are also zero-filled, with uninitialized-origin metadata preserved for code-quality diagnostics. Real MASM programs running on real systems should not rely on arbitrary register or flag startup values.

[info] execution-complete: Execution completed successfully.
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

Expected key Final Registers rows:

```text
EBX    | 00000002h / u: 2          / s:  2
EFLAGS | 00000040h / 64
  CF   | 0
  ZF   | 1
  SF   | 0
  OF   | 0
```

### Browser test 2 - zero result sets ZF

Program:

```asm
.code
main PROC
    xor eax, eax
main ENDP
END main
```

Expected key Final Registers rows:

```text
EAX    | 00000000h / u: 0          / s:  0
EFLAGS | 00000040h / 64
  CF   | 0
  ZF   | 1
  SF   | 0
  OF   | 0
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

### Browser test 3 - byte carry sets CF and ZF

Program:

```asm
.code
main PROC
    mov al, 0FFh
    add al, 1
main ENDP
END main
```

Expected key Final Registers rows:

```text
EAX    | 00000000h / u: 0          / s:  0
    AL |       00h / u: 0          / s:  0
EFLAGS | 00000041h / 65
  CF   | 1
  ZF   | 1
  SF   | 0
  OF   | 0
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

### Browser test 4 - signed overflow sets SF and OF

Program:

```asm
.code
main PROC
    mov al, 7Fh
    add al, 1
main ENDP
END main
```

Expected key Final Registers rows:

```text
EAX    | 00000080h / u: 128        / s:  128
    AL |       80h / u: 128        / s: -128
EFLAGS | 00000880h / 2176
  CF   | 0
  ZF   | 0
  SF   | 1
  OF   | 1
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

### Browser test 5 - TEST clears CF and OF while setting SF from operand

Program:

```asm
.code
main PROC
    mov eax, 80000000h
    stc
    test eax, eax
main ENDP
END main
```

Expected key Final Registers rows:

```text
EAX    | 80000000h / u: 2147483648 / s: -2147483648
EFLAGS | 00000080h / 128
  CF   | 0
  ZF   | 0
  SF   | 1
  OF   | 0
```

Expected Program Console:

```text

```

Expected Memory Changes:

```text
No memory changes.
```

### Windows CMD local testing guidance

From the project root in Windows CMD with Python and Node.js available:

```bat
py -3 scripts\run_tests.py --web --quiet
py -3 scripts\run_tests.py --diagnostics --quiet
py -3 scripts\run_tests.py --static --quiet
```

Expected snippets:

```text
[web] PASS
```

```text
[diagnostics] PASS
```

```text
[static] PASS
```

Optional broader focused verification:

```bat
py -3 scripts\run_tests.py --structure --quiet
py -3 scripts\run_tests.py --native --quiet
py -3 scripts\run_tests.py --source-run --quiet
py -3 scripts\run_tests.py --web --quiet
py -3 scripts\run_tests.py --diagnostics --quiet
py -3 scripts\run_tests.py --protocol --quiet
py -3 scripts\run_tests.py --static --quiet
```

Expected behavior:

```text
Every focused group reports PASS.
```

`program.asm` is not applicable for these local tests because the Phase 64C regression programs are already embedded in the test suite.

Regression signs:

- `EFLAGS` appears but no child rows appear under it.
- A child row is missing one of `CF`, `ZF`, `SF`, or `OF`.
- Child rows show anything other than `0` or `1`.
- Child rows show `[unchanged]`.
- Unmodeled flags such as `PF`, `AF`, `DF`, `IF`, or `TF` appear.
- Parent `EFLAGS` formatting changes from hex/unsigned display.
- Simulator Messages lose the blank line between startup notice and `execution-complete`.
- Program Console shows diagnostic text.
- Any focused local test command reports FAIL.

## 14. Compliance review summary

### First compliance review

Issues found:

- Minor code-quality issue: EFLAGS bit positions were embedded directly in `REGISTER_DISPLAY_ROWS`.
- Minor edge-case test gap: there was no explicit formatter test proving flag child rows are not synthesized when `EFLAGS` is absent.

Fixes applied:

- Added documented constants:
  - `EFLAGS_CF_BIT`
  - `EFLAGS_ZF_BIT`
  - `EFLAGS_SF_BIT`
  - `EFLAGS_OF_BIT`
- Updated Phase 64C row descriptors to use those constants.
- Added a formatter edge-case test proving `CF`, `ZF`, `SF`, and `OF` rows are omitted when `EFLAGS` is unavailable.

Files changed during first compliance review:

- `web/src/formatters.js`
- `tests/web/test_formatters.mjs`

Verdict after first compliance review:

```text
complete
```

### Second compliance review

Additional issues found:

- None.

Additional fixes applied:

- None.

Final second-review verdicts:

- Final scope verdict: complete.
- Final documentation verdict: complete.
- Final test coverage verdict: complete.
- Final TODO-style note verdict: complete.

### Final gap check

Missing work found:

- One stale documentation phrase in `docs/SUPPORTED_SYNTAX.md`: “conditional control flow” was still listed broadly as deferred, which contradicted already-implemented direct equality conditional jumps.

Fix applied:

- Updated the deferred list to name remaining future branch/control-flow systems precisely.
- Added explicit wording that `je`, `jz`, `jne`, and `jnz` are already implemented for direct executable code-label and procedure-entry targets.

Tests rerun after the final gap-check fix:

```bash
python3 scripts/run_tests.py --static --quiet
python3 scripts/run_tests.py --web --quiet
```

Results:

```text
--static: PASS
--web: PASS
```

Final verdict:

```text
complete
```

## 15. Re-review summary

The second review re-read the Phase 64C guide section, relevant specification sections, changed files, changed documentation, tests, TODO-style notes, and implementation assumptions.

Confirmed:

- Phase 64C requirements are met.
- `index.html` reflects Phase 64C.
- Changed documentation does not promise future behavior.
- Runtime/source-run MASM behavior metadata remains Phase 64A.
- No future milestone behavior was implemented.
- No stale TODO-style note was introduced.
- No target-owned TODO-style note remains unresolved.
- Tests are meaningful and cover success, edge, and regression cases for the display behavior.
- No new diagnostic path was added, so no new rendered diagnostic test was required beyond existing diagnostics regression coverage.

## 16. User-test follow-up summary

Prompt 8 was conditional and was not run.

The user reported that everything appeared to pass and proceeded directly to the final gap check.

No user-test discrepancy was reported.

No user-test fixes were required.

## 17. Known limitations

- Aggregate `python3 scripts/run_tests.py --all --quiet` timed out in the assistant/container environment. This is reported as an environment limitation, not as a project failure, because focused groups passed.
- Browser/Wasm rebuild smoke was skipped because `emcc` was unavailable in the assistant/container environment.
- Phase 64C is formatter/display behavior only. It does not add new source-run JSON fields, new flags, new flag semantics, or flag-validity annotations.
- Locally served browser artifacts can be stale if the developer does not refresh or rebuild as needed. Since no C/Wasm files changed, Emscripten rebuild is optional for this milestone.

## 18. Next recommended milestone

Next canonical phase:

```text
Phase 64D - Memory Change Source Attribution Display
```

After Phase 64D, the next normal control-flow implementation phase remains:

```text
Phase 65 - Signed Relational Conditional Jumps
```

## 19. Changed-files ZIP/package produced

Changed-files packages produced:

- `milestone_64C_implementation.zip`
- `milestone_64C_first_compliance_check.zip`
- `milestone_64C_final_compliance_check.zip`

No second compliance package was produced because no project files changed during the second compliance pass.

No full latest repository/archive ZIP was created during this milestone report step.

Recommended latest repository/archive name:

```text
Latest_repository_state_milestone_64C.zip
```
