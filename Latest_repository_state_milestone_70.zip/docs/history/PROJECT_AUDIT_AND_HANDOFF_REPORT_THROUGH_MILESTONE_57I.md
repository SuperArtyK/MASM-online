# Project Audit and Handoff Report Through Milestone 57I

Generated for the Online MASM32 Educational Simulator project.

This report is a curated continuity, audit, and stale-assumption prevention document. It extends the earlier `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md` style for the work completed from Phase 43 through Phase 57I. It is intended to be the first historical report read by future AI assistants after the canonical specification and implementation guide.

This report does not replace the canonical source-of-truth files.

---

## Read this first

Future assistants should treat this block as the minimum orientation before using the rest of this report.

```text
Current repository/archive milestone:
Phase 57I - .CONST Uninitialized Storage Acceptance

Current runtime/source-run MASM behavior phase:
Phase 57I - .CONST Uninitialized Storage Acceptance

Next canonical phase:
Phase 57J - .CONST Uninitialized Storage Diagnostics and Policy
```

Operational rules:

- The canonical source-of-truth files remain `docs/FULL_IMPLEMENTATION_SPEC.md` and `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`.
- Raw milestone reports are historical evidence only. They may contain true-at-the-time wording that was superseded by later milestones.
- Do not implement Phase 57J behavior unless Phase 57J is the selected target milestone.
- Do not treat `.CONST ?` / `.CONST DUP(?)` declaration diagnostics as implemented in Phase 57I. Phase 57I accepts the storage; Phase 57J owns declaration diagnostics and policy.
- Do not describe implemented behavior as future work merely because an older milestone report says it was future work at that time.

---

## 1. Authority and source-of-truth policy

The active project source of truth remains the canonical documentation pair in the repository:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

Authority split:

- `docs/FULL_IMPLEMENTATION_SPEC.md` owns product boundaries, stable behavior, cross-cutting rules, current/future/non-goal distinctions, diagnostic policy, status-surface hygiene, and stable display/source-run behavior expectations.
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` owns phase numbering, phase scope, per-phase implementation tasks, required tests, and acceptance criteria.
- `docs/SUPPORTED_SYNTAX.md` reflects implemented accepted/rejected syntax and user-facing diagnostics for the current runtime/source-run behavior phase.
- `docs/TESTING_GUIDE.md` explains aggregate/focused verification.
- `docs/MILESTONE_HISTORY.md` is historical navigation. It does not override the spec/guide.
- Milestone reports are historical evidence. They may contain statements that were true at the time but were superseded by later milestones.
- The earlier through-42 handoff is a navigation aid for older project history. This report continues that role through Phase 57I.

Important interpretation rule:

- If a milestone report contradicts the current canonical spec/guide or the verified latest repository behavior, the current canonical spec/guide and verified repository behavior win.
- If a completed implementation appears to diverge from the current spec/guide, do not silently reinterpret history. Flag the divergence and either fix implementation or update documentation intentionally in a target milestone.
- Do not treat older raw milestone reports as current behavior without checking the reconciliation and supersession sections in this report.

---

## 2. Files and evidence used

Primary repository archive inspected:

- `Latest_repository_state_milestone_57I.zip`

Canonical files inspected inside the archive:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`
- `docs/SUPPORTED_SYNTAX.md`
- `docs/TESTING_GUIDE.md`
- `docs/MILESTONE_HISTORY.md`
- `docs/BUILDING_AND_DEVELOPMENT.md`
- `README.md`

Historical evidence files available in the audit session:

- `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_42.md`
- `Milestone 43 report.md`
- `Milestone 44 report.md`
- `Milestone 45 report.md`
- `Milestone 46 report.md`
- `Milestone 47 report.md`
- `Milestone 48 report.md`
- `Milestone 49 report.md`
- `Milestone 50 report.md`
- `Milestone 50A report.md`
- `Milestone 50B report.md`
- `Milestone 51 report.md`
- `Milestone 52 report.md`
- `Milestone 52A report.md`
- `Milestone 53 report.md`
- `Milestone 53A report.md`
- `Milestone 53B report.md`
- `Milestone 53C report.md`
- `Milestone 53D report.md`
- `Milestone 53E report.md`
- `Milestone 54 report.md`
- `Milestone 55 report.md`
- `Milestone 56 report.md`
- `Milestone 56A report.md`
- `Milestone 56B report.md`
- `Milestone 57 report.md`
- `Milestone 57-CORR1 report.md`
- `Milestone 57-CORR2 report.md`
- `Milestone 57A report.md`
- `Milestone 57B report.md`
- `Milestone 57C report.md`
- `Milestone 57D report.md`
- `Milestone 57E report.md`
- `Milestone 57F report.md`
- `Milestone 57G report.md`
- `Milestone 57H report.md`
- `Milestone 57I report.md`


---

## 3. Current verified repository state

The latest inspected repository state is:

```text
Repository/archive milestone:
Phase 57I - .CONST Uninitialized Storage Acceptance

Runtime/source-run MASM behavior phase:
Phase 57I - .CONST Uninitialized Storage Acceptance
```

Verification command run during this handoff preparation:

```bash
cd /mnt/data/audit_repo_57I
python3 scripts/run_tests.py --all
```

Observed result summary:

```text
[structure] PASS - repository structure and metadata checks passed
[native] PASS - native C non-source-run tests passed
[source-run] PASS - source-run integration binary passed independently
[web] PASS - browser-side Node module tests passed
[diagnostics] PASS - native diagnostic producer and rendered messages passed
[protocol] PASS - protocol tests passed independently
[static] PASS - runner/documentation consistency checks passed
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
All implemented milestone tests passed.
```

Conclusion:

- Latest verified implementation state: through Phase 57I.
- Runtime/source-run behavior also advances to Phase 57I because Phase 57I changes accepted source behavior by accepting `.CONST ?` and `.CONST DUP(?)` declarations.
- The browser/Wasm rebuild smoke was not run because `emcc` was unavailable in the environment. This is a dependency skip, not a test failure.

---

## Minimum required reading path for future assistants

When using this handoff to continue the project, read these sections first:

1. `Read this first`
2. `1. Authority and source-of-truth policy`
3. `3. Current verified repository state`
4. `4. Canonical next phase`
5. `6. Current behavior ledger`
6. `8. Superseded assumptions and stale wording traps`
7. `9. Current high-risk areas`
8. the specific milestone entry in `7. Milestone 43-57I reconciliation ledger` that is relevant to the current task

Do not begin implementation from a raw milestone report alone. Use raw reports only after this report and the canonical spec/guide establish current behavior.

---

## 4. Canonical next phase

The next canonical phase in the current implementation guide is:

```text
Phase 57J - .CONST Uninitialized Storage Diagnostics and Policy
```

Phase 57J owns configurable declaration diagnostics for `.CONST ?` and `.CONST DUP(?)` declarations accepted by Phase 57I.

Current Phase 57I behavior intentionally does not implement the Phase 57J declaration diagnostic policy.

Important next-phase boundary:

- Phase 57I accepts `.CONST ?` and `.CONST DUP(?)` storage as read-only uninitialized-origin storage.
- Existing `uninitialized-read` diagnostics apply when those bytes are read.
- Existing `.CONST` write protection applies to direct and computed writes.
- Phase 57J must add declaration-level diagnostics such as `const-uninitialized-storage`.
- Phase 57J must not add new `.CONST` syntax beyond Phase 57I.
- Phase 57J must not weaken `.CONST` write protection.
- Phase 57J must not add browser UI controls unless the guide is intentionally changed.


Phase 57J implementation checklist:

- Activate the reserved diagnostic-policy registry family `const-uninitialized-storage` as an implemented/current family.
- Support policy values `off`, `warn`, and `error` through the source-run/test-facing policy path.
- Keep the default policy as `warn` unless the canonical guide is deliberately changed.
- Emit one declaration diagnostic per accepted `.CONST ?` or `.CONST DUP(?)` declaration that contains uninitialized-origin storage.
- Attach the diagnostic to the declaration token/declarator and preserve source line, column, byte offset, and span length.
- Render the diagnostic through Simulator Messages, not Program Console.
- Keep the declaration diagnostic separate from later read-time `uninitialized-read` diagnostics.
- In `error` mode, refuse execution before runtime begins.
- In `off` mode, suppress only the declaration diagnostic; do not suppress read-time `uninitialized-read` diagnostics unless their own policy is off.
- Preserve mandatory `.CONST` write protection and its diagnostic precedence.
- Add structured diagnostic tests, exact rendered Simulator Messages tests, policy routing tests, invalid-policy tests, and registry/default-value tests.
- Do not add browser UI controls for this policy unless the guide is deliberately revised to require them.

---

## 5. Non-negotiable project invariants

Future assistants must preserve these rules unless the canonical spec and guide are deliberately changed.

### 5.1 Product boundary

The project is:

- a static browser application;
- a C99 MASM-like parser plus internal VM compiled to WebAssembly with Emscripten;
- an educational MASM32/Irvine32-style console simulator;
- an incremental learning/debugging tool.

The project is not:

- a full MASM compiler;
- a full x86 emulator;
- a Windows emulator;
- a PE loader;
- a real linker;
- a WinAPI simulator;
- a host include loader;
- a full macro assembler.

### 5.2 C99 core boundary

Core VM/parser/executor/memory/Irvine32/runtime/Wasm-facing code remains C99:

- use `.c` and `.h` files for core modules;
- no C++ core code;
- no C++ standard library;
- no classes/templates/exceptions/RTTI;
- no `extern "C"` wrappers unless language policy is intentionally changed later;
- browser UI may remain JavaScript/TypeScript.

### 5.3 Documentation and API comments

Every source/header file needs a file-level block header. Every public function, struct, enum, and module API needs Doxygen-style `///` comments.

### 5.4 Memory safety

All simulated memory reads and writes must route through checked VM memory helpers. Centralized range, region, permission, and overflow checks are mandatory.

`.CONST` protection must be enforced by final effective address range and central memory permissions, not only by static symbol detection.

### 5.5 UI stream separation

Program Console and Simulator Messages are separate streams.

- Program Console is simulated program I/O.
- Simulator Messages contain diagnostics, warnings, notices, runtime errors, and execution-status messages.

User-visible diagnostic paths need structured diagnostic tests and exact rendered Simulator Messages tests.

### 5.6 Incremental scope

Implement one focused milestone at a time unless explicitly instructed otherwise. Do not implement future milestone behavior early for convenience.

---

## 6. Current behavior ledger

This section summarizes current behavior after Phase 57I. It is intentionally organized by topic rather than only by chronology.

### 6.1 Instruction support through Phase 57I

Current executable instruction families include the subset built incrementally through signed `idiv` plus earlier supported instructions. Relevant Phase 43-57I additions include:

- `inc` / `dec`
- `and` / `or` / `xor`
- `not`
- `shl` / `sal`
- `shr`
- `sar`
- `rol`
- `ror`
- `lea`
- unsigned one-operand `mul`
- signed one-operand `imul`
- selected two- and three-operand `imul`
- unsigned one-operand `div`
- signed one-operand `idiv`
- virtual Irvine32 `exit` from Phase 42 remains available when `INCLUDE Irvine32.inc` is active

Still not implemented unless the current guide/repository later proves otherwise:

- labels and jumps;
- conditional jumps;
- `loop`;
- stack instructions such as `push`, `pop`, `call`, `ret`, `leave`;
- procedure frame semantics;
- Irvine32 routine bodies beyond the virtual `exit` terminator;
- real Windows API calls;
- PE/linker behavior;
- host include loading;
- full macro expansion;
- executable QWORD/SQWORD memory operations.

### 6.2 Memory layout and validation

Current memory behavior includes:

- checked VM memory regions;
- fixed-layout compatibility mode;
- automatic deterministic layout support;
- mandatory Level 1 region-only validation;
- optional section-capacity validation;
- optional section-image validation;
- optional declared-object-bounds validation;
- mandatory `.CONST` write protection;
- uninitialized-origin tracking;
- planned access checks for strict validation modes where applicable.

Validation levels established by Phase 53A/53B:

```text
Level 1 - Region-only validation
  Always enforced. Validates final effective address, byte range, region containment, permissions, .CONST protection, and address overflow.

Level 2 - Section-capacity validation
  Optional warning/strict policy.

Level 3 - Section-image validation
  Optional warning/strict policy.

Level 4 - Declared-object validation
  Optional allocated-object warning/strict behavior.
```

Default source execution remains closest to native MASM-style memory behavior while still enforcing simulated memory safety and `.CONST` protection.

### 6.3 `.CONST` behavior through Phase 57I

Current `.CONST` behavior:

- initialized `.CONST` declarations are allocated in the `.CONST` region;
- `.CONST` storage is read-only to simulated program writes;
- direct `.CONST` writes are rejected;
- computed writes whose final byte range overlaps `.CONST` are rejected through runtime memory permission/range checks;
- cross-region accesses overlapping protected `.CONST` can report `region-boundary-crossing` where applicable;
- `.CONST ?` declarations are accepted as of Phase 57I;
- `.CONST DUP(?)` declarations are accepted as of Phase 57I;
- accepted `.CONST ?` and `.CONST DUP(?)` bytes retain uninitialized-origin metadata;
- reads from accepted `.CONST` uninitialized-origin bytes are allowed if ordinary memory validation succeeds;
- existing `uninitialized-read` diagnostics apply when those bytes are read;
- Phase 57G seeded uninitialized-storage visible-byte mode includes `.CONST` uninitialized-origin bytes after Phase 57I.

Current `.CONST` non-behavior:

- Phase 57I does not add declaration-level diagnostics for `.CONST ?` or `.CONST DUP(?)`.
- Phase 57J owns future configurable declaration diagnostics for this suspicious teaching pattern.
- `.CONST` write protection is mandatory and must not become optional.

### 6.4 Uninitialized-origin and visible-byte behavior

Current uninitialized-origin behavior:

- `.DATA?`, scalar `?`, `DUP(?)`, and Phase 57I `.CONST ?` / `.CONST DUP(?)` storage carry uninitialized-origin metadata.
- Default visible bytes are deterministic zero-filled unless overwritten.
- The metadata is separate from the visible byte value.
- Default `uninitialized-read` behavior is warning mode after Phase 53C.
- Explicit opt-out suppresses only `uninitialized-read` teaching diagnostics.
- Strict mode stops before consuming uninitialized-origin bytes.
- Phase 57G adds opt-in seeded visible bytes for uninitialized-origin storage.
- Phase 57I extends seeded uninitialized-storage visible-byte behavior to uninitialized-origin `.CONST` bytes.

Do not collapse these concepts:

- visible byte value;
- initialized/uninitialized origin metadata;
- declaration-level `.CONST ?` warning policy;
- read-time `uninitialized-read` diagnostics.

### 6.5 Modeled flags and undefined-flag behavior

Current modeled flags:

- `CF`
- `ZF`
- `SF`
- `OF`

Phase 50A added internal validity metadata for modeled flags. Phase 50B added shared undefined-flag-use diagnostics for flag consumers. Phase 53C changed the default undefined-flag-use policy to warning mode.

Current behavior:

- deterministic EFLAGS bits are preserved where specified;
- validity metadata distinguishes deterministic simulator values from architecturally valid flag values;
- undefined producer warnings remain in place for relevant shift/rotate cases;
- flag consumers such as `adc`, `sbb`, and `cmc` use undefined-flag-use policy;
- default undefined-flag-use behavior is warning mode;
- strict/error mode can stop before consuming an architecturally undefined modeled flag.

Future flag consumers must use the shared undefined-flag-use helper.

### 6.6 Diagnostic policy behavior

Current implemented diagnostic-policy registry families include:

- `uninitialized-read`
- `undefined-flag-use`
- `compatibility-notice`
- `startup-state-notice`

Reserved/inactive or future-owned families include:

- `const-uninitialized-storage` until Phase 57J implements it;
- `code-image-read` or `.code` access policy families until their owning future phase;
- other future diagnostic families only when activated by the guide.

Public compatibility behavior:

- existing public `strict` settings are mapped through compatibility helpers to central `error` where applicable;
- compatibility notices remain non-fatal;
- compatibility-notice `error` is not current behavior;
- section-capacity, section-image, and declared-object validation remain on their existing memory-validation policy paths, not necessarily central registry families.

Default teaching diagnostics after Phase 53C/53D/57E:

- uninitialized reads warn by default;
- undefined flag use warns by default;
- compatibility notices are on by default;
- startup-state notice is on by default.

### 6.7 Startup-state behavior

Default startup behavior:

- general-purpose registers start at zero;
- modeled flags start at zero;
- `EIP` starts at zero;
- unmodeled EFLAGS bits remain clear;
- uninitialized-origin storage visible bytes are zero-filled by default while metadata is preserved.

Phase 57E added a default non-fatal startup-state notice through Simulator Messages.

Phase 57F added an opt-in seeded-random startup mode for general-purpose registers and modeled flags:

```text
startup_register_flag_mode = zero | seeded-random
startup_state_seed = <u32>
```

Phase 57G added an independent opt-in seeded-random visible-byte mode for uninitialized-origin storage:

```text
uninitialized_storage_visible_byte_mode = zero | seeded-random
startup_state_seed = <u32>
```

Important boundaries:

- register/flag startup randomization and uninitialized-storage visible-byte randomization are separate axes;
- default remains zero behavior;
- no host randomness, wall-clock randomness, process memory, or `rand()` nondeterminism should be used;
- initialized `.data` and initialized `.CONST` bytes are not randomized;
- seeded uninitialized storage still preserves uninitialized-origin metadata.

### 6.8 Parser, symbol, include, and compatibility behavior

Current relevant parser policies:

- Instruction names, directives, registers, virtual includes, and Irvine32 routine names remain case-insensitive.
- User-defined symbols obey the documented `OPTION CASEMAP` policy.
- `INCLUDE Irvine32.inc` is a virtual include recognized by the simulator.
- `exit`, `Exit`, and `EXIT` remain accepted case-insensitively when `INCLUDE Irvine32.inc` is active.
- `INCLUDE Macros.inc` is accepted only as limited compatibility metadata/notice behavior, not real macro expansion.
- `.386`, `.486`, `.586`, `.686`, `.model flat, stdcall`, `.stack`, `TITLE`, `SUBTITLE`, and `PAGE` compatibility notices are current behavior where accepted.
- Unsupported `.model` forms remain errors.
- Compact negative register-indirect displacements such as `[eax-4]` are accepted after Phase 57-CORR2 when equivalent spaced forms are supported.
- Unsupported scaled-index/base-plus-index addressing remains rejected unless a later phase implements it.

### 6.9 Display and source-run output behavior

Current output/display behavior:

- Program Console and Simulator Messages are separate streams.
- Final register display includes width-aware hexadecimal, unsigned decimal, and signed decimal for known-width integer registers/aliases.
- `EFLAGS` remains hex/unsigned-oriented rather than signed display.
- Memory-change rows include signed display where width is known and supported.
- Final-register `[unchanged]` display markers are added for canonical parent register families not explicitly written by the program.
- Alias rows do not receive their own `[unchanged]` markers.
- Same-value writes still count as writes because Phase 57H uses explicit write tracking, not final-value equality.
- Source-run JSON-compatible `registerWrites` metadata exists for display.

### 6.10 Repository/archive milestone vs runtime/source-run behavior phase

Current state after Phase 57I:

```text
Repository/archive milestone:
Phase 57I - .CONST Uninitialized Storage Acceptance

Runtime/source-run MASM behavior phase:
Phase 57I - .CONST Uninitialized Storage Acceptance
```

Maintenance-only, display-only, documentation-only, test-runner-only, and some diagnostic architecture phases may advance repository/archive status without advancing runtime/source-run MASM behavior phase.

Do not "fix" an apparent mismatch unless the target phase explicitly changes runtime-visible MASM/source behavior or requires metadata advancement.

---

## 7. Milestone 43-57I reconciliation ledger

This ledger summarizes decision-relevant facts. Consult raw milestone reports only for detailed provenance.

### Phase 43 - INC and DEC

Primary historical evidence: `Milestone 43 report.md`

Implemented:

- Runtime `inc` and `dec` for 8/16/32-bit register and unambiguous memory destinations.
- Signed PTR aliases by width.
- Read-modify-write memory behavior through checked helpers.
- MASM-compatible rejection of ambiguous memory destinations such as `inc [eax]`.
- `ZF`, `SF`, and `OF` update; `CF` is preserved.

Did not implement:

- Future bitwise/shift/control-flow/stack/procedure/Irvine32 expansion.
- Executable QWORD/SQWORD memory operations.

Regression watch:

- Failed memory reads/writes must not partially mutate state.
- `.CONST` computed writes must fail centrally.

### Phase 44 - AND, OR, and XOR

Primary historical evidence: `Milestone 44 report.md`

Implemented:

- Runtime `and`, `or`, and `xor` for register/memory forms where width is inferable or explicit.
- Register, immediate, and memory source combinations within supported shapes.
- Memory destinations with register/immediate sources when unambiguous.
- Logical flag behavior: `ZF` and `SF` update; `CF` and `OF` clear.

Did not implement:

- `not`, shifts, rotates, `cmp`, control flow, stack/procedures, executable QWORD/SQWORD.

Regression watch:

- Memory-to-memory and immediate-destination forms remain rejected.
- Untyped memory/immediate forms remain ambiguous.

### Phase 45 - NOT

Primary historical evidence: `Milestone 45 report.md`

Implemented:

- Runtime unary `not` for 8/16/32-bit register and unambiguous memory destinations.
- Signed PTR aliases by width.
- Flag preservation: modeled flags remain unchanged.

Did not implement:

- Shift/rotate/control-flow/stack/procedure behavior.

Regression watch:

- Compile-time expression `NOT` remains separate from runtime instruction `not`.

### Phase 46 - SHL and SAL

Primary historical evidence: `Milestone 46 report.md`

Implemented:

- Runtime `shl` and `sal` as equivalent left-shift operations.
- Register/memory destinations at supported widths.
- Immediate byte counts and `CL` count operand.
- Count masking: `effective_count = raw_count & 31`.
- Count-zero no-op preserving destination and modeled flags.
- Default undefined-shift warning behavior; strict undefined-shift validation path.
- Flag-specific diagnostics for architecturally undefined modeled flags.

Did not implement:

- Shift-right, rotates, control flow, stack/procedures, PF/AF, QWORD/SQWORD execution.

Regression watch:

- `SAL` and `SHL` are same operation but retain mnemonic identity.
- Undefined shift warnings do not imply nondeterministic simulator state; the simulator preserves flagged values deterministically.

### Phase 47 - SHR

Primary historical evidence: `Milestone 47 report.md`

Implemented:

- Runtime logical right shift `shr`.
- Same destination/count policy as Phase 46.
- Count-zero no-op.
- Undefined modeled-flag warnings/strict behavior for applicable cases.

Did not implement:

- `sar`, rotates, control flow, stack/procedures.

Regression watch:

- `shr` fills high bits with zero.
- Count registers other than `CL` remain rejected.

### Phase 48 - SAR

Primary historical evidence: `Milestone 48 report.md`

Implemented:

- Runtime arithmetic right shift `sar`.
- High bits filled from original sign bit.
- Same destination/count policy as previous shift phases.
- Undefined modeled-flag warning/strict behavior.

Did not implement:

- Rotates, control flow, stack/procedures.

Regression watch:

- Effective count >= width produces deterministic sign-fill behavior while preserving undefined modeled flags as specified.

### Phase 49 - ROL

Primary historical evidence: `Milestone 49 report.md`

Implemented:

- Runtime rotate-left `rol`.
- Register/memory destinations, immediate/CL counts.
- Count masking and rotate amount handling.
- `CF` updates for nonzero counts.
- `ZF` and `SF` are preserved because `ROL` does not define them.
- `OF` defined for count 1; default `undefined-modeled-flag` warning for other nonzero counts.

Did not implement:

- Rotate-right, carry rotates, smart flag-consumer behavior, control flow, stack/procedures.

Regression watch:

- Rotate undefined modeled-flag warnings do not become strict shift errors; strict undefined-shift validation remains shift-only unless later changed.

### Phase 50 - ROR

Primary historical evidence: `Milestone 50 report.md`

Implemented:

- Runtime rotate-right `ror`.
- Same rotate destination/count policy as `rol`.
- `CF` receives most significant bit of rotated result for nonzero counts.
- `OF` for count 1 is XOR of the two most significant bits of the rotated result.
- `ZF`/`SF` preserved.
- Undefined `OF` warning for non-one nonzero counts.

Did not implement:

- Smart flag-validity metadata, flag-consumer diagnostics, carry rotates.

Regression watch:

- `ror al, 8` has nonzero effective count and rotate amount 0; destination bits may be unchanged, but flag behavior/warnings still follow nonzero-count rotate policy.

### Phase 50A - Undefined Modeled Flag Validity Metadata

Primary historical evidence: `Milestone 50A report.md`

Implemented:

- Internal validity metadata for `CF`, `ZF`, `SF`, and `OF`.
- Metadata distinguishes deterministic EFLAGS bits from architecturally valid flags.
- Undefined producer cases mark only the affected modeled flags invalid.
- Rollback/no-partial-mutation behavior includes flag validity metadata.

Did not implement:

- New syntax.
- Website-visible flag-validity display.
- Consumer diagnostics.

Regression watch:

- Preserve metadata on flag-preserving instructions.
- Mark metadata valid when helpers define/set/clear/write flags.

### Phase 50B - Undefined Flag Use Diagnostics for Flag Consumers

Primary historical evidence: `Milestone 50B report.md`

Implemented:

- Shared C99 helper for instructions consuming modeled flags.
- `undefined-flag-use` diagnostic.
- Policies: `off`, `warn`, `error`.
- Integrated with existing flag consumers at the time: `adc`, `sbb`, `cmc`.

Initial behavior at the time:

- Browser/default behavior remained off until later changed.

Superseded by later milestone:

- Phase 53C changed default undefined-flag-use behavior to warning mode.

Regression watch:

- Future flag consumers must use the shared helper.

### Phase 51 - Post-30 Memory, Diagnostic, Irvine, and Instruction Integration Smoke Harness

Primary historical evidence: `Milestone 51 report.md`

Implemented:

- Validation-only smoke coverage for memory/layout/diagnostics/Irvine/post-30 instruction families.
- Fixed-layout vs automatic deterministic layout equivalence coverage.
- `.CONST` permission precedence coverage.
- Uninitialized read-modify-write warning coverage.
- Irvine32 `exit` casing and CASEMAP preservation coverage.

Did not implement:

- New MASM syntax, runtime behavior, parser behavior, instructions, or UI settings.

Regression watch:

- Phase 51 is validation-only. Do not infer feature additions from it.

### Phase 52 - LEA

Primary historical evidence: `Milestone 52 report.md`

Implemented:

- Runtime `lea` computes effective addresses without memory reads or writes.
- Supported 32-bit register destinations only.
- Supported effective-address source forms reuse the currently supported address-expression subset:
  - `lea reg32, symbol`
  - `lea reg32, symbol[offset]`
  - `lea reg32, [symbol + constant]`
  - `lea reg32, [reg32]`
  - `lea reg32, [reg32 + constant]`
  - `lea reg32, [reg32 - constant]`
  - `lea reg32, symbol[reg32]`
  - `lea reg32, [symbol + reg32]`
- Effective address arithmetic for register-derived expressions wraps modulo 32 bits.
- Modeled flags and flag-validity metadata are preserved exactly.
- LEA emits no Program Console output and produces no memory-change rows.
- LEA source operands do not trigger memory-read, unaligned, object-bound, uninitialized-read, `.CONST` permission, or executable QWORD/SQWORD diagnostics merely because an address is computed.
- Source-run and browser metadata advanced to Phase 52 because LEA adds runtime-visible MASM behavior.

Did not implement:

- Scaled-index addressing.
- `base + index * scale` address expressions.
- `OFFSET symbol` as a valid LEA source.
- Memory destinations.
- Control flow, stack/procedure behavior, multiplication/division, executable QWORD/SQWORD operations, broader Irvine32 behavior, macro behavior, WinAPI behavior, PE loading, linking, host include loading, or browser settings UI.
- Signed display formatting; Phase 52A owns that display-only follow-up.

Regression watch:

- LEA is address-only. Do not route LEA through dereference-oriented memory validation helpers that emit memory diagnostics or executable-width diagnostics.
- Keep tests proving LEA over `.DATA?`, `.CONST`, QWORD/SQWORD declarations, unmapped computed addresses, and object-bound validation settings remains diagnostic-free when the source expression itself is valid.
- Keep static/source-span diagnostics for invalid LEA source/destination forms, unsupported scaled-index syntax, unknown symbols, and static displacement overflow.

### Phase 52A - Signed Register and Memory Value Display

Primary historical evidence: `Milestone 52A report.md`

Implemented:

- Width-aware signed decimal display for known-width 8/16/32-bit register and memory values.
- Register alias grouping.
- Improved memory-change formatting.
- Preserved source-run JSON semantics and unsigned fields.

Did not implement:

- Runtime semantics.
- Signed QWORD/SQWORD display.

Regression watch:

- Display width controls signed interpretation, not declaration signedness or parent register width.
- `EFLAGS` remains special.

### Phase 53 - Unsigned MUL

Primary historical evidence: `Milestone 53 report.md`

Implemented:

- One-operand unsigned `mul` for 8/16/32-bit register and unambiguous memory sources.
- Implicit accumulator result behavior:
  - `mul r/m8`: `AL * source8 -> AX`
  - `mul r/m16`: `AX * source16 -> DX:AX`
  - `mul r/m32`: `EAX * source32 -> EDX:EAX`
- `CF` and `OF` indicate whether upper half is nonzero.
- `ZF` and `SF` preserved deterministically.
- Memory sources route through checked reads and do not create memory-change rows.

Did not implement:

- Signed multiply.
- Division.
- QWORD/SQWORD execution.
- Scaled-index addressing.

Regression watch:

- Failed memory reads must not partially mutate accumulator registers or flags.

### Phase 53A - Memory Validation Policy Clarification and Symbol-Offset Runtime Correction

Primary historical evidence: `Milestone 53A report.md`

Implemented:

- Formal Level 1/2/3/4 memory validation policy split.
- Corrected parser/static symbol-offset validation so valid representable symbol-offset memory operands are not rejected too early for crossing object/section boundaries.
- Preserved final runtime byte-range enforcement through checked helpers.
- Preserved `.CONST` write protection precedence.
- Added planned access checks for strict allocated-object validation.

Did not implement:

- Section-capacity validation.
- Section-image validation.
- Browser settings UI.
- Phase 54 signed `imul`.

Superseded/followed by:

- Phase 53B implements section-capacity and section-image validation modes.

Regression watch:

- Parser should reject malformed/unrepresentable operands, not valid Level-1-contained accesses merely because they cross object/image boundaries.

### Phase 53B - Section-Capacity and Section-Image Validation Modes

Primary historical evidence: `Milestone 53B report.md`

Implemented:

- Optional `section-capacity-violation` policies: `off`, `warn`, `strict`.
- Optional `section-image-violation` policies: `off`, `warn`, `strict`.
- Warning mode continues; strict mode stops before mutation.
- Default remains off.

Did not implement:

- Browser settings UI.
- Default teaching diagnostics for these families.
- New instructions or syntax.

Regression watch:

- Level 1 mandatory checks and `.CONST` protection remain authoritative and are not reclassified as optional section diagnostics.

### Phase 53C - Default Teaching Diagnostics for Existing Warning Modes

Primary historical evidence: `Milestone 53C report.md`

Implemented:

- Default `uninitialized-read` policy changed to warning mode.
- Default `undefined-flag-use` policy changed to warning mode.
- Explicit opt-out and strict/error behavior preserved.
- Section-capacity, section-image, and allocated-object validation remain opt-in.
- Fixed partial-overlap uninitialized-origin detection for indirect/cast reads.

Did not implement:

- New syntax, instructions, diagnostic codes, browser settings UI, or compatibility notices.

Supersedes:

- Earlier opt-in-only descriptions of uninitialized-read and undefined-flag-use diagnostics.

Regression watch:

- Default warning continues execution using deterministic simulator values.

### Phase 53D - Compatibility No-Op and Limited-Behavior Notices

Primary historical evidence: `Milestone 53D report.md`

Implemented:

- Non-fatal `simulator-notice` diagnostics for accepted MASM compatibility constructs.
- Diagnostic codes:
  - `compatibility-no-op`
  - `compatibility-metadata-only`
  - `compatibility-limited`
- Notices for processor directives, `.model flat, stdcall`, `.stack`, `INCLUDE Macros.inc`, and listing/documentation directives.

Did not implement:

- Macro expansion.
- Listing generation.
- Stack execution/procedure frames.
- Host include loading.

Follow-up:

- Phase 53E added UI opt-out for compatibility notices.

Regression watch:

- Active semantic constructs must not receive generic no-op notices.

### Phase 53E - Memory Validation and Teaching Diagnostic UI Settings

Primary historical evidence: `Milestone 53E report.md`

Implemented:

- Browser Diagnostic settings panel.
- UI controls for memory range validation, uninitialized-read diagnostics, undefined-flag-use diagnostics, and compatibility notices.
- Structured worker/source-run settings routing.
- `ui-error` messages for invalid setting values.
- Compatibility-notice opt-out.

Defaults preserved:

- uninitialized reads warn;
- undefined flag use warns;
- compatibility notices on;
- memory range validation defaults to region-only;
- object/section validation off unless selected.

Did not implement:

- New MASM syntax, new instructions, new runtime validation semantics, or Phase 54 behavior.

Regression watch:

- Diagnostic settings are local page-session preferences; share URLs were not implemented.

### Phase 54 - One-Operand Signed IMUL

Primary historical evidence: `Milestone 54 report.md`

Implemented:

- One-operand signed `imul` accumulator forms for 8/16/32-bit register and unambiguous memory sources.
- Signed implicit result behavior:
  - `imul r/m8`: signed `AL * source8 -> AX`
  - `imul r/m16`: signed `AX * source16 -> DX:AX`
  - `imul r/m32`: signed `EAX * source32 -> EDX:EAX`
- `CF`/`OF` indicate signed overflow/truncation.
- `ZF`/`SF` preserved deterministically.
- Explicit rejection for deferred two-/three-operand `imul` forms.

Addendum:

- Phase 53E UI addendum made the Diagnostic settings panel collapsible.

Did not implement:

- Two-/three-operand `imul` forms.
- Division.
- QWORD/SQWORD execution.

Regression watch:

- One-operand `imul` must remain distinct from Phase 55 forms.

### Phase 55 - Two- and Three-Operand IMUL Forms

Primary historical evidence: `Milestone 55 report.md`

Implemented:

- Selected non-accumulator signed `imul` forms.
- 16/32-bit register destinations.
- 16/32-bit register and memory sources.
- Three-operand immediate forms.
- Signed immediate validation against destination width.
- Destination receives low-width result only.
- `CF`/`OF` indicate signed truncation/overflow; `ZF`/`SF` preserved deterministically.

Did not implement:

- 8-bit explicit-destination `imul`.
- Memory-destination `imul`.
- `imul reg, imm` two-operand immediate form.
- QWORD/SQWORD execution.

Regression watch:

- One-operand Phase 54 forms remain accepted.

### Phase 56 - Unsigned DIV

Primary historical evidence: `Milestone 56 report.md`

Implemented:

- One-operand unsigned `div` for 8/16/32-bit register and unambiguous memory divisors.
- Implicit dividend/result behavior:
  - `div r/m8`: `AX / source8 -> AL quotient, AH remainder`
  - `div r/m16`: `DX:AX / source16 -> AX quotient, DX remainder`
  - `div r/m32`: `EDX:EAX / source32 -> EAX quotient, EDX remainder`
- `divide-by-zero` and `quotient-overflow` diagnostics.
- No-partial-mutation for divide errors and strict validation stops.
- Modeled flags and validity metadata preserved for successful and failed `div`.

Did not implement:

- Signed `idiv`.
- Control flow, stack/procedure behavior, QWORD/SQWORD execution.

Regression watch:

- Memory divisor reads do not create memory-change rows.

### Phase 56A - Test Runner Decomposition and Assistant Verification Ergonomics

Primary historical evidence: `Milestone 56A report.md`

Implemented:

- Focused test groups:
  - `--structure`
  - `--native`
  - `--source-run`
  - `--web`
  - `--diagnostics`
  - `--protocol`
  - `--static`
- `--all`, `--quick`, `--quiet`, and `--verbose` modes.
- Test documentation and verification ergonomics.

Did not implement:

- MASM syntax, parser behavior, VM behavior, executor behavior, Wasm API behavior, browser UI behavior, diagnostic codes, or rendered message wording.

Status distinction:

- Repository/archive advanced to 56A; runtime/source-run behavior remained Phase 56.

Regression watch:

- `--quick` is not full verification and must not print the full success line.

### Phase 56B - User-Facing Diagnostic Wording Cleanup

Primary historical evidence: `Milestone 56B report.md`

Implemented:

- Removed live milestone-relative wording from user-facing diagnostics/current-status text.
- Replaced vague wording with stable, behavior-specific, actionable diagnostics.
- Updated status documentation to distinguish repository/archive milestone and runtime/source-run MASM behavior phase.
- Added static audit coverage to prevent live milestone-relative wording from returning.

Did not implement:

- New syntax, parser acceptance, VM behavior, executor behavior, Wasm API behavior, browser controls/layout/interaction, diagnostic codes, diagnostic JSON fields, or rendered message categories.

Status distinction:

- Repository/archive advanced to 56B; runtime/source-run behavior remained Phase 56.

Regression watch:

- Historical reports need not be rewritten, but current/live diagnostics must not use milestone-relative phrasing.

### Phase 57 - Signed IDIV

Primary historical evidence: `Milestone 57 report.md`

Implemented:

- One-operand signed `idiv` for 8/16/32-bit register and unambiguous memory divisors.
- Signed dividend/result behavior:
  - `idiv r/m8`: signed `AX / source8 -> AL quotient, AH remainder`
  - `idiv r/m16`: signed `DX:AX / source16 -> AX quotient, DX remainder`
  - `idiv r/m32`: signed `EDX:EAX / source32 -> EAX quotient, EDX remainder`
- Quotient truncation toward zero.
- Remainder has the same sign as the dividend.
- `divide-by-zero` and `quotient-overflow` diagnostics.
- Modeled flags and flag-validity metadata preserved.

Did not implement:

- QWORD/SQWORD execution.
- Control flow, stack/procedure behavior, broader Irvine32 behavior.

Status distinction:

- Runtime/source-run metadata intentionally advanced to Phase 57.

Regression watch:

- Signed minimum divided by -1 overflow cases must remain covered.

### Phase 57-CORR1 - .CONST Cross-Region Diagnostic Clarification

Primary historical evidence: `Milestone 57-CORR1 report.md`

Implemented:

- New structured diagnostic code `region-boundary-crossing` for cross-region accesses overlapping protected `.CONST` storage.
- Applied only to cross-region/protected `.CONST` overlap cases.
- Direct or wholly-contained `.CONST` writes remain `permission-denied`.
- Ordinary cross-region failures without `.CONST` overlap remain ordinary region/range diagnostics.
- Added `.CONST` overlap metadata.

Did not implement:

- New syntax, instruction semantics, layout behavior, browser controls, or runtime/source-run phase metadata advancement.

Status distinction:

- Repository/archive advanced; runtime/source-run behavior remained Phase 57.

Regression watch:

- A single source-level memory access cannot be split or partially executed across VM regions.

### Phase 57-CORR2 - Compact Negative Register-Indirect Displacement Correction

Primary historical evidence: `Milestone 57-CORR2 report.md`

Implemented:

- Accepted compact negative register-indirect displacements such as `[eax-4]` where spaced `[eax - 4]` equivalents were already supported.
- Applied through shared simple register-displacement path.
- Preserved `lea` behavior for simple register-minus-constant addressing.
- Preserved rejection of scaled-index/base-plus-index/advanced arithmetic forms.

Did not implement:

- New advanced addressing families.
- Runtime memory behavior changes.
- Runtime/source-run phase metadata advancement.

Status distinction:

- Repository/archive advanced; runtime/source-run behavior remained Phase 57.

Regression watch:

- Do not reintroduce whitespace-sensitive rejection for compact negative simple displacement.

### Phase 57A - README Landing Page Cleanup

Primary historical evidence: `Milestone 57A report.md`

Implemented:

- Rewrote README into concise project landing page.
- Moved milestone history into `docs/MILESTONE_HISTORY.md`.
- Preserved project boundaries and current-status distinctions.
- Updated static documentation checks.

Did not implement:

- Syntax, parser, VM, executor, Wasm API, browser UI, worker protocol, diagnostic fields/codes/wording, or runtime/source-run metadata changes.

Status distinction:

- Repository/archive advanced; runtime/source-run behavior remained Phase 57.

Regression watch:

- README must remain concise; long milestone history belongs in docs.

### Phase 57B - Milestone History and Build Documentation Extraction

Primary historical evidence: `Milestone 57B report.md`

Implemented:

- Added/updated `docs/MILESTONE_HISTORY.md` as AI-assistant-friendly history navigation.
- Added `docs/BUILDING_AND_DEVELOPMENT.md`.
- Kept README concise and linked to deeper docs.
- Extended static documentation checks.

Did not implement:

- Runtime/source behavior or UI/protocol/diagnostic behavior.

Status distinction:

- Repository/archive advanced; runtime/source-run behavior remained Phase 57.

Regression watch:

- Milestone history is historical evidence, not canonical source of truth.

### Phase 57C - Diagnostic Policy Registry Design

Primary historical evidence: `Milestone 57C report.md`

Implemented:

- Behavior-preserving C99 diagnostic-policy registry skeleton.
- Central policy value vocabulary: `off`, `warn`, `error`.
- Central family identifiers/names for existing and reserved families.
- Implemented/current and reserved/inactive registry entries.
- Parse/format/lookup/default helpers and unit tests.

Did not implement:

- Routing of existing diagnostic behavior through registry.
- New user-visible diagnostics or settings.
- Runtime/source behavior metadata advancement.

Status distinction:

- Repository/archive advanced; runtime/source-run behavior remained Phase 57.

Regression watch:

- `strict` is not a central registry value; legacy public `strict` is mapped by compatibility helpers in later migration.

### Phase 57D - Existing Diagnostic Policy Migration

Primary historical evidence: `Milestone 57D report.md`

Implemented:

- Migrated existing configurable diagnostic-policy lookup toward the Phase 57C registry where practical.
- Added registry-backed compatibility helpers.
- Preserved existing public setting names/defaults/behavior/wording.
- Mapped public `strict` to central `error`.
- Mapped compatibility-notice `on` to central `warn`.
- Kept compatibility notices non-fatal.

Did not implement:

- New diagnostic families, browser settings, syntax, VM behavior, diagnostic codes, rendered wording, or runtime/source metadata changes.

Status distinction:

- Repository/archive advanced; runtime/source-run behavior remained Phase 57.

Regression watch:

- Reserved families must remain inactive until their owner phase activates them.

### Phase 57E - Startup State Notice and Zero-Default Documentation

Primary historical evidence: `Milestone 57E report.md`

Implemented:

- Documented deterministic startup state.
- Activated `startup-state-notice` as an implemented non-fatal notice family.
- Default source-run/browser startup notice through Simulator Messages for successful executions.
- Registry-backed opt-out path.
- Preserved zero startup behavior.

Did not implement:

- Startup randomization, browser UI controls, memory randomization, `.CONST ?`, `.code` access policy.

Status distinction:

- Repository/archive advanced; runtime/source-run behavior remained Phase 57.

Regression watch:

- Startup notice is Simulator Messages only, never Program Console.

### Phase 57F - Seeded Random Register and Flag Startup Mode

Primary historical evidence: `Milestone 57F report.md`

Implemented:

- Opt-in seeded-random startup for general-purpose registers and modeled flags.
- Separate setting axis:
  - `startup_register_flag_mode = zero | seeded-random`
- Shared unsigned 32-bit seed:
  - `startup_state_seed = <u32>`
- Default zero behavior preserved.
- Mode-specific startup notice wording.
- Worker/protocol/source-run plumbing and setting diagnostics.

Did not implement:

- Memory randomization.
- Uninitialized-storage visible-byte randomization.
- `.CONST ?` support.
- Browser UI controls.

Status distinction:

- Runtime/source-run metadata advanced to Phase 57F because non-default settings can change execution results.

Regression watch:

- `EIP` remains zero; it is execution metadata, not a general-purpose register.

### Phase 57G - Seeded Random Uninitialized Storage Mode

Primary historical evidence: `Milestone 57G report.md`

Implemented:

- Independent opt-in seeded visible-byte mode for uninitialized-origin storage:
  - `uninitialized_storage_visible_byte_mode = zero | seeded-random`
- Shared seed with Phase 57F.
- Covered `.DATA?`, scalar `?`, and `DUP(?)` uninitialized-origin storage forms then supported.
- Preserved uninitialized-origin metadata after seeding visible bytes.
- Added Phase 57G source-run/runtime metadata and setting diagnostics.

Did not implement:

- `.CONST ?` / `.CONST DUP(?)` acceptance.
- Browser UI controls.
- Display markers.
- New syntax or instruction behavior.

Status distinction:

- Runtime/source-run metadata advanced to Phase 57G because non-default settings can change memory bytes.

Regression watch:

- Do not merge register/flag startup and uninitialized-storage visible-byte startup into one enum.

### Phase 57H - Register Unchanged Display Markers

Primary historical evidence: `Milestone 57H report.md`

Implemented:

- Final-register `[unchanged]` markers for canonical parent register families not explicitly written by the program.
- Explicit register-family write tracking in C99 CPU model.
- JSON-compatible `registerWrites` metadata.
- Alias rows do not show separate markers.
- Same-value writes count as writes.

Did not implement:

- Syntax, parser, VM instruction behavior, memory semantics, diagnostics, browser controls, or runtime/source-run metadata advancement.

Status distinction:

- Repository/archive advanced; runtime/source-run behavior remained Phase 57G.

Regression watch:

- Do not infer unchanged status by comparing initial and final values.

### Phase 57I - .CONST Uninitialized Storage Acceptance

Primary historical evidence: `Milestone 57I report.md`

Implemented:

- Accepted `.CONST ?` declarations.
- Accepted `.CONST DUP(?)` declarations.
- Allocated those bytes in `.CONST`.
- Preserved `.CONST` read-only protection.
- Preserved uninitialized-origin metadata.
- Included accepted `.CONST` uninitialized-origin bytes in Phase 57G seeded uninitialized-storage visible-byte behavior.
- Integrated reads with existing `uninitialized-read` diagnostics.
- Advanced runtime/source-run/browser/protocol metadata to Phase 57I.

Did not implement:

- Phase 57J declaration diagnostics.
- Browser UI controls for that diagnostic.
- New unrelated `.CONST` initializer grammar.

Status distinction:

- Repository/archive and runtime/source-run behavior both advanced to Phase 57I.

Regression watch:

- `.CONST ?` acceptance must not weaken `.CONST` write protection.
- Declaration diagnostics remain future Phase 57J until implemented.

---

## 8. Superseded assumptions and stale wording traps

Future assistants should treat this table as a high-priority stale-context filter.

| Earlier statement or likely assumption | Later/current correction | Current behavior |
| --- | --- | --- |
| Phase 50B says `undefined-flag-use` is opt-in/default-off. | Phase 53C changed default behavior. | `undefined-flag-use` warns by default unless disabled. |
| Early uninitialized-read diagnostics were opt-in. | Phase 53C changed default behavior. | `uninitialized-read` warns by default unless disabled. |
| Phase 53A says section-capacity/image validation is future. | Phase 53B implemented those policies. | Section-capacity and section-image validation exist but remain opt-in. |
| Phase 53D adds compatibility notices but no UI opt-out. | Phase 53E added UI/settings opt-out. | Compatibility notices are on by default and can be disabled through settings. |
| Phase 57E says startup is deterministic zero. | Phase 57F/57G add opt-in seeded startup modes. | Default remains zero; opt-in seeded modes can change registers/flags and uninitialized visible bytes. |
| Phase 57F randomizes only registers/flags. | Phase 57G adds independent uninitialized-storage visible-byte seeding. | There are two independent startup axes. |
| Phase 57G seeded storage covered only data-side uninitialized storage then supported. | Phase 57I extends accepted `.CONST` uninitialized-origin bytes into seeded storage behavior. | Seeded uninitialized-storage mode includes `.CONST ?` / `.CONST DUP(?)` bytes. |
| Phase 57H is newer than 57G, so runtime/source metadata should be 57H. | Phase 57H is display/source-run metadata only and did not advance runtime/source behavior phase. | Runtime/source-run behavior remained 57G until Phase 57I. |
| `.CONST ?` was rejected through Phase 57G. | Phase 57I accepts it. | `.CONST ?` and `.CONST DUP(?)` are accepted read-only uninitialized-origin storage. |
| `.CONST ?` acceptance means declaration warning exists. | Phase 57J owns declaration diagnostics. | Phase 57I has no `const-uninitialized-storage` declaration diagnostic yet. |
| Compact `[eax-4]` forms are unsupported because earlier parsing was whitespace-sensitive. | Phase 57-CORR2 fixed compact negative simple displacement. | Compact negative simple register displacements are accepted where equivalent spaced forms are supported. |
| `.code` memory access denial is current because future policy text discusses it. | `.code` access policy is future-owned by later guide phases unless tests prove otherwise. | Do not claim `.code` access denial is implemented before its owning phase. |
| QWORD/SQWORD declarations imply executable QWORD/SQWORD memory operations. | Executable QWORD/SQWORD operations remain unsupported in MASM32 Educational Mode. | QWORD/SQWORD metadata and executable 64-bit memory operations are separate concepts. |
| Milestone history or raw reports override canonical docs. | They are historical evidence only. | Spec/guide plus verified latest repo state are authoritative. |

---

## 9. Current high-risk areas

These areas are most likely to produce assistant mistakes.

### 9.1 User-symbol case policy vs keyword case-insensitivity

Keep separate:

- instruction/directive/register/include/Irvine32 routine recognition is case-insensitive;
- user-defined symbols obey `OPTION CASEMAP` behavior.

Do not let Irvine32 `exit` casing rules leak into user-symbol equality.

### 9.2 `.CONST ?` acceptance vs declaration diagnostics

Current Phase 57I accepts `.CONST ?` and `.CONST DUP(?)` but does not implement the Phase 57J declaration policy.

Do not invent `const-uninitialized-storage` diagnostics before Phase 57J.

### 9.3 `.CONST` read-only protection

`.CONST` write protection is mandatory and central. It must not be optional, warning-only, or overridden by teaching diagnostics.

Direct and computed writes must fail if final effective byte range violates `.CONST` permissions.

### 9.4 Memory validation precedence

Mandatory Level 1 region/permission checks happen before optional educational object/section diagnostics. Optional diagnostics must not reclassify fundamental invalid address or permission failures.

### 9.5 Visible bytes vs uninitialized-origin metadata

Do not conflate:

- byte value currently visible to the program;
- whether the byte originated from uninitialized storage;
- whether a declaration warning should be emitted;
- whether a read warning/error should be emitted.

### 9.6 Runtime/source-run metadata vs repository/archive milestone

Maintenance, documentation, display-only, and architecture-only phases often do not advance runtime/source-run behavior metadata.

Always check the behavior category of the target phase before changing phase metadata in source-run JSON, worker protocol, browser status, supported syntax, or tests.

### 9.7 Diagnostic policy registry migration

The central registry uses `off`, `warn`, and `error` values. Existing public paths may still expose `strict` and map it to `error` through compatibility helpers.

Do not introduce a new ad hoc diagnostic-policy path when the family belongs in the registry.

### 9.8 Flag validity metadata

Any future flag-consuming behavior must call the shared undefined-flag-use helper. Do not directly read flag bits in a way that bypasses validity metadata.

### 9.9 Display-only behavior

Display formatting changes must not be confused with runtime semantics.

- Phase 52A display does not alter VM behavior.
- Phase 57H unchanged markers do not alter VM behavior.
- Same-value writes still count as writes for display markers.

### 9.10 Irvine32 behavior

Current executable Irvine32 behavior remains narrow:

- `INCLUDE Irvine32.inc` activates virtual Irvine32 recognition;
- `exit` is supported as a virtual terminator;
- broader Irvine32 routines remain future work unless implemented later.

Do not implement real Windows API behavior or `call ExitProcess` as a shortcut.

---

## 10. Future work and explicit non-goals

### 10.1 Immediate next phase

The next canonical phase is:

```text
Phase 57J - .CONST Uninitialized Storage Diagnostics and Policy
```

Expected Phase 57J focus:

- activate or implement `const-uninitialized-storage` diagnostic policy;
- default warning behavior;
- policy `off` suppression;
- policy `error` fatal assembly behavior;
- exact rendered Simulator Messages tests;
- separation from read-time `uninitialized-read` diagnostics;
- preserve `.CONST` write protection.

### 10.2 Future phases after 57J

Use the current implementation guide for exact phase order. Do not infer or renumber phases from this report.

Likely nearby future areas in the guide include `.code`/segment symbol access policy and related memory diagnostics, but the guide is authoritative.

### 10.3 Persistent non-goals

The following remain outside scope unless the canonical spec/guide are deliberately changed:

- full MASM compiler behavior;
- full macro expansion;
- host include loading;
- native x86 execution;
- full x86 emulator behavior;
- Windows API simulation;
- PE loading/linking;
- object-file generation/linking;
- real Irvine32 library implementation beyond explicitly modeled routines;
- filesystem access from simulated code;
- arbitrary process interaction.

---

## 11. Required first steps for future assistants

Before implementing, editing docs, or auditing a new topic, future assistants should do the following in order:

1. Read `docs/FULL_IMPLEMENTATION_SPEC.md`.
2. Read `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`.
3. Read this handoff report.
4. Inspect the latest repository archive actually provided in the current session.
5. Confirm the latest completed repository/archive milestone.
6. Confirm the latest runtime/source-run MASM behavior phase.
7. Confirm the next canonical phase from the guide.
8. Run or inspect aggregate tests where possible.
9. Treat raw milestone reports as historical evidence, not as current behavior.
10. If raw reports appear to contradict current docs/tests, check the supersession table before drawing conclusions.

If implementing a milestone:

- implement exactly one focused target milestone unless explicitly instructed otherwise;
- do not implement future features early;
- state assumptions;
- add success/error/edge/regression/rendered-message tests where applicable;
- preserve C99 core and checked memory helper rules;
- update current-status surfaces only when the phase owns those changes.

---

## 12. How to update this handoff after future milestones

When a later milestone is completed and accepted, update this handoff or its successor using this process:

1. Update the current repository/archive milestone.
2. Update the runtime/source-run MASM behavior phase only if the new milestone changes runtime-visible MASM/source behavior or explicitly owns metadata advancement.
3. Add the new milestone to the reconciliation ledger with implemented behavior, non-goals, assumptions that remain valid, superseded wording, and regression-watch items.
4. Add `Primary historical evidence: Milestone <phase> report.md` to the new milestone entry.
5. Update the current behavior ledger for any subsystem whose current behavior changed.
6. Add a supersession note when the new milestone changes a statement that was true in an earlier milestone report.
7. Move the raw milestone report into the cold-storage archive or repository `docs/milestone_reports/` location.
8. Re-run the relevant aggregate or focused test commands if the update claims verified repository behavior.
9. Do not rewrite completed phase history as if earlier milestones originally said something different. Use corrective notes or non-renumbering corrective phases when needed.

---

## 13. Raw milestone report archive index

Recommended archival strategy:

- Keep this curated handoff report as active assistant context.
- Move raw milestone reports into cold storage such as `milestone_reports_43_through_57I_archive.zip` or `docs/milestone_reports/` inside the repository.
- Do not attach every raw report individually in future sessions unless a specific provenance audit requires them.

Raw report files available during this handoff:

```text
Milestone 43 report.md
Milestone 44 report.md
Milestone 45 report.md
Milestone 46 report.md
Milestone 47 report.md
Milestone 48 report.md
Milestone 49 report.md
Milestone 50 report.md
Milestone 50A report.md
Milestone 50B report.md
Milestone 51 report.md
Milestone 52 report.md
Milestone 52A report.md
Milestone 53 report.md
Milestone 53A report.md
Milestone 53B report.md
Milestone 53C report.md
Milestone 53D report.md
Milestone 53E report.md
Milestone 54 report.md
Milestone 55 report.md
Milestone 56 report.md
Milestone 56A report.md
Milestone 56B report.md
Milestone 57 report.md
Milestone 57-CORR1 report.md
Milestone 57-CORR2 report.md
Milestone 57A report.md
Milestone 57B report.md
Milestone 57C report.md
Milestone 57D report.md
Milestone 57E report.md
Milestone 57F report.md
Milestone 57G report.md
Milestone 57H report.md
Milestone 57I report.md
```


Interpretation warning:

Raw milestone reports are useful for provenance, assumptions, and exact implementation-history details. They may also contain stale statements such as "future work" that later milestones implemented. This curated report should be used first to determine current behavior.

---

## 14. Verification command summary

Aggregate command run during this handoff:

```bash
cd /mnt/data/audit_repo_57I
python3 scripts/run_tests.py --all
```

Observed result:

```text
All implemented milestone tests passed.
Browser/Wasm rebuild smoke: SKIP - emcc unavailable in this environment.
```

Focused groups available in the repository:

```bash
python3 scripts/run_tests.py --structure
python3 scripts/run_tests.py --native
python3 scripts/run_tests.py --source-run
python3 scripts/run_tests.py --web
python3 scripts/run_tests.py --diagnostics
python3 scripts/run_tests.py --protocol
python3 scripts/run_tests.py --static
```

Use `--quick` only for smoke checks. It is not full verification.

---

## 15. Final handoff checklist

Current status:

- Repository/archive milestone: Phase 57I - .CONST Uninitialized Storage Acceptance
- Runtime/source-run MASM behavior phase: Phase 57I - .CONST Uninitialized Storage Acceptance
- Next canonical phase: Phase 57J - .CONST Uninitialized Storage Diagnostics and Policy
- Latest repository archive inspected: `Latest_repository_state_milestone_57I.zip`
- Aggregate tests: passed, with `emcc` rebuild smoke skipped due to unavailable dependency

Current active context recommendation:

- Keep `docs/FULL_IMPLEMENTATION_SPEC.md`.
- Keep `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`.
- Keep this report: `PROJECT_AUDIT_AND_HANDOFF_REPORT_THROUGH_MILESTONE_57I.md`.
- Keep the latest repository archive.
- Keep only the newest milestone report temporarily if not yet folded into a handoff.
- Archive older raw milestone reports rather than attaching them individually.

Most important stale-context warning:

```text
Do not read a raw milestone report in isolation and treat its "not implemented" or "future work" wording as current. Check the canonical spec/guide, latest repository tests, and this report's supersession table first.
```
