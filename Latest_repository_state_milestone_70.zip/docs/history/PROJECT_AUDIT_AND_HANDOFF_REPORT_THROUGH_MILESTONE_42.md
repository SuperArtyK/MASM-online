> **Historical report supersession note**
>
> This report describes project state through Milestone 42. It is preserved for provenance, stale-assumption detection, and regression-risk review.
>
> It is not current behavior authority after later accepted milestones. For current implementation work, read the current canonical `docs/FULL_IMPLEMENTATION_SPEC.md`, current canonical `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`, current `docs/SUPPORTED_SYNTAX.md`, the latest repository archive or checkout, and the latest accepted milestone report in `docs/history/reports/`.
>
> Any wording in this report such as "current state," "current status," "next phase," or "future work" is relative to Milestone 42 unless a later canonical document explicitly says otherwise.

# Project Audit and Handoff Report Through Milestone 42

Generated for the Online MASM32 Educational Simulator project.

This report is a continuity and audit document. It does not replace the canonical specification or guide. It exists to make future implementation chats less dependent on long chat history and less likely to mix old milestone assumptions with the current project state.

## 1. Authority and source-of-truth policy

The active project source of truth remains the canonical specification and implementation guide pair in the repository:

- `docs/FULL_IMPLEMENTATION_SPEC.md`
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`

For this audit, I used the latest uploaded repository archive:

- `Latest_repository_state_milestone_42.zip`

The repository archive's `docs/` pair includes the revised Phase 35A CASEMAP policy. The root-level suffixed files also contain that CASEMAP-updated text:

- `FULL_IMPLEMENTATION_SPEC_CASEMAP_ALL_NONE_PHASE35A.md`
- `INCREMENTAL_IMPLEMENTATION_GUIDE_CASEMAP_ALL_NONE_PHASE35A.md`

Important interpretation rule:

- The full specification owns product boundaries and stable behavior.
- The implementation guide owns phase numbering, tasks, tests, and acceptance criteria.
- Milestone reports are implementation history and audit evidence, not a replacement for the canonical spec/guide.
- Older drafts and older roadmap files are audit history only.
- If an older milestone report contradicts the current canonical spec/guide, the current canonical spec/guide wins.
- If a completed implementation diverges from the current spec/guide, future work should flag that explicitly and either fix the implementation or update the spec/guide intentionally.

## 2. Why this report exists

The project now has a large accumulated history: scaffold, CPU/flags/memory, parser/executor, source-run UI, data layout, memory operands, expressions, diagnostics, layout policies, randomized layout, object maps, validation modes, uninitialized-origin tracking, Irvine32 registry metadata, and `exit` termination. Long contexts make it easier for an assistant to retrieve stale assumptions from older drafts or earlier milestones.

This report reduces that risk by keeping the high-signal facts near the front:

- What is implemented now.
- What is explicitly not implemented.
- What is planned later.
- What is outside the simulator's scope.
- Which design decisions must not regress.
- What the next assistant should verify before coding.

## 3. Current verified repository state

I extracted and tested `Latest_repository_state_milestone_42.zip`.

Command used:

```bash
cd /mnt/data/repo_m42
python3 scripts/run_tests.py
```

Observed result summary:

```text
Phase 0 C tests passed.
Milestone 1 CPU register tests passed.
Milestone 2 flag model tests passed.
Checked memory region and fixed-layout compatibility tests passed.
Phase 35 layout policy tests passed.
Executor tests through Milestone 42 passed.
Lexer tests passed.
Minimal parser tests passed.
Source execution tests through Phase 42 regression coverage passed.
Data section, .DATA?/.CONST, signed PTR alias, all-GPR register-indirect, TYPE, LENGTHOF, SIZEOF, character literal, extended constant-expression, and nested DUP tests through Milestone 30 passed.
test_object_map passed
... diagnostic rendering tests passed ...
Milestone structure tests passed.
All implemented milestone tests passed.
```

Conclusion:

- Latest verified implementation state: through Milestone 42.
- Next canonical phase in the current guide: Phase 43 - INC and DEC.
- Future implementation sessions should still re-verify repository state before coding, because the user may upload a newer archive or local changes later.

## 4. Non-negotiable project invariants

### Product boundaries

The project is:

- a static browser app;
- a C99 MASM-like parser plus internal VM compiled to WebAssembly;
- a MASM32/Irvine32-style educational console simulator;
- an incremental learning/debugging tool.

The project is not:

- a full MASM compiler;
- a full x86 emulator;
- a Windows emulator;
- a PE loader;
- a real linker;
- a WinAPI simulator;
- a full macro assembler.

### C99 core boundary

The VM, parser, executor, memory model, Irvine32 runtime, and Wasm API must remain C99:

- `.c` and `.h` core files only;
- no C++ standard library;
- no classes/templates/exceptions/RTTI;
- no `extern "C"` wrappers unless language policy explicitly changes later;
- browser UI may remain JavaScript or TypeScript.

### Documentation requirement

Every source/header file needs a file-level block header. Every public function, struct, enum, and module-level API needs Doxygen-style `///` comments.

### Diagnostics and UI streams

Program Console and Simulator Messages are separate streams.

- Program Console is simulated program I/O.
- Simulator Messages are diagnostics, warnings, runtime errors, and execution-status messages.

Every new UI-visible diagnostic path must have structured diagnostic tests and rendered Simulator Messages tests through the native C JSON producer and Node formatter harness.

### Memory safety rule

All simulated memory reads and writes must go through checked VM memory helpers. Centralized memory permission/range checks are mandatory. `.CONST` protection must be enforced by final effective address range, not only by static symbol detection.

### Incremental scope rule

Each implementation session should implement exactly one milestone unless explicitly instructed otherwise. Do not implement future milestone features for convenience.

## 5. Canonical next phase

The repository is verified through Milestone 42. The current canonical guide lists:

```text
Phase 43 - INC and DEC
```

Phase 43 is a focused read-modify-write instruction milestone. It must not implement bitwise instructions, shifts, rotates, `lea`, multiplication, division, labels, jumps, stack behavior, or procedure behavior.

Before starting Phase 43, the assistant should:

1. Read the current `docs/FULL_IMPLEMENTATION_SPEC.md` and `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`.
2. Verify the repository still matches Milestone 42 completion.
3. Summarize exact Phase 43 requirements.
4. List assumptions.
5. Create a test plan before coding.
6. Implement only Phase 43.

## 6. Completed milestone ledger

### Milestone 0 - Project Skeleton and Development Setup

Implemented:
- Static browser project scaffold with `web/`, `src/`, `tests/`, `scripts/`, and `docs/` layout.
- C99 core scaffold and Wasm-facing API sentinel path.
- Web Worker scaffold, UI/worker protocol, `PING`/`PONG`, and `READY` messages.
- Initial Program Console and Simulator Messages panels.
- Native C test runner and strict/static compliance checks.
- Windows/Emscripten build scripts and setup README material.

Not implemented in this milestone:
- No CPU model, flags, parser, assembler, VM memory, instruction execution, Irvine32 runtime, debugger, or URL sharing.

Deferred or future owner:
- All simulator semantics start in later milestones.

Important assumptions:
- The milestone intentionally creates only the buildable vertical scaffold.

Tests or verification noted:
- Phase 0 C tests and worker protocol smoke checks.

Regression watch:
- Do not infer simulator language support from the scaffold alone.

### Milestone 1 - Core CPU Register Model

Implemented:
- Canonical 32-bit MASM32 register storage: EAX, EBX, ECX, EDX, ESI, EDI, EBP, ESP, EIP, EFLAGS.
- Register enum, width/display metadata, and alias reads/writes for AX/AH/AL, BX/BH/BL, CX/CH/CL, DX/DH/DL, SI/DI/BP/SP.
- Defensive helper behavior for invalid registers and null pointers.

Not implemented in this milestone:
- No instruction execution, parser integration, debugger UI, or Extended 32-bit/64-bit register mode.

Deferred or future owner:
- Flags semantics are Milestone 2; execution uses this model from Milestone 4 onward.

Important assumptions:
- Aliases are derived from canonical registers, not stored independently.

Tests or verification noted:
- Native CPU tests for alias read/write behavior.

Regression watch:
- Do not duplicate alias state in future code; canonical registers remain authoritative.

### Milestone 2 - Flags Model

Implemented:
- Modeled CF, ZF, SF, and OF inside CPU/EFLAGS helpers.
- Set/clear/read/write helpers.
- Arithmetic helper functions for addition, subtraction, and compare-style subtraction.

Not implemented in this milestone:
- No parser/executor instruction behavior was added in this milestone; no other real x86 flags are modeled.

Deferred or future owner:
- Later instruction milestones reuse these helpers for arithmetic and flag-setting instructions.

Important assumptions:
- Invalid arithmetic widths fail without mutating state.

Tests or verification noted:
- Native flag tests for carry, zero, sign, and overflow edge cases.

Regression watch:
- Do not claim parity, auxiliary, interrupt, direction, or trap flags exist unless a later phase adds them.

### Milestone 3 - Simulated Memory Regions

Implemented:
- Checked memory subsystem with deterministic fixed regions: `.code`, `.data`, `.heap`, and `.stack`.
- Read/write helpers for 8/16/32/64-bit storage.
- Region permissions, bounds checks, overflow-safe access ranges, little-endian encoding, and unaligned-access warnings.
- Raw byte-level memory-change hooks.

Not implemented in this milestone:
- No parser-level memory operands, stack instructions, heap allocation API, or symbol-aware memory deltas yet.

Deferred or future owner:
- All future memory accesses must route through these checked helpers.

Important assumptions:
- Unaligned access is allowed but diagnosed as a warning.

Tests or verification noted:
- Native memory tests for valid access, invalid access, permissions, and unaligned reads/writes.

Regression watch:
- Bypassing checked memory helpers is a critical regression.

### Milestone 4 - Minimal IR and Executor

Implemented:
- Initial IR instruction and operand model for immediates, registers, and absolute memory addresses.
- Executor VM initialization, program loading, stepping, and last-step delta capture.
- Initial `mov`, `add`, and `sub` execution for supported IR operand shapes.
- Integration with CPU, flags, and checked memory modules.

Not implemented in this milestone:
- No source parser, labels, control flow, stack/call behavior, Irvine32, or browser source execution yet.

Deferred or future owner:
- Parser and UI milestones later feed source-generated IR into this executor.

Important assumptions:
- Internal IR, not native x86 machine code, is the execution format.

Tests or verification noted:
- Native executor tests including hardcoded IR program `mov eax,20; add eax,22`.

Regression watch:
- Do not conflate IR execution with full x86 emulation.

### Milestone 5 - Lexer

Implemented:
- Standalone allocation-free lexer with source spans.
- Tokens for identifiers, directives, registers, numbers, strings, quoted literals, comma/bracket/colon/newline, comments, plus/minus, and EOF.
- Decimal/hex/signed numeric literal recognition and diagnostics for malformed literals.

Not implemented in this milestone:
- No parser semantics, symbol resolution, data layout, or source execution.

Deferred or future owner:
- Parser phases assign semantic meaning to tokens.

Important assumptions:
- Token lexemes point into original source; callers provide bounded buffers.

Tests or verification noted:
- Lexer tests for token classes, positions, numeric forms, comments, and error cases.

Regression watch:
- Do not move semantic validation into the lexer beyond tokenization and literal diagnostics.

### Milestone 6 - Parser for Minimal Code

Implemented:
- Minimal `.code` parser for straight-line programs.
- Structural labels, PROC/ENDP markers, simple register/immediate and register/register forms for existing opcodes.
- `END main` parsing and source metadata preservation.

Not implemented in this milestone:
- No `.data`, memory operands, symbols, control flow, stack, calls, or Irvine32 behavior.

Deferred or future owner:
- Labels are syntactic until control-flow milestones resolve them.

Important assumptions:
- PROC/ENDP are structural only at this point.

Tests or verification noted:
- Parser/source-run acceptance program ending with EAX = 42.

Regression watch:
- Do not treat accepted labels as executable branch targets before label-resolution phases.

### Milestone 7 - Basic UI Execution

Implemented:
- Browser Run path through worker/Wasm source-run API.
- UI displays final register state and Simulator Messages.
- Program Console is cleared and remains separate from diagnostics.

Not implemented in this milestone:
- No console output routines, debugger stepping, breakpoints, input, or long-running execution control.

Deferred or future owner:
- Irvine32 console behavior and debugger UI are later phases.

Important assumptions:
- Synchronous worker execution is acceptable for the current straight-line subset.

Tests or verification noted:
- Worker/protocol tests and browser-visible acceptance program with EAX = 42.

Regression watch:
- Keep Program Console separate from Simulator Messages.

### Milestone 8 - Data Section and Symbols

Implemented:
- `.data` declarations for BYTE/WORD/DWORD/QWORD and DB/DW/DD/DQ aliases.
- Strings, flat DUP, `?`, negative initializers, data image layout, symbol table, and `OFFSET symbol`.
- Direct symbol memory writes such as `mov var, 100`.
- Symbol-aware memory-change JSON/UI display.

Not implemented in this milestone:
- No indexed operands, constant symbol offsets, PTR overrides, register-indirect operands, or control flow.

Deferred or future owner:
- Constant offsets, width overrides, and richer memory operands are staged in later milestones.

Important assumptions:
- `?` is deterministic zero-filled storage but logically uninitialized for later metadata phases.

Tests or verification noted:
- Data layout, source-run, direct writes, OFFSET, DUP, strings, and range diagnostics.

Regression watch:
- Do not treat QWORD data declaration support as executable QWORD memory-operation support.

### Milestone 9 - Constant Symbol Offsets

Implemented:
- Byte-offset forms: `nums[8]`, `[nums + 8]`, `[nums - 4]`, `[symbol]`, `[symbol + 0]`, and `symbol[0]`.
- Symbol metadata width inference, symbol-aware memory deltas with byte offsets and aligned element indexes.
- Out-of-bounds diagnostics and unaligned warnings.

Not implemented in this milestone:
- No PTR overrides, register-indirect addressing, scaled-index addressing, or general expressions.

Deferred or future owner:
- PTR and register-indirect operands are separate phases.

Important assumptions:
- Offsets are byte offsets, not element indexes.

Tests or verification noted:
- Aligned, unaligned, zero-offset, negative, out-of-bounds, source-run, and formatter tests.

Regression watch:
- Do not reinterpret `nums[8]` as the eighth DWORD element.

### Milestone 10 - PTR Width Overrides

Implemented:
- `BYTE PTR`, `WORD PTR`, `DWORD PTR`, and `QWORD PTR` parsing for existing symbol-relative memory forms.
- Explicit width override, immediate range validation, and diagnostics for unsupported/malformed forms.
- QWORD PTR recognized but executable 64-bit memory operations rejected in MASM32 mode.

Not implemented in this milestone:
- No register-indirect PTR forms beyond existing operands; no executable QWORD operation support.

Deferred or future owner:
- Register-indirect operands reuse this width path later; Extended 32-bit Mode may enable QWORD execution later.

Important assumptions:
- Accepted syntax is `<WIDTH> PTR <currently-supported-memory-operand>`.

Tests or verification noted:
- Parser/source-run tests for explicit widths, range validation, and QWORD runtime rejection.

Regression watch:
- Do not silently truncate or execute unsupported QWORD memory operations.

### Milestone 11 - Register-Indirect Memory Operands

Implemented:
- Initial register-indirect forms `[esi]`, `[edi]`, `[ebx]`, `[ebp]` and simple displacements.
- Symbol/register forms `array[esi]` and `[array + esi]`.
- Width via PTR or known source/destination context, checked memory, unaligned warnings, and scaled-index rejection.

Not implemented in this milestone:
- No all-GPR base coverage yet; no scaled-index execution.

Deferred or future owner:
- All-GPR bases and global memory-width rules are later milestones.

Important assumptions:
- Register values in symbol/register forms are byte offsets.

Tests or verification noted:
- Valid/invalid register-indirect, displacement, unaligned, and out-of-bounds tests.

Regression watch:
- Do not add unsupported base registers early unless the all-GPR phase is being implemented.

### Milestone 12 - TYPE Operator

Implemented:
- `TYPE symbol` in immediate/source contexts returns declared element size in bytes.
- Works with BYTE/WORD/DWORD/QWORD and aliases using existing symbol metadata.

Not implemented in this milestone:
- No LENGTHOF, SIZEOF, general expressions, or TYPE of unsupported expressions.

Deferred or future owner:
- LENGTHOF and SIZEOF follow in dedicated phases.

Important assumptions:
- TYPE is parse-time constant folding into an immediate operand.

Tests or verification noted:
- Scalar, array, string, DUP, QWORD metadata, unknown-symbol, and unsupported-expression tests.

Regression watch:
- Do not make TYPE return total byte size; that is SIZEOF.

### Milestone 13 - LENGTHOF Operator

Implemented:
- `LENGTHOF symbol` returns element count for scalars, arrays, strings, and flat DUP declarations.

Not implemented in this milestone:
- No SIZEOF, character literals, general expressions, or control flow.

Deferred or future owner:
- SIZEOF and character literals are next.

Important assumptions:
- Byte strings count emitted bytes, including explicit terminators.

Tests or verification noted:
- Byte/word/dword/qword/string/DUP declarations and diagnostics.

Regression watch:
- Do not confuse LENGTHOF with byte size or element width.

### Milestone 14 - SIZEOF Operator and Character / Packed Character Literals

Implemented:
- `SIZEOF symbol` returns total byte size.
- Single-character and packed multi-character literals up to destination width.
- Little-endian packing for immediates and scalar initializers; BYTE/DB quoted literals emit byte sequences.
- Diagnostics for empty, too-wide, unsupported escape, and unsupported expression forms.

Not implemented in this milestone:
- No general expression parser, binary/octal expansion, runtime QWORD operations, control flow, or Irvine32.

Deferred or future owner:
- Expression support broadens in equate/expression milestones.

Important assumptions:
- Parser decodes quoted literals using lexer spans.

Tests or verification noted:
- SIZEOF metadata, literal packing, data declarations, memory/register immediates, and width-overflow diagnostics.

Regression watch:
- Do not change BYTE/DB multi-character literals into packed scalar behavior.

### Milestone 15 - Textbook MASM Compatibility Backlog Checkpoint

Implemented:
- Supported-syntax reference documenting implemented subset and scheduled/deferred constructs.
- `unsupported-feature` diagnostics for common textbook constructs not yet supported.
- Backlog notes for signed integer types, non-integer data types, expression parser expansion, macros, structures, and high-level flow.

Not implemented in this milestone:
- No feature expansion; no signed declarations, EQU/TEXTEQU, macros, structures, high-level flow, linker declarations, control flow, stack, or Irvine32.

Deferred or future owner:
- Signed types and later expression/directive phases convert some backlog items into implemented features.

Important assumptions:
- This milestone is documentation/diagnostics, not semantics.

Tests or verification noted:
- Unsupported construct diagnostics and supported-syntax documentation checks.

Regression watch:
- Do not treat old unsupported-feature classifications as permanent if later milestones implemented them.

### Milestone 16 - Diagnostic Plumbing and Lexer Error Surfacing

Implemented:
- Lexer diagnostics are preserved through source-run JSON and UI Simulator Messages.
- Diagnostic code, message, line, column, byte offset, and span length surface to the browser path.
- Known lexer failures no longer collapse to generic `lexer-failed` where specific diagnostics exist.

Not implemented in this milestone:
- No new MASM syntax and no multi-diagnostic parser recovery yet.

Deferred or future owner:
- Multi-diagnostic recovery follows in Milestone 17.

Important assumptions:
- Parser diagnostics mirror lexer reasons through the existing source-run path.

Tests or verification noted:
- Invalid character, unterminated string/character, invalid hex, overflow, malformed text, and parser diagnostic surfacing.

Regression watch:
- Do not hide specific lexer errors behind umbrella messages.

### Milestone 17 - Multi-Diagnostic Unsupported-Feature Recovery

Implemented:
- Recovery for known unsupported line-level constructs, unsupported blocks, and unsupported sections.
- Multiple recoverable unsupported-feature diagnostics in one parse pass while refusing execution.
- Noisy cascades inside skipped unsupported bodies are suppressed.

Not implemented in this milestone:
- No semantics for unsupported constructs and no recovery after fatal/infrastructure failures.

Deferred or future owner:
- Specific unsupported constructs become implemented only in their scheduled phases.

Important assumptions:
- Recovery is conservative and construct-aware.

Tests or verification noted:
- Multiple unsupported constructs, block recovery, section recovery, diagnostic order, and no execution.

Regression watch:
- Do not parse unsupported block bodies as if they were supported code.

### Milestone 18 - Signed Integer Data Types

Implemented:
- SBYTE, SWORD, SDWORD, and SQWORD declarations with signed range validation.
- Two's-complement little-endian storage, unary-plus numeric literals, DUP/`?`/packed-literal support, and TYPE/LENGTHOF/SIZEOF integration.

Not implemented in this milestone:
- No movsx/movzx/conversion instructions; no automatic sign-extension on ordinary `mov`; no executable SQWORD operations.

Deferred or future owner:
- Sign/zero extension instructions are Milestone 19; Extended 32-bit Mode may enable 64-bit execution later.

Important assumptions:
- Signedness affects declaration validation and metadata, not ordinary move semantics.

Tests or verification noted:
- Valid/invalid signed ranges, metadata operators, DUP, packed literals, and 64-bit execution rejection.

Regression watch:
- Do not make `mov eax, sb` sign-extend automatically.

### Milestone 19 - Sign and Zero Extension Instructions

Implemented:
- Parser/IR/executor support for `movsx`, `movzx`, `cbw`, `cwde`, `cwd`, and `cdq`.
- Register destinations with 8/16-bit register or memory sources for movsx/movzx; accumulator conversions update AX/EAX/DX:AX/EDX:EAX.

Not implemented in this milestone:
- No memory destinations for movsx/movzx; no 32/64-bit source extension forms; no future instruction groups.

Deferred or future owner:
- More conversions or extended-width forms require later explicit phases.

Important assumptions:
- Conversion instructions do not modify modeled flags.

Tests or verification noted:
- Signed data, unsigned byte data, register aliases, memory sources, invalid widths, and accumulator conversions.

Regression watch:
- Keep ordinary MOV non-sign-extending.

### Milestone 20 - Exchange, Negation, and NOP

Implemented:
- `xchg`, `neg`, and `nop` parser/IR/executor support.
- Width-matched xchg reg/reg, reg/mem, mem/reg; neg for reg/mem; nop advances without mutation.
- NEG updates CF/ZF/SF/OF; XCHG and NOP preserve modeled flags.

Not implemented in this milestone:
- No adc/sbb, inc/dec, test, bitwise, shifts/rotates, control flow, stack, calls, Irvine32, or debugger stepping.

Deferred or future owner:
- Carry/borrow arithmetic follows in Milestone 21; inc/dec is now Phase 43.

Important assumptions:
- NEG reuses subtraction flag semantics for `0 - operand`.

Tests or verification noted:
- Register exchange, memory exchange, negation edge cases, malformed operand diagnostics, and nop state preservation.

Regression watch:
- Do not allow memory-to-memory xchg.

### Milestone 21 - Carry/Borrow Arithmetic and Carry Flag Control

Implemented:
- `adc`, `sbb`, `clc`, `stc`, and `cmc`.
- CF input for adc/sbb and CF/ZF/SF/OF updates; carry-control instructions mutate CF only.

Not implemented in this milestone:
- No TEST, inc/dec, bitwise, shifts/rotates, control flow, stack, calls, Irvine32, or debugger.

Deferred or future owner:
- TEST is Milestone 22; inc/dec later as Phase 43.

Important assumptions:
- Existing width-validation model remains authoritative.

Tests or verification noted:
- Carry propagation, borrow propagation, immediate ranges, memory operands, and carry-flag control behavior.

Regression watch:
- Preserve CF semantics; do not treat adc/sbb as add/sub without carry.

### Milestone 22 - TEST Instruction

Implemented:
- `test` parser/IR/executor support for register/register, register/immediate, register/memory, memory/register, and unambiguous memory/immediate forms.
- AND-for-flags-only behavior: destination is not modified; ZF/SF updated; CF/OF cleared.
- MASM-compatible ambiguous memory-width diagnostics for forms such as `test [esi], 1`.

Not implemented in this milestone:
- No signed PTR aliases, all-GPR register bases, global width resolver, bitwise families, shifts, control flow, stack, or Irvine32.

Deferred or future owner:
- Signed PTR aliases, all-GPR bases, and global width resolver follow.

Important assumptions:
- `test mem, imm` requires explicit or inferable memory width.

Tests or verification noted:
- Destination-not-modified tests, memory/immediate width tests, register and memory forms, and diagnostic rendering.

Regression watch:
- Do not classify MASM-invalid ambiguous memory width as temporary unsupported syntax.

### Milestone 23 - Signed PTR Width Aliases

Implemented:
- SBYTE PTR, SWORD PTR, SDWORD PTR, and SQWORD PTR parsing.
- Signed aliases map to 1/2/4/8-byte access widths; SQWORD remains recognized but executable 64-bit access is rejected in MASM32 mode.

Not implemented in this milestone:
- No all-GPR base support, global resolver, control flow, stack, Irvine32, or Extended 32-bit Mode.

Deferred or future owner:
- All-GPR register-indirect bases are Milestone 24.

Important assumptions:
- Signed PTR aliases are width aliases for ordinary raw-bit memory accesses.

Tests or verification noted:
- Signed PTR reads/writes, ordinary MOV non-sign-extension, SQWORD rejection, and diagnostics.

Regression watch:
- Do not introduce signed display/semantics into ordinary memory values without a later phase.

### Milestone 24 - All-GPR Register-Indirect Base Registers

Implemented:
- All 32-bit GPRs accepted as base registers in `[reg]` and simple displacement forms, including ESP.
- Existing symbol-plus-register forms preserved and broadened.
- Invalid computed addresses fail at runtime through checked memory, not parser base rejection.

Not implemented in this milestone:
- No scaled-index addressing, global width refactor, MASM header directives, control flow, stack, Irvine32, or debugger.

Deferred or future owner:
- Global width-resolution consolidation follows in Milestone 25; scaled-index remains future.

Important assumptions:
- ESP is valid as a base register in this simplified model.

Tests or verification noted:
- Every base register, displacement forms, runtime invalid address path, and scaled-index rejection.

Regression watch:
- Do not reject `[eax]` at parse time merely because the runtime address is invalid.

### Milestone 25 - Global Memory Width Resolution Rules

Implemented:
- Shared parser/instruction memory-width resolver for current memory-capable instructions.
- Resolver sources: PTR, symbol metadata, symbol-relative metadata, same-instruction register width, and instruction-specific implicit width.
- Stable `ambiguous-memory-width` diagnostics for MASM-invalid memory/immediate ambiguity.

Not implemented in this milestone:
- No new instruction behavior beyond resolver refactor; no scaled-index or future memory forms.

Deferred or future owner:
- All later memory-capable instruction parsers should reuse this resolver.

Important assumptions:
- Symbol metadata has precedence unless explicit PTR overrides it.

Tests or verification noted:
- Regression tests across mov/add/sub/adc/sbb/xchg/neg/test memory forms and diagnostic rendering.

Regression watch:
- Do not duplicate ad hoc width inference in future instruction parsers.

### Milestone 26 - MASM32 Header Directives

Implemented:
- Accepted processor compatibility directives `.386`, `.486`, `.586`, `.686` as no-ops.
- Accepted `.model flat, stdcall`, `.stack` metadata, virtual `INCLUDE Irvine32.inc`, virtual no-op `INCLUDE Macros.inc`, listing directives TITLE/SUBTITLE/PAGE.
- CASEMAP syntax was initially accepted/classified; Phase 35A later corrected full semantics.

Not implemented in this milestone:
- No real include loading, Windows API, linker behavior, macro expansion, stack runtime, listing generation, conditional assembly, or Irvine32 procedure execution.

Deferred or future owner:
- CASEMAP behavior is corrected by Phase 35A; stack runtime and Irvine32 execution are later.

Important assumptions:
- Header compatibility exists so pasted textbook programs need fewer deletions.

Tests or verification noted:
- Header acceptance, unsupported model/include/option diagnostics, and source-run compatibility.

Regression watch:
- Do not read host files for INCLUDE. Do not treat processor directives as changing VM mode.

### Milestone 27 - Additional Data Sections: .DATA? and .CONST

Implemented:
- `.DATA?` supported as writable deterministic zero-filled uninitialized-origin storage.
- `.CONST` supported as initialized read-only storage backed by a read-only memory region/protection.
- Static diagnostics for obvious `.CONST` writes plus runtime protection for computed/partial-overlap writes through central memory checks.

Not implemented in this milestone:
- No uninitialized-read warnings yet; no UI memory visualization changes.

Deferred or future owner:
- Uninitialized-origin metadata is strengthened in Milestone 39 and read validation in Milestone 40.

Important assumptions:
- `.DATA?` rejects initialized declarations; `.CONST` requires initialized declarations.

Tests or verification noted:
- `.DATA?`, `.CONST`, metadata operators, static CONST writes, indirect CONST writes, partial overlaps, and memory-change suppression.

Regression watch:
- Do not protect `.CONST` only by symbol metadata; address-range permission checks are mandatory.

### Milestone 28 - Numeric Equates and Stage A Constant Expressions

Implemented:
- Numeric equates using `=` and `EQU` with an equate table separate from data symbols.
- Stage A constant expressions: literals, equates, unary +/- , parentheses, binary +/-. 
- Expressions in immediates, data initializers, DUP counts, constant symbol offsets, `.stack`, and static `OFFSET symbol + constant`.

Not implemented in this milestone:
- No TEXTEQU, text substitution, macros, recursive/forward equates, or extended expression operators.

Deferred or future owner:
- Extended operators are Milestone 29; nested DUP is Milestone 30.

Important assumptions:
- Equates are compile-time numeric constants, not addressable data symbols.

Tests or verification noted:
- Equate definitions, expression contexts, unsupported expression forms, OFFSET-equate rejection, and source-run JSON.

Regression watch:
- Do not allow `OFFSET` on numeric equates.

### Milestone 29 - Extended Constant Expressions

Implemented:
- Compile-time operators `*`, `/`, `MOD`, `SHL`, `SHR`, `AND`, `OR`, `XOR`, `NOT`, `HIGH`, `LOW`, `HIGHWORD`, and `LOWWORD`.
- Operator precedence/associativity and diagnostics for division/mod by zero and unsupported/overflow cases.

Not implemented in this milestone:
- No runtime bitwise/shift instructions, nested DUP, control flow, stack, Irvine32, or broader expression compatibility.

Deferred or future owner:
- Runtime bitwise/shift instruction groups are later phases; nested DUP is next.

Important assumptions:
- Expression folding applies only in constant contexts.

Tests or verification noted:
- Operators, precedence, extraction operators, data/offset contexts, equates, errors, and regressions.

Regression watch:
- Do not confuse compile-time `AND`/`SHL` operators with runtime instructions.

### Milestone 30 - Nested DUP and Initializer Expressions

Implemented:
- Recursive nested DUP expansion in data declarations.
- Constant-expression-backed DUP counts and initializer values.
- Correct TYPE/LENGTHOF/SIZEOF metadata after expansion and deterministic zero-fill for `?`.

Not implemented in this milestone:
- No Irvine32, exit, control flow, macros, conditional assembly, new instructions, or broader expression features.

Deferred or future owner:
- Uninitialized-origin byte metadata is refined in later memory-validation phases.

Important assumptions:
- Existing fixed data-image capacity remains authoritative.

Tests or verification noted:
- Nested DUP success, constant counts, mixed initializers, strings/literals, metadata, capacity errors, and source-run behavior.

Regression watch:
- Do not implement macro-like DUP behavior outside declarations.

### Milestone 31 - Native Diagnostic Rendering Harness

Implemented:
- Native C diagnostic JSON producer.
- Node harness that runs real C source-run JSON through the real browser Simulator Messages formatter.
- Structured diagnostic field checks plus exact rendered message assertions integrated into the aggregate test runner.

Not implemented in this milestone:
- No language/runtime/UI feature behavior added.

Deferred or future owner:
- Every new user-visible diagnostic path should add rendered Simulator Messages coverage.

Important assumptions:
- The harness verifies formatter behavior but not fresh Wasm artifacts unless rebuilt.

Tests or verification noted:
- Native producer smoke test and Node diagnostic rendering golden tests.

Regression watch:
- Do not rely only on native internal status checks for user-visible diagnostics.

### Milestone 32 - Memory Layout Policy Object

Implemented:
- C99 layout-policy module representing fixed educational layout through a named policy object.
- Policy-based VM memory initialization and compatibility wrappers.
- Centralized layout defaults with no user-visible behavior change.

Not implemented in this milestone:
- No automatic sizing, randomized layout, UI controls, object-bounds diagnostics, stack instructions, heap allocation, or layout JSON exposure.

Deferred or future owner:
- Automatic sizing, heap/stack sizing, and randomization are Milestones 33-35.

Important assumptions:
- Fixed educational layout remains byte-for-byte default compatible.

Tests or verification noted:
- Layout-policy tests, default fixed-layout compatibility, and anti-hardcoding/static checks.

Regression watch:
- Do not change default layout behavior in infrastructure phases.

### Milestone 33 - Automatic Deterministic Region Sizing

Implemented:
- `VM_LAYOUT_MODE_AUTOMATIC` and deterministic size computation from code/data/const/heap/stack metadata.
- Alignment, overflow checks, per-region maxima, total reservation limits, resource-limit diagnostics, and `.CONST`/`.DATA?` behavior preservation.

Not implemented in this milestone:
- No randomized layout, UI controls, object-bounds validation, stack instructions, heap allocation routines, Irvine32, or new syntax/instructions.

Deferred or future owner:
- Stack/heap size metadata and randomized layout follow.

Important assumptions:
- Automatic mode is test/internal selectable only in this phase; fixed layout remains default.

Tests or verification noted:
- Automatic layout tests, resource-limit diagnostics, no post-load growth, and rendered Simulator Messages coverage.

Regression watch:
- Do not expose or default to automatic layout without a later UI/settings phase.

### Milestone 34 - Stack and Heap Size Metadata for Layout

Implemented:
- `.stack` metadata and configured heap-size requests affect automatic deterministic layout sizing.
- Validation against layout-policy limits and resource-limit diagnostics with source spans.

Not implemented in this milestone:
- No push/pop/call/ret/leave, stack frames, heap allocation API, UI controls, randomized layout, object bounds, new syntax, or instructions.

Deferred or future owner:
- Runtime stack behavior and heap APIs are later phases.

Important assumptions:
- `.stack` changes capacity metadata only, not ESP.

Tests or verification noted:
- Automatic layout stack/heap sizing, defaults, expressions, resource limits, fixed-layout preservation.

Regression watch:
- Do not initialize/move ESP as part of layout metadata.

### Milestone 35 - Seeded and Fresh Randomized Memory Layout

Implemented:
- Seeded and fresh randomized layout modes with deterministic placement for a seed and generated seed reporting.
- Randomized region bases, guard gaps, non-overlap, alignment, limits, and relocation of symbolic addresses/IR operands.
- Fixed layout remains default; randomized modes are internal/test-only.

Not implemented in this milestone:
- No browser UI selector, URL seed persistence, object allocation map, object-bounds diagnostics, stack instructions, heap API, Irvine32, or debugger UI.

Deferred or future owner:
- Object map and validation modes follow in Milestones 36-40; UI controls later.

Important assumptions:
- Literal numeric addresses do not relocate; symbolic OFFSET operands do.

Tests or verification noted:
- Seed reproducibility, different seeds, fresh seed metadata, symbolic relocation, fixed default preservation.

Regression watch:
- Do not relocate hardcoded numeric addresses as if they were symbols.

### Milestone 35A - OPTION CASEMAP and User Symbol Case Policy Correction

Implemented:
- Default user-symbol policy is CASEMAP:ALL / ASCII-folded case-insensitive matching.
- `OPTION CASEMAP:ALL` and `OPTION CASEMAP:NONE` are supported; `NOTPUBLIC` is recognized but unsupported; invalid values use invalid-option-value.
- Source-order policy, exact/folded lookup rules, ambiguous-symbol diagnostics, policy-change warning, and no retroactive re-keying.
- Instructions/registers/directives/operators/data types/PTR names/virtual includes/Irvine32 names remain case-insensitive under every CASEMAP mode.

Not implemented in this milestone:
- No object map/provenance work, macro behavior, NOTPUBLIC semantics, PUBLIC/EXTERN/linker behavior, control flow, stack, Irvine32 routines, or new runtime instructions.

Deferred or future owner:
- Future user-symbol categories must follow the same active policy when implemented.

Important assumptions:
- ASCII folding only; no locale/Unicode case mapping.

Tests or verification noted:
- Default lookup, CASEMAP:ALL, CASEMAP:NONE, duplicates, equates, operators, policy-change warnings, ambiguous folded lookup, NOTPUBLIC, invalid values, and rendered diagnostics.

Regression watch:
- Do not regress to case-sensitive user symbols by default. Do not reject CASEMAP:ALL.

### Milestone 36 - Declared Object Allocation Map

Implemented:
- Parser-side object map for `.data`, `.DATA?`, and `.CONST` declarations.
- Entries store symbol name, section, final selected-layout address/range, size, element metadata, signedness/type, permissions, source location/span, and initialization-origin placeholder.
- Lookup/classification helpers for address ranges across fixed, automatic, and randomized layouts.

Not implemented in this milestone:
- No object-bounds warnings/errors, provenance tracking, uninitialized-read diagnostics, or UI memory visualization changes.

Deferred or future owner:
- Warning and strict modes are Milestones 37-38; uninitialized metadata/read modes are 39-40.

Important assumptions:
- Each declaration becomes one owning object after DUP expansion; adjacent declarations remain separate.

Tests or verification noted:
- Scalars, arrays, nested DUP, `.DATA?`, `.CONST`, adjacent objects, zero-size skipping, randomized layout, and classification cases.

Regression watch:
- Do not make the object map itself enforce bounds before warning/strict modes are active.

### Milestone 37 - Allocated-Object Warning Mode

Implemented:
- Opt-in allocated-object warning validation mode using the object map.
- Warnings for valid-region but outside-object accesses, partial object-boundary overlaps, and spans across adjacent declared objects.
- Default region-only behavior preserved; lower-level memory diagnostics take precedence; warnings are non-fatal.

Not implemented in this milestone:
- No strict object-bounds errors, provenance, uninitialized-read diagnostics, UI setting controls, worker toggle, or debugger visualization.

Deferred or future owner:
- Strict mode follows in Milestone 38; UI settings later.

Important assumptions:
- Access wholly inside another declared object is valid and should not warn.

Tests or verification noted:
- Warning mode source-run JSON, rendered messages, valid object access, outside object access, partial/spanning access, and diagnostic precedence.

Regression watch:
- Do not confuse object-bounds warning with provenance validation.

### Milestone 38 - Allocated-Object Strict Mode

Implemented:
- Opt-in allocated-object strict validation mode.
- Fatal `object-bounds-violation` runtime diagnostics for accesses inside valid memory regions but outside declared object bounds.
- Default region-only behavior and lower-level diagnostic precedence preserved.

Not implemented in this milestone:
- No provenance tracking, uninitialized-read diagnostics, UI settings controls, new syntax/instructions, or memory visualization UI.

Deferred or future owner:
- Provenance and UI controls remain future; uninitialized modes are Milestones 39-40.

Important assumptions:
- Strict object bounds still allow accesses wholly inside another declared object.

Tests or verification noted:
- Strict mode valid/invalid access, cross-object spans, computed addresses, `.CONST` precedence, source-run JSON, and rendered messages.

Regression watch:
- Do not change default mode to strict.

### Milestone 39 - Uninitialized-Origin Metadata and Write Tracking

Implemented:
- Byte-level initialized/uninitialized-origin metadata for `.data`, `.DATA?`, `.CONST`, explicit initializers, `?`, nested DUP(?), and mixed declarations.
- Successful program writes mark covered bytes initialized; failed writes do not; partial writes update only written bytes.
- Test-only metadata export and object-map summary counts.

Not implemented in this milestone:
- No uninitialized-read warning/strict diagnostics, UI display/toggle, provenance tracking, or register taint.

Deferred or future owner:
- Read validation modes are Milestone 40.

Important assumptions:
- Parser/data layout owns initial byte origin; mutable state owns runtime write mask.

Tests or verification noted:
- Scalar ?, nested DUP(?), `.DATA?`, partial/full writes, failed writes, no-taint copy rule, selected/randomized layout metadata.

Regression watch:
- Do not warn on reads in default mode yet.

### Milestone 40 - Uninitialized-Read Warning and Strict Modes

Implemented:
- Opt-in warning and strict modes for reads from uninitialized-origin bytes not yet written by the simulated program.
- Byte-level multi-byte read validation; warning mode continues; strict mode stops with `uninitialized-read`.
- Read-modify-write checks occur before write-back initialization; default mode remains warning-free and zero-filled.

Not implemented in this milestone:
- No UI toggle, provenance modes, new instruction groups, Irvine32 work, or change to normal served-site defaults.

Deferred or future owner:
- UI controls and provenance diagnostics remain future.

Important assumptions:
- One diagnostic per memory-read range is enough.

Tests or verification noted:
- Warning/strict modes, partial initialization, RMW paths, precedence over lower-level diagnostics, source-run JSON, and rendered messages.

Regression watch:
- Do not make uninitialized-read warnings default.

### Milestone 41 - Virtual Irvine32 Symbol Registry

Implemented:
- `INCLUDE Irvine32.inc` records virtual include activation.
- Parser-owned registry classifies known Irvine32 names as supported metadata, planned routines, unsupported routines, Windows/API/external names, or unknown.
- Known Irvine32 names in currently recognized executable forms can produce `unsupported-irvine32-routine`; JSON exposes virtual include metadata.

Not implemented in this milestone:
- No CALL, RET, executable exit, routine bodies, Program Console output/input, Windows API execution, linking, host includes, or stack behavior.

Deferred or future owner:
- Milestone 42 implements `exit`; CALL/RET/Irvine32 routines are later.

Important assumptions:
- The registry lives in the parser until runtime dispatch exists.

Tests or verification noted:
- Virtual include metadata, classification, unsupported routines, Macros.inc no-op, unknown names, and diagnostics.

Regression watch:
- Do not treat registry metadata as executable Irvine32 runtime.

### Milestone 42 - Irvine32 `exit` Virtual Terminator

Implemented:
- `exit` recognized only when `INCLUDE Irvine32.inc` is active.
- Zero-operand virtual terminator lowers to IR/VM termination, stops execution successfully, skips later instructions, and preserves registers/flags/memory/Program Console.
- Without include, `exit` reports `unknown-instruction`; with operands, `invalid-instruction-operands`.

Not implemented in this milestone:
- No CALL, RET, `call ExitProcess`, Windows API behavior, stack behavior, other Irvine32 routine bodies, Program Console I/O, or linker/include loading.

Deferred or future owner:
- Next canonical phase is Phase 43: INC and DEC, after repository verification.

Important assumptions:
- `exit` matching is case-insensitive and independent of CASEMAP user-symbol policy.

Tests or verification noted:
- Source-run success, post-exit skip behavior, no-include diagnostic, operand diagnostic, registry interaction, UI metadata, and rendered messages.

Regression watch:
- Do not infer full Irvine32 or Windows termination behavior from `exit`.



## 7. Cross-cutting behavior maps

### 7.1 CASEMAP and user-defined symbol policy

Current canonical behavior:

- Parser starts in `CASEMAP:ALL` behavior.
- Default user-defined symbols are case-insensitive using ASCII folding.
- `OPTION CASEMAP:ALL` is supported and explicitly selects folded lookup from that point forward.
- `OPTION CASEMAP:NONE` is supported and selects exact-case lookup from that point forward.
- `OPTION CASEMAP:NOTPUBLIC` is recognized but unsupported because public/external linkage semantics are not modeled.
- Other CASEMAP values are invalid.
- Supported CASEMAP policy changes are accepted but produce `casemap-policy-changed` warnings when the policy actually changes after an earlier supported CASEMAP directive.
- Warning-only programs may still execute.
- Any assembly error prevents execution.

Critical non-regression examples:

```asm
.DATA?
buf DWORD ?

.code
main PROC
    mov eax, OFFSET bUF
    mov DWORD PTR [eax], 77
    mov ebx, DWORD PTR [eax]
main ENDP
END main
```

Default mode must succeed and leave EBX = 77.

```asm
OPTION CASEMAP:NONE

.DATA?
buf DWORD ?

.code
main PROC
    mov eax, OFFSET bUF
main ENDP
END main
```

Exact-case mode must produce `unknown-symbol` for `bUF`.

```asm
OPTION CASEMAP:ALL

.DATA?
buf DWORD ?
bUF DWORD ?

OPTION CASEMAP:NONE

.code
main PROC
    mov eax, OFFSET bUF
main ENDP
END main
```

If recovery continues, this may produce:

- `duplicate-symbol` on the second declaration;
- `casemap-policy-changed` warning;
- `unknown-symbol` on `OFFSET bUF`.

That sequence is intentional and not contradictory.

### 7.2 Data sections

`.data`:

- writable initialized data;
- supports integer declarations, aliases, strings/character literals, DUP, nested DUP, and `?` metadata.

`.DATA?`:

- writable deterministic zero-filled storage;
- must retain uninitialized-origin metadata;
- must reject initialized declarations;
- reads/writes allowed by default;
- uninitialized-read diagnostics are opt-in validation modes only.

`.CONST`:

- initialized read-only data;
- write protection enforced through final effective address range;
- obvious writes receive static diagnostics where practical;
- computed/indirect/partial-overlap writes must fail through central checked memory helpers;
- failed writes must not produce successful memory-change rows.

### 7.3 QWORD/SQWORD boundary

Implemented:

- QWORD/SQWORD declarations and metadata.
- TYPE/LENGTHOF/SIZEOF on QWORD/SQWORD symbols.
- QWORD/SQWORD initializers within data layout.
- QWORD/SQWORD PTR recognition as width forms.

Deferred:

- Executable QWORD/SQWORD memory operations in MASM32 Educational Mode.
- Extended 32-bit Mode support for 64-bit execution.

Regression watch:

- Do not silently truncate executable QWORD/SQWORD operations.
- Do not describe QWORD/SQWORD declaration support as full 64-bit execution support.

### 7.4 Memory operand and width rules

Implemented memory support includes:

- direct symbols;
- constant byte offsets;
- bracketed symbol offsets;
- PTR overrides;
- signed PTR aliases;
- register-indirect forms with all 32-bit GPR bases;
- symbol-plus-register byte-offset forms;
- global width resolver for current memory-capable instructions.

Rules:

- Memory width must be explicit or inferable.
- MASM-invalid ambiguous memory/immediate forms must produce `ambiguous-memory-width` or equivalent invalid-instruction diagnostics.
- Ambiguous memory-width diagnostics should not be worded as "unsupported for now".

Deferred:

- scaled-index addressing;
- full expression-backed memory operands;
- full LEA behavior until its phase;
- stack-frame locals and parameter addressing until procedure/stack phases.

### 7.5 Layout modes

Implemented:

- fixed educational layout;
- automatic deterministic layout;
- stack/heap metadata for automatic sizing;
- seeded randomized layout;
- fresh randomized layout;
- symbolic relocation for selected layout.

Current default:

- fixed educational layout remains default browser/source-run behavior unless a test/internal configuration selects another mode.

Deferred:

- browser UI layout selector;
- URL/share-state seed persistence;
- layout setting persistence;
- user-facing layout metadata display.

### 7.6 Object-map and memory validation modes

Implemented:

- declared object allocation map;
- allocated-object warning mode;
- allocated-object strict mode;
- uninitialized-origin metadata and write tracking;
- uninitialized-read warning mode;
- uninitialized-read strict mode.

Defaults:

- region-only memory validation remains default;
- object-bounds and uninitialized-read modes are opt-in;
- warning-only modes continue execution;
- strict modes stop execution with runtime diagnostics.

Not implemented:

- provenance tracking;
- register taint tracking;
- UI toggles for validation modes;
- object/provenance visualization.

### 7.7 Irvine32 state

Implemented:

- virtual include recognition for `INCLUDE Irvine32.inc`;
- parser-owned registry/classification of known Irvine32-related names;
- `INCLUDE Macros.inc` accepted as virtual no-op;
- executable `exit` virtual terminator only when Irvine32 include is active.

Not implemented yet:

- CALL and RET;
- stack runtime;
- real `ExitProcess`;
- WriteString, WriteChar, Crlf, WriteInt, ReadInt, ReadString, ReadChar, and other Irvine32 routines;
- Program Console output/input routines;
- Windows API behavior;
- host include loading or linking.

## 8. Current diagnostic model

Diagnostics have structured machine-readable fields and rendered browser text. Important stable codes and categories include:

- `unsupported-feature`
- `unsupported-option`
- `invalid-option-value`
- `unsupported-include`
- `unsupported-model`
- `unknown-symbol`
- `duplicate-symbol`
- `ambiguous-symbol`
- `ambiguous-memory-width`
- `invalid-instruction-operands`
- `unknown-instruction`
- `runtime-error`
- `object-bounds-violation`
- `uninitialized-read`
- `resource-limit-exceeded`
- `casemap-policy-changed` as a warning
- unaligned-access warnings

Diagnostic rules:

- Preserve source line, column, byte offset, and span length.
- For runtime diagnostics without a source location, use explicit null/absent source metadata according to existing JSON conventions.
- Warning-only programs execute.
- Any assembly error prevents execution.
- Runtime strict-mode errors stop execution.
- Lower-level memory diagnostics take precedence over object/uninitialized validations.

## 9. Explicitly not implemented yet but planned later

This is not exhaustive through Phase 244, but it captures the major remaining work families.

Runtime instruction families:

- INC/DEC (next canonical phase, Phase 43).
- Runtime AND/OR/XOR, NOT, SHL/SAL, SHR, SAR, ROL, ROR.
- LEA.
- MUL/IMUL/DIV/IDIV forms.
- CMP forms.
- Direct JMP and conditional jumps.
- CALL/RET/LEAVE/RET imm16.

Procedure and stack behavior:

- call depth limit;
- root procedure termination semantics;
- stack pointer initialization/runtime semantics;
- PROC metadata attributes;
- PROC USES parsing and save/restore;
- LOCAL declarations and stack-frame allocation/lifetime;
- PROTO and INVOKE behavior;
- ADDR operator for INVOKE.

Console and Irvine32:

- Program Console buffer limits and serialization;
- Crlf, WriteChar, WriteString, WriteInt, WriteDec, WriteHex, WriteBin;
- ReadChar, ReadInt, ReadString;
- input blocking/continuation behavior;
- additional Irvine32 routine bodies.

UI and tooling:

- CodeMirror 6 editor integration;
- source highlighting;
- diagnostic markers;
- debugger stepping;
- register/flags/memory/stack UI;
- breakpoints;
- layout/validation settings controls;
- URL sharing and persistence.

Language/data features:

- STRUCT, UNION, RECORD;
- TYPEDEF and aliases;
- selected macro compatibility;
- high-level MASM flow directives;
- broader expression features as scheduled;
- additional data types such as REAL4/REAL8/REAL10/TBYTE/FWORD if scheduled.

## 10. Explicit non-goals

Do not implement or imply these without a major project-scope change:

- native x86 binary execution;
- real `ml.exe` or `ml64.exe` compatibility;
- full MASM macro system in v1;
- full x64 MASM or Windows x64 ABI;
- PE loading;
- real object-file linking;
- Windows API execution;
- DLL imports;
- GUI API simulation;
- threads;
- hardware/paging/privilege/interrupt simulation;
- browser or host filesystem access from simulated programs;
- network access from simulated programs;
- arbitrary JavaScript execution from simulated programs.

## 11. Regression watchlist for future assistants

Preserve these facts unless the user explicitly asks to change the spec/guide and implementation together:

- User-defined symbols are case-insensitive by default.
- `OPTION CASEMAP:ALL` is supported and selects default folded lookup.
- `OPTION CASEMAP:NONE` affects user-defined symbols only.
- Instructions, registers, directives, operators, data types, PTR width names, virtual include names, and recognized Irvine32 routine names remain case-insensitive under all CASEMAP modes.
- `OPTION CASEMAP:NOTPUBLIC` is recognized but unsupported.
- `.DATA?` is deterministic zero-filled but uninitialized-origin tracked.
- `.CONST` write protection is address-range/permission based through central memory writes.
- QWORD/SQWORD declarations and metadata are supported; executable QWORD/SQWORD memory operations remain deferred.
- Default memory layout remains fixed educational layout.
- Automatic/randomized layouts are not default user-facing modes yet.
- Object-bounds warning/strict modes are opt-in.
- Uninitialized-read warning/strict modes are opt-in.
- Access wholly inside another declared object is valid under object-bounds modes; provenance is not implemented.
- Program Console and Simulator Messages are separate streams.
- Warning-only programs may execute; assembly-error programs must not execute.
- Native diagnostic JSON plus Node formatter harness is required for user-visible diagnostics.
- `exit` is the only implemented executable Irvine32-like behavior and only with `INCLUDE Irvine32.inc`.
- `call ExitProcess` is not supported Windows API behavior.
- `INCLUDE Irvine32.inc` and `INCLUDE Macros.inc` are virtual includes, not host file reads.

## 12. Recommended future implementation workflow

For every future milestone implementation:

1. Read `docs/FULL_IMPLEMENTATION_SPEC.md` and `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`.
2. Verify repository state and latest completed milestone.
3. Summarize exact milestone requirements.
4. List assumptions in the requested format.
5. Ask only blocking questions.
6. Create a test plan before writing code.
7. Implement only that milestone.
8. Add Doxygen documentation for new public/internal entities.
9. Add tests for success, error, edge, regression, and rendered-message paths.
10. Run relevant tests and report exact commands/results.
11. Provide user-visible manual test programs when applicable.
12. Review for stale code/comments and supported-syntax documentation drift.

## 13. New-chat handoff checklist

When starting a fresh chat, provide the new assistant:

- the current canonical spec and guide;
- this audit report;
- the latest repository archive;
- the latest completed milestone number;
- the next requested task;
- the rule that repository state must be verified before implementing.

The next assistant should be told explicitly that the project is verified through Milestone 42 in the uploaded archive, and that the next canonical phase appears to be Phase 43, but it must verify that state before making changes.

## 14. Appendix: evidence inputs used

Project files and reports consulted from the uploaded materials:

- `Latest_repository_state_milestone_42.zip`
- `docs/FULL_IMPLEMENTATION_SPEC.md` inside the archive
- `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md` inside the archive
- `docs/SUPPORTED_SYNTAX.md` inside the archive
- `docs/TESTING_GUIDE.md` inside the archive
- `MASM32 Simulator Milestone 0.txt`
- `Milestone 2 Flags Model.txt`
- `Simulated Memory Regions.txt`
- `MASM32 Simulator Milestones.txt`
- `MASM32 Simulator Setup.txt`
- `MASM32 Simulator Planning.txt`
- `MASM32 Educational Simulator.txt`
- `Milestone 18.txt` through `Milestone 23.txt`
- `Milestone 25.txt` through `Milestone 31.txt`
- `Milestone 33.txt`
- `Milestone 35A.txt`
- `Milestone 38.txt` through `Milestone 40.txt`
- `MASM32 Simulator Implementation.txt`
- `MASM32 Simulator Implementation Plan.txt`
- prior in-chat milestone report excerpts for reports not present as distinct local files

External rationale references for the report format:

- Microsoft Azure Architecture Decision Record guidance: https://learn.microsoft.com/en-us/azure/well-architected/architect-role/architecture-decision-record
- Lost in the Middle: How Language Models Use Long Contexts: https://arxiv.org/abs/2307.03172
