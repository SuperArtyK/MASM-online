# Historical Project Artifacts

This directory contains historical audit, handoff, and report material for the Online MASM32 Educational Simulator project.

This README is an archive index only. It does not define simulator behavior, phase scope, accepted syntax, rejected syntax, diagnostics, runtime behavior, current-status phase labels, or acceptance criteria.

Current source-of-truth files:

```text
docs/FULL_IMPLEMENTATION_SPEC.md
docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md
docs/SUPPORTED_SYNTAX.md
```

Current implementation work must start with the canonical spec and guide, then the current supported-syntax reference, then the latest repository archive or checkout, then the latest accepted milestone report.

## Directory layout

```text
docs/history/
  Curated audit and handoff reports.

docs/history/reports/
  Standalone milestone reports.
```

## Authority model

Historical audit and handoff reports are navigation aids. They may explain why earlier choices were made, which assumptions were used, which risks were known, and which behaviors were implemented at the time of the report.

Historical audit and handoff reports do not override:

- the current canonical full implementation specification;
- the current canonical incremental implementation guide;
- the current supported-syntax reference;
- the latest accepted repository state;
- the latest accepted milestone report.

If a historical report uses wording such as "current behavior," "current status," "next phase," or "future work," read that wording relative to the milestone named in that report, not relative to the latest repository state.

Curated audit/handoff reports may lag behind standalone milestone reports. When they lag, use the latest standalone milestone report, canonical spec, canonical guide, current supported-syntax reference, repository archive or checkout, and tests to determine current status. Do not treat the absence of a current curated audit/handoff report as evidence that later milestones are incomplete.

When the latest curated audit/handoff report is older than the latest standalone milestone report, future assistants must state that fact explicitly during audits. The older curated report remains useful for provenance and stale-assumption review, but it is not the latest project-level status authority. The current canonical spec and guide, current supported-syntax reference, latest repository state, and latest standalone milestone report are the active evidence set.

If a curated audit/handoff report and a later standalone milestone report disagree, do not automatically treat either historical file as authoritative over the canonical spec and guide. Use the contradiction as an audit finding, then resolve it against the current canonical spec, current canonical guide, current supported-syntax reference, repository state, and implemented tests.

## Milestone report coverage

Standalone milestone reports are preserved from the point where report files are available in this repository history.

If this archive contains standalone reports only from Milestone 42 onward, then Milestones 0-41 do not have individual original report files in this archive.

Historical coverage for missing early standalone reports comes from:

- completed phase definitions in `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`;
- accumulated milestone history in `docs/MILESTONE_HISTORY.md`, where available;
- curated audit or handoff reports in this directory;
- later milestone reports that summarize inherited behavior or regression-watch notes.

Do not fabricate original-looking milestone reports for missing early milestones.

A reconstructed historical summary may be added later, but it must be labeled clearly as reconstructed. It must not be presented as an original milestone report written at the time.

Prefer one clearly labeled reconstructed summary over many reconstructed per-milestone files unless the user explicitly requests per-milestone archival reconstruction.

## Recommended reading order for future assistants

For current implementation work:

1. Read `docs/FULL_IMPLEMENTATION_SPEC.md`.
2. Read `docs/INCREMENTAL_IMPLEMENTATION_GUIDE.md`.
3. Read `docs/SUPPORTED_SYNTAX.md`.
4. Inspect the latest repository archive or checkout.
5. Read the latest milestone report in `docs/history/reports/`.
6. Use older audit/handoff reports only for provenance, stale-assumption detection, or regression-risk review.

For project archaeology or stale-assumption audits:

1. Start with the current spec and guide to establish current authority.
2. Read the latest milestone report.
3. Read older milestone reports as historical evidence.
4. Read curated handoff/audit reports for context.
5. Treat contradictions between older reports and current canonical files as audit findings unless the current spec/guide deliberately preserves the older behavior.

## Rules for adding future historical files

When adding a future milestone report, place it under:

```text
docs/history/reports/
```

When adding a future curated audit or handoff report, place it under:

```text
docs/history/
```

Do not store new historical reports in the repository root unless the user explicitly requests that location.

Do not use historical files as current-status surfaces. Current status belongs in concise active documents and runtime-visible surfaces such as:

- `README.md`;
- `docs/SUPPORTED_SYNTAX.md`;
- `docs/BUILDING_AND_DEVELOPMENT.md`;
- browser status text;
- worker/protocol status text;
- source-run metadata;
- the latest milestone report.

Historical-file organization is documentation organization only. It must not advance the runtime/source-run MASM behavior phase and must not change parser behavior, source-run behavior, VM behavior, diagnostics, accepted syntax, rejected syntax, runtime metadata, or current-status phase labels.
